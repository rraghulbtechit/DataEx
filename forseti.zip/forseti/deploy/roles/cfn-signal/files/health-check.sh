#!/bin/bash

exec > /tmp/health-check.log
exec 2>&1

# Log for Kibana, $1 = ERROR Level, $2 = Log Message
log () {
    echo -n '{'
    echo -n "\"source_application\":\"${source_application}\","
    echo -n "\"environment\":\"${environment}\","
    echo -n "\"stack\":\"${STACK}\","
    echo -n "\"cloudservice\":\"${cloudservice}\","
    echo -n "\"service\":\"${service}\","
    echo -n "\"Application\":\"${Application}\","
    echo -n "\"Name\":\"${Name}\","
    echo -n "\"timestamp\":\"$(date +"%Y-%m-%dT%H:%M:%S.%3N+00:00")\","
    echo -n "\"@version\":1,"
    echo -n "\"message\":\"$2\","
    echo -n "\"level\":\"$1\","
    echo -n "\"ec2\":{"
        echo -n "\"instance\":\"$InstanceId\","
        echo -n "\"ami\":\"$AMI\","
        echo -n "\"region\":\"$AWS_DEFAULT_REGION\","
        echo -n "\"type\":\"$InstanceType\","
        echo -n "\"az\":\"$AvailabilityZone\""
        echo -n "}"
    echo '}'
}

# Load identifiable variables in case the load-aws-metadata script fails.
InstanceId=$(/usr/bin/curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | jq .instanceId | sed 's/\"//g')
privateIp=$(/usr/bin/curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | jq .privateIp | sed 's/\"//g')
source_application="cfn-signal-health-check"

# Load AWS metadata as environment variables
. /usr/bin/load-aws-metadata.sh
while [ -z "${STACK}" ] || [ -z "${INSTANCE}" ] || [ -z "${AWS_DEFAULT_REGION}" ]
do
    log "ERROR" "Failed to load AWS metadata for instanceId $InstanceId ($privateIp). Retrying."
    . /usr/bin/load-aws-metadata.sh
    sleep 10
done

# Set logging name for this script
source_application="$service-$Application-cfn-signal-health-check"

# Print variables used to call cfn-signal
log "INFO" "Starting health check for ${source_application}"

while true
do
    up=$(curl -s -k http://localhost:8080/health | jq .status | sed 's/\"//g')

    if [ "$up" = "UP" ]
    then
        log "INFO" "up"
        touch /tmp/cfn-signal-sending-success
        /usr/local/bin/cfn-signal --success true --stack ${STACK} --resource ${INSTANCE} --region ${AWS_DEFAULT_REGION}
        success=$?
        log "INFO" "cfn-signal exit code ${success}"
        touch /tmp/cfn-signal-success
        exit 0
    fi

    log "INFO" "not up"
    sleep 10 # seconds
done

touch /tmp/ran-health-check-sh
log "INFO" "Finished health check for ${source_application}"