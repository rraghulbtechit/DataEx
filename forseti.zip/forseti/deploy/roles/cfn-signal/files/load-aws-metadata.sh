#!/bin/bash

# From https://gist.githubusercontent.com/brillozon/188fde35d270382851c6/raw/574d0c2c23da93a7698740b38c29f8334a39e284/load-aws-metadata.sh
# See for an explanation: http://brillozon.com/devops/2015/04/29/making-aws-metadata-available-on-ec2/

# Get the region
export AWS_DEFAULT_REGION=$(/usr/bin/curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | jq .region | sed 's/\"//g')

datadir=awsdata
instancedatafile=$datadir/instancedata.json
stackdatafile=$datadir/stack-metadata.json

# Put all the extracted data into one directory.
/bin/mkdir -p $datadir

curl="/usr/bin/curl --retry 3 --silent --show-error --fail"
instance_data_url=http://169.254.169.254/latest

# Use the HTTP reflection interface to determine which instance we are.
instanceid=$($curl $instance_data_url/meta-data/instance-id | /usr/bin/tee $datadir/instanceid)

# Use the AWS CLI to grab the instance data.
/usr/bin/aws ec2 describe-instances |
  /usr/bin/jq '.Reservations[].Instances[] | select(.InstanceId == "'$instanceid'")' |
  /usr/bin/tee $instancedatafile > /tmp/aws.txt

# This is the pattern to extract data from the instance data JSON file.
  stackid=$(/usr/bin/jq '.Tags[] | select(.Key == "aws:cloudformation:stack-id")   | .Value' $instancedatafile | sed 's/\"//g')
stackname=$(/usr/bin/jq '.Tags[] | select(.Key == "aws:cloudformation:stack-name") | .Value' $instancedatafile | sed 's/\"//g')
logicalid=$(/usr/bin/jq '.Tags[] | select(.Key == "aws:cloudformation:logical-id") | .Value' $instancedatafile | sed 's/\"//g')

export environment=$(/usr/bin/jq '.Tags[] | select(.Key == "environment") | .Value' $instancedatafile | sed 's/\"//g')
export service=$(/usr/bin/jq '.Tags[] | select(.Key == "service") | .Value' $instancedatafile | sed 's/\"//g')
export cloudservice=$(/usr/bin/jq '.Tags[] | select(.Key == "cloudservice") | .Value' $instancedatafile | sed 's/\"//g')
export Application=$(/usr/bin/jq '.Tags[] | select(.Key == "Application") | .Value' $instancedatafile | sed 's/\"//g')
export Name=$(/usr/bin/jq '.Tags[] | select(.Key == "Name") | .Value' $instancedatafile | sed 's/\"//g')
export InstanceId=$(/usr/bin/jq '.InstanceId' $instancedatafile | sed 's/\"//g')
export AMI=$(/usr/bin/jq '.ImageId' $instancedatafile | sed 's/\"//g')
export InstanceType=$(/usr/bin/jq '.InstanceType' $instancedatafile | sed 's/\"//g')
export AvailabilityZone=$(/usr/bin/jq '.Placement.AvailabilityZone' $instancedatafile | sed 's/\"//g')

# Need the evals to remove the extra quoting.  This assumes that the
# region is the availability zone with the last character truncated.
zlen=$(eval /bin/echo $zone | /usr/bin/wc -c)
rend=$(expr $zlen - 2)

# Store off the region as it comes in handy and is not in the metadata.
/bin/echo $region > $datadir/region

# Print variables
/bin/echo
/bin/echo "Region: $AWS_DEFAULT_REGION"
/bin/echo "Stack: $stackname"
/bin/echo "Instance: $logicalid"
/bin/echo

# cfn-get-metadata needs to run priviledged.
#sudo /usr/local/bin/cfn-get-metadata -s $(eval echo $stackid) -r $(eval echo $logicalid) --region=$region | /usr/bin/tee $stackdatafile > /dev/null

# set env variables
export STACK=${stackname}
export INSTANCE=${logicalid}

touch /tmp/ran-load-aws-metadata-sh