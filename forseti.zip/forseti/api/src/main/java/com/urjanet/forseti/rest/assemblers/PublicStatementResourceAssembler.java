package com.urjanet.forseti.rest.assemblers;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.rest.resources.PublicStatementResource;

// Based on:
// https://www.jiwhiz.com/blogs/Design_and_Build_RESTful_API_with_Spring_HATEOAS

@Component
public class PublicStatementResourceAssembler implements ResourceAssembler<Statement, PublicStatementResource>{

	@Override
	public PublicStatementResource toResource(Statement stmt) {

		PublicStatementResource resource = new PublicStatementResource();
		BeanUtils.copyProperties(stmt, resource);
		return resource;
	}

}
