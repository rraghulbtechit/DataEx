package com.urjanet.forseti.rest.v1;

import static com.urjanet.forseti.rest.Permissions.READ_PDR;
import static com.urjanet.forseti.rest.Permissions.RW_PDR;

import java.util.Date;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.forseti.helpers.DTOUtils;
import com.urjanet.forseti.helpers.PDRCallbackCompletedDTO;
import com.urjanet.forseti.helpers.PDRCancellationDTO;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.helpers.PDRSubmittedAcquisitionDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.rest.assemblers.PrivatePDRResourceAssembler;
import com.urjanet.forseti.rest.assemblers.PrivateStatementResourceAssembler;
import com.urjanet.forseti.rest.resources.PrivatePDRResource;
import com.urjanet.forseti.rest.resources.PrivateStatementResource;
import com.urjanet.forseti.service.PDRService;

@RestController
@RequestMapping(value = "/v1/private/pdrs", produces = {"application/hal+json", "application/json"})
@Validated
public class PrivatePDRController {

	private static final Logger LOG = LoggerFactory.getLogger(PrivatePDRController.class);
	
	@Autowired
	private PDRService pdrService;

	@Autowired
	private PrivatePDRResourceAssembler pdrResourceAssembler;

	@Autowired
	private PrivateStatementResourceAssembler statementResourceAssembler;

	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> getPDR(@PathVariable long pdrId) {

		PDR pdr = pdrService.findByID(pdrId);
		return new ResponseEntity<>(pdrResourceAssembler.toResource(pdr),
				HttpStatus.OK);

	}

	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivatePDRResource>> pdrCollection(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler,
			@RequestParam(required = false) String jobId) {

		Page<PDR> page = null;
		if (StringUtils.isEmpty(jobId)) {
			page = pdrService.findAll(pageable);
		} else {
			page = pdrService.findAllByBifrostId(pageable, jobId);
		}

		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);		
	}

	@RequestMapping(method = RequestMethod.GET, value="/findpdrstotimeout")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivatePDRResource>> findPDRsToTimeout(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler) {

		Page<PDR> page = pdrService.findPDRsToTimeout(pageable);
		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/findpdrstocallback")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivatePDRResource>> findPDRsToCallback(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler) {

		Page<PDR> page = pdrService.findPDRsToCallback(pageable);
		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);

	}
	
	@RequestMapping(method = RequestMethod.GET, value="/findnewpdrstosubmitacquisition")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivatePDRResource>> findNewPDRsToSubmitAcquisition(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler) {

		Page<PDR> page = pdrService.findNewPDRsToSubmitAcquisition(pageable);
		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, value="/findpendingpdrstosubmitacquisition")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR  + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivatePDRResource>> findPendingPDRsToSubmitAcquisition(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler) {

		Page<PDR> page = pdrService.findPendingPDRsToSubmitAcquisition(pageable);
		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/result")
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> pdrResult(@PathVariable long pdrId,
			@Valid @RequestBody PDRCompletionDTO resource) {

		PDR pdr = pdrService.findByID(pdrId);
		
		// Only update the database if completionStatus is null
		if (pdr.getCompletionStatus() == null) {
			pdr.setCompletionStatus(PDRCompletionStatus.valueOf(resource
					.getCompletionStatus()));
			pdr.setCompletionStatusDetail(resource.getCompletionStatusDetail());
			pdr.setCompletedAt(resource.getCompletedAt());
	
			// Process statements
			Set<Statement> statements = pdr.getStatements();
			if (resource.getStatements() != null) {
				resource.getStatements().forEach((dto) -> statements.add(DTOUtils.statementFromDTO(dto, pdrId)));
				pdr.setStatements(statements);
			}
	
			pdrService.registerCompletion(pdr);
		} else {
			LOG.warn("PDR {} will not be updated since its completion status "
					+ "has already been set to {}",
					pdr.getId(), pdr.getCompletionStatus().name());
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}	
	
	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}/statements")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PrivateStatementResource>> getStatements(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Statement> assembler,
			@PathVariable long pdrId) {

		Page<Statement> page = pdrService
				.findStatementsByPDRID(pageable, pdrId);
		return new ResponseEntity<>(assembler.toResource(page,
				statementResourceAssembler), HttpStatus.OK);

	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{pdrId}")
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public ResponseEntity<Void> delete(@PathVariable long pdrId) {
		pdrService.delete(pdrId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/cancel")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> cancelPDR(@PathVariable long pdrId,
			@Valid @RequestBody PDRCancellationDTO resource) {
		
		if (resource.getStatus().equals(PDRCompletionStatus.CANCELLED.name())) {
			PDR pdr = pdrService.findByID(pdrId);
			PDR cancelledPDR = pdrService.cancelAcquisition(pdr);
			return new ResponseEntity<>(
					pdrResourceAssembler.toResource(cancelledPDR),
					HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/timeout")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> timeoutPDR(@PathVariable long pdrId) {
		
		PDR pdr = pdrService.findByID(pdrId);
		if (pdr.getCompletionStatus() != null) {
			return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
		}
		PDR timedOutPDR = pdrService.timeout(pdr);
		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(timedOutPDR),
				HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/triggercallback")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> triggerCallback(@PathVariable long pdrId) {
		
		PDR pdr = pdrService.findByID(pdrId);
		PDR triggeredPDR = pdrService.triggerCallback(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(triggeredPDR),
				HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/triggerretry")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> triggerRetry(@PathVariable long pdrId) {

		PDR pdr = pdrService.findByID(pdrId);
		PDR triggeredPDR = pdrService.triggerRetry(pdr);

		return new ResponseEntity<>(pdrResourceAssembler.toResource(triggeredPDR), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, 
			value = "/{pdrId}/updatestatustoinvalidcredentials")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> updateStatusToInvalidCredentials(@PathVariable long pdrId) {

		PDR pdr = pdrService.findByID(pdrId);
		PDR updatedPDR = pdrService.changeStatusFields(pdr, 
				PDRCompletionStatus.FAILURE, PDRCompletionStatusDetail.CREDENTIALS_INVALID);

		if (updatedPDR == null)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		else 	
			return new ResponseEntity<>(pdrResourceAssembler.toResource(updatedPDR), 
					HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/callbackcompleted")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public ResponseEntity<PrivatePDRResource> callbackCompleted(
			@PathVariable long pdrId,
			@Valid @RequestBody PDRCallbackCompletedDTO resource) {

		PDR pdr = pdrService.findByID(pdrId);
		pdr.setCompletionCallbackResult(resource.getCompletionCallbackResult());
		PDR updatedPDR = pdrService.save(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(updatedPDR),
				HttpStatus.OK);
	}
	
	
	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}/submittedacquisition")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public ResponseEntity<PrivatePDRResource> submittedAcquisition(
			@PathVariable long pdrId,
			@Valid @RequestBody PDRSubmittedAcquisitionDTO resource) {

		PDR pdr = pdrService.findByID(pdrId);
		pdr.setBifrostId(resource.getBifrostId());
		pdr.setStartedAt(new Date());
		PDR updatedPDR = pdrService.save(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(updatedPDR),
				HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}/sourcetree")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<String> viewSourceTree(@PathVariable long pdrId) throws Exception {
		
		// The line below will throw an EntityNotFoundException if a matching
		// Statement is not found
		PDR pdr = pdrService.findByID(pdrId);
		String json = pdrService.getSourceTree(pdr);
		return new ResponseEntity<>(json, HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}/logs")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<byte[]> viewLogs(@PathVariable long pdrId) throws Exception {
		
		// The line below will throw an EntityNotFoundException if a matching
		// Statement is not found
		PDR pdr = pdrService.findByID(pdrId);
		return pdrService.getLogs(pdr);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}/statements/{statementId}/source")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<byte[]> viewStatementSource(@PathVariable long pdrId, @PathVariable long statementId) {
		
		// The line below will throw an EntityNotFoundException if a matching
		// Statement is not found
		Statement statement = pdrService.findStatementByID(statementId);
		PDR pdr = pdrService.findByID(pdrId);
		return pdrService.getStatementSource(pdr, statement);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/{pdrId}/replay")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivatePDRResource> pdrReplay(@PathVariable long pdrId) {

		PDR pdr = pdrService.findByID(pdrId);
		pdrService.replay(pdr, null);

		return new ResponseEntity<>(pdrResourceAssembler.toResource(pdr), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/{pdrId}/statements/{statementId}/replay")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PrivateStatementResource> statementReplay(@PathVariable long pdrId, 
			@PathVariable long statementId) {

		// The line below will throw an EntityNotFoundException if a matching
		// Statement is not found
		Statement statement = pdrService.findStatementByID(statementId);
		PDR pdr = pdrService.findByID(pdrId);
		pdrService.replay(pdr, statement);
		
		return new ResponseEntity<>(statementResourceAssembler.toResource(statement), HttpStatus.OK);
	}
	
}
