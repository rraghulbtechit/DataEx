package com.urjanet.forseti.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.filter.AbstractRequestLoggingFilter;

import com.urjanet.heimdallr.resourceserver.common.UserContext;

public class DetailedRequestLoggingFilter extends AbstractRequestLoggingFilter {
	
	public DetailedRequestLoggingFilter() {
		super();
	}
	
	@Override
	protected void beforeRequest(HttpServletRequest request, String message) {

		// Don't log health checks (like "unknown entering GET http://172.25.20.154:8080/health")
		if (! request.getRequestURL().toString().contains("health")) {
			
			StopWatch stopwatch = new StopWatch();
			logger.info(getUsername(request) + " entering " + request.getMethod()
				+ " " + request.getRequestURL().toString());
			stopwatch.start();
			request.setAttribute("stopwatch", stopwatch);
		}
	}

	@Override
	protected void afterRequest(HttpServletRequest request, String message) {

		// Don't log "org.springframework.security.web.authentication.WebAuthenticationDetails@3bcc: RemoteIpAddress: 172.26.41.198; SessionId: null exiting GET http://172.26.25.180:8080/health (2ms)"
		if (! request.getRequestURL().toString().contains("health")) {
			
			StopWatch stopwatch = (StopWatch) request.getAttribute("stopwatch");
			stopwatch.stop();
			logger.info(getUsername(request) + " exiting " + request.getMethod()
				+ " " + request.getRequestURL().toString() + " ("
				+ stopwatch.getTotalTimeMillis() + "ms)");
		}
	}

	private String getUsername(HttpServletRequest request) {

		String username = "unknown";

		Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();

		if (authentication != null) {
			if (authentication.getDetails() != null && authentication.getDetails() instanceof UserContext) {
				UserContext ctx = (UserContext) authentication.getDetails();
					username = String.format("[%s:%s]",
							ctx.getOrganizationName(), ctx.getName());

			} else if (authentication.getDetails() != null ) {
				username = authentication.getDetails().toString();
			}
		}

		return username;

	}

}
