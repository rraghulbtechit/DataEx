package com.urjanet.forseti.rest;

public class Permissions {

	private static final String PREFIX = "PERM_FSTI_";

	public static final String ACCESS_PRIVATE_API = PREFIX + "ACCESS_PRIVATE";
	
	public static final String ACCESS_SIMULATOR_API = PREFIX + "ACCESS_SIMULATOR";

	public static final String READ_INDUSTRY = PREFIX + "READ_INDUSTRY";

	public static final String RW_INDUSTRY = PREFIX + "RW_INDUSTRY";
	
	public static final String READ_PROVIDER = PREFIX + "READ_PROVIDER";

	public static final String RW_PROVIDER = PREFIX + "RW_PROVIDER";
	
	public static final String READ_PDR = PREFIX + "READ_PDR";
	
	public static final String RW_PDR = PREFIX + "RW_PDR";

//	public static final String DELETE_PDR = PREFIX + "DELETE_PDR";
//	
//	public static final String CANCEL_PDR = PREFIX + "CANCEL_PDR";
//	
//	public static final String EXPIRE_PDR = PREFIX + "EXPIRE_PDR";
//	
//	public static final String RECORD_PDR_CALLBACK = PREFIX + "RECORD_PDR_CALLBACK";
//	
//	public static final String RECORD_PDR_EXTRACTION_RESULT = PREFIX + "RECORD_PDR_EXTRACTION_RESULT";

}
