package com.urjanet.forseti.rest.assemblers;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.rest.resources.PublicPDRResource;
import com.urjanet.forseti.rest.v1.PublicPDRController;
import com.urjanet.forseti.rest.v1.PublicProviderController;
import com.urjanet.forseti.util.AssemblerUtils;
import com.urjanet.forseti.util.SecurityUtils;

@Component
public class PublicPDRResourceAssembler implements
		ResourceAssembler<PDR, PublicPDRResource> {

	@Override
	public PublicPDRResource toResource(PDR pdr) {

		PublicPDRResource resource = new PublicPDRResource();

		BeanUtils.copyProperties(pdr, resource);

		if (pdr.getCompletionStatus() != null) {
			resource.setCompletionStatus(pdr.getCompletionStatus().name());
		}
		
		if (pdr.getStatements()!=null && pdr.getStatements().size()>0) {
			resource.setStatementCount(pdr.getStatements().size());
		} else {
			resource.setStatementCount(0);
		}

		resource.add(linkTo(
				methodOn(PublicPDRController.class).getPDR(pdr.getId()))
				.withSelfRel());

		if (AssemblerUtils.displayStatementsLink(pdr)) {
			resource.add(linkTo(
				methodOn(PublicPDRController.class).getStatements(null, null,
						pdr.getId())).withRel("statements"));
		}

	    if (SecurityUtils.authorizedToViewProviders()) { 
			resource.add(linkTo(
					methodOn(PublicProviderController.class).getProvider(
							pdr.getProviderId())).withRel("provider"));
	    }

	    if (AssemblerUtils.displayCancelLink(pdr)) {
			resource.add(linkTo(
					methodOn(PublicPDRController.class)
							.cancelPDR(pdr.getId(), null)).withRel("cancel"));
		}

		return resource;
	}

}
