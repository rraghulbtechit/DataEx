package com.urjanet.forseti.rest.assemblers;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.core.EmbeddedWrapper;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.rest.resources.PrivatePDRResource;
import com.urjanet.forseti.rest.v1.PrivatePDRController;
import com.urjanet.forseti.rest.v1.PublicProviderController;
import com.urjanet.forseti.util.AssemblerUtils;
import com.urjanet.forseti.util.SecurityUtils;

@Component
public class PrivatePDRResourceAssembler implements
		ResourceAssembler<PDR, PrivatePDRResource> {
	
	@Autowired
	private UserResourceAssembler userResourceAssembler;

	@Override
	public PrivatePDRResource toResource(PDR pdr) {
		
		PrivatePDRResource resource = new PrivatePDRResource();
		
		BeanUtils.copyProperties(pdr, resource);
		if (pdr.getCompletionStatus() != null) {
			resource.setCompletionStatus(pdr.getCompletionStatus().name());
		}

		if (pdr.getStatements()!=null && pdr.getStatements().size()>0) {
			resource.setStatementCount(pdr.getStatements().size());
		} else {
			resource.setStatementCount(0);
		}
		
		resource.add(linkTo(
				methodOn(PrivatePDRController.class).getPDR(pdr.getId()))
				.withSelfRel());

		if (AssemblerUtils.displayStatementsLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).getStatements(null, null,
						pdr.getId())).withRel("statements"));
		}

		resource.add(linkTo(
				methodOn(PrivatePDRController.class).pdrResult(pdr.getId(),
						null)).withRel("complete"));

		if (AssemblerUtils.displayCancelLink(pdr)) {
			resource.add(linkTo(
					methodOn(PrivatePDRController.class).cancelPDR(pdr.getId(),
							null)).withRel("cancel"));
		}
		
		if (AssemblerUtils.displayTimeoutLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).timeoutPDR(pdr.getId()))
				.withRel("timeout"));
		}
		
		if (AssemblerUtils.displayTriggerCallbackLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).triggerCallback(pdr.getId()))
				.withRel("triggercallback"));
		}
		
		if (AssemblerUtils.displayTriggerRetryLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).triggerRetry(pdr.getId()))
				.withRel("triggerretry"));
        }

		if (AssemblerUtils.displayUpdateStatusToInvalidCredentialsLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).updateStatusToInvalidCredentials
				(pdr.getId())).withRel("updatestatustoinvalidcredentials"));
        }
		
		if (AssemblerUtils.displayCallbackLink(pdr)) {
            resource.add(linkTo(
				methodOn(PrivatePDRController.class).callbackCompleted(pdr.getId(), null))
				.withRel("callbackcompleted"));
        }
		
		if (AssemblerUtils.displaySubmitAcqLink(pdr)) {
			resource.add(linkTo(
				methodOn(PrivatePDRController.class).submittedAcquisition(pdr.getId(), null))
				.withRel("submittedacquisition"));
		}

		if (SecurityUtils.authorizedToViewProviders()) {
			resource.add(linkTo(
					methodOn(PublicProviderController.class).getProvider(
							pdr.getProviderId())).withRel("provider"));
		}
		
		try {
			if (! StringUtils.isEmpty(pdr.getSourceTree()) )
					resource.add(linkTo(methodOn(PrivatePDRController.class)
							.viewSourceTree(pdr.getId()))
							.withRel("viewsourcetree"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if (! StringUtils.isEmpty(pdr.getLogsId()) )
				resource.add(linkTo(methodOn(PrivatePDRController.class)
						.viewLogs(pdr.getId()))
						.withRel("viewlogs"));
		}  catch (Exception e) {
			e.printStackTrace();
		}
		
		if (AssemblerUtils.displayReplayLink(pdr))
			resource.add(linkTo(
					methodOn(PrivatePDRController.class).pdrReplay(pdr.getId()))
					.withRel("replay"));
		
		//embed the owner's fields into the PDR data
		List<EmbeddedWrapper> embeddables = new ArrayList<>();
		
		if(null != pdr.getOwner()){
			embeddables.add(userResourceAssembler.toEmbeddable(pdr.getOwner()));	
	        	resource.setEmbeddeds(new Resources<>(embeddables));
		}
					
		return resource;
	}

}
