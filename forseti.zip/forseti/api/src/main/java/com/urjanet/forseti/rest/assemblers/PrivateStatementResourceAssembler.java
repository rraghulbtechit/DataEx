package com.urjanet.forseti.rest.assemblers;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.rest.resources.PrivateStatementResource;
import com.urjanet.forseti.rest.v1.PrivatePDRController;
import com.urjanet.forseti.util.AssemblerUtils;

// Based on:
// https://www.jiwhiz.com/blogs/Design_and_Build_RESTful_API_with_Spring_HATEOAS

@Component
public class PrivateStatementResourceAssembler implements ResourceAssembler<Statement, PrivateStatementResource>{

	@Override
	public PrivateStatementResource toResource(Statement stmt) {

		PrivateStatementResource resource = new PrivateStatementResource();
		BeanUtils.copyProperties(stmt, resource);
		
		if (! StringUtils.isEmpty(stmt.getSourceIds()))
			resource.add(linkTo(methodOn(PrivatePDRController.class)
					.viewStatementSource(stmt.getPdrID(), stmt.getId()))
					.withRel("viewstatementsource"));
		
		if (AssemblerUtils.displayReplayLink(stmt))
			resource.add(linkTo(methodOn(PrivatePDRController.class)
					.statementReplay(stmt.getPdrID(), stmt.getId()))
					.withRel("replay"));
			
		return resource;
	}

}
