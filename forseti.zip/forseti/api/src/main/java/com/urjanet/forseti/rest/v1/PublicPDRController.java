package com.urjanet.forseti.rest.v1;

import static com.urjanet.forseti.rest.Permissions.READ_PDR;
import static com.urjanet.forseti.rest.Permissions.RW_PDR;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.forseti.helpers.PDRCancellationDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.rest.assemblers.PublicPDRResourceAssembler;
import com.urjanet.forseti.rest.assemblers.PublicStatementResourceAssembler;
import com.urjanet.forseti.rest.resources.PublicPDRResource;
import com.urjanet.forseti.rest.resources.PublicStatementResource;
import com.urjanet.forseti.service.PDRService;
import com.urjanet.forseti.util.SecurityUtils;

@RestController
@RequestMapping(value = "/v1/public/pdrs", produces = {"application/hal+json", "application/json"})
@Validated
public class PublicPDRController {


	@Autowired
	private PDRService pdrService;

	@Autowired
	private PublicPDRResourceAssembler pdrResourceAssembler;

	@Autowired
	private PublicStatementResourceAssembler statementResourceAssembler;	
	
	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<PublicPDRResource> getPDR(@PathVariable long pdrId) {
		
		PDR pdr = pdrService.findByIdAndOrganizationId(pdrId,SecurityUtils.getOrganizationId());
		
		return new ResponseEntity<>(pdrResourceAssembler.toResource(pdr),
				HttpStatus.OK);

	}

	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PublicPDRResource>> pdrCollection(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<PDR> assembler,
			@RequestParam(required = false) String correlationId) {

		Page<PDR> page = null;
		if (StringUtils.isEmpty(correlationId)) {
			page = pdrService.findAllByOrganizationId(pageable, SecurityUtils.getOrganizationId());
		} else {
			page = pdrService.findAllByCorrelationIdAndOrganizationId(pageable, correlationId, SecurityUtils.getOrganizationId());
		}
		return new ResponseEntity<>(assembler.toResource(page,
				pdrResourceAssembler), HttpStatus.OK);
	}


	@RequestMapping(method = RequestMethod.PATCH, value = "/{pdrId}")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PublicPDRResource> cancelPDR(@PathVariable long pdrId,
			@Valid @RequestBody PDRCancellationDTO resource) {
	
		if (resource.getStatus().equals(PDRCompletionStatus.CANCELLED.name())) {
			PDR pdr = pdrService.findByIdAndOrganizationId(pdrId, SecurityUtils.getOrganizationId());
			PDR cancelledPDR = pdrService.cancelAcquisition(pdr);
			return new ResponseEntity<>(
					pdrResourceAssembler.toResource(cancelledPDR),
					HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{pdrId}/statements")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PDR + "','" + RW_PDR + "')")
	public HttpEntity<PagedResources<PublicStatementResource>> getStatements(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Statement> assembler,
			@PathVariable long pdrId) {
		
		@SuppressWarnings("unused")
		PDR pdr = pdrService.findByIdAndOrganizationId(pdrId,SecurityUtils.getOrganizationId());
		// The above line will throw an EntityNotFoundException if a matching
		// PDR is not found
		Page<Statement> page = pdrService
				.findStatementsByPDRID(pageable, pdrId);
		return new ResponseEntity<>(assembler.toResource(page,
				statementResourceAssembler), HttpStatus.OK);

	}

}
