package com.urjanet.forseti.rest;

import com.urjanet.heimdallr.resourceserver.security.CustomAuthenticationEntryPoint;
import com.urjanet.heimdallr.resourceserver.security.StatelessAuthenticationFilter;
import com.urjanet.heimdallr.resourceserver.security.TokenGetAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@EnableWebSecurity
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class JWTWebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Value("${DANGER_SECURITY_DISABLED:false}")
	boolean securityDisabled = false;

	@Autowired
	private TokenGetAuthenticationService tokenGetAuthenticationService;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		        .httpBasic().disable()
		        .csrf().disable()
		        .exceptionHandling()
		        // Return 401 (instead of 403) when an anonymous user tries to access a protected resource
		        .authenticationEntryPoint(new CustomAuthenticationEntryPoint())
		
		        .and()
		        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		        .and()
		        .servletApi()
		        .and()
		        .headers().cacheControl()
		        .and()
		        .and()
		        .authorizeRequests()

				//allow access to Actuator metrics
                .antMatchers("/health").permitAll()
                .antMatchers("/dump").hasAuthority("PERM_MONITORING")
                .antMatchers("/configprops").hasAuthority("PERM_MONITORING")
                .antMatchers("/env").hasAuthority("PERM_MONITORING")
                .antMatchers("/mappings").hasAuthority("PERM_MONITORING")
                .antMatchers("/trace").hasAuthority("PERM_MONITORING")
                .antMatchers("/health/**").hasAuthority("PERM_MONITORING")
                .antMatchers("/metrics/**").hasAuthority("PERM_MONITORING")

				// allow access for CORS pre-flight requests
				.antMatchers(HttpMethod.OPTIONS, "/v1/**").permitAll()
				
				// must have the role ACCESS_PRIVATE_API to hit the private API
				.antMatchers("/v1/private/**")
				.hasAuthority(Permissions.ACCESS_PRIVATE_API)
				.antMatchers("/v1/public/simulator/**")
				.hasAuthority(Permissions.ACCESS_SIMULATOR_API)
				// all other request need to be authenticated
				.anyRequest()
				.authenticated()

				.and()

				// custom Token based authentication based on the header
				// previously given to the client
				.addFilterBefore(
						new StatelessAuthenticationFilter(
								tokenGetAuthenticationService),
						UsernamePasswordAuthenticationFilter.class)
				.addFilterAfter(new DetailedRequestLoggingFilter(),
						StatelessAuthenticationFilter.class);

	}
}