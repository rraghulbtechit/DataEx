package com.urjanet.forseti.util;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;

public class SecurityUtils {

	// Get organizationId for the owner of this PDR
	public static long getOrganizationId() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getOrganizationId();
	}
	
	// Get organizationName for the owner of this PDR
	public static String getOrganizationName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getOrganizationName();
	}
	
	//  Get the list of Roles for this user
	public static Collection<String> getUserRoles() {
	    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    if (authentication == null || !authentication.isAuthenticated()) {
	      return null;
	    }
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getRoles();
	}
	
	// Get the list of GrantedAuthorities for this user
	public static Collection<? extends GrantedAuthority> getGrantedAuthorities() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getAuthorities();
	}
	
	// Returns boolean based on user's permission to view Providers
	public static Boolean authorizedToViewProviders() {
		Collection<? extends GrantedAuthority> authorities = getGrantedAuthorities();
		for (GrantedAuthority authority : authorities) {
		     if (authority.getAuthority().equals(Permissions.READ_PROVIDER) ||
		    		 authority.getAuthority().equals(Permissions.RW_PROVIDER)) {
		    	 return true;
		  }
		}
		return false;
	}
	
	// Returns boolean based on user's permission to view Industries
	public static Boolean authorizedToViewIndustries() {
		Collection<? extends GrantedAuthority> authorities = getGrantedAuthorities();
		for (GrantedAuthority authority : authorities) {
		     if (authority.getAuthority().equals(Permissions.READ_INDUSTRY) ||
		    		 authority.getAuthority().equals(Permissions.RW_INDUSTRY)) {
		    	 return true;
		  }
		}
		return false;
	}

	// Get the username for the owner of this PDR
	public static String getUsername() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getUsername();
	}
	
	// Get the id for the owner of this PDR
	public static long getUserID() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	    UserContext ctx = (UserContext) authentication.getDetails();
	    return ctx.getId();
	}
	
}
