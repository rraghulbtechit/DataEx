package com.urjanet.forseti.rest.v1;

import static com.urjanet.forseti.rest.Permissions.READ_INDUSTRY;
import static com.urjanet.forseti.rest.Permissions.READ_PROVIDER;
import static com.urjanet.forseti.rest.Permissions.RW_INDUSTRY;
import static com.urjanet.forseti.rest.Permissions.RW_PDR;
import static com.urjanet.forseti.rest.Permissions.RW_PROVIDER;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.forseti.helpers.DTOUtils;
import com.urjanet.forseti.helpers.PDRDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.User;
import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.model.nondatabase.Provider;
import com.urjanet.forseti.rest.assemblers.PublicIndustryResourceAssembler;
import com.urjanet.forseti.rest.assemblers.PublicPDRResourceAssembler;
import com.urjanet.forseti.rest.assemblers.PublicProviderResourceAssembler;
import com.urjanet.forseti.rest.resources.PublicIndustryResource;
import com.urjanet.forseti.rest.resources.PublicPDRResource;
import com.urjanet.forseti.rest.resources.PublicProviderResource;
import com.urjanet.forseti.service.PDRService;
import com.urjanet.forseti.service.PIBService;
import com.urjanet.forseti.service.UserService;
import com.urjanet.forseti.util.SecurityUtils;

/* Dev Note: 
 * 
 * Forseti API 1.1+
 * The public PDS API exposes endpoints to only read provider and industry data.
 * 		Forseti uses PIB to retrieve this information.
 * The private PDS APIs that used to support PATCH/POST to create/update/delete 
 * have been deprecated in earlier releases, and deleted from this release.
 */
@RestController
@RequestMapping(value = "/v1/public/providers", produces = {"application/hal+json", "application/json"})
@Validated
public class PublicProviderController {

	private static final Logger log = LoggerFactory.getLogger(PublicProviderController.class);
	
	private final Tracer tracer;
	
	@Autowired
	private PIBService pibService;
	
	@Autowired
	private PDRService pdrService;
	
	@Autowired
	private UserService userService;

	@Autowired
	private PublicProviderResourceAssembler providerResourceAssembler;

	@Autowired
	private PublicIndustryResourceAssembler industryResourceAssembler;

	@Autowired
	private PublicPDRResourceAssembler pdrResourceAssembler;

	@Autowired
	public PublicProviderController(Tracer tracer) {
		this.tracer = tracer;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{providerId}")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PROVIDER + "','" + RW_PROVIDER + "')")
	public HttpEntity<PublicProviderResource> getProvider(
			@PathVariable String providerId) {

		Provider provider = pibService.findProviderByID(providerId, SecurityUtils.getUserRoles());
		return new ResponseEntity<>(
				providerResourceAssembler.toResource(provider), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PROVIDER + "','" + RW_PROVIDER + "')")
	public HttpEntity<PagedResources<PublicProviderResource>> providerCollection(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Provider> assembler,
			@RequestParam(required = false) String name) throws Exception {

		Page<Provider> page = null;
		if (StringUtils.isEmpty(name)) {
			page = pibService.findAllProviders(pageable, SecurityUtils.getUserRoles());
		} else {
			page = pibService.findAllProvidersWithNameContaining(pageable, name, SecurityUtils.getUserRoles());
		}

		return new ResponseEntity<>(assembler.toResource(page,
				providerResourceAssembler), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/{providerId}/pdrs")
	@ResponseBody
	@PreAuthorize("hasAuthority('" + RW_PDR + "')")
	public HttpEntity<PublicPDRResource> schedulePDR(
			@PathVariable String providerId, @Valid @RequestBody PDRDTO resource) {
		
		// Check that the supplied provider is available in PiB
		Provider provider = pibService.findProviderByID(providerId, SecurityUtils.getUserRoles());
		if (provider == null) {
			throw new EntityNotFoundException(String.format("Provider %s is invalid", providerId));
		}
		
		// Validate all required fields required to login for statement retrieval
		validateRequiredFields(provider, resource);
		
		PDR pdr = new PDR();
		pdr.setCorrelationId(resource.getCorrelationId());
		pdr.setProviderId(providerId);
		pdr.setProviderName(provider.getName());
		
		/* Note on Normalized AccountNumber:
		 * 	Forseti-api deals only with the value as sent in the request - 
		 * 		if the AccountNumber is raw and un-normalized, that is what is stored
		 * 		in the forseti database and passed along to bifrost.
		 * 	Bifrost normalizes the AccountNumber when it receives the request, and
		 * 		this normalized value is used internally within bifrost workflow components.
		 */
		pdr.setAccountNumber(resource.getAccountNumber());
		pdr.setUsername(resource.getUsername());
		pdr.setPassword(resource.getPassword());
		pdr.setPassword2(resource.getPassword2());
		pdr.setPeriodStart(DTOUtils.toISODate(resource.getPeriodStart()));
		pdr.setPeriodEnd(DTOUtils.toISODate(resource.getPeriodEnd()));
		pdr.setOrganizationName(SecurityUtils.getOrganizationName());
		
		// Calculate the expiration date
		LocalDateTime t = new LocalDateTime();
		t = t.plusSeconds(resource.getTimeout());
		pdr.setExpirationDate(t.toDate());
		pdr.setCompletionCallbackUrl(resource.getCompletionCallbackUrl());
		pdr.setSource("API");
		
		// Set the organization who owns the PDR
		pdr.setOrganizationId(SecurityUtils.getOrganizationId());
		
		//set trace id  using currentSpan
		String traceId = Span.idToHex(tracer.getCurrentSpan().getTraceId());
		pdr.setTraceId(traceId);

		
		
		
		//when creating new PDR, create user record if
		//it doesn't already exist
		User owner = userService.createUserIfNotFound(SecurityUtils.getUserID()
				, SecurityUtils.getUsername()
				, SecurityUtils.getOrganizationId()
				, SecurityUtils.getOrganizationName());
		
		pdr.setOwner(owner);
		
		log.info("Saving PDR with traceId={}", traceId);

		PDR createdPDR = pdrService.requestAcquisition(pdr);
		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(createdPDR), HttpStatus.ACCEPTED);
	}

	// Validate all required fields required to login for statement retrieval
	private void validateRequiredFields(Provider provider, PDRDTO resource) {
		if (provider.getRequiredFields()!=null)
			for (String field: provider.getRequiredFields()) {
				if ( (field.equalsIgnoreCase("username") && StringUtils.isBlank(resource.getUsername()))
						|| (field.equalsIgnoreCase("password") && StringUtils.isBlank(resource.getPassword()))
						|| (field.equalsIgnoreCase("password2") && StringUtils.isBlank(resource.getPassword2())) ) {
					
					throw new IllegalArgumentException(field + " is a required field");
				}
			}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{providerId}/industries")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_INDUSTRY + "','" + RW_INDUSTRY + "')")
	public HttpEntity<PagedResources<PublicIndustryResource>> providerIndustries(@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Industry> assembler, @PathVariable String providerId) throws Exception {

		Page<Industry> page = pibService.findIndustriesForProvider(pageable, providerId, SecurityUtils.getUserRoles());

		return new ResponseEntity<>(assembler.toResource(page,
				industryResourceAssembler), HttpStatus.OK);
	}
}
