package com.urjanet.forseti.rest.assemblers;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityLinks;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.RelProvider;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.User;
import com.urjanet.forseti.rest.resources.UserResource;
import com.urjanet.forseti.rest.v1.UserController;


@Component
public class UserResourceAssembler extends EmbeddableResourceAssemblerSupport<User, UserResource, UserController>{
	
    @Autowired
    public UserResourceAssembler(final EntityLinks entityLinks, 
    		final RelProvider relProvider) {
   	
        super(entityLinks, 
    		relProvider, 
    		UserController.class, 
    		UserResource.class);        
    }
	
	@Override
	public UserResource toResource(User user) {
		UserResource resource = new UserResource();
		BeanUtils.copyProperties(user, resource);
		
		return resource;
	}


	@Override
	public Link linkToSingleResource(User entity) {
        return entityLinks.linkToSingleResource(UserResource.class, 
    		entity.getId());
	}

}
