package com.urjanet.forseti.rest.v1;

public class UserController {

}
