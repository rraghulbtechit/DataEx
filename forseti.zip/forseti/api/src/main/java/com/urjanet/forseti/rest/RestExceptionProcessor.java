package com.urjanet.forseti.rest;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.urjanet.forseti.service.BadRequestException;
import com.urjanet.forseti.service.EntityNotFoundException;
import com.urjanet.forseti.service.PIBServiceException;
@ControllerAdvice
public class RestExceptionProcessor {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	
	@SuppressWarnings("rawtypes")
	@ExceptionHandler(EntityNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ResponseBody
	protected ResponseEntity entityNotFound() {
		return new ResponseEntity(HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler({org.springframework.orm.ObjectOptimisticLockingFailureException.class})
	@ResponseStatus(value = HttpStatus.CONFLICT)
	@ResponseBody
	public ErrorInfo conflict(HttpServletRequest req, Exception ex) {
		log.error("Optimistic Locking Failure Error: " + ex.getMessage());
		String errorMessage = ex.getMessage();
		String errorURL = req.getRequestURL().toString();
		return new ErrorInfo(errorURL, errorMessage);
	}
	
	@ExceptionHandler({MethodArgumentNotValidException.class, 
		DataIntegrityViolationException.class, 
		ConstraintViolationException.class,
		HttpMessageNotReadableException.class,
		IllegalArgumentException.class,
		BadRequestException.class})
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ErrorInfo invalidArgument(HttpServletRequest req, Exception ex) {
		log.error("Invalid Request Error: " + ex.getMessage());
		String errorMessage = ex.getMessage();
		String errorURL = req.getRequestURL().toString();
		return new ErrorInfo(errorURL, errorMessage);
	}
	
	@ExceptionHandler({AccessDeniedException.class})
	@ResponseStatus(value = HttpStatus.FORBIDDEN)
	@ResponseBody
	public ErrorInfo accessDenied(HttpServletRequest req, Exception ex) {
		log.error("Access Denied Error: " + ex.getMessage());
		String errorMessage = ex.getMessage();
		String errorUrl = req.getRequestURL().toString();
		return new ErrorInfo(errorUrl, errorMessage);
	}
	
	@ExceptionHandler( {Exception.class, PIBServiceException.class} )
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ErrorInfo serverError(HttpServletRequest req, Exception ex) {
		log.error("Internal Server Error: " + ex.getMessage(), ex);
		String errorMessage = ex.getMessage();
		String errorURL = req.getRequestURL().toString();
		return new ErrorInfo(errorURL, errorMessage);
	}

	class ErrorInfo {

		private String errorURL;
		private String errorMessage;

		public ErrorInfo(String errorURL, String errorMessage) {
			super();
			this.errorURL = errorURL;
			this.errorMessage = errorMessage;
		}

		public String getErrorURL() {
			return errorURL;
		}

		public void setErrorURL(String errorURL) {
			this.errorURL = errorURL;
		}

		public String getErrorMessage() {
			return errorMessage;
		}

		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}

	}

}
