package com.urjanet.forseti.rest.v1;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.validation.Valid;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.forseti.helpers.DTOUtils;
import com.urjanet.forseti.helpers.PDRDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.model.User;
import com.urjanet.forseti.repository.PDRDAO;
import com.urjanet.forseti.rest.assemblers.PublicPDRResourceAssembler;
import com.urjanet.forseti.rest.resources.PublicPDRResource;
import com.urjanet.forseti.service.UserService;
import com.urjanet.forseti.util.SecurityUtils;

@RestController
@RequestMapping(value = "/v1/public/simulator", produces = {"application/hal+json", "application/json"})
@Validated
public class PublicSimulatorController {

	@Autowired
	private PDRDAO pdrDAO;
	
	@Autowired
	private UserService userService;

	@Autowired
	private PublicPDRResourceAssembler pdrResourceAssembler;
	
	private final String MOCK_PROVIDER_ID = "153a90d3-a41a-11e1-993e-12313d02ea33";	//NewMexicoGasCompany
	
	/*
	 * Simulate a successful PDR
	 * 
	 * @param 	PDRDTO 							resource
	 * 
	 * @return 	HttpEntity<PublicPDRResource>	HtppStatus of 202 plus the newly created PDR
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/success")
	@ResponseBody
	public HttpEntity<PublicPDRResource> success(@Valid @RequestBody PDRDTO resource) {

		PDR pdr = new PDR();
		pdr.setAccountNumber(resource.getAccountNumber());
		pdr.setUsername(resource.getUsername());
		pdr.setPassword(resource.getPassword());
		pdr.setPassword2(resource.getPassword2());
		pdr.setCorrelationId(resource.getCorrelationId());
		pdr.setPeriodStart(DTOUtils.toISODate(resource.getPeriodStart()));
		pdr.setPeriodEnd(DTOUtils.toISODate(resource.getPeriodEnd()));
		// Calculate the expiration date
		LocalDateTime t = new LocalDateTime();
		t = t.plusSeconds(resource.getTimeout());
		pdr.setExpirationDate(t.toDate());
		pdr.setCompletionCallbackUrl(resource.getCompletionCallbackUrl());
		pdr.setSource("Simulator");
		pdr.setBifrostId(UUID.randomUUID().toString());
		pdr.setStartedAt(new Date());
		pdr.setProviderId(MOCK_PROVIDER_ID);
		pdr.setCompletionStatus(PDRCompletionStatus.SUCCESS);
		// Set the organization who owns the PDR
		pdr.setOrganizationId(SecurityUtils.getOrganizationId());
		
		//when creating new PDR, create user record if
		//it doesn't already exist
		User owner = userService.createUserIfNotFound(SecurityUtils.getUserID()
				, SecurityUtils.getUsername()
				, SecurityUtils.getOrganizationId()
				, SecurityUtils.getOrganizationName());
		
		pdr.setOwner(owner);
		
		PDR newPDR =  pdrDAO.save(pdr);
		
		// Fake Statement Data
		int NUM_STMTS = 5;
		Set<Statement> stmts = new HashSet<>();
		for (int i = 0; i < NUM_STMTS; i++) {
			Statement stmt = new Statement();
			stmt.setRecentPayment(new BigDecimal(99.99));
			stmt.setBillingCity("Decatur");
			stmt.setBillingCountry("US");
			stmt.setBillingName("Francisco d’Anconia");
			stmt.setBillingPhone("123-123-1234");
			stmt.setBillingPostalCode("90210");
			stmt.setBillingState("CO");
			stmt.setBillingStreet1("123 Main St");
			stmt.setBillingStreet2("Apt. 123");
			stmt.setRecentPaymentDate(new Date());
			stmt.setPaymentCurrency("USD");
			stmt.setStatementDate(new Date());
			stmt.setPdrID(newPDR.getId());
			stmts.add(stmt);
		}
		pdr.setStatements(stmts);
		// Set the sleuth trace id
		pdr.setTraceId("1");		
		
		newPDR =  pdrDAO.save(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(newPDR), HttpStatus.ACCEPTED);
	}
	
	/*
	 * Simulate a PDR that times out
	 * 
	 * @param 	PDRDTO 				resource
	 * 	
	 * @return 	HttpEntity<PublicPDRResource>	HtppStatus of 202 plus the newly created PDR
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/timeout")
	@ResponseBody
	public HttpEntity<PublicPDRResource> timeout(@Valid @RequestBody PDRDTO resource) {

		PDR pdr = new PDR();
		pdr.setAccountNumber(resource.getAccountNumber());
		pdr.setUsername(resource.getUsername());
		pdr.setPassword(resource.getPassword());
		pdr.setPassword2(resource.getPassword2());
		pdr.setCorrelationId(resource.getCorrelationId());
		pdr.setPeriodStart(DTOUtils.toISODate(resource.getPeriodStart()));
		pdr.setPeriodEnd(DTOUtils.toISODate(resource.getPeriodEnd()));
		// Setting the expirationDate to timeout in 1 second
		LocalDateTime t = new LocalDateTime();
		t = t.plusMillis(1);
		pdr.setExpirationDate(t.toDate());
		pdr.setCompletionCallbackUrl(resource.getCompletionCallbackUrl());
		pdr.setSource("Simulator");
		pdr.setBifrostId(UUID.randomUUID().toString());
		pdr.setStartedAt(new Date());
		pdr.setProviderId(MOCK_PROVIDER_ID);
		// Set the organization who owns the PDR
		pdr.setOrganizationId(SecurityUtils.getOrganizationId());
		// Set the sleuth trace id
		pdr.setTraceId("1");
		
		//when creating new PDR, create user record if
		//it doesn't already exist
		User owner = userService.createUserIfNotFound(SecurityUtils.getUserID()
				, SecurityUtils.getUsername()
				, SecurityUtils.getOrganizationId()
				, SecurityUtils.getOrganizationName());
		
		pdr.setOwner(owner);
		
		PDR newPDR =  pdrDAO.save(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(newPDR), HttpStatus.ACCEPTED);
	}
	
	/*
	 * Simulate a PDR that fails
	 * 
	 * @param 	PDRDTO 				resource
	 * 	
	 * @return 	HttpEntity<PublicPDRResource>	HttpStatus of 202 plus the newly created PDR
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/error")
	@ResponseBody
	public HttpEntity<PublicPDRResource> error(@Valid @RequestBody PDRDTO resource) {

		PDR pdr = new PDR();
		pdr.setAccountNumber(resource.getAccountNumber());
		pdr.setUsername(resource.getUsername());
		pdr.setPassword(resource.getPassword());
		pdr.setPassword2(resource.getPassword2());
		pdr.setCorrelationId(resource.getCorrelationId());
		pdr.setPeriodStart(DTOUtils.toISODate(resource.getPeriodStart()));
		pdr.setPeriodEnd(DTOUtils.toISODate(resource.getPeriodEnd()));
		// Calculate the expiration date
		LocalDateTime t = new LocalDateTime();
		t = t.plusSeconds(resource.getTimeout());
		pdr.setExpirationDate(t.toDate());
		pdr.setCompletionCallbackUrl(resource.getCompletionCallbackUrl());
		pdr.setSource("Simulator");
		pdr.setBifrostId(UUID.randomUUID().toString());
		pdr.setStartedAt(new Date());
		pdr.setProviderId(MOCK_PROVIDER_ID);
		pdr.setCompletionStatus(PDRCompletionStatus.FAILURE);
		// Set the organization who owns the PDR
		pdr.setOrganizationId(SecurityUtils.getOrganizationId());
		// Set the sleuth trace id
		pdr.setTraceId("1");
		
		//when creating new PDR, create user record if
		//it doesn't already exist
		User owner = userService.createUserIfNotFound(SecurityUtils.getUserID()
				, SecurityUtils.getUsername()
				, SecurityUtils.getOrganizationId()
				, SecurityUtils.getOrganizationName());
		
		pdr.setOwner(owner);
		
		PDR newPDR =  pdrDAO.save(pdr);

		return new ResponseEntity<>(
				pdrResourceAssembler.toResource(newPDR), HttpStatus.ACCEPTED);
	}

}
