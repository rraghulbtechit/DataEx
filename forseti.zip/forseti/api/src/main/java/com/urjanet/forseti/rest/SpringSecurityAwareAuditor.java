package com.urjanet.forseti.rest;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.urjanet.heimdallr.resourceserver.common.UserContext;

public class SpringSecurityAwareAuditor implements AuditorAware<Long> {


	  public Long getCurrentAuditor() {
	    
	    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

	    if (authentication == null || !authentication.isAuthenticated()) {
	      return null;
	    }
	    
	    UserContext ctx = (UserContext) authentication.getDetails();
	    
	    //UserContext ctx = (UserContext) authentication.getPrincipal();
	    return ctx.getId();
	    //return Long.parseLong(authentication.getPrincipal().toString());
	  }
	
}
