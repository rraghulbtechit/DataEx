package com.urjanet.forseti.rest.v1;

import static com.urjanet.forseti.rest.Permissions.READ_INDUSTRY;
import static com.urjanet.forseti.rest.Permissions.READ_PROVIDER;
import static com.urjanet.forseti.rest.Permissions.RW_INDUSTRY;
import static com.urjanet.forseti.rest.Permissions.RW_PROVIDER;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.model.nondatabase.Provider;
import com.urjanet.forseti.rest.assemblers.PublicIndustryResourceAssembler;
import com.urjanet.forseti.rest.assemblers.PublicProviderResourceAssembler;
import com.urjanet.forseti.rest.resources.PublicIndustryResource;
import com.urjanet.forseti.rest.resources.PublicProviderResource;
import com.urjanet.forseti.service.PIBService;
import com.urjanet.forseti.util.SecurityUtils;

/* Dev Note: 
 * 
 * Forseti API 1.1+
 * The public PDS API exposes endpoints to only read provider and industry data.
 * 		Forseti uses PIB to retrieve this information.
 * The private PDS APIs that used to support PATCH/POST to create/update/delete 
 * have been deprecated in earlier releases, and deleted from this release.
 */
@RestController
@RequestMapping(value="/v1/public/industries", produces = {"application/hal+json", "application/json"})
public class PublicIndustryController {
	
	@Autowired
	private PIBService pibService;

	@Autowired
	private PublicIndustryResourceAssembler industryResourceAssembler;

	@Autowired
	private PublicProviderResourceAssembler providerResourceAssembler;

	@RequestMapping(method = RequestMethod.GET, value = "/{industryId}")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_INDUSTRY + "','" + RW_INDUSTRY + "')")
	public HttpEntity<PublicIndustryResource> getIndustry(
			@PathVariable String industryId) {

		Industry industry = pibService.findIndustryByID(industryId, SecurityUtils.getUserRoles());
		return new ResponseEntity<>(industryResourceAssembler.toResource(industry), 
									HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_INDUSTRY + "','" + RW_INDUSTRY + "')")
	public HttpEntity<PagedResources<PublicIndustryResource>> industryCollection(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Industry> assembler,
			@RequestParam(required = false) String name) throws Exception {
		
		Page<Industry> page = null;
		
		if (StringUtils.isEmpty(name)) {
			page = pibService.findAllIndustries(pageable, SecurityUtils.getUserRoles());
		} else {
			page = pibService.findAllIndustriesWithNameContaining(pageable,name, SecurityUtils.getUserRoles());
		}

		return new ResponseEntity<>(assembler.toResource(page,
				industryResourceAssembler), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, value="/{industryId}/providers")
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('" + READ_PROVIDER + "','" + RW_PROVIDER + "')")
	public HttpEntity<PagedResources<PublicProviderResource>> getIndustryProviders(
			@PageableDefault Pageable pageable,
			PagedResourcesAssembler<Provider> assembler,
			@PathVariable String industryId) throws Exception {

		Page<Provider> page = pibService.findProvidersForIndustry(pageable, industryId, SecurityUtils.getUserRoles());
		return new ResponseEntity<>(assembler.toResource(page,
				providerResourceAssembler), HttpStatus.OK);
	}
	
	
	
}
