package com.urjanet.forseti.rest.assemblers;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.nondatabase.Provider;
import com.urjanet.forseti.rest.resources.PublicProviderResource;
import com.urjanet.forseti.rest.v1.PublicProviderController;
import com.urjanet.forseti.util.SecurityUtils;

// Based on:
// https://www.jiwhiz.com/blogs/Design_and_Build_RESTful_API_with_Spring_HATEOAS

/* Dev Note: 
 * 
 * Forseti API 1.1+
 * The public PDS API exposes endpoints to only read provider and industry data.
 * 		Forseti uses PIB to retrieve this information.
 * The private PDS APIs that used to support PATCH/POST to create/update/delete 
 * have been deprecated in earlier releases, and deleted from this release.
 */
@Component
public class PublicProviderResourceAssembler implements ResourceAssembler<Provider, PublicProviderResource>{

	@Override
	public PublicProviderResource toResource(Provider p) {

		PublicProviderResource resource = new PublicProviderResource();

		BeanUtils.copyProperties(p, resource);
		
		resource.add(linkTo(methodOn(PublicProviderController.class).getProvider(p.getUuid()))
                .withSelfRel());

		resource.add(linkTo(methodOn(PublicProviderController.class).schedulePDR(p.getUuid(), null))
                .withRel("extract"));

		if (SecurityUtils.authorizedToViewIndustries()) {
			try {
				resource.add(linkTo(methodOn(PublicProviderController.class)
						.providerIndustries(null,null,p.getUuid()))
						.withRel("industries"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return resource;
		
	}

}
