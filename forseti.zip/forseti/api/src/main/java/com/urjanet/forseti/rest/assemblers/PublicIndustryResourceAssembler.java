package com.urjanet.forseti.rest.assemblers;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.BeanUtils;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.rest.resources.PublicIndustryResource;
import com.urjanet.forseti.rest.v1.PublicIndustryController;
import com.urjanet.forseti.util.SecurityUtils;

// Based on:
// https://www.jiwhiz.com/blogs/Design_and_Build_RESTful_API_with_Spring_HATEOAS

/* Dev Note: 
 * 
 * Forseti API 1.1+
 * The public PDS API exposes endpoints to only read provider and industry data.
 * 		Forseti uses PIB to retrieve this information.
 * The private PDS APIs that used to support PATCH/POST to create/update/delete 
 * have been deprecated in earlier releases, and deleted from this release.
 */
@Component
public class PublicIndustryResourceAssembler implements ResourceAssembler<Industry, PublicIndustryResource>{

	@Override
	public PublicIndustryResource toResource(Industry i) {
		
		PublicIndustryResource resource = new PublicIndustryResource();
		
		BeanUtils.copyProperties(i, resource);
		
		resource.add(linkTo(methodOn(PublicIndustryController.class).getIndustry(i.getUuid()))
                .withSelfRel());

		if (SecurityUtils.authorizedToViewProviders()) {
			try {
				resource.add(linkTo(methodOn(PublicIndustryController.class)
						.getIndustryProviders(null,null,i.getUuid()))
						.withRel("providers"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return resource;
	}

}
