package com.urjanet.forseti.rest;

import java.util.List;

import org.springframework.cloud.sleuth.Sampler;
import org.springframework.cloud.sleuth.Span;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.web.HateoasPageableHandlerMethodArgumentResolver;
import org.springframework.hateoas.config.EnableHypermediaSupport;
import org.springframework.hateoas.config.EnableHypermediaSupport.HypermediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Configuration
@EnableHypermediaSupport(type = { HypermediaType.HAL })
@EnableJpaAuditing
public class RestConfiguration extends WebMvcConfigurerAdapter {
	
	public static final int MAX_PAGE_SIZE = 32;

	@Override
	public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
		for (HttpMessageConverter<?> converter : converters) {
			if (converter instanceof MappingJackson2HttpMessageConverter) {
				MappingJackson2HttpMessageConverter jsonMessageConverter = (MappingJackson2HttpMessageConverter) converter;
				ObjectMapper objectMapper = jsonMessageConverter
						.getObjectMapper();
				objectMapper
						.configure(SerializationFeature.INDENT_OUTPUT, true);
				objectMapper
						.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
				//objectMapper.setDateFormat(ISO_DATE_FORMAT);
				break;
			}
		}
	}

	@Override
	public void addArgumentResolvers(
			List<HandlerMethodArgumentResolver> argumentResolvers) {

		// Set a maximum page size for the application
		HateoasPageableHandlerMethodArgumentResolver resolver = new HateoasPageableHandlerMethodArgumentResolver();
		resolver.setMaxPageSize(MAX_PAGE_SIZE);
		argumentResolvers.add(resolver);

		super.addArgumentResolvers(argumentResolvers);

	}

	@Bean
	public AuditorAware<Long> auditorProvider() {
		return new SpringSecurityAwareAuditor();
	}

    @Bean
    public Sampler forsetiSampler() {
    	return new Sampler() {
    		@Override
    		public boolean isSampled(Span span) {
    			//logic to determine whether to trace the request
    			//will likely want to change based on deployment environment
    			//only trace requests that are a POST to /v1/public/providers/{id}/pdrs
    			//for now trace all of them for debugging
    			String name = span.getName();
    			return ((name.matches("http:/v1/public/providers/\\d/pdrs")) && (Math.random() > 0));
    		}
    	};
    }
    
    @Bean
    public RestTemplate pibRestTemplate() {
    	return RestHelper.getRestTemplate();
    }
}
