package com.urjanet.forseti.util;

import org.apache.commons.lang3.StringUtils;

import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.Statement;

public class AssemblerUtils {

	// Returns boolean if timeoutLink can be displayed
	public static Boolean displayTimeoutLink(PDR pdr) {
		return (pdr.getCompletionStatus() == null);
	}
	
	// Returns boolean if cancelLink can be displayed
	public static Boolean displayCancelLink(PDR pdr) {
		return (pdr.getCompletionStatus() == null);
	}
	
	// Returns boolean if triggercallbackLink can be displayed
	public static Boolean displayTriggerCallbackLink(PDR pdr) {
		return (pdr.getCompletionStatus() != null &&
				pdr.getCompletionCallbackUrl() != null);			 
	}
	
	// Returns boolean if triggerretryLink can be displayed
	public static Boolean displayTriggerRetryLink(PDR pdr) {
		return (pdr.getCompletionStatus() != null && 
				pdr.getCompletionStatus().equals(PDRCompletionStatus.PENDING) &&
				StringUtils.isNotBlank(pdr.getBifrostId()));
	}
	
	// Returns boolean if updatestatusLink can be displayed
	public static Boolean displayUpdateStatusToInvalidCredentialsLink(PDR pdr) {
		return (pdr.getCompletionStatus() != null && 
				pdr.getCompletionStatus().equals(PDRCompletionStatus.PENDING) &&
				StringUtils.isNotBlank(pdr.getBifrostId()));
	}
	
	// Returns boolean if callbackcompletedLink can be displayed
	public static Boolean displayCallbackLink(PDR pdr) {
		return (pdr.getCompletionStatus() != null &&
				pdr.getCompletionCallbackUrl() != null &&
				pdr.getCompletionCallbackResult() == null);				
	}
	
	// Returns boolean if submittedacquisitionLink can be displayed
	public static Boolean displaySubmitAcqLink(PDR pdr) {
		return (pdr.getBifrostId() == null &&
				pdr.getCompletionStatus() == null);
	}
	
	// Returns boolean if statementsLink can be displayed
	public static Boolean displayStatementsLink(PDR pdr) {
		return (pdr.getCompletionStatus() != null && 
				pdr.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS) &&
				!pdr.getStatements().isEmpty());
	}
	
	// Returns boolean if pdrReplayLink can be displayed
	public static Boolean displayReplayLink(PDR pdr) {
		// TODO - Additional checks here?  
		return (pdr.getCompletionStatus() != null &&
				pdr.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS) &&
				!pdr.getStatements().isEmpty());
	}
	
	// Returns boolean if statementReplayLink can be displayed
	public static Boolean displayReplayLink(Statement statement) {
		
		return (StringUtils.isNotBlank(statement.getSourceIds()));
	}
}
