#!/bin/bash

aglio -i paymentdataservice-api-documentation.apib -o paymentdataservice-api-documentation.html
