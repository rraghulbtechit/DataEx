--liquibase formatted sql

--changeset amcconnell:18 context:endtoendTest
    
INSERT INTO provider (active, name, bifrost_provider_id, url, version, created_date)  
  VALUES (true, 'Comcast', 'Comcast', 'http://xfinity.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider_industry (provider_id, industry_id) values (6,4);
