--liquibase formatted sql

--changeset darrenl:33 context:integrationTest

INSERT INTO user (id, username, organization_id, organization_name) VALUES (1, 'urja_admin', 1, 'Urjanet');

UPDATE pdr SET owner_id = 1 WHERE id = 1;

