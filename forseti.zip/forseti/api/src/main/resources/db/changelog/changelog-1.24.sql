--liquibase formatted sql

--changeset sparikh:24

ALTER TABLE statement ADD source_ids varchar(5000);
ALTER TABLE pdr ADD source_tree varchar(200);
ALTER TABLE pdr ADD logs_id varchar(200);