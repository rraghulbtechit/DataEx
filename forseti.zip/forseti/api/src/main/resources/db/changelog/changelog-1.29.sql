--liquibase formatted sql

--changeset sparikh:29
ALTER TABLE pdr ADD retry_at datetime DEFAULT NULL;

--changeset sparikh:29.1 context:integrationTest
INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, source, version, created_date, organization, bifrost_id, completion_status, retry_at)
VALUES ('pending pdr test', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'API', 3, CURRENT_TIMESTAMP, 1, 'fake-bifrost-id-5', 'PENDING', DATEADD('MINUTE', -10, CURRENT_TIMESTAMP));