--liquibase formatted sql

--changeset sparikh:12.1 context:integrationTest
INSERT INTO pdr (correlation_id, provider_id, username, password, password2, account_number, completion_callback_url, source, version, create_date, organization, period_start, period_end, expiration_date)
VALUES ('test password2', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'xbE+QqJ+XwAy/L1uu6EOmw==', 'vx+J0Chj/n1NHk2HkvlEog==', '12345678-0006', 'http://localhost/mycallback', 'API', 3, '3015-01-01 01:01:01', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '4001-01-01 01:01:01');