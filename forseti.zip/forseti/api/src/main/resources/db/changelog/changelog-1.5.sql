--liquibase formatted sql

--changeset amcconnell:5 context:integrationTest


INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, period_start, period_end, completion_callback_url, completion_callback_result, source, bifrost_id, completion_status, completion_status_detail, started_at, completed_at, version, create_date, expiration_date, organization) VALUES ('123', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0001', '2015-08-26 18:37:47', '2015-08-26 18:37:52', 'http://localhost/mycallback', null, 'API', 'bfid11111', 'SUCCESS', 'No comment', '2015-08-26 18:38:48', '2015-08-26 18:38:51', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,1);

