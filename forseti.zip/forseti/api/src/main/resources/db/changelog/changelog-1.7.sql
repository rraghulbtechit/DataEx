--liquibase formatted sql

--changeset amcconnell:7 context:integrationTest

INSERT INTO statement (id, job_id, billing_name, billing_street_1, billing_street_2, billing_city, billing_state, billing_postal_code, billing_country, billing_phone, due_date, payment_currency, date_paid, service_period_start, service_period_end, total_bill, outstanding_balance, recent_payment, new_charges, previous_balance, version, last_modified, create_date) VALUES (1, 1, 'Andrew McConnell', '234 Garden Ln', 'Apt 666', 'Decatur', 'GA', '30030', 'US', '678-525-6467', '2015-08-31 16:45:10', 'USD', '2015-08-31 16:45:25', '2015-08-31 16:45:28', '2015-08-31 16:45:35', 23,45,67,123,99.99,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

