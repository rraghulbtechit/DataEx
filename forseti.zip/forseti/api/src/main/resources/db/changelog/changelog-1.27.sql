--liquibase formatted sql

--changeset sparikh:27

ALTER TABLE pdr ADD last_retried_at datetime DEFAULT NULL;
ALTER TABLE pdr ADD last_received_at datetime DEFAULT NULL;
ALTER TABLE pdr ADD retry_count int(2) DEFAULT NULL;
