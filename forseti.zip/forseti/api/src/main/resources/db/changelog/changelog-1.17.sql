--liquibase formatted sql

--changeset sparikh:17 context:integrationTest

INSERT INTO statement (id, pdr_id, billing_name, billing_street_1, billing_street_2, billing_city, billing_state, billing_postal_code, billing_country, billing_phone, due_date, payment_currency, recent_payment_date, statement_date, total_bill, recent_payment, version, last_modified, created_date) 
VALUES (2, 2, 'Sonali Parikh', '234 Garden Ln', 'Apt 666', 'Decatur', 'GA', '30030', 'US', '678-525-6467', '2015-08-31 16:45:10', 'USD', '2015-08-31 16:45:25', '2015-08-31 16:45:28', 167, 123.12, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
