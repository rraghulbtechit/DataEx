--liquibase formatted sql

--changeset sparikh:23

ALTER TABLE pdr ADD organization_name varchar(100);
UPDATE pdr SET organization_name = 'Urjanet' WHERE organization = 1;
UPDATE pdr SET organization_name = 'eCredable' WHERE organization = 2;
UPDATE pdr SET organization_name = 'FactorTrust' WHERE organization = 3;
