--liquibase formatted sql

--changeset jmullenbach:22

ALTER TABLE pdr ADD trace_id varchar(255);
--set the traceId to be the same as the id in case there are any pending submitacquisition jobs when this is run
UPDATE pdr p SET p.trace_id=p.id WHERE p.trace_id IS NULL;
