--liquibase formatted sql

--changeset sparikh:28.1 context:integrationTest
INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, source, version, created_date, organization, bifrost_id, completion_status, expiration_date)
VALUES ('pending pdr test', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'API', 3, CURRENT_TIMESTAMP, 1, 'fake-bifrost-id-1', 'PENDING', DATEADD('HOUR', 4, CURRENT_TIMESTAMP));

INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, source, version, created_date, expiration_date, organization, bifrost_id, completion_status, last_retried_at, last_received_at)
VALUES ('pending pdr test', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'API', 3, CURRENT_TIMESTAMP, '3015-01-01 01:01:01', 1, 'fake-bifrost-id-2', 'PENDING', '2016-01-01 01:01:01', '2016-01-01 01:11:01');

INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, source, version, created_date, organization, bifrost_id, completion_status, last_retried_at, last_received_at)
VALUES ('pending pdr test', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'API', 3, CURRENT_TIMESTAMP, 1, 'fake-bifrost-id-3', 'PENDING', DATEADD('HOUR', -26, CURRENT_TIMESTAMP), DATEADD('HOUR', -25, CURRENT_TIMESTAMP));

INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, source, version, created_date, organization, bifrost_id, completion_status, last_retried_at, last_received_at, expiration_date)
VALUES ('pending pdr test', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'API', 3, CURRENT_TIMESTAMP, 1, 'fake-bifrost-id-4', 'PENDING', '2016-01-01 01:01:01', '2016-01-01 01:11:01', DATEADD('MINUTE', -40, CURRENT_TIMESTAMP));
