--liquibase formatted sql

--changeset darrenl:32

ALTER TABLE pdr ADD owner_id BIGINT(20);

UPDATE pdr
SET owner_id = created_by
WHERE owner_id IS NULL;

ALTER TABLE pdr CHANGE COLUMN organization organization_id BIGINT(20) NOT NULL;

ALTER TABLE user ADD INDEX user_org_id_idx (organization_id ASC);
