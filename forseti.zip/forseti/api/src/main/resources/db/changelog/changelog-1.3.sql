--liquibase formatted sql

--changeset amcconnell:3 context:integrationTest

INSERT INTO provider (active, name, description, bifrost_provider_id, url, login_failures_reported, version, create_date) VALUES 
  (true, 'Verizon Wireless', null, 'VERIZON', 'http://vzw.com',true,1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, description, bifrost_provider_id, url, login_failures_reported, version, create_date) VALUES 
  (false, 'U.S. Cellular', null, 'USCELLULAR', 'http://uscellular.com', false, 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, description, bifrost_provider_id, url, login_failures_reported, version, create_date) VALUES 
  (false, 'AT&T', null, 'ATT', 'http://att.com', false, 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, description, bifrost_provider_id, url, login_failures_reported, version, create_date) VALUES 
    (false, 'Sprint', null, 'SPRINT', 'http://sprint.com', false, 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, description, bifrost_provider_id, url, login_failures_reported, version, create_date) VALUES 
    (false, 'T-Mobile', null, 'TMOBILE', 'http://tmobile.com', false, 1, CURRENT_TIMESTAMP);


INSERT INTO provider_industry (provider_id, industry_id) values (1,1);
INSERT INTO provider_industry (provider_id, industry_id) values (1,4);
INSERT INTO provider_industry (provider_id, industry_id) values (1,5);

INSERT INTO provider_industry (provider_id, industry_id) values (2,1);

INSERT INTO provider_industry (provider_id, industry_id) values (3,1);
INSERT INTO provider_industry (provider_id, industry_id) values (3,4);
INSERT INTO provider_industry (provider_id, industry_id) values (3,5);

INSERT INTO provider_industry (provider_id, industry_id) values (4,1);

INSERT INTO provider_industry (provider_id, industry_id) values (5,1);

