--liquibase formatted sql

--changeset amcconnell:1 context:integrationTest

INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Mobile Phone', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (false, 'Utility', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (false, 'Satellite TV', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (false, 'Cable', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (false, 'Land Line Phone', 1, CURRENT_TIMESTAMP);

