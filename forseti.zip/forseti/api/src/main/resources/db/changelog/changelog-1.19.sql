--liquibase formatted sql

--changeset amcconnell:19 context:endtoendTest
    
INSERT INTO provider (active, name, bifrost_provider_id, url, version, created_date)  
  VALUES (true, 'DirecTV', 'DirecTV', 'http://directv.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, bifrost_provider_id, url, version, created_date)  
  VALUES (true, 'Charter Communications', 'CharterCommunications', 'http://charter.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider_industry (provider_id, industry_id) values (7,3);
INSERT INTO provider_industry (provider_id, industry_id) values (8,4);