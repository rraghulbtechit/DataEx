--liquibase formatted sql

--changeset sparikh:13.1 context:endtoendTest

INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Mobile Phone', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Utility', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Satellite TV', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Cable', 1, CURRENT_TIMESTAMP);
INSERT INTO industry (active, name, version, create_date) VALUES (true, 'Land Line Phone', 1, CURRENT_TIMESTAMP);
    
INSERT INTO provider (active, name, bifrost_provider_id, url, version, create_date)  
  VALUES (true, 'Verizon Wireless', 'Verizon', 'http://vzw.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, bifrost_provider_id, url, version, create_date) 
  VALUES (true, 'AT&T', 'ATT', 'http://att.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, bifrost_provider_id, url, version, create_date) 
  VALUES (true, 'Sprint', 'Sprint', 'http://sprint.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, bifrost_provider_id, url, version, create_date) 
  VALUES (true, 'T-Mobile', 'TMobile', 'http://tmobile.com', 1, CURRENT_TIMESTAMP);

INSERT INTO provider (active, name, bifrost_provider_id, url, version, create_date) 
  VALUES (true, 'Mock Provider', 'MockProviderAlias', null, 1, CURRENT_TIMESTAMP);

INSERT INTO provider_industry (provider_id, industry_id) values (1,1);
INSERT INTO provider_industry (provider_id, industry_id) values (1,4);
INSERT INTO provider_industry (provider_id, industry_id) values (1,5);

INSERT INTO provider_industry (provider_id, industry_id) values (2,1);

INSERT INTO provider_industry (provider_id, industry_id) values (3,1);
INSERT INTO provider_industry (provider_id, industry_id) values (3,4);
INSERT INTO provider_industry (provider_id, industry_id) values (3,5);

INSERT INTO provider_industry (provider_id, industry_id) values (4,1);

INSERT INTO provider_industry (provider_id, industry_id) values (5,1);
