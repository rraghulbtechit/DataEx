--liquibase formatted sql

--changeset sparikh:10.1 context:integrationTest
INSERT INTO pdr (correlation_id, provider_id, username, password, account_number, completion_callback_url, source, version, create_date, expiration_date, organization, period_start, period_end)
VALUES ('pending acq', 1, 'RZrU+hCB/18o7UjhUPDb9A==', 'XzljRYmI7DMvgD5+94s58A==', '12345678-0006', 'http://localhost/mycallback', 'API', 3, CURRENT_TIMESTAMP, '3015-01-01 01:01:01', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);