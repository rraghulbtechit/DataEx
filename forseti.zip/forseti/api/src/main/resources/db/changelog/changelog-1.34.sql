--liquibase formatted sql

--changeset darrenl:34 context:integrationTest

UPDATE pdr SET owner_id = 1;
