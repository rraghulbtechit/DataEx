package com.urjanet.forseti.rest.assemblers;

import static org.junit.Assert.assertTrue;

import java.beans.PropertyDescriptor;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.beanutils.PropertyUtilsBean;
import org.junit.Test;
import org.springframework.hateoas.ResourceSupport;

import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.model.nondatabase.Provider;
import com.urjanet.forseti.rest.resources.PrivatePDRResource;
import com.urjanet.forseti.rest.resources.PrivateStatementResource;
import com.urjanet.forseti.rest.resources.PublicIndustryResource;
import com.urjanet.forseti.rest.resources.PublicPDRResource;
import com.urjanet.forseti.rest.resources.PublicProviderResource;
import com.urjanet.forseti.rest.resources.PublicStatementResource;

public class ResourceAssemblerTest {

	@Test
	public void publicPDR() {
		Set<String> excludes = new HashSet<>();
		excludes.add("completionStatus");
		excludes.add("statementCount");
		testResource(PublicPDRResource.class, PDR.class,excludes);
	}

	@Test
	public void privatePDR() {
		Set<String> excludes = new HashSet<>();
		excludes.add("completionStatus");
		excludes.add("statementCount");
		testResource(PrivatePDRResource.class, PDR.class, excludes);
	}

	@Test
	public void publicStatement() {
		testResource(PublicStatementResource.class, Statement.class);
	}

	@Test
	public void privateStatement() {
		testResource(PrivateStatementResource.class, Statement.class);
	}

	public void testResource(Class<? extends ResourceSupport> resource, Class<?> model) {
		testResource(resource,model,new HashSet<String>());
	}
	
	@Test
	public void publicIndustry() {
		Set<String> excludes = new HashSet<>();
		excludes.add("uuid");
		testResource(PublicIndustryResource.class, Industry.class,excludes);
	}
	
	@Test
	public void publicProvider() {
		Set<String> excludes = new HashSet<>();
		excludes.add("uuid");
		testResource(PublicProviderResource.class, Provider.class,excludes);
	}

	/**
	 * Adds some fields to exclude that are common to all ResourceSupport subclasses.
	 * 
	 * @param resource
	 * @param model
	 * @param filter
	 */
	public void testResource(Class<? extends ResourceSupport> resource, Class<?> model, Set<String> filter) {
		filter.add("links");
		filter.add("id");
		test(resource,model,filter);
	}

	
	private void test(Class<?> resource, Class<?> model,
			Set<String> exclusionFilter) {

		// Make sure that there aren't any relevant properties in
		// resource that aren't in the model. If there are, then
		// BeanUtils.copyProperties is
		// going to skip them. The various ResourceAssembler classes make
		// extensive use of that
		// utility, and without a backstop of some sort, its easy to break. The
		// integration
		// tests SHOULD catch that when the JSON is examined. Nonetheless, this
		// is a good
		// safety.
		PropertyUtilsBean pub = new PropertyUtilsBean();
		PropertyDescriptor[] descriptors = pub.getPropertyDescriptors(resource);

		Object[] filtered = Arrays.stream(descriptors)
				.filter(d -> !exclusionFilter.contains(d.getName())).toArray();

		for (Object o : filtered) {
			PropertyDescriptor descriptor = (PropertyDescriptor) o;
			// System.out.println("src=" + descriptor.getName());
			
			//skip embedded fields that won't be found in the model
			if(!(descriptor.getName().equals("embeddeds")))
			{
				assertTrue("Resource has field " + descriptor.getName()
						+ " with no match in the model",
						hasSimilarDescriptor(model, descriptor));	
			}
			

		}

	}

	private static boolean hasSimilarDescriptor(Class<?> clazz,
			PropertyDescriptor resourceDescriptor) {

		boolean rc = false;
		PropertyUtilsBean pub = new PropertyUtilsBean();
		PropertyDescriptor[] descriptors = pub.getPropertyDescriptors(clazz);

		for (PropertyDescriptor descriptor : descriptors) {
			// System.out.println(descriptor.getName());
			if (descriptorEquals(resourceDescriptor, descriptor)) {
				rc = true;
				break;
			}
		}

		return rc;
	}

	public static boolean descriptorEquals(PropertyDescriptor d1,
			PropertyDescriptor d2) {

		return d1.getName().equals(d2.getName())
				&& d1.getPropertyType().equals(d2.getPropertyType());

	}

}
