package com.urjanet.forseti.rest.v1.tests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.urjanet.forseti.Application;
import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class ActuatorControllerTest extends BaseIntegrationTest {

	// Test users
	private UserContext admin = new UserContext(1L, "admin", "Administrator",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.RW_INDUSTRY),
					new SimpleGrantedAuthority(Permissions.RW_PROVIDER), 
					new SimpleGrantedAuthority(Permissions.ACCESS_PRIVATE_API)));
	private UserContext monitorUser = new UserContext(3L, "monitor.user", "Monitor Administrator",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority("PERM_MONITORING")));
	
	@Ignore
	@Test
	/* This test used to pass before the 1.3.3 upgrade. It doesn't now.
	 * There is no point testing the health actuator endpoint anyway!
	 */
	public void healthcheck() throws Exception {
		mockMvc.perform(
				get("/health")).andExpect(
				status().isOk());
	}
	
	@Test
	public void metricsUnauthorized() throws Exception {
		mockMvc.perform(
				get("/metrics")).andExpect(
				status().isUnauthorized());
	}

	@Test
	public void metricsForbidden() throws Exception {
		mockMvc.perform(
				get("/metrics").header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isForbidden());
	}
	
	@Test
	public void metricsAuthorized() throws Exception {
		mockMvc.perform(
				get("/metrics").header("Authorization",
						"Bearer " + th.createTokenForUser(monitorUser))).andExpect(
				status().isOk());
	}
	
}
