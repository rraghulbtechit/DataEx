package com.urjanet.forseti.rest.v1.tests;

import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.urjanet.forseti.Application;
import com.urjanet.forseti.helpers.PDRCancellationDTO;
import com.urjanet.forseti.helpers.PDRDTO;
import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class PublicPDRControllerTest extends BaseIntegrationTest {
	
	private UserContext customer = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.READ_PDR), 
					new SimpleGrantedAuthority(Permissions.RW_PDR),
					new SimpleGrantedAuthority(Permissions.READ_PROVIDER),
					new SimpleGrantedAuthority(Permissions.READ_INDUSTRY)));
	
	private UserContext customerDontShowProvider = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.READ_PDR)));

	
	@Before
	public void setup() throws Exception {
		super.setup();
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	
	@Test
	public void pdrNotFound() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/182736876").header("Authorization",
				"Bearer " + th.createTokenForUser(customer))).andExpect(
				status().isNotFound());
	}

	@Test
	public void findpdrByID() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("$", not(hasKey("active"))))
				.andExpect(jsonPath("createdDate",notNullValue()))
				.andExpect(jsonPath("lastModified").doesNotExist())
				.andExpect(jsonPath("periodStart", notNullValue()))
				.andExpect(jsonPath("periodEnd", notNullValue()))
				.andExpect(jsonPath("expirationDate", notNullValue()))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("password2").doesNotExist())
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(jsonPath("completionStatus", equalTo("SUCCESS")))
				.andExpect(jsonPath("statementCount", equalTo(1)))
				.andExpect(jsonPath("source").doesNotExist())
				.andExpect(jsonPath("bifrostId").doesNotExist())
				.andExpect(jsonPath("startedAt").doesNotExist())
				.andExpect(
						jsonPath("completionStatusDetail",
								equalTo("No comment")))
				.andExpect(
						jsonPath("completionCallbackUrl",
								equalTo("http://localhost/mycallback")))
				.andExpect(
						jsonPath("_links.statements.href",
								endsWith("/v1/public/pdrs/1/statements")))
				.andExpect(
						jsonPath("_links.self.href",
								endsWith("/v1/public/pdrs/1")))
				.andExpect(
						jsonPath("_links.provider.href",
								endsWith("/v1/public/providers/1e60a473-7f13-d8f2-a038-22000b109b8b")));
	}
	
	@Test
	public void findpdrByIDTestPassword2() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/7").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("$", not(hasKey("active"))))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword1")))
				.andExpect(jsonPath("password2", equalTo("mypassword2")));
	}
	
	@Test
	public void findAllpdrs() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("_embedded.publicPDRResourceList", hasSize(10)));
	}

	@Test
	public void findAllpdrsByCorrelationId() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs?correlationId=123").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("_embedded.publicPDRResourceList", hasSize(1)));
	}

	@Test
	public void findAllpdrSByCorrelationIdSearchNoMatch() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs?correlationId=123asdfkljkj").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("page.totalElements",
								org.hamcrest.Matchers.equalTo(0)));
	}

	@Test
	public void createExtractionRequestInvalidProvider() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(3600));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		mockMvc.perform(
				post("/v1/public/providers/999/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).contentType(
						MediaType.APPLICATION_JSON).content(
						mapper.writeValueAsString(pdr))).andExpect(
				status().isNotFound());

	}

	@Test
	public void testSchedulePDR_MissingRequiredFields() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(3600));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		
		MvcResult result = mockMvc.perform(
				post("/v1/public/providers/1/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).contentType(
						MediaType.APPLICATION_JSON).content(
						mapper.writeValueAsString(pdr)))
				.andExpect(status().isBadRequest())
				.andReturn();
		
		assertNotNull(result.getResolvedException());
		assertTrue(result.getResolvedException().getMessage().contains("accountNumber"));
		assertTrue(result.getResolvedException().getMessage().contains("username"));
		assertTrue(result.getResolvedException().getMessage().contains("password"));
		assertTrue(result.getResolvedException().getMessage().contains("3 error"));
	}

	@Test
	public void testSchedulePDR_InvalidDates() throws Exception {

		Resource resource = new ClassPathResource("InvalidDateFormatTest.json");
		String json = IOUtils.toString(resource.getInputStream());
		
		MvcResult result = mockMvc.perform(
				post("/v1/public/providers/1/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).contentType(
						MediaType.APPLICATION_JSON).content(json))
				.andExpect(status().isBadRequest())
				.andReturn();
		
		assertNotNull(result.getResolvedException());
		assertTrue(result.getResolvedException().getMessage().contains("periodStart"));
		assertTrue(result.getResolvedException().getMessage().contains("periodEnd"));
		assertTrue(result.getResolvedException().getMessage().contains("2 error"));
	}
	
	@Test
	public void testSchedulePDR_InvalidCompletionCallbackUrls() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		
		List<String> invalidUrls = Arrays.asList("", 
												" ", 
												"notaurl", 
												"notaurl.com", 
												"notaurl.com.com");
		for (String ccu: invalidUrls) {
			pdr.setCompletionCallbackUrl(ccu);
			
			MvcResult result = mockMvc.perform(
					post("/v1/public/providers/1/pdrs").header("Authorization",
							"Bearer " + th.createTokenForUser(customer)).contentType(
							MediaType.APPLICATION_JSON).content(
							mapper.writeValueAsString(pdr)))
					.andExpect(status().isBadRequest())
					.andReturn();
			
			assertNotNull(result.getResolvedException());
			assertTrue(result.getResolvedException().getMessage().contains("completionCallbackUrl"));
			assertTrue(result.getResolvedException().getMessage().contains("error"));
		}
	}
	
	@Test
	public void testSchedulePDR_InvalidTimeout() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setTimeout(new Integer(DateTimeConstants.SECONDS_PER_WEEK * 3 + 1));
		
		MvcResult result = mockMvc.perform(
				post("/v1/public/providers/1/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).contentType(
						MediaType.APPLICATION_JSON).content(
						mapper.writeValueAsString(pdr)))
				.andExpect(status().isBadRequest())
				.andReturn();
		
		assertNotNull(result.getResolvedException());
		assertTrue(result.getResolvedException().getMessage().contains("timeout"));
		assertTrue(result.getResolvedException().getMessage().contains("1 error"));
	}
	
	@Test
	public void createExtractionRequestTimeoutLowerThanMin() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(-1));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		
		mockMvc.perform(
				post("/v1/public/providers/1/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).contentType(
						MediaType.APPLICATION_JSON).content(
						mapper.writeValueAsString(pdr))).andExpect(
				status().isBadRequest());

	}

	@Test
	public void cancelpdr_json() throws Exception {
		mockMvc.perform(
				patch("/v1/public/pdrs/4").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
				.content("{ \"status\": \"CANCELLED\" }")
					.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isAccepted());
	}
	
	@Test
	public void cancelpdr_ValidationFail() throws Exception {
		String lengthAbove255 = "1";
		for (int i=0; i<255; i++)
			lengthAbove255 +=  "1";
		PDRCancellationDTO pdr = new PDRCancellationDTO();
		pdr.setStatus(lengthAbove255);
		MvcResult result = mockMvc.perform(
				patch("/v1/public/pdrs/4").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
				.content(mapper.writeValueAsString(pdr))
				.contentType(
						MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andReturn();

		assert(result.getResolvedException()!=null);
		assert(result.getResolvedException().getMessage().contains("status"));
		assert(result.getResolvedException().getMessage().contains("1 error"));
	}

	@Test
	public void cancelpdrInvalidArgument() throws Exception {
		mockMvc.perform(
				patch("/v1/public/pdrs/1").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).content(
						"{ \"status\": \"FAKESTATUS\" }").contentType(
						MediaType.APPLICATION_JSON)).andExpect(
				status().isBadRequest());
	}
	
	@Test
	public void cancelpdrInvalidID() throws Exception {
		mockMvc.perform(
				patch("/v1/public/pdrs/982341324").header("Authorization",
						"Bearer " + th.createTokenForUser(customer)).content(
						"{ \"status\": \"CANCELLED\" }").contentType(
						MediaType.APPLICATION_JSON)).andExpect(
				status().isNotFound());
	}
	
	@Test
	public void findStatements() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/2").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("statementCount", equalTo(1)));
				
		mockMvc.perform(get("/v1/public/pdrs/2/statements").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath(
								"_links.self.href",
								endsWith("/v1/public/pdrs/2/statements")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingName",
								equalTo("Sonali Parikh")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingStreet1",
								equalTo("234 Garden Ln")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingStreet2",
								equalTo("Apt 666")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingCity",
								equalTo("Decatur")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingState",
								equalTo("GA")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingCountry",
								equalTo("US")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].billingPostalCode",
								equalTo("30030")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].totalBill",
								equalTo(167.0)))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].recentPayment",
								equalTo(123.12)))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].dueDate",
								notNullValue()))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].paymentCurrency",
								equalTo("USD")))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].recentPaymentDate",
								notNullValue()))
				.andExpect(
						jsonPath(
								"_embedded.publicStatementResourceList[0].statementDate",
								notNullValue()))
				
				.andExpect(
						jsonPath("_embedded.publicStatementResourceList",
								hasSize(1)))
						
				.andExpect(
						jsonPath("_embedded.publicStatementResourceList[0].pdrID").doesNotExist());

	}

	@Test
	public void findStatementsNotFound() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/999/statements").header("Authorization",
				"Bearer " + th.createTokenForUser(customer))).andExpect(
				status().isNotFound());
	}
	
	@Test
	public void findpdrWithoutStatements() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.statements").doesNotExist());
	}
	
	@Test
	public void findpdrDontShowProvider() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(customerDontShowProvider)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.provider").doesNotExist());
	}
	
	@Test
	public void findpdrWithCancel() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.cancel.href",
								endsWith("/v1/public/pdrs/6")));
	}
	
	@Test
	public void findpdrWithoutCancel() throws Exception {
		mockMvc.perform(get("/v1/public/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(
						jsonPath("_links.cancel").doesNotExist());
	}

}
