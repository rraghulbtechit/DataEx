package com.urjanet.forseti.rest.v1.tests;

import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;
import com.urjanet.forseti.Application;
import com.urjanet.forseti.helpers.PDRDTO;
import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class PublicSimulatorControllerTest extends BaseIntegrationTest {

	private UserContext customer = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList(new SimpleGrantedAuthority(
					Permissions.ACCESS_SIMULATOR_API)));

	private UserContext admin = new UserContext(2L, "admin", "Admin",
			1L, "Some Org", Arrays.asList(new SimpleGrantedAuthority(Permissions.RW_PDR),
					new SimpleGrantedAuthority(Permissions.ACCESS_PRIVATE_API)));
	
	@Test
	public void success() throws Exception {
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(3600));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		MvcResult result = mockMvc.perform(
				post("/v1/public/simulator/success").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
					.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(pdr)))
				.andExpect(status().isAccepted())
				.andExpect(jsonPath("password", endsWith("mypassword")))
				.andExpect(jsonPath("password2", nullValue()))
				.andReturn();
		
		String content = result.getResponse().getContentAsString();

		JsonNode rootNode = mapper.readTree(content);
		JsonNode self = rootNode.path("_links").path("self");
		String deleteUrl = self.path("href").asText().replace("public", "private");
		mockMvc.perform(
				delete(deleteUrl).header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNoContent());
	}
	
	@Test
	public void successWithPassword2() throws Exception {
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword1");
		pdr.setPassword2("mypassword2");
		MvcResult result = mockMvc.perform(
				post("/v1/public/simulator/success").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
					.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(pdr)))
				.andExpect(status().isAccepted())
				.andExpect(jsonPath("password",endsWith("mypassword1")))
				.andExpect(jsonPath("password2",endsWith("mypassword2")))
				.andReturn();
		
		String content = result.getResponse().getContentAsString();

		JsonNode rootNode = mapper.readTree(content);
		JsonNode self = rootNode.path("_links").path("self");
		String deleteUrl = self.path("href").asText().replace("public", "private");
		mockMvc.perform(
				delete(deleteUrl).header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNoContent());
	}

	@Test
	public void timeout() throws Exception {
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(3600));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		MvcResult result = mockMvc.perform(
				post("/v1/public/simulator/timeout").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
					.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(pdr)))
				.andExpect(status().isAccepted()).andReturn();
		
		String content = result.getResponse().getContentAsString();

		JsonNode rootNode = mapper.readTree(content);
		JsonNode self = rootNode.path("_links").path("self");
		String deleteUrl = self.path("href").asText().replace("public", "private");
		mockMvc.perform(
				delete(deleteUrl).header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNoContent());
		
	}
	
	@Test
	public void error() throws Exception {
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setPeriodStart(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setPeriodEnd(ISODateTimeFormat.date().print(new DateTime()));
		pdr.setTimeout(new Integer(3600));
		pdr.setCompletionCallbackUrl("http://dummyurl");
		MvcResult result = mockMvc.perform(
				post("/v1/public/simulator/error").header("Authorization",
						"Bearer " + th.createTokenForUser(customer))
					.contentType(MediaType.APPLICATION_JSON)
					.content(mapper.writeValueAsString(pdr)))
				.andExpect(status().isAccepted()).andReturn();
		
		String content = result.getResponse().getContentAsString();

		JsonNode rootNode = mapper.readTree(content);
		JsonNode self = rootNode.path("_links").path("self");
		String deleteUrl = self.path("href").asText().replace("public", "private");
		mockMvc.perform(
				delete(deleteUrl).header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNoContent());
	}
	
	@Test
	public void validationFail_MissingRequiredFields() throws Exception {

		PDRDTO pdr = new PDRDTO();
		
		List<String> urls = Arrays.asList("/v1/public/simulator/success", 
											"/v1/public/simulator/timeout",
											"/v1/public/simulator/error");
		for (String url: urls) {
			MvcResult result = mockMvc.perform(
					post(url).header("Authorization",
							"Bearer " + th.createTokenForUser(customer))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(pdr)))
					.andExpect(status().isBadRequest())
					.andReturn();
			
			assertNotNull(result.getResolvedException());
			assertTrue(result.getResolvedException().getMessage().contains("accountNumber"));
			assertTrue(result.getResolvedException().getMessage().contains("username"));
			assertTrue(result.getResolvedException().getMessage().contains("password"));
			assertTrue(result.getResolvedException().getMessage().contains("3 error"));
		}
	}
	
	@Test
	public void validationFail_InvalidLength() throws Exception {

		String lengthAbove255 = "1";
		for (int i=0; i<255; i++)
			lengthAbove255 +=  "1";
		
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber(lengthAbove255);
		pdr.setUsername(lengthAbove255);
		pdr.setPassword(lengthAbove255);
		pdr.setPassword2(lengthAbove255);
		pdr.setCorrelationId(lengthAbove255);
		pdr.setCompletionCallbackUrl(lengthAbove255);
	 
		List<String> urls = Arrays.asList("/v1/public/simulator/success", 
											"/v1/public/simulator/timeout",
											"/v1/public/simulator/error");
		for (String url: urls) {
			MvcResult result = mockMvc.perform(
					post(url).header("Authorization",
							"Bearer " + th.createTokenForUser(customer))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(pdr)))
					.andExpect(status().isBadRequest())
					.andReturn();
			
			assertNotNull(result.getResolvedException());
			assertTrue(result.getResolvedException().getMessage().contains("accountNumber"));
			assertTrue(result.getResolvedException().getMessage().contains("username"));
			assertTrue(result.getResolvedException().getMessage().contains("password"));
			assertTrue(result.getResolvedException().getMessage().contains("password2"));
			assertTrue(result.getResolvedException().getMessage().contains("correlationId"));
			assertTrue(result.getResolvedException().getMessage().contains("completionCallbackUrl"));
			assertTrue(result.getResolvedException().getMessage().contains("7 error"));
		}
	}
	
	@Test
	public void validationFail_InvalidTimeout() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		pdr.setTimeout(-100);
	 
		List<String> urls = Arrays.asList("/v1/public/simulator/success", 
											"/v1/public/simulator/timeout",
											"/v1/public/simulator/error");
		for (String url: urls) {
			MvcResult result = mockMvc.perform(
					post(url).header("Authorization",
							"Bearer " + th.createTokenForUser(customer))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(pdr)))
					.andExpect(status().isBadRequest())
					.andReturn();
			
			assertNotNull(result.getResolvedException());
			assertTrue(result.getResolvedException().getMessage().contains("timeout"));
			assertTrue(result.getResolvedException().getMessage().contains("1 error"));
		}
	}
	
	@Test
	public void validationFail_InvalidCompletionCallbackUrls() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		
		List<String> urls = Arrays.asList("/v1/public/simulator/success", 
											"/v1/public/simulator/timeout",
											"/v1/public/simulator/error");
		for (String url: urls) {
			
			List<String> invalidUrls = Arrays.asList("", 
													" ", 
													"notaurl", 
													"notaurl.com", 
													"notaurl.com.com");
			for (String ccu: invalidUrls) {
				pdr.setCompletionCallbackUrl(ccu);
				
				MvcResult result = mockMvc.perform(
						post(url).header("Authorization",
								"Bearer " + th.createTokenForUser(customer))
							.contentType(MediaType.APPLICATION_JSON)
							.content(mapper.writeValueAsString(pdr)))
						.andExpect(status().isBadRequest())
						.andReturn();

				assertNotNull(result.getResolvedException());
				assertTrue(result.getResolvedException().getMessage().contains("completionCallbackUrl"));
				assertTrue(result.getResolvedException().getMessage().contains("error"));
			}
		}
	}
	
	@Test
	public void testValidCompletionCallbackUrls() throws Exception {

		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber("myacctnum");
		pdr.setUsername("myusername");
		pdr.setPassword("mypassword");
		
		List<String> urls = Arrays.asList("/v1/public/simulator/success", 
											"/v1/public/simulator/timeout",
											"/v1/public/simulator/error");
		for (String url: urls) {
			
			List<String> validUrls = Arrays.asList(null, 
													"http://validurl", 
													"https://validurl",
													"https://validurl.com",
													"https://request-caching-service.urjanet.net/items/");
			for (String ccu: validUrls) {
				pdr.setCompletionCallbackUrl(ccu);
				
				MvcResult result = mockMvc.perform(
						post(url).header("Authorization",
								"Bearer " + th.createTokenForUser(customer))
							.contentType(MediaType.APPLICATION_JSON)
							.content(mapper.writeValueAsString(pdr)))
						.andExpect(status().isAccepted()).andReturn();
				
				String content = result.getResponse().getContentAsString();

				JsonNode rootNode = mapper.readTree(content);
				JsonNode self = rootNode.path("_links").path("self");
				String deleteUrl = self.path("href").asText().replace("public", "private");
				mockMvc.perform(
						delete(deleteUrl).header("Authorization",
								"Bearer " + th.createTokenForUser(admin))).andExpect(
						status().isNoContent());
			}
		}
	}
}
