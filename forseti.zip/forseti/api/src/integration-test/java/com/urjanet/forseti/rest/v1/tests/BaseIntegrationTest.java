package com.urjanet.forseti.rest.v1.tests;

import javax.servlet.Filter;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.urjanet.heimdallr.resourceserver.security.TokenCreator;

@ActiveProfiles(profiles = {"it"},inheritProfiles = false)
public class BaseIntegrationTest {
	protected ObjectMapper mapper = new ObjectMapper();

	MediaType contentType = new MediaType(
			MediaType.APPLICATION_JSON.getType(), "hal+json");
	MockMvc mockMvc;

	@Autowired
	WebApplicationContext webApplicationContext;

	@Autowired
	Filter springSecurityFilterChain;

	@Value("${urja.security.token.publicKey}")
	String publicKey;
	
	@Value("${urja.security.token.privateKey}")
	String privateKey;

	TokenCreator th;

	@Before
	public void setup() throws Exception {

		th = new TokenCreator(privateKey, 300);

		mockMvc = MockMvcBuilders
				.webAppContextSetup(webApplicationContext)
				.addFilters(springSecurityFilterChain)
				.build();

	}
	

}
