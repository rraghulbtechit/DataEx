package com.urjanet.forseti.rest.v1.tests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.urjanet.forseti.Application;
//import org.springframework.mock.http.MockHttpOutputMessage;
import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class PublicIndustryControllerTest  extends BaseIntegrationTest{

	private UserContext customer = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.READ_INDUSTRY),
					new SimpleGrantedAuthority(Permissions.READ_PROVIDER)));

	private UserContext customerWithoutAuthority = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList());
	
	@Test
	public void industryNotFound() throws Exception {
		mockMvc.perform(get("/v1/public/industries/2").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isNotFound());
	}

	@Test
	public void industryInaccessible() throws Exception {
		mockMvc.perform(get("/v1/public/industries/123456").header("Authorization",
				"Bearer " + th.createTokenForUser(customer)))
				.andExpect(status().isNotFound());
	}
	
	@Test
	public void findIndustryByIDFail() throws Exception {
		mockMvc.perform(get("/v1/public/industries/1").header("Authorization",
				"Bearer " + th.createTokenForUser(customerWithoutAuthority)))
					.andExpect(status().isForbidden());
	}
	
}
