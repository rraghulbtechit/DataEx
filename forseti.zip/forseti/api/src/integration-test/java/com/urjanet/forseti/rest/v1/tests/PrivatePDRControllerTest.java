package com.urjanet.forseti.rest.v1.tests;

import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.urjanet.forseti.Application;
import com.urjanet.forseti.helpers.PDRCallbackCompletedDTO;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.helpers.PDRDTO;
import com.urjanet.forseti.helpers.PDRSubmittedAcquisitionDTO;
import com.urjanet.forseti.helpers.StatementDTO;
import com.urjanet.forseti.rest.Permissions;
import com.urjanet.heimdallr.resourceserver.common.UserContext;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class PrivatePDRControllerTest extends BaseIntegrationTest {

	// Test users
	private UserContext admin = new UserContext(1L, "admin", "Administrator",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.RW_PROVIDER),
					new SimpleGrantedAuthority(Permissions.RW_INDUSTRY),
					new SimpleGrantedAuthority(Permissions.ACCESS_PRIVATE_API), 
					new SimpleGrantedAuthority(Permissions.RW_PDR)));
	
	private UserContext customerDontShowProvider = new UserContext(1L, "customer", "Customer",
			1L, "Some Org", Arrays.asList(
					new SimpleGrantedAuthority(Permissions.ACCESS_PRIVATE_API),
					new SimpleGrantedAuthority(Permissions.READ_PDR)));
	
	@Before
	public void setup() throws Exception {
		super.setup();
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	@Test
	public void pdrNotFound() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/182736876").header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNotFound());
	}

	@Test
	public void findpdrByID() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/1").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("password2").doesNotExist())
				.andExpect(jsonPath("_links.callbackcompleted.href",
							endsWith("/v1/private/pdrs/1/callbackcompleted")));

	}
	
	@Test
	public void findpdrByID_VerifyEmbeddedUser() throws Exception {		
		
		mockMvc.perform(
				get("/v1/private/pdrs/1").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("_embedded.user.username",
						equalTo("urja_admin")))
				.andExpect(jsonPath("_embedded.user.organizationName",
						equalTo("Urjanet")));
		
	}

	@Test
	public void findpdrByIDNoRelForCallbackcompleted() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/3").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("_links", not(hasKey("triggercallback"))))
				.andExpect(jsonPath("_links", not(hasKey("callbackcompleted"))));
	}

	@Test
	public void findAllpdrs() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("_embedded.privatePDRResourceList", hasSize(10)));
	}

	@Test
	public void findAllpdrsByJobId() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs?jobId=bfid11111").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("_embedded.privatePDRResourceList", hasSize(1)))
				.andExpect(jsonPath("_embedded.privatePDRResourceList[0].providerName", 
                        notNullValue()));
	}

	@Test
	public void findAllpdrSByJobIdSearchNoMatch() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs?jobId=123asdfkljkj").header(
						"Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("page.totalElements",
								org.hamcrest.Matchers.equalTo(0)));
	}

	@Test
	public void findStatements() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/1/statements").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("_embedded.privateStatementResourceList",
								hasSize(1)));

	}

	@Test
	public void findStatementsNotFound() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/999/statements").header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isNotFound());
	}
	
	@Test
	public void cancelpdr() throws Exception {
		mockMvc.perform(
				patch("/v1/private/pdrs/3/cancel")
						.header("Authorization",
								"Bearer " + th.createTokenForUser(admin))
						.content("{ \"status\": \"CANCELLED\" }")
						.contentType(MediaType.APPLICATION_JSON)).andExpect(
				status().isAccepted());
	}

	@Test
	public void timeoutpdr() throws Exception {
		mockMvc.perform(
				patch("/v1/private/pdrs/5/timeout").header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isOk());
	}

	@Test
	public void timeoutpdrBadRequest() throws Exception {
		mockMvc.perform(
				patch("/v1/private/pdrs/1/timeout").header("Authorization",
						"Bearer " + th.createTokenForUser(admin))).andExpect(
				status().isPreconditionFailed());
	}

	@Test
	public void findPDRsToTimeout() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/findpdrstotimeout").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("_embedded.privatePDRResourceList", hasSize(2)));
	}

	@Test
	public void findPDRsToCallback() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/findpdrstocallback").header("Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("page.totalElements",
								org.hamcrest.Matchers.equalTo(1)));
	}

	@Test
	public void findNewPDRsToSubmitAcquisition() throws Exception {
		mockMvc.perform(
				get("/v1/private/pdrs/findnewpdrstosubmitacquisition").header(
						"Authorization",
						"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(
						jsonPath("page.totalElements",
								org.hamcrest.Matchers.equalTo(2)));
    }

    @Test
    public void findPendingPDRsToSubmitAcquisition() throws Exception {
        mockMvc.perform(get("/v1/private/pdrs/findpendingpdrstosubmitacquisition")
                .header("Authorization", "Bearer " + th.createTokenForUser(admin)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("page.totalElements", org.hamcrest.Matchers.equalTo(1)));
    }
	
	@Test
	public void callbackCompleted() throws Exception {
		PDRCallbackCompletedDTO dto = new PDRCallbackCompletedDTO();
		dto.setCompletionCallbackResult(200);
		mockMvc.perform(
				patch("/v1/private/pdrs/3/callbackcompleted")
						.header("Authorization",
								"Bearer " + th.createTokenForUser(admin))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(dto))).andExpect(
				status().isOk());
	}

	@Test
	public void submittedAcquisition() throws Exception {
		PDRSubmittedAcquisitionDTO dto = new PDRSubmittedAcquisitionDTO();
		dto.setBifrostId("test id");
		mockMvc.perform(
				patch("/v1/private/pdrs/3/submittedacquisition")
						.header("Authorization",
								"Bearer " + th.createTokenForUser(admin))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("bifrostId", equalTo("test id")))
				.andExpect(jsonPath("startedAt", notNullValue()));
	}

	@Test
	public void pdrResult() throws Exception {

		PDRCompletionDTO pdr = new PDRCompletionDTO();
		pdr.setBifrostId("bfid11111");
		pdr.setCompletionStatus("SUCCESS");
		pdr.setCompletedAt(new Date());

		pdr.setStatements(new HashSet<>());

		StatementDTO stmt = new StatementDTO();
		stmt.setAccountNumber("874399272");
		stmt.setBillingName("MIKE PRIDEMORE");
		stmt.setBillingStreet1("769 BARRETT VILLAGE LN NW");
		stmt.setBillingStreet2("MARIETTA, GA 30064-4746");
		stmt.setTotalBill(new BigDecimal(97.68));

		pdr.getStatements().add(stmt);

		stmt = new StatementDTO();
		stmt.setAccountNumber("534004287099");
		stmt.setBillingName("CARTER W. GRIFFITH");
		stmt.setBillingStreet1("715 ELLSWORTH DR NW");
		stmt.setBillingStreet2("MARIETTA, GA 30064-4746");
		stmt.setTotalBill(new BigDecimal(400));

		pdr.getStatements().add(stmt);

		stmt = new StatementDTO();
		stmt.setAccountNumber("534004287099");
		stmt.setBillingName("CARTER W. GRIFFITH");
		stmt.setBillingStreet1("715 ELLSWORTH DR NW");
		stmt.setBillingStreet2("MARIETTA, GA 30064-4746");
		stmt.setTotalBill(new BigDecimal(80));

		pdr.getStatements().add(stmt);

		mockMvc.perform(
				patch("/v1/private/pdrs/1/result")
						.header("Authorization",
								"Bearer " + th.createTokenForUser(admin))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(pdr))).andExpect(
				status().isOk());
	}
	
	@Test
	public void findpdrWithoutStatements() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.statements").doesNotExist());
	}
	
	@Test
	public void findpdrWithCancel() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.cancel.href",
								endsWith("/v1/private/pdrs/6/cancel")));
	}
	
	@Test
	public void findpdrWithoutCancel() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(
						jsonPath("_links.cancel").doesNotExist());
	}
	
	@Test
	public void findpdrWithTimeout() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.timeout.href",
								endsWith("/v1/private/pdrs/6/timeout")));
	}
	
	@Test
	public void findpdrWithoutTimeout() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(
						jsonPath("_links.timeout").doesNotExist());
	}
		
	@Test
	public void findpdrWithCallbackLink() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(
						jsonPath("_links.callbackcompleted.href",
								endsWith("/v1/private/pdrs/1/callbackcompleted")))
				.andExpect(jsonPath("_links.triggercallback.href", 
                        endsWith("/v1/private/pdrs/1/triggercallback")));
	}
	
	@Test
	public void findpdrWithoutCallbackLink() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(jsonPath("_links.callbackcompleted").doesNotExist())
				.andExpect(jsonPath("_links.triggercallback").doesNotExist());
	}
	
	@Test
	public void findpdrWithSubmitAcqLink() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.submittedacquisition.href",
								endsWith("/v1/private/pdrs/6/submittedacquisition")));
	}
	
	@Test
	public void findpdrWithoutSubmitAcqLink() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/1").header("Authorization",
				"Bearer " + th.createTokenForUser(admin)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("123")))
				.andExpect(
						jsonPath("_links.submittedacquisition").doesNotExist());
	}
	
	@Test
	public void findpdrDontShowProvider() throws Exception {
		mockMvc.perform(get("/v1/private/pdrs/6").header("Authorization",
				"Bearer " + th.createTokenForUser(customerDontShowProvider)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(contentType))
				.andExpect(jsonPath("username", equalTo("myusername")))
				.andExpect(jsonPath("password", equalTo("mypassword")))
				.andExpect(jsonPath("correlationId", equalTo("pending acq")))
				.andExpect(
						jsonPath("_links.provider").doesNotExist());
	}
	
	@Test
	public void createCompletePDR_ValidationFailOnPDRDTO() throws Exception {

		String lengthAbove255 = "1";
		for (int i=0; i<255; i++)
			lengthAbove255 +=  "1";
		
		PDRDTO pdr = new PDRDTO();
		pdr.setAccountNumber(lengthAbove255);
		pdr.setUsername(lengthAbove255);
		pdr.setPassword(lengthAbove255);
		pdr.setPassword2(lengthAbove255);
		pdr.setCorrelationId(lengthAbove255);
		pdr.setCompletionCallbackUrl(lengthAbove255);
		pdr.setTimeout(-100);
		
		MvcResult result = mockMvc
				.perform(
						post("/v1/public/providers/1/pdrs")
								.header("Authorization",
										"Bearer "
												+ th.createTokenForUser(admin))
								.contentType(MediaType.APPLICATION_JSON)
								.content(mapper.writeValueAsString(pdr)))
				.andExpect(status().isBadRequest()).andReturn();
		
		assert(result.getResolvedException()!=null);
		assert(result.getResolvedException().getMessage().contains("accountNumber"));
		assert(result.getResolvedException().getMessage().contains("username"));
		assert(result.getResolvedException().getMessage().contains("password"));
		assert(result.getResolvedException().getMessage().contains("password2"));
		assert(result.getResolvedException().getMessage().contains("correlationId"));
		assert(result.getResolvedException().getMessage().contains("completionCallbackUrl"));
		assert(result.getResolvedException().getMessage().contains("timeout"));
		assert(result.getResolvedException().getMessage().contains("error"));
	}
	
	@Test
	public void submittedAcquisition_ValidationFail() throws Exception {
		String lengthAbove255 = "1";
		for (int i=0; i<255; i++)
			lengthAbove255 +=  "1";
		
		PDRSubmittedAcquisitionDTO dto = new PDRSubmittedAcquisitionDTO();
		dto.setBifrostId(lengthAbove255);
		MvcResult result = mockMvc.perform(
				patch("/v1/private/pdrs/3/submittedacquisition")
						.header("Authorization",
								"Bearer " + th.createTokenForUser(admin))
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(dto))).andExpect(
					status().isBadRequest()).andReturn();
		
		assert(result.getResolvedException()!=null);
		assert(result.getResolvedException().getMessage().contains("bifrostId"));
		assert(result.getResolvedException().getMessage().contains("1 error"));
	}
	
    @Test
    public void testTriggerRetryLinkExists() throws Exception {
        mockMvc.perform(get("/v1/private/pdrs?jobId=fake-bifrost-id-1")
                .header("Authorization", "Bearer " + th.createTokenForUser(admin)))
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("_embedded.privatePDRResourceList", hasSize(1)))
                .andExpect(jsonPath("_embedded.privatePDRResourceList[0]_links.triggerretry", 
                                notNullValue()))
                .andExpect(status().isOk());
    }
    
    @Test
    public void testTriggerRetryLinkDoesntExist() throws Exception {
        mockMvc.perform(get("/v1/private/pdrs?jobId=bfid11111")
                .header("Authorization", "Bearer " + th.createTokenForUser(admin)))
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("_embedded.privatePDRResourceList", hasSize(1)))
                .andExpect(jsonPath("_embedded.privatePDRResourceList[0]_links.triggerretry")
                        .doesNotExist())
                .andExpect(status().isOk());
    }
    
    @Test
    public void testUpdateStatusToInvalidCredentialsLinkExists() throws Exception {
        mockMvc.perform(get("/v1/private/pdrs?jobId=fake-bifrost-id-1")
                .header("Authorization", "Bearer " + th.createTokenForUser(admin)))
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("_embedded.privatePDRResourceList", hasSize(1)))
                .andExpect(jsonPath("_embedded.privatePDRResourceList[0]_links.updatestatustoinvalidcredentials", 
                                notNullValue()))
                .andExpect(status().isOk());
    }
    
    @Test
    public void testUpdateStatusToInvalidCredentialsLinkDoesntExist() throws Exception {
        mockMvc.perform(get("/v1/private/pdrs?jobId=bfid11111")
                .header("Authorization", "Bearer " + th.createTokenForUser(admin)))
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("_embedded.privatePDRResourceList", hasSize(1)))
                .andExpect(jsonPath("_embedded.privatePDRResourceList[0]_links.updatetatustoinvalidcredentials")
                        .doesNotExist())
                .andExpect(status().isOk());
    }

}
