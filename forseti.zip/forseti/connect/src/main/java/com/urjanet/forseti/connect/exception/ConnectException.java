package com.urjanet.forseti.connect.exception;

@SuppressWarnings("serial")
public class ConnectException extends Exception {
	
    public ConnectException(String message, Throwable e) {
        super(message, e);
    }
    
    public ConnectException(String message) {
        super(message);
    }

    public ConnectException() {
        super();
    }
}
