package com.urjanet.forseti.connect.exception;

@Deprecated
public class InvalidStatementException extends Exception {

    public InvalidStatementException() {
        super();
    }

    public InvalidStatementException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidStatementException(String message) {
        super(message);
    }

    public InvalidStatementException(Throwable cause) {
        super(cause);
    }
}
