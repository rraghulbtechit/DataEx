package com.urjanet.forseti.connect.listener;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.aws.core.env.ResourceIdResolver;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.model.Message;
import com.urjanet.bifrost.sdk.BifrostMidgardDocumentUtils;
import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.BifrostResponse;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.exception.ConnectException;
import com.urjanet.forseti.connect.listener.aws.AWSClient;
import com.urjanet.forseti.connect.transform.DomainTransformer;
import com.urjanet.forseti.connect.transform.JsonUtils;
import com.urjanet.forseti.helpers.DTOUtils;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.service.PDRService;
import com.urjanet.midgard.sdk.MidgardDocumentUtils;

@Component
public class JobStatusListener implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(JobStatusListener.class);

    private static int RESULTS_PER_PAGE = 10;
    		
    @Autowired
    private AWSClient awsClient;
    
    @Autowired
    private DomainTransformer domainTransformer;

	@Autowired
	private ResourceIdResolver resourceIdResolver;
	
	@Autowired
	private Tracer tracer;
	
	@Autowired
	private PDRService pdrService;
    
    @Override
    public void run(String... args) throws Exception {
        boolean running = true;
        
        String responseQueue = resourceIdResolver.resolveToPhysicalResourceId(AWSClient.RESPONSE_QUEUE);
        log.debug("Connect JobStatusListener started, waiting on messages...");
        
        while (running) {
            
            Message msg = awsClient.receive(responseQueue, 10);
            
            if (msg == null) {
                continue;
            }

            try {
            	Map<String, String> body = JsonUtils.readJsonToMap(msg.getBody());
                log.debug("Parsing message body: {}", body.get("Message"));
                
                // 1. Convert message into BifrostResponse
                BifrostResponse bifrostResponse = MidgardDocumentUtils.getObjectMapper().readValue(
                		(String)body.get("Message"), BifrostResponse.class);
                
                // This shouldn't happen, but we've seen it occur when bifrost is having issues
                if (bifrostResponse == null) {
                    throw new ConnectException("Got a null bifrostResponse! Message receieved: " + msg.getBody());
                }
                
                BifrostRequest bifrostRequest = BifrostMidgardDocumentUtils.getRequest(bifrostResponse.getBifrostRequest());
                String bifrostId = bifrostResponse.getBifrostId();
                log.debug("Received bifrostResponse {} from bifrost for bifrostID={}", bifrostResponse, bifrostId);
                
        		//create a new span for Sleuth
            	Long traceId = Span.hexToId(bifrostResponse.getTraceId());
        		Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiConnect:JobStatusListener");
        		Span span = builder.build();
        		//continue the span in the trace so it shows up in the logs
        		this.tracer.continueSpan(span);
                
                // 2. Transform BifrostResult to PDS Domain Object
                PDRCompletionDTO pdrComplete = domainTransformer.processBifrostResponse(bifrostResponse, bifrostRequest);
                log.debug("For bifrostID {}, logging the PDRComplete {}", bifrostId, MidgardDocumentUtils.toJson(pdrComplete));
                
                // 3. Lookup the PDR by jobID from the DB
                Page<PDR> pdrs = pdrService.findAllByBifrostId(new PageRequest(0, RESULTS_PER_PAGE), bifrostId);
                
                // There should be only one so pull the first one, throw an error otherwise
                if (pdrs.getTotalElements() == 0) {
                    throw new ConnectException("No pdr found with associated bifrostId = " + bifrostId
                    		+ " => Throwing a ConnectException");
                } else if (pdrs.getTotalElements() > 1) {
                    throw new ConnectException("More than 1 pdr found with associated bifrostId " + bifrostId
                    		+ "=> Throwing a ConnectException");
                }
                PDR pdr = pdrs.getContent().get(0);
                log.debug("Found pdr: {}", pdr);
                
                // 4.1. Was this PDR timedout? If so, Forseti will not update PDR in the database
                if (pdr.getCompletionStatus()!=null && pdr.getCompletionStatus().equals(PDRCompletionStatus.TIMEOUT)) {
                	log.warn("Forseti will *not* update PDR {} since it was timedout. "
                			+ "This is the BifrostResponse {}", pdr.getId(), bifrostResponse);
                	awsClient.deleteMessage(responseQueue, msg.getReceiptHandle());
                	continue;
                }
                
                // 4.2. Was this PDR replayed? 
                // Since Replay is an internal feature, Forseti will not update PDR in the database
                if (bifrostRequest.isReplayRun()) {
                	log.info("Forseti will *not* update PDR {} since it was replayed. "
                			+ "This is the BifrostResponse {}", pdr.getId(), bifrostResponse);
                	awsClient.deleteMessage(responseQueue, msg.getReceiptHandle());
                	continue;
                }
                
                // 4.3. Does this PDR need to be retried and put in PENDING status?
                boolean retryPDR = isThisPDRRetryable(pdrComplete, pdr);
                if (retryPDR) {
                    // 4.3.1. PDR will be retried
                    log.info("PDR {} will be retried by PDS.", pdr.getId());
                    
                    pdr.setRetryAt(calculateNextRetryDate(pdr));
                    pdr.setLastReceivedAt(new Date());
                    // Updating these fields with the latest run. The bifrost database stores details of all runs
                    pdr.setSourceTree(pdrComplete.getSourceTree());
                    pdr.setLogsId(pdrComplete.getLogsId());
                    
                    // 5.1. Update database and trigger callback (if needed)
                    if (pdr.getCompletionStatus()!=null && 
                    		pdr.getCompletionStatus().equals(PDRCompletionStatus.PENDING)) {
                    
                        // CompletionStatus was already set to PENDING => Do not trigger callback!
                        log.info("PDR {} already had a PENDING status. Since there is no change in status, "
                        		+ "no callback is triggered.", pdr.getId());
                        pdrService.save(pdr);
                        
                    } else {
                        // Update database and trigger callback
                        log.info("Updated PDR {} with status=PENDING. This change in status triggers a callback.", pdr.getId());
                        pdr.setCompletionStatus(PDRCompletionStatus.PENDING);
                        pdr.setCompletionStatusDetail(PDRCompletionStatusDetail.RETRYING_UNTIL_EXPIRATION.toString());
                        pdrService.save(pdr);
                        pdrService.triggerCallback(pdr);
                    }
                    
                } else {
                    // 4.3.2. PDR will not be retried
                    log.info("PDR {} will not be retried by PDS.", pdr.getId());
                    
            		pdr.setRetryAt(null);
                    
                	pdr.setCompletionStatus(PDRCompletionStatus.valueOf(pdrComplete.getCompletionStatus()));
        			pdr.setCompletionStatusDetail(pdrComplete.getCompletionStatusDetail());
        			pdr.setCompletedAt(pdrComplete.getCompletedAt());
        			pdr.setSourceTree(pdrComplete.getSourceTree());
        			pdr.setLogsId(pdrComplete.getLogsId());
        	
        			// Process statements
        			Set<Statement> statements = new HashSet<Statement>();
        			if (pdrComplete.getStatements() != null) {
        				pdrComplete.getStatements().forEach((dto) -> statements.add(DTOUtils.statementFromDTO(dto, pdr.getId())));
        				pdr.setStatements(statements);
        			}
        	
        			// 5.2. Update database and trigger callback
        			int size = (pdrComplete.getStatements() == null) ? 0 : pdrComplete.getStatements().size();
        			log.info("Updated PDR {} with status={}|{} and {} statements. This change in status triggers a callback.", 
        			        pdr.getId(), pdr.getCompletionStatus().name(), pdr.getCompletionStatusDetail(), size);
        			pdrService.save(pdr);
        			pdrService.triggerCallback(pdr);
                }
                
                // 6. Publish failure notification
                String failureTopicArn = resourceIdResolver.resolveToPhysicalResourceId(AWSClient.FAILURE_TOPIC);
                awsClient.notifyFailure(retryPDR, pdr, pdrComplete, bifrostRequest, bifrostResponse, failureTopicArn);
                
                // 7. Delete message from the queue if it was successfully processed
                awsClient.deleteMessage(responseQueue, msg.getReceiptHandle());
               
            } catch (ConnectException e) {
                log.error("Error occured while processing response message {}", e.toString(), e);
            } catch (Exception e) {
                log.error("Unexpected Error!", e);
            } finally {
                // TODO - What goes in here?
            }
        }
    }

	/* This function returns true if a PDR should be retried by PDS and put
     * in PENDING state.
     * 
     * The following conditions must be met: 
     *  1. completionStatus == FAILURE
     *  2. completionStatusDetail == GENERAL_FAILURE
     *  3. expirationDate >= now() + 4 hours
     */
    public boolean isThisPDRRetryable(PDRCompletionDTO pdrComplete, PDR pdr) {
        Date now = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(Calendar.HOUR_OF_DAY, 4);
        
        if ( pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.FAILURE.name())
                && pdrComplete.getCompletionStatusDetail().equals(ResultCode.GENERAL_FAILURE.name())
                && pdr.getExpirationDate().getTime() - cal.getTime().getTime() >= 0 )
            
            return true;
         
        return false;
         
    }
    
	/* This function returns the date at which the PDR should be retried next.
     * 
     * The following logic is used: 
     * 
     *  if expirationDate > now + 24 hours
     *      retryAt = now + 24 hours
     *      
     *  else if expirationDate - 4 hours >= now
     *  	retryAt = expirationDate - 4 hours
     */
    public Date calculateNextRetryDate(PDR pdr) {
		Date retryAt = null;
		
		Date now = new Date();
		
		Calendar calNow = Calendar.getInstance();
		calNow.setTime(now);
        
		Calendar nowPlus24 = Calendar.getInstance();
		nowPlus24.setTime(now);
		nowPlus24.add(Calendar.HOUR_OF_DAY, 24);
        
		Calendar expirationMinus4 = Calendar.getInstance();
		expirationMinus4.setTime(pdr.getExpirationDate());
		expirationMinus4.add(Calendar.HOUR_OF_DAY, -4);
        
		if (pdr.getExpirationDate().getTime() > nowPlus24.getTime().getTime()) {
			retryAt = nowPlus24.getTime();
		
		} else {
			if (expirationMinus4.getTime().getTime() >= calNow.getTime().getTime())
				retryAt = expirationMinus4.getTime();
		}
		
		return retryAt;
	}    
}
