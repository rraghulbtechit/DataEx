package com.urjanet.forseti.connect.transform;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.urjanet.midgard.sdk.MidgardDocumentUtils;

public class JsonUtils {

	private static ObjectMapper jsonMapper = MidgardDocumentUtils.getObjectMapper();
	
    public static Map<String, String> readJsonToMap(String json) throws Exception {
        Map<String, String> map = new HashMap<>();
        
        JsonNode node = jsonMapper.readTree(json);
        
        node.fields().forEachRemaining(n -> {
            map.put(n.getKey(), n.getValue().asText());
        });
        
        return map;
    }
	
}