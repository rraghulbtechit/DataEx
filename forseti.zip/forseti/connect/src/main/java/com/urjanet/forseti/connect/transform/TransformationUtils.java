package com.urjanet.forseti.connect.transform;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.urjanet.bifrost.sdk.AccountNumberUtils;
import com.urjanet.bifrost.sdk.BifrostMidgardDocumentUtils;
import com.urjanet.bifrost.sdk.BifrostResponse;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.domain.Address;
import com.urjanet.forseti.connect.domain.Statement;

import urjanet.clean.format.FormatException;
import urjanet.clean.format.Formatter;
import urjanet.clean.format.FormatterAddress;
import urjanet.clean.format.FormatterFactory;
import urjanet.keys.AccountKeys;
import urjanet.keys.AddressKeys;
import urjanet.keys.DataValues;
import urjanet.keys.MetaKeys;
import urjanet.keys.RecentPaymentKeys;
import urjanet.keys.SummaryKeys;
import urjanet.keys.TemporalKeys;
import urjanet.keys.uds.GroupingKeys;
import urjanet.pull.core.Extract;
import urjanet.pull.core.ExtractValue;
import urjanet.util.CalendarUtils;

/* Dev Note:
 *  This class will look very different when ymir is live.
 */
public class TransformationUtils {
	
	private static final Logger LOG = LoggerFactory.getLogger(TransformationUtils.class);  
	
	static String statementGroupKey = GroupingKeys.STATEMENT_GROUP.getValue();
	static String additionalProviderGroupKey = GroupingKeys.ADDITIONAL_PROVIDER.getValue();
	static String accountNumberKey = AccountKeys.ACCOUNT_NUMBER.getValue();
    static String totalKey = SummaryKeys.AMOUNT_DUE.getValue();
    static String totalKeyBackup = SummaryKeys.TOTAL_BILL_AMOUNT.getValue();
    static String dueDateKey = SummaryKeys.AMOUNT_DUE_BY_DATE.getValue();
    static String periodStartKey = TemporalKeys.PERIOD_START_DATE.getValue();
    static String periodEndKey = TemporalKeys.PERIOD_END_DATE.getValue();
    static String statementDateKey = SummaryKeys.STATEMENT_DATE.getValue();
        
    
    public static ResultCode validateExtract(BifrostResponse bifrostResponse, ResultCode acquisitionResultCode) 
    		throws JsonParseException, JsonMappingException, IOException {
    	
		if (acquisitionResultCode != ResultCode.SUCCESS)
			return acquisitionResultCode;
		
    	/* 2 step process for validating the legacy extract object -
    	 * 	1. Check for CRITICAL and ERROR events as found by the legacy engine
    	 * 	2. Check for validity of required fields (AccountNumber and StatementDate).
    	 */
		return validateRequiredFields(BifrostMidgardDocumentUtils.getExtractionResult(bifrostResponse.getExtractionResult()), 
									FormatterFactory.getFormatter(/*TODO: localeId*/));
    }
    
	// This method will return a map of accounts -> list of statements given an extract and 
    // validation ResultCode
    public static Map<String, List<Statement>> processExtract(Extract extract, ResultCode validateResult) {
    	
    	Map<String, List<Statement>> statements = new HashMap<String, List<Statement>>();
    	if (validateResult == ResultCode.SUCCESS) {
			try {
				statements = transformExtract(extract, FormatterFactory.getFormatter(/*TODO: localeId*/));
			} catch (FormatException e) {
				LOG.warn("Encountered error in transformation: " + e.getMessage());
			}
		}
    	return statements;
    }
    
	/*  Validation 2 - If AccountNumber and StatementDate are not valid for any statement, 
	 * 		don't error out the entire result and call this a a PARTIAL_DELIVERY, unless
	 * 		all statements fail on these audits and then we error out with ACQUISITION_FAILURE.
	 */
	public static ResultCode validateRequiredFields(Extract extract, Formatter formatter) {
		LOG.debug("Validating extract required fields");
		
		ResultCode code = ResultCode.SUCCESS;

        List<Extract> statementExtracts = getStatementExtracts(extract);
        
        int numberErrors = 0;
        int numberStatements = (statementExtracts == null) ? 0 : statementExtracts.size();
        for (Extract statementExtract : statementExtracts) {
            boolean errorInStatement = false;
        	
        	LOG.debug("Validating required fields for {}", statementExtract.getName());
        	
            String accountNumber = findStringExtractValue(statementExtract, accountNumberKey);
            if (StringUtils.isBlank(accountNumber)) {
            	LOG.warn("Required field (AccountNumber) is invalid.");
            	//code = ResultCode.ACQUISITION_FAILURE;
            	errorInStatement = true;
            }

            Date statementDate = null; 
            Date periodStart = null; 
            Date periodEnd = null; 
            try {
            	
            	periodStart = parseExtractDate(statementExtract, periodStartKey, null, formatter);
 	            periodEnd = parseExtractDate(statementExtract, periodEndKey, null, formatter);
            	statementDate = parseExtractDate(statementExtract, statementDateKey, null, formatter);
            	
            } catch (FormatException e) {
            	LOG.warn("Failed to format dates in " + statementExtract.getName(), e);
            	
            } finally {
            	statementDate = verifyStatementDate(statementDate, periodEnd, periodStart);
            	
            	if (statementDate == null) {
 	            	LOG.warn("Required field (StatementDate) is invalid.");
 	            	//code = ResultCode.ACQUISITION_FAILURE;
 	            	errorInStatement = true;
 	            }
            }
            
            if (errorInStatement) {
                numberErrors ++;
                LOG.error("Since at least one required field is invalid, we will discard "
                        + "statement for {}.", statementExtract.getName());
            }
        }
        
        if (numberErrors > 0) {
            LOG.info("numberErrors = "  + numberErrors);
            LOG.info("numberStatements = "  + numberStatements);
            code = (numberErrors == numberStatements) ? ResultCode.ACQUISITION_FAILURE
                                                      : ResultCode.PARTIAL_DELIVERY;
        }
        
		LOG.info("Finished validation with a result code of " + code.name());
		return code;
	}

	
	/* 	
	 * This function transforms the legacy Extract object into fields needed by PDS.
	 * This will remain a lossy transformation till we enhance it to parse out all UDS-related fields.
	 * 
	 * 	@param	Extract
	 * 	@return Map<String, List<Statement>> 
	 */
	public static Map<String, List<Statement>> transformExtract(Extract extract, Formatter formatter) throws FormatException {
		LOG.debug("Transforming extract into Statement entities");
		
        List<Statement> statements = new ArrayList<Statement>();
        
        /* Build a list of Statements by iterating over extract's statement groups. 
         * 
         * Not sure if there is a more efficient way to parse/query extract (ask for all ACCOUNTS??);
         * that can help us build our result faster.
         * (extract.getExtractValuesMap();?)
         */
        List<Extract> statementExtracts = getStatementExtracts(extract);
        
        for (Extract statementExtract : statementExtracts) {
        	
            Statement statement = new Statement();
            
            String accountNumber = findStringExtractValue(statementExtract, accountNumberKey);
            // Use Normalized AccountNumber inside bifrost
            statement.setAccountNumber(AccountNumberUtils.normalizeAccountNumber(accountNumber));
            
            // TODO: remove default USD and add other currency when supported
            statement.setPaymentCurrency("USD");
            
        	Date periodStart = parseExtractDate(statementExtract, periodStartKey, null, formatter);
            Date periodEnd = parseExtractDate(statementExtract, periodEndKey, null, formatter);
            statement.setPeriodStart(periodStart);
            statement.setPeriodEnd(periodEnd);
            
            Date statementDate = parseExtractDate(statementExtract, statementDateKey, null, formatter);
            statement.setStatementDate(verifyStatementDate(statementDate, periodEnd, periodStart));
          
            BigDecimal totalBill = parseExtractBigDecimal(statementExtract, totalKey, null);
            if (totalBill == null)
                totalBill = parseExtractBigDecimal(statementExtract, totalKeyBackup, null);
            statement.setTotalBill(totalBill);           
            
            statement.setDueDate(parseExtractDate(statementExtract, dueDateKey, statement.getStatementDate(), true, formatter)); // due date should be after statement date
            
            statement.setRecentPayment(sumRecentPayments(statementExtract));
            statement.setRecentPaymentDate(mostRecentPayment(statementExtract, statement.getStatementDate(), formatter)); 
            
            try {
            	statement.setAddress(parseAddress(statementExtract));
            } catch (FormatException e) {
                LOG.warn("Ignoring FormatException while parsing address, setting address to null: " + e.getMessage());
            }
            
            statement.setSourceIds(StringUtils.join(statementExtract.getSourceNodes(), ","));
            
            statements.add(statement);
            LOG.debug("statement = {}", statement);
        }
                
		// Iterate over the statements to build the result, Might need to figure out how to query extract better
        Map<String, List<Statement>> mapAccountsToStatements = new HashMap<String, List<Statement>>();
        for (Statement statement: statements) {
        	String accountNumber = statement.getAccountNumber();
        	List<Statement> accountStatements = null;
        	if (mapAccountsToStatements.get(accountNumber) == null) {
        		accountStatements = new ArrayList<Statement>();
        	} else {
        		accountStatements = mapAccountsToStatements.get(accountNumber);
        	}
        	accountStatements.add(statement);
        	
        	mapAccountsToStatements.put(accountNumber, accountStatements);
        }
        
		return mapAccountsToStatements;
    }

	
	/**
	 * Returns a list of main-provider StatementGroup Extracts, 
	 * given a woot Extract. True additional provider statements
	 * will not be returned.
	 * 
	 * @param wootExtract
	 * @return
	 */
	private static List<Extract> getStatementExtracts(Extract wootExtract) {
//		if (!wootExtract.getName().equals("woot"))
//			throw new UrjanetRuntimeException("Cannot perform getStatementExtracts() on a non-woot extract");
		
		List<Extract> statementExtracts = new ArrayList<Extract>();
		
        Map<String, Extract> subWootExtractMap = wootExtract.getSubExtractMap();
        for (String group : subWootExtractMap.keySet()) {
        	
        	if (group.startsWith(statementGroupKey)) {
        		statementExtracts.add(subWootExtractMap.get(group));
        		
        	} else if (group.startsWith(additionalProviderGroupKey)) {
        		Extract additionalProviderExtract = subWootExtractMap.get(group);
        		String providerRelationship = additionalProviderExtract.getValue(MetaKeys.PROVIDER_RELATIONSHIP.getValue());
        		
        		if (providerRelationship == null || providerRelationship.equals(DataValues.RELATED_PROVIDER.getValue())) {
        			LOG.debug("Skipping statements for additional provider {} in group {}", 
        					additionalProviderExtract.getValue(MetaKeys.PROVIDER_ID.getValue()), 
        					additionalProviderExtract.getName());
        			continue;
        		}
        		
        		Map<String, Extract> subAPExtractMap = additionalProviderExtract.getSubExtractMap();
        		for (String group2 : subAPExtractMap.keySet()) {
        			if (group2.startsWith(statementGroupKey)) {
        				statementExtracts.add(subAPExtractMap.get(group2));
        			} else {
        				LOG.warn("Encountered unknown subextract of {}: {}, while building statements", additionalProviderGroupKey, group2);
        			}
        		}
        	} else {
				LOG.warn("Encountered unknown subextract of woot: {}, while building statements", group);
        	}
        }
        
        return statementExtracts;
	}
	
	    
    public static Address parseAddress(Extract currentExtract) throws FormatException {
		
        // If there is no billing address, then return an empty Address 
        Extract billingAddressSubExtract = findBillingAddressGroup(currentExtract);
        if (billingAddressSubExtract == null) { 
            return new Address();
        }

        String recipient = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RECIPIENT1.getValue());
        String recipient2 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RECIPIENT2.getValue());
        String addrSt1 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_STREET1.getValue());
        String addrSt2 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_STREET2.getValue());
        String city = findStringExtractValue(billingAddressSubExtract, AddressKeys.CITY.getValue());
        String postCode = findStringExtractValue(billingAddressSubExtract, AddressKeys.POSTAL_CODE.getValue());
        String state = findStringExtractValue(billingAddressSubExtract, AddressKeys.STATE_PROVINCE.getValue());
        
        // Set base formatter
        FormatterAddress baseFmt = new FormatterAddress();
        baseFmt.setStreet1(addrSt1);
        baseFmt.setStreet2(addrSt2);
        baseFmt.setCity(city);
        baseFmt.setPostal(postCode);
        baseFmt.setState(state);
        baseFmt.setAddressRecipient1(recipient);
        baseFmt.setAddressRecipient2(recipient2);
        
        // Parse the full address if its not null
        Formatter addrFmttr = FormatterFactory.getFormatter();
        String fullAddr = findStringExtractValue(billingAddressSubExtract, AddressKeys.FULL_ADDRESS.getValue());
        if (fullAddr != null) {
            FormatterAddress fullFmt = addrFmttr.formatAddress(fullAddr);
            // merge the parsed into the base
            baseFmt.merge(fullFmt);
        }
        
        // Grab the raws and attempt them
        String raw1 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_1.getValue());
        String raw2 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_2.getValue());
        String raw3 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_3.getValue());
        String raw4 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_4.getValue());
        String raw5 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_5.getValue());
        String raw6 = findStringExtractValue(billingAddressSubExtract, AddressKeys.ADDRESS_RAW_6.getValue());
        
        if (raw1 != null || raw2 != null || raw3 != null || raw4 != null || raw5 != null || raw6 != null) {
            FormatterAddress rawFmt = new FormatterAddress(raw1, raw2, raw3, raw4, raw5, raw6);
            FormatterAddress rawCleanFmt = addrFmttr.formatAddress(rawFmt.getUnformattedRawLines());
            
            // merge into base
            baseFmt.merge(rawCleanFmt);
        }
        
        Address address = new Address();
        address.setBillingName(baseFmt.getAddressRecipient1());
        address.setBillingStreet1(baseFmt.getStreet1());
        address.setBillingStreet2(baseFmt.getStreet2());
        address.setBillingCity(baseFmt.getCity());
        address.setBillingPostalCode(baseFmt.getPostal());
        address.setBillingState(baseFmt.getState());
        return address;
    }

	private static String findStringExtractValue(Extract extract, String key) {
	    ExtractValue value = findExtractValue(extract, key);
	    
	    if (value != null) {
	        return value.getValue();
	    } else {
	        return null;
	    }
	}
	
	private static List<String> findStringExtractValues(Extract extract, String key) {
	    List<ExtractValue> values = findExtractValues(extract, key);
	    
	    List<String> retValues = null;
	    
	    if (values != null) {
	    	retValues = new ArrayList<>();
	    	for (ExtractValue value : values) {
			    if (value != null) {
			    	retValues.add(value.getValue());
			    }
	    	}
	    }
	    
	    return retValues;
	}
	
	private static ExtractValue findExtractValue(Extract extract, String key) {
	    ExtractValue value = extract.getExtractValuesMap().get(key);
	
	    if (value == null && extract.getSubExtractMap() != null) {
	        for (Extract subExtract : extract.getSubExtractMap().values()) {
	            value = findExtractValue(subExtract, key);
	
	            if (value != null) {
	                return value;
	            }
	        }
	    }
	
	    return value;
	}
	
	private static List<ExtractValue> findExtractValues(Extract extract, String key) {
	    
	    List<ExtractValue> retVals = new ArrayList<>();

	    ExtractValue value = extract.getExtractValuesMap().get(key);
	    if (value != null)
	    	retVals.add(value);
	    
	    if (extract.hasExtracts()) {
	    	for (Extract subExtract : extract.getSubExtractMap().values()) {
	    		retVals.addAll(findExtractValues(subExtract, key));
	    	}
	    }
	
	    return retVals;
	}

    /**
     * Checks if the extract is a billing_address subextract. If not, recursively calls itself on the subextract map.
     *
     * @param extract
     * @return a billing_address subextract if it exists; null if not
     */
    public static Extract findBillingAddressGroup(Extract extract) {
        ExtractValue addressTypeId = extract.getExtractValue(AddressKeys.ADDRESS_TYPE_ID.getValue());
        if (addressTypeId != null && StringUtils.equals(DataValues.BILLING_ADDRESS.getValue(), addressTypeId.getValue())) {
            return extract;
        }

        if (extract.getSubExtractMap() != null) {
            for (Extract subExtract : extract.getSubExtractMap().values()) {
                Extract target = findBillingAddressGroup(subExtract);

                if (target != null) {
                    return target;
                }
            }
        }

        return null;
    }
	
	private static BigDecimal parseExtractBigDecimal(Extract extract, String key, String hint) throws FormatException {
	    String numberStr = findStringExtractValue(extract, key);
	    if (numberStr != null && !numberStr.isEmpty()) {
	        return FormatterFactory.getFormatter().formatCurrency(numberStr, hint);
	    }
	    return null;
	}
	
	private static BigDecimal sumExtractBigDecimal(Extract extract, String key, String hint) throws FormatException {
	    List<String> numberStr = findStringExtractValues(extract, key);
	    BigDecimal ret = null;
	    
	    if (numberStr != null && !numberStr.isEmpty()) {
	    	ret = new BigDecimal(0);
	    	for (String num : numberStr) {
			    if (num != null && !num.isEmpty()) {
			        ret = ret.add(FormatterFactory.getFormatter().formatCurrency(num, hint));
			    }
	    	}
	    }
	    return ret;
	}

    private static Date parseExtractDate(Extract extract, String key, Date referenceDate, Formatter formatter) throws FormatException {
    	return parseExtractDate(extract, key, referenceDate, false, formatter);
    }

    private static List<Date> parseExtractDates(Extract extract, String key, Date referenceDate, Formatter formatter) throws FormatException {
    	return parseExtractDates(extract, key, referenceDate, false, formatter);
    }
    
	private static Date parseExtractDate(Extract extract, String key, Date referenceDate, boolean forceAfter, Formatter formatter) throws FormatException {
	    ExtractValue ev = findExtractValue(extract, key);
	    
	    if (ev == null) {
	        return null;
	    }
	    
	    String dateStr = ev.getValue();
	    String formatHint = ev.getFormatHint();
	    
	    return parseDate(dateStr, formatHint, referenceDate, forceAfter, formatter);
	}
    
	private static List<Date> parseExtractDates(Extract extract, String key, Date referenceDate, boolean forceAfter, Formatter formatter) throws FormatException {
	    List<ExtractValue> evs = findExtractValues(extract, key);
	    
	    if (evs == null) {
	        return null;
	    }
	    
	    List<Date> retDates = new ArrayList<>();
	    
	    for (ExtractValue ev : evs) {
	    
		    String dateStr = ev.getValue();
		    String formatHint = ev.getFormatHint();
		    
		    retDates.add(parseDate(dateStr, formatHint, referenceDate, forceAfter, formatter));
	    }
	    
	    return retDates;
	}
	
	public static Date parseDate(String dateStr, String formatHint, Date referenceDate, boolean forceAfter, Formatter formatter) throws FormatException {
	    Date date = formatter.formatDate(dateStr, formatHint);
	    
	    //LOG.debug("Date string, {}, with format hint {} parsed into {}", dateStr, formatHint, date);
	    return verifyYear(date, referenceDate, forceAfter);
	}
	
	
	/*
	 *	@param forceAfter If true, force new date to be after reference date by adding a year if needed. 
	 *		If false, force new date to be before reference date if needed. 
	 *		If incoming date already has year specified, this does not do anything.
	 *
	 *	@return	Date
	*/
	private static Date verifyYear(Date date, Date referenceDate, boolean forceAfter) {
	    if (referenceDate == null) {
	        return date;
	    }
	    
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    // In order to trust date comparisons (before/after calls)
	    // we need to zero-out all time fields
	    cal.set(Calendar.HOUR, 0);
	    cal.set(Calendar.HOUR_OF_DAY, 0);
	    cal.set(Calendar.MINUTE, 0);
	    cal.set(Calendar.SECOND, 0);
	    cal.set(Calendar.MILLISECOND, 0);
	    date = cal.getTime();
	    
	    Calendar refCal = Calendar.getInstance();
	    refCal.setTime(referenceDate);
	    refCal.set(Calendar.HOUR, 0);
	    refCal.set(Calendar.HOUR_OF_DAY, 0);
	    refCal.set(Calendar.MINUTE, 0);
	    refCal.set(Calendar.SECOND, 0);
	    refCal.set(Calendar.MILLISECOND, 0);
	    referenceDate = refCal.getTime();
	
	    int refYear = refCal.get(Calendar.YEAR);
	    int initYear = cal.get(Calendar.YEAR);
	
	    // If year is too early, it wasn't parsed (got some default year), try to backfill using reference date
	    if (initYear <= 1970 && refYear > 1970) {
	        cal.set(Calendar.YEAR, refYear);

	        if (forceAfter && cal.getTime().before(referenceDate)) { // if force after
	        	cal.add(Calendar.YEAR, 1);
	        	date = cal.getTime();
	        } else { // choose date nearest referenceDate, checking +/- 1 year from reference year
	        	
	        	// default to same year date as the return value
	        	date = cal.getTime();
	        	cal.set(Calendar.YEAR, refYear - 1);
	        	Date prevYearDate = cal.getTime();
	        	cal.set(Calendar.YEAR, refYear + 1);
	        	Date nextYearDate = cal.getTime();
	        	
	        	int diff = Math.abs(CalendarUtils.numberOfDaysIn(date, referenceDate));
	        	int diff2 = Math.abs(CalendarUtils.numberOfDaysIn(prevYearDate, referenceDate));
	        	
	        	// previous year date is closer to the reference date
	        	if (diff2 < diff) {
	        		date = prevYearDate;
	        		diff = diff2;
	        	}
	        	
	        	diff2 = Math.abs(CalendarUtils.numberOfDaysIn(nextYearDate, referenceDate));
	        	
	        	// next year date is closer to the reference date
	        	if (diff2 < diff) {
	        		date = nextYearDate;
	        	}
	        }
	    }
	    
	    return date;
	}
	
	/**
	 * This method will try to clean the statement date.  If the date is incomplete (i.e. missing year in most cases)
	 * It will look though the list of refrence dates and find the latest year and attach that to the date.
	 * 
	 * In the case that the statement date is completely empty, we'll use the first reference date as a default.  Use
	 * care when passing those values in due to this behavior.  For forseti, we'll default to the period end date, so
	 * that value will be first in the list.
	 * 
	 * @param statement
	 * @param referenceDates
	 */
	private static Date verifyStatementDate(Date statementDate, Date... referenceDates ) {
		Date validStatementDate = statementDate;
		
	    if (statementDate == null) {
	        // Default to the first reference date if it exists
	    	// TODO: we should probably use the latest date? Are we possibly passing in next bill XXX dates?
	        if (referenceDates != null && referenceDates.length > 0) {
	        	validStatementDate = referenceDates[0];
	        }
	        
	        return validStatementDate;
	    }
	    
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(statementDate);
	    if (cal.get(Calendar.YEAR) > 1970) {
		    //LOG.debug("Statement date appears to have a sane year: {}", statementDate);
	        return validStatementDate;
	    }
	    
	   // LOG.debug("No year found on stmtDate, looking at input reference years");
	    // Ruh-ro! missing year on stmt date, take the list of referenceDates passed in and figure out the largest year
	    // I'm making assumptions that the statement date should logically be in the latest year seen.  We'll see if this
	    // holds true in the future.
	    if (referenceDates != null && referenceDates.length > 0) {
	        int maxYear = Arrays.asList(referenceDates).stream()
	        .map(d -> {
	        	cal.setTime(d);
	            return cal.get(Calendar.YEAR);
	        })
	        .max(Integer::compareTo)
	        .get();
	        
	        //LOG.debug("Setting year of stmtdate to max year found: {}", maxYear);
	        cal.setTime(statementDate);
	        cal.set(Calendar.YEAR, maxYear);
	        validStatementDate = cal.getTime();
	    }
	    
	    return validStatementDate;
	}
	
    private static BigDecimal sumRecentPayments(Extract extract) throws FormatException {
        List<BigDecimal> recents = new ArrayList<>(0);

        recents.add(sumExtractBigDecimal(extract, RecentPaymentKeys.RECENT_PAYMENTS.getValue(), null));
        
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS2.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS3.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS4.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS5.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS6.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS7.getValue(), null));
        recents.add(parseExtractBigDecimal(extract, SummaryKeys.RECENT_PAYMENTS8.getValue(), null));
        
        if (recents.stream().filter(p -> p != null).count() == 0) {
            return null;
        } else {
            return recents.stream().filter(p -> p != null).reduce(BigDecimal.ZERO, BigDecimal::add);
        }
    }
    
    
    private static Date mostRecentPayment(Extract extract, Date referenceDate, Formatter formatter) throws FormatException {
        List<Date> recentDates = new ArrayList<>();

        recentDates.addAll(parseExtractDates(extract, RecentPaymentKeys.RECENT_PAYMENTS_DATE_RECEIVED.getValue(), referenceDate, formatter));
        
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS2_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS3_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS4_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS5_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS6_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS7_DATE_RECEIVED.getValue(), referenceDate, formatter));
        recentDates.add(parseExtractDate(extract, SummaryKeys.RECENT_PAYMENTS8_DATE_RECEIVED.getValue(), referenceDate, formatter));
        
        
        if (recentDates.stream().filter(p -> p != null).count() == 0) {
            return null;
        } else {
            return recentDates.stream().filter(p -> p != null).max(Date::compareTo).get();
        }
    }
    
}
