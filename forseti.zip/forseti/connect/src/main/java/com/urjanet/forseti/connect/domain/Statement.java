package com.urjanet.forseti.connect.domain;

import java.math.BigDecimal;
import java.util.Date;

public class Statement {

	private Address address;

	private String accountNumber;
	
	private BigDecimal totalBill;
	
	private Date periodStart;
	
	private Date periodEnd;
	
	private Date dueDate;
	
	private String paymentCurrency;
	
	private Date statementDate;
	
	private BigDecimal recentPayment;
	
	private Date recentPaymentDate;
	
	private String sourceIds;
	
	// TODO - Add more fields when needed - amountDue, datePaid..
	
	public Statement() {
		super();
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getTotalBill() {
		return totalBill;
	}

	public void setTotalBill(BigDecimal totalBill) {
		this.totalBill = totalBill;
	}

	public Date getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(Date periodStart) {
		this.periodStart = periodStart;
	}

	public Date getPeriodEnd() {
		return periodEnd;
	}

	public void setPeriodEnd(Date periodEnd) {
		this.periodEnd = periodEnd;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public Date getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public BigDecimal getRecentPayment() {
		return recentPayment;
	}

	public void setRecentPayment(BigDecimal recentPayment) {
		this.recentPayment = recentPayment;
	}

	public Date getRecentPaymentDate() {
		return recentPaymentDate;
	}

	public void setRecentPaymentDate(Date recentPaymentDate) {
		this.recentPaymentDate = recentPaymentDate;
	}

	public String getSourceIds() {
		return sourceIds;
	}
	
	public void setSourceIds(String sourceIds) {
		this.sourceIds = sourceIds;
	}
	
	@Override
	public String toString() {
		return "Statement [address=" + address + ", accountNumber=" + accountNumber + ", totalBill=" + totalBill
				+ ", periodStart=" + periodStart + ", periodEnd=" + periodEnd + ", dueDate=" + dueDate
				+ ", paymentCurrency=" + paymentCurrency + ", statementDate=" + statementDate + ", recentPayment="
				+ recentPayment + ", recentPaymentDate=" + recentPaymentDate 
				+ ", sourceIds=" + sourceIds 
				+ "]";
	}
		
	
	
}