package com.urjanet.forseti.connect.listener.aws;

public class ForsetiFailureMessage {
    
    private String timestamp;
    
	// Provider Info
	private String providerId;
	private String providerAlias;
	private String acquisitionTemplate;
    private String extractionTemplate;
    
    // Bifrost Unique IDs
	private String bifrostId;
	private String traceId;
	private String monocleLink;
	
	// Result info
	private String resultCode;
	private String resultDetail;
	
	// Non-forseti status
	private String acquisitionStatus;
	private String extractionStatus;
	private String transformationStatus;
	
	// Logs info
	private String s3BucketKey;
	private String s3BucketName;
	
	// Request Info
	private String customer;
	private String createdAt;
	
	// Enhanced error handling
	private Integer retryCount;
	private String retryAt;
	private String expirationDate;
	
	public ForsetiFailureMessage() { }

	public String getTimestamp() {
        return timestamp;
    }    

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }    

    public String getProviderId() {
		return providerId;
	}

    public String getMonocleLink() {
        return monocleLink;
    }    

    public void setMonocleLink(String monocleLink) {
        this.monocleLink = monocleLink;
    }    

    public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	
	public String getProviderAlias() {
		return providerAlias;
	}
	
	public void setProviderAlias(String providerAlias) {
		this.providerAlias = providerAlias;
	}

	public String getAcquisitionTemplate() {
		return acquisitionTemplate;
	}

	public void setAcquisitionTemplate(String acquisitionTemplate) {
		this.acquisitionTemplate = acquisitionTemplate;
	}

	public String getExtractionTemplate() {
		return extractionTemplate;
	}

	public void setExtractionTemplate(String extractionTemplate) {
		this.extractionTemplate = extractionTemplate;
	}

	public String getBifrostId() {
		return bifrostId;
	}

	public void setBifrostId(String bifrostId) {
		this.bifrostId = bifrostId;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
	
	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultDetail() {
		return resultDetail;
	}

	public void setResultDetail(String resultDetail) {
		this.resultDetail = resultDetail;
	}    
	
    public String getAcquisitionStatus() {
        return acquisitionStatus;
    }    

    public void setAcquisitionStatus(String acquisitionStatus) {
        this.acquisitionStatus = acquisitionStatus;
    }
    
    public String getExtractionStatus() {
        return extractionStatus;
    }    

    public void setExtractionStatus(String extractionStatus) {
        this.extractionStatus = extractionStatus;
    }    

    public String getTransformationStatus() {
        return transformationStatus;
    }    

    public void setTransformationStatus(String transformationStatus) {
        this.transformationStatus = transformationStatus;
    }    

    public String getS3BucketKey() {
		return s3BucketKey;
	}

	public void setS3BucketKey(String s3BucketKey) {
		this.s3BucketKey = s3BucketKey;
	}

	public String getS3BucketName() {
		return s3BucketName;
	}

	public void setS3BucketName(String s3BucketName) {
		this.s3BucketName = s3BucketName;
	}
	
	public String getCustomer() {
		return customer;
	}
	
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	
	public String getCreatedAt() {
		return createdAt;
	}
	
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	
	public Integer getRetryCount() {
        return retryCount;
    }
	
	public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }
	
	public String getRetryAt() {
		return retryAt;
	}
	
	public void setRetryAt(String retryAt) {
		this.retryAt = retryAt;
	}
	
	public String getExpirationDate() {
        return expirationDate;
    }
	
	public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
	
}