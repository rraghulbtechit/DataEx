package com.urjanet.forseti.connect.transform;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.urjanet.bifrost.sdk.BifrostMidgardDocumentUtils;
import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.BifrostResponse;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.domain.Statement;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.helpers.StatementDTO;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;

import urjanet.pull.core.Extract;

/* Dev Note:
 *  This class will look very different when ymir is live.
 */
@Component
public class DomainTransformer {
	
	private static final Logger LOG = LoggerFactory.getLogger(DomainTransformer.class);
    
    private static List<String> validBifrostStatuses = new ArrayList<String>();
    
    static {
        validBifrostStatuses.add(ResultCode.CREDENTIALS_INVALID.name());
        validBifrostStatuses.add(ResultCode.GENERAL_FAILURE.name());
        validBifrostStatuses.add(ResultCode.UNSUPPORTED_ACCOUNT_PREPAID.name());
        validBifrostStatuses.add(ResultCode.USER_ACTION_REQUIRED.name());
        validBifrostStatuses.add(ResultCode.MULTI_FACTOR_AUTH_FAILURE.name());
        validBifrostStatuses.add(ResultCode.LIMITED_ACCESS.name());
        validBifrostStatuses.add(ResultCode.WEBSITE_DOWN.name());
        validBifrostStatuses.add(ResultCode.MISSING_REQUIRED_PARAMETER.name());
    }

    public DomainTransformer( ) {
        super();
    }
    
    // TODO - Redo this function when YMIR is live
    public PDRCompletionDTO processBifrostResponse(BifrostResponse bifrostResponse, BifrostRequest bifrostRequest) 
    		throws JsonParseException, JsonMappingException, IOException {
    	/*
		 * ResultCode of FAILURE implies one of the following 
		 * 	1. bifrost was unable to login due to invalid credentials
		 * 	2. bifrost was unable to login due to errors like MFA, Unsupported Account Prepaid, ..
		 *  3. bifrost was not successful in acquiring statement data
		 * 	4. bifrost was not successful in extracting statement data
		 * 	5. bifrost encountered an unexpected error
		 * 	6. no statements were retrieved matching the given account number. 
		 * 			CompletionStatusDetail = ACCOUNT_NOT_FOUND
		 * 
		 * 	Return Response contains:
		 * 		CompletionStatus = FAILURE,
		 *		CompletionStausDetail = ACCOUNT_NOT_FOUND, CREDENTIALS_INVALID, GENERAL_FAILURE, 
		 *                                MULTI_FACTOR_AUTH_FAILURE, USER_ACTION_REQUIRED, LIMITED_ACCESS
		 * 
		 * ResultCode of SUCCESS implies all of the following
		 * 	1. valid credentials were supplied
		 * 	2. bifrost was successful in acquiring and extracting statement data.
		 * 
		 * 	To create the return response:
		 * 		CompletionStatus = SUCCESS
		 * 
		 * 	1. statementsMap == null 
		 * 		This will be treated as an invalid scenario.
		 * 			CompletionStatusDetail = INVALID // ??
		 * 
		 * 	2. statementsMap.size() == 1 && statementsMap.get(accountNumber).size == 0 
		 * 		Valid statements were not within the date range.
		 * 			CompletionStatusDetail = NO_STATEMENTS_IN_PERIOD.
		 * 
		 *  3. statementsMap.size() == 1 && statementsMap.get(accountNumber).size > 0 
		 *      Some statements were retrieved but not all 
		 *      (some pdfs were corrupt or statements had an audit error)
		 *          CompletionStatusDetail = PARTIAL_DELIVERY
		 * 
		 *  4. statementsMap.size() == 1 && statementsMap.get(accountNumber).size > 0 
		 * 		Statements were retrieved matching the given account number
		 * 		and within the date range.
		 * 			CompletionStatusDetail = null for now.
		 * 
		 * 	5. statementsMap.size() > 1   TODO - ?? 
		 */
	   
    	PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
       	pdrComplete.setBifrostId(bifrostResponse.getBifrostId());
		pdrComplete.setCompletedAt(new Date());
		pdrComplete.setSourceTree(bifrostResponse.getAcquisitionResult());
		pdrComplete.setLogsId(bifrostResponse.getAcquisitionLog());

		// TODO - Update MidgardDocument with the transformation resultCode
		// Validate Extract
		ResultCode resultCode = TransformationUtils.validateExtract(bifrostResponse, 
				ResultCode.valueOf(bifrostResponse.getAcquisitionStatus()));

		// Transform Extract into a PDS Domain Object
        Extract extract = BifrostMidgardDocumentUtils.getExtractionResult(bifrostResponse.getExtractionResult());

		return transformExtractIntoPDSDO(pdrComplete, resultCode, bifrostRequest, extract);
	}
    
    public PDRCompletionDTO transformExtractIntoPDSDO(PDRCompletionDTO pdrComplete, 
            ResultCode resultCode, BifrostRequest request, Extract extract) {
        
        if (resultCode == ResultCode.BILL_NOT_YET_AVAILABLE) {
            
            pdrComplete.setCompletionStatus(PDRCompletionStatus.SUCCESS.toString());
            pdrComplete.setCompletionStatusDetail(PDRCompletionStatusDetail.NO_STATEMENTS_IN_PERIOD.toString());
            pdrComplete.setStatements(null);
            return pdrComplete;
            
        } else if (resultCode == ResultCode.SUCCESS || resultCode == ResultCode.PARTIAL_DELIVERY) {

            /* PARTIAL_DELIVERY is a SUCCESSful scenario in which we've navigated to 
             * and extracted data from  all available statements; some statements had 
             * some sort of error (corrupt pdf or audit errors)
             */
            
            pdrComplete.setCompletionStatus(PDRCompletionStatus.SUCCESS.toString());

            // Transform the extract into a map of accounts -> list of statements
            Map<String, List<Statement>> allStatements = TransformationUtils.processExtract(extract, resultCode);

            // Filter out statements by requested accounts
            Map<String, List<Statement>> filteredStatementsAccounts = filterStatementsByAccounts(allStatements, 
                                                                                request.getAccountNumbers());
            if ( (filteredStatementsAccounts==null || filteredStatementsAccounts.isEmpty())
                    && !allStatements.values().isEmpty()) {
                
                pdrComplete.setCompletionStatus(PDRCompletionStatus.FAILURE.toString());
                pdrComplete.setCompletionStatusDetail(PDRCompletionStatusDetail.ACCOUNT_NOT_FOUND.toString());
                pdrComplete.setStatements(null);
                return pdrComplete;
            }
            
            // Filter out statements by date range
            Map<String, List<Statement>> filteredStatements = filterStatementsByDateRange(filteredStatementsAccounts, 
                                                                    request.getPeriodStart(), request.getPeriodEnd());
            if ( (filteredStatements.size()==0 || filteredStatements.values().isEmpty()) 
                    && !filteredStatementsAccounts.values().isEmpty()) {
                
                pdrComplete.setCompletionStatusDetail(PDRCompletionStatusDetail.NO_STATEMENTS_IN_PERIOD.toString());
                pdrComplete.setStatements(null);
                return pdrComplete;
            }
            
            // map from statement to statementDTO
            List<StatementDTO> statements = new ArrayList<StatementDTO>();
            for (String accountNumber : filteredStatements.keySet()) {

                List<Statement> bifrostStatements = filteredStatements.get(accountNumber);
                for (Statement bStatement : bifrostStatements) {
                    StatementDTO statementDTO = new StatementDTO();

                    if (bStatement.getAddress() != null) {
                        statementDTO.setBillingName(bStatement.getAddress().getBillingName());
                        statementDTO.setBillingStreet1(bStatement.getAddress().getBillingStreet1());
                        statementDTO.setBillingStreet2(bStatement.getAddress().getBillingStreet2());
                        statementDTO.setBillingCity(bStatement.getAddress().getBillingCity());
                        statementDTO.setBillingState(bStatement.getAddress().getBillingState());
                        statementDTO.setBillingCountry(bStatement.getAddress().getBillingCountry());
                        statementDTO.setBillingPostalCode(bStatement.getAddress().getBillingPostalCode());
                        statementDTO.setBillingPhone(bStatement.getAddress().getBillingPhone());
                    }
                    statementDTO.setAccountNumber(bStatement.getAccountNumber());
                    statementDTO.setTotalBill(bStatement.getTotalBill());
                    statementDTO.setDueDate(bStatement.getDueDate());
                    statementDTO.setPaymentCurrency(bStatement.getPaymentCurrency());
                    statementDTO.setStatementDate(bStatement.getStatementDate());
                    statementDTO.setRecentPayment(bStatement.getRecentPayment());
                    statementDTO.setRecentPaymentDate(bStatement.getRecentPaymentDate());
                    
                    statementDTO.setSourceIds(bStatement.getSourceIds());

                    statements.add(statementDTO);
                }
            }
            pdrComplete.setStatements(new HashSet<>(statements));
            
            // somewhat of a hack for returning the right status if resultCode == PARTIAL_DELIVERY
            if (resultCode.equals(ResultCode.PARTIAL_DELIVERY)) {
                if (pdrComplete.getStatements()!=null && pdrComplete.getStatements().size()>0) {
                    pdrComplete.setCompletionStatusDetail(ResultCode.PARTIAL_DELIVERY.toString());
                } else {
                    // If there were no statements, then fail?? Is this right?
                    pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
                    pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.toString());
                    LOG.debug("Updating the status of PDR with bifrostID {} to FAILURE|GENERAL_FAILURE "
                            + "since either no statements were available or all of them failed audit.", 
                            pdrComplete.getBifrostId());
                }
            }
            
        } else {
            String completionStatusDetail = resultCode.toString();
            if (StringUtils.isBlank(completionStatusDetail) || (!validBifrostStatuses.contains(completionStatusDetail)))
                completionStatusDetail = ResultCode.GENERAL_FAILURE.name();

            pdrComplete.setCompletionStatusDetail(completionStatusDetail);
            pdrComplete.setCompletionStatus(PDRCompletionStatus.FAILURE.toString());
            pdrComplete.setStatements(null);
            
        }
        
        return pdrComplete;
    }

    // Filter results by discarding statements for accounts that were not asked for
    private Map<String, List<Statement>> filterStatementsByAccounts(Map<String, List<Statement>> statementsMap,  
            Set<String> targetAccounts) {
    	
    	for (String acct: statementsMap.keySet()) {
			LOG.debug("Account {} has {} statements pre-filter", acct,
					statementsMap.get(acct).size());
		}
		
    	Map<String, List<Statement>> rc = new HashMap<String, List<Statement>>();
		for (String account : statementsMap.keySet()) {
		    if (targetAccounts.contains(account))
                rc.put(account, statementsMap.get(account));
		}
		
		LOG.debug("Accounts not filtered out: {} ", rc.keySet());
		rc.keySet()
				.stream()
				.forEach(
						account -> LOG.debug(
								"Account {} has {} statements post-filter",
								account, rc.get(account).size()));
		
		return rc;
    }
    
    // Filter results by discarding statements outside the date range
    protected Map<String, List<Statement>> filterStatementsByDateRange(Map<String, List<Statement>> statementsMap,
                                                                                Date periodStart, Date periodEnd) {
        
        for (String acct : statementsMap.keySet()) {
            LOG.debug("Account {} has {} statements pre-filter", acct,
                    statementsMap.get(acct).size());
        }

        Map<String, List<Statement>> rc =  new HashMap<String, List<Statement>>();
        for (String account : statementsMap.keySet()) {
            List<Statement> filteredStatements = new ArrayList<Statement>();
            
            List<Statement> statements = statementsMap.get(account);
            for (Statement stmt : statements) {
                if (dateBetween(stmt.getStatementDate(), periodStart, periodEnd)) {
                    filteredStatements.add(stmt);
                } else {
                    LOG.debug(
                            "Filtering out-of-range statement for account {} with date of {}",
                            account, stmt.getStatementDate());
                }
            }
            
            if (filteredStatements.size() > 0)
                rc.put(account, filteredStatements);
        }
        rc.keySet()
                .stream()
                .forEach(
                        account -> LOG.debug(
                                "Account {} has {} statements post-filter",
                                account, rc.get(account).size()));
        
        return rc;
    }
    
	public static boolean dateBetween(Date source, Date start, Date end) {
		
		boolean rc = false;
		
		if (source == null) {
			rc = false;
		} else if (start == null && end == null) {
			rc = true;
		} else if (start == null) {
			rc = source.before(end);
		} else if (end == null) {
			rc = source.after(start);
		} else if (source.equals(start) || source.equals(end)) {
			rc = true;
		} else if (start.before(source) && end.after(source)) {
			rc = true;
		}
		
		return rc;
	}
   
}
