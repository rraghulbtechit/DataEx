package com.urjanet.forseti.connect.listener.aws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.amazonaws.handlers.AsyncHandler;
import com.amazonaws.services.sns.AmazonSNSAsyncClient;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.amazonaws.services.sqs.AmazonSQSAsyncClient;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.BifrostResponse;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.exception.ConnectException;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;
import com.urjanet.midgard.sdk.MidgardDocumentUtils;
import com.urjanet.midgard.sdk.storage.MidgardStorageUtils;

@Component
public class AWSClient {
    private static final Logger log = LoggerFactory.getLogger(AWSClient.class);
    
    private AmazonSNSAsyncClient snsAsyncClient;
    private AmazonSNSClient snsClient;
    private AmazonSQSAsyncClient sqsClient;
    
    private ForsetiAsyncHandler asyncHandler;
    
    public static final String RESPONSE_QUEUE = "ForsetiResponseQueue";
    public static final String FAILURE_TOPIC = "ForsetiFailureTopic";
    
    public AWSClient() {
        super();
        this.snsClient = new AmazonSNSClient();
        this.snsAsyncClient = new AmazonSNSAsyncClient();
        this.sqsClient = new AmazonSQSAsyncClient();
        
        asyncHandler = new ForsetiAsyncHandler();
    }  
    
    public Message receive(String queueUrl, int timeout) {
    		
        ReceiveMessageResult result = sqsClient.receiveMessage(new ReceiveMessageRequest()
            .withQueueUrl(queueUrl)
            .withMaxNumberOfMessages(1)
            .withWaitTimeSeconds(timeout)            
            );
        
        if (result.getMessages().isEmpty()) {
            return null;
        } else {
            return result.getMessages().get(0);
        }
    }
    
    public void deleteMessage(String queueUrl, String msgId) {
        sqsClient.deleteMessage(queueUrl, msgId);
    }
    
    public void send(String topicName, String payload) {
        PublishRequest pr = new PublishRequest()
            .withTargetArn(topicName)
            .withMessage(payload);
        
        snsAsyncClient.publishAsync(pr, asyncHandler);
    }
	
    
    private class ForsetiAsyncHandler implements AsyncHandler<PublishRequest, PublishResult> {
        @Override
        public void onError(Exception e) {
            log.warn("Message failed to publish", e);            
        }

        @Override
        public void onSuccess(PublishRequest request, PublishResult result) {
            log.debug("Message {} published", result.getMessageId());            
        }        
    }
    
    public void notifyFailure(boolean retryPDR, PDR pdr, PDRCompletionDTO pdrComplete, 
    		BifrostRequest bifrostRequest, BifrostResponse bifrostResponse, 
    		String failureTopic) 
    		throws ConnectException {
		
    	if (pdrComplete == null) {
 		    throw new ConnectException("PDRCompletionDTO was null for bifrostId " 
 		    		+ bifrostResponse.getBifrostId()
 		    		+ "=> Throwing a ConnectException");
 		    
 		    // TODO - How to handle these!!
 		}
    	 
    	// Publish ForsetiFailureMessage to ForsetiFailureTopic
    	if ( shouldPublishFailureMessage(retryPDR, pdr, pdrComplete) ) {
			try {
				ForsetiFailureMessage message = new ForsetiFailureMessage();

		        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		        final TimeZone utc = TimeZone.getTimeZone("UTC");
		        sdf.setTimeZone(utc);
				message.setTimestamp(sdf.format(new Date()));
				
				message.setCustomer(bifrostRequest.getCustomer());
				message.setCreatedAt(sdf.format(pdr.getCreatedDate()));
				message.setProviderId(bifrostRequest.getProviderId());
				message.setProviderAlias(bifrostRequest.getProvider());
				message.setAcquisitionTemplate(bifrostRequest.getProviderAcquisitionTemplate().getTemplateName());
				message.setExtractionTemplate(bifrostRequest.getProviderExtractionTemplate().getTemplateName());
				
				message.setBifrostId(bifrostResponse.getBifrostId());
				message.setTraceId(bifrostResponse.getTraceId());
				// Hard coding the production monocle url. Obviously this doesn't hold in non-prod environments
				message.setMonocleLink("https://monocle.urjanet.net/forseti/pdrs/list?bifrostId=" 
						+ message.getBifrostId());
				
				// Remember that FAILURE | GENERAL_FAILURE here means that the PDR
				// will be retried and put in PENDING state.
				message.setResultCode(pdrComplete.getCompletionStatus());
				message.setResultDetail(pdrComplete.getCompletionStatusDetail());
				
				message.setAcquisitionStatus(bifrostResponse.getAcquisitionStatus());
				message.setExtractionStatus(bifrostResponse.getAcquisitionStatus());
				// TODO - Update with the correct transformation resultCode
				message.setTransformationStatus(bifrostResponse.getTransformationStatus());
				
				message.setS3BucketKey(bifrostResponse.getAcquisitionLog());
				message.setS3BucketName(MidgardStorageUtils.getBucketName());
				
				message.setRetryCount(pdr.getRetryCount());
				if (pdr.getRetryAt() != null)
					message.setRetryAt(sdf.format(pdr.getRetryAt()));
				message.setExpirationDate(sdf.format(pdr.getExpirationDate()));
				
				String json = MidgardDocumentUtils.toJson(message);
				PublishRequest pubRequest = new PublishRequest(failureTopic, json);
				snsClient.publish(pubRequest);
				
			} catch (IOException e) {
				e.printStackTrace();
				 throw new ConnectException("Exception while mapping MD to ForsetiFailureMessage " + e.toString()
		    		+ "=> Throwing a ConnectException");
			}
		}
	}
    
    /* This function returns true if forseti should publish a failure message.
     * 
     * This is the criteria:
     *  1. status = SUCCESS and statusDetail = PARTIAL_DELIVERY OR
     *  2. All cases where status != SUCESS and statusDetail != CREDENTIALS_INVALID
     *  3. AND only for an initial and final failure
     */
    public boolean shouldPublishFailureMessage(boolean retryPDR, PDR pdr, PDRCompletionDTO pdrComplete) {
    	boolean result = false;
    	
    	if (pdrComplete!=null && pdrComplete.getCompletionStatus()!= null && pdrComplete.getCompletionStatusDetail()!=null) {
    	    
    	    if (pdrComplete.getCompletionStatus().equals(ResultCode.SUCCESS.name()) && 
    	            pdrComplete.getCompletionStatusDetail().equals(PDRCompletionStatusDetail.PARTIAL_DELIVERY.toString())) {
    	        
    	        result = true;
    	    }
    	    
    		if ( !(pdrComplete.getCompletionStatusDetail().equals(ResultCode.CREDENTIALS_INVALID.name())) && 
    				!(pdrComplete.getCompletionStatus().equals(ResultCode.SUCCESS.name())) ) {
    	
    			result = true;
    		}
    	}
    	
    	// Publish only for initial and final failures
    	if (result) {
    		if (pdr.getRetryCount() == null || 
					(pdr.getRetryCount() != null && !retryPDR)) {
				
				result = true;
			} else {
				result = false;
			}
    	}
    	
    	return result;
    }
}
