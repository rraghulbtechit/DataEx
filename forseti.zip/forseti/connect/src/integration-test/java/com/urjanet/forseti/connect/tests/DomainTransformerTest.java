package com.urjanet.forseti.connect.tests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.urjanet.forseti.connect.transform.DomainTransformer;

public class DomainTransformerTest {
    private DomainTransformer domainTransformer;
    
    private static ObjectMapper jsonMapper = null;
    
    /* Update tests!
    @Before
    public void setup() throws Exception {
    	jsonMapper = new ObjectMapper();
		jsonMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jsonMapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
		jsonMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		jsonMapper.enable(SerializationFeature.INDENT_OUTPUT);
		jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		Application application = new Application();
		domainTransformer = new DomainTransformer(new TestAWSClient(application));
    }

    @After
    public void teardown() throws Exception {
        // Close connections?
    }
    
    @Test
    public void testSuccess_SingleAccount_NoJSON() {
		BifrostStatementRetrievalResponse response = new BifrostStatementRetrievalResponse();
		response.setBifrostId("1234");
		response.setResultCode(ResultCode.SUCCESS);
		response.setErrorMsg(null);
		response.setS3BucketName(null);
		response.setS3BucketKey(null);

		Map<String, List<Statement>> mapStatements = new HashMap<String, List<Statement>>();
		String acct = "473066384-00001";
		List<Statement> statements = new ArrayList<Statement>();
		Statement statement = new Statement();
		statement.setAccountNumber(acct);
		statements.add(statement);
		mapStatements.put(acct, statements);

		response.setStatements(mapStatements);
		 
        PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
        assertNotNull(completeDTO);
        assertNotNull(completeDTO.getBifrostId());
        assertNotNull(completeDTO.getCompletedAt());
        //assertNotNull(completeDTO.getStatements());
        assertEquals(PDRCompletionStatus.SUCCESS.toString(), completeDTO.getCompletionStatus());
        assertNull(completeDTO.getCompletionStatusDetail());
    }
    
    @Test
    public void testSuccess_SingleAccount_2Statements_JSON() {
    	try {
	        BifrostStatementRetrievalResponse response = getResponse("success_2statements.json");
	        assertEquals(response.getBifrostId(), "b307e91f-e6bb-4c9f-a58f-85739ebb978d");
	        assertEquals(response.getResultCode().name(), ResultCode.SUCCESS.name());
	        assertNull(response.getErrorMsg());
	        assertNotNull(response.getStatements());
	        
            PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
            assertNotNull(completeDTO);
            assertEquals(completeDTO.getBifrostId(), "b307e91f-e6bb-4c9f-a58f-85739ebb978d");
            assertNotNull(completeDTO.getCompletedAt());
            assertEquals(PDRCompletionStatus.SUCCESS.toString(), completeDTO.getCompletionStatus());
            assertNull(completeDTO.getCompletionStatusDetail());
            assertNotNull(completeDTO.getStatements());
            
            Set<StatementDTO> statements = completeDTO.getStatements();
            assertEquals(statements.size(), 2);
            Iterator<StatementDTO> iterator = statements.iterator();
            while (iterator.hasNext()){
            	StatementDTO stmt = (StatementDTO) iterator.next();
            	assertEquals(stmt.getAccountNumber(), "10010");
            	assertEquals(stmt.getBillingName(), "JOHN DOE");
            	assertNotNull(stmt.getDueDate());
            }
            
    	} catch (Exception e) {
    		fail(e.toString());
    	}
    }
    
    
    @Test
    public void testSuccess_AccountNotFound_JSON() {
    	try {
	        BifrostStatementRetrievalResponse response = getResponse("success_accountnotfound.json");
	        assertEquals(response.getBifrostId(), "1234");
	        assertEquals(response.getResultCode().name(), ResultCode.SUCCESS.name());
	        assertNull(response.getErrorMsg());
	        assertNotNull(response.getStatements());
	        
            PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
            assertNotNull(completeDTO);
            assertEquals(completeDTO.getBifrostId(), "1234");
            assertNotNull(completeDTO.getCompletedAt());
            assertEquals(PDRCompletionStatus.SUCCESS.toString(), completeDTO.getCompletionStatus());
            assertEquals(completeDTO.getCompletionStatusDetail(), DomainTransformer.ACCOUNT_NOT_FOUND);
            assertNull(completeDTO.getStatements());
            
    	} catch (Exception e) {
    		fail(e.toString());
    	}
    }
    
    @Test
    public void testSuccess_NoStatements_JSON() {
    	try {
	        BifrostStatementRetrievalResponse response = getResponse("success_nostatements.json");
	        assertEquals(response.getBifrostId(), "1234");
	        assertEquals(response.getResultCode().name(), ResultCode.SUCCESS.name());
	        assertNull(response.getErrorMsg());
	        assertNotNull(response.getStatements());
        
            PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
            assertNotNull(completeDTO);
            assertEquals(completeDTO.getBifrostId(), "1234");
            assertNotNull(completeDTO.getCompletedAt());
            assertEquals(PDRCompletionStatus.SUCCESS.toString(), completeDTO.getCompletionStatus());
            assertNull(completeDTO.getCompletionStatusDetail());
            assertNotNull(completeDTO.getStatements());
            
    	} catch (Exception e) {
    		fail(e.toString());
    	}
    }
    
    @Test
    public void testFailure_SingleAccount_NoJSON() {
		BifrostStatementRetrievalResponse response = new BifrostStatementRetrievalResponse();
		response.setBifrostId("1234");
		response.setResultCode(ResultCode.GENERAL_FAILURE);
		response.setErrorMsg(ResultCode.GENERAL_FAILURE.name());

		Map<String, List<Statement>> mapStatements = new HashMap<String, List<Statement>>();
		String acct = "1234567890";
		List<Statement> statements = new ArrayList<Statement>();
		Statement statement = new Statement();
		statement.setAccountNumber(acct);
		statements.add(statement);
		mapStatements.put(acct, statements);
		response.setStatements(mapStatements);
		 
        PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
        assertNotNull(completeDTO);
        assertEquals(completeDTO.getBifrostId(), "1234");
        assertNotNull(completeDTO.getCompletedAt());
        assertEquals(PDRCompletionStatus.FAILURE.toString(), completeDTO.getCompletionStatus());
        assertNotNull(completeDTO.getCompletionStatusDetail());
        assertNull(completeDTO.getStatements());
    } 
    
    @Test
    public void testFailure_CredentialsInvalid_JSON() {
    	try {
	        BifrostStatementRetrievalResponse response = getResponse("failure_CredentialsInvalid.json");
	        assertEquals(response.getBifrostId(), "1234");
	        assertEquals(response.getResultCode().name(), ResultCode.FAILURE.name());
	        assertEquals(response.getErrorMsg(), ResultCode.CREDENTIALS_INVALID.name());
	        assertNull(response.getStatements());
        
            PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
            assertNotNull(completeDTO);
            assertEquals(completeDTO.getBifrostId(), "1234");
            assertNotNull(completeDTO.getCompletedAt());
            assertEquals(PDRCompletionStatus.FAILURE.toString(), completeDTO.getCompletionStatus());
            assertEquals(completeDTO.getCompletionStatusDetail(), ResultCode.CREDENTIALS_INVALID.name());
            assertNull(completeDTO.getStatements());
            
    	} catch (Exception e) {
    		fail(e.toString());
    	}
    }
    
    @Test
    public void testFailure_AcquisitionFailure_JSON() {
    	try {
	        BifrostStatementRetrievalResponse response = getResponse("failure_AcquisitionFailure.json");
	        assertEquals(response.getBifrostId(), "1234");
	        assertEquals(response.getResultCode().name(), ResultCode.FAILURE.name());
	        assertEquals(response.getErrorMsg(), ResultCode.ACQUISITION_FAILURE.name());
	        assertNull(response.getStatements());
        
            PDRCompletionDTO completeDTO = domainTransformer.processBifrostResponse(response);
            assertNotNull(completeDTO);
            assertEquals(completeDTO.getBifrostId(), "1234");
            assertNotNull(completeDTO.getCompletedAt());
            assertEquals(PDRCompletionStatus.FAILURE.toString(), completeDTO.getCompletionStatus());
            assertEquals(completeDTO.getCompletionStatusDetail(), ResultCode.GENERAL_FAILURE.name());
            assertNull(completeDTO.getStatements());
            
    	} catch (Exception e) {
    		fail(e.toString());
    	}
    }
    
    private BifrostStatementRetrievalResponse getResponse(String filePath) throws IOException  {
    	URL url = getClass().getClassLoader().getResource("responses/" + filePath);
    	BifrostStatementRetrievalResponse response = jsonMapper.readValue(new File(url.getFile()), BifrostStatementRetrievalResponse.class);
    	response.setS3BucketKey(filePath.replace(".json", "_map.json"));
    	return response;
    }
    */
}
