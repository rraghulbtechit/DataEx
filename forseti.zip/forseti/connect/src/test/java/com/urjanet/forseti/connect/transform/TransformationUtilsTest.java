package com.urjanet.forseti.connect.transform;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDate;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.urjanet.bifrost.sdk.AccountNumberUtils;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.domain.Address;
import com.urjanet.forseti.connect.domain.Statement;
import com.urjanet.forseti.connect.transform.extract.JsonFileExtractSource;
import com.urjanet.forseti.connect.transform.extract.WootFileExtractSource;

import urjanet.clean.format.FormatException;
import urjanet.clean.format.Formatter;
import urjanet.clean.format.FormatterFactory;
import urjanet.keys.AddressKeys;
import urjanet.keys.DataValues;
import urjanet.keys.uds.GroupingKeys;
import urjanet.pull.core.Extract;
import urjanet.pull.web.GroupPolicy;

/**
 * Created by sparikh and bwilson on 1/19/17.
 */
public class TransformationUtilsTest {

	private static ObjectMapper jsonMapper = null;
	private static Formatter formatter = FormatterFactory
			.getFormatter(/* TODO: localeId */);

	@Before
	public void setup() throws Exception {
		jsonMapper = new ObjectMapper();
		jsonMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jsonMapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
		jsonMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		jsonMapper.enable(SerializationFeature.INDENT_OUTPUT);
		jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	@After
	public void teardown() throws Exception {
		// ???
	}

	@Test
	public void testProcessMissingStatmentDate() {
		try {
			Extract extract = JsonFileExtractSource.get().getExtract("missingStatementDate.json");

			Map<String, List<Statement>> map = TransformationUtils.transformExtract(extract,
					FormatterFactory.getFormatter());
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			assertEquals(map.size(), 3);

			String account = "287254055526";
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 1);
			Statement stmt = statements.get(0);
			assertNotNull(stmt);
			assertEquals(stmt.getAccountNumber(), account);
			assertEquals(stmt.getPaymentCurrency(), "USD");
			assertNull(stmt.getStatementDate());
			assertNotNull(stmt.getTotalBill());
			assertNull(stmt.getDueDate());
			assertNull(stmt.getPeriodStart());
			assertNull(stmt.getPeriodEnd());
			assertNotNull(stmt.getRecentPayment());
			assertNotNull(stmt.getRecentPaymentDate());

			account = "534004287099";
			statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 2);
			for (int i = 0; i < 2; i++) {
				stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNull(stmt.getStatementDate());
				assertNotNull(stmt.getTotalBill());
				assertNull(stmt.getDueDate());
				assertNull(stmt.getPeriodStart());
				assertNull(stmt.getPeriodEnd());
				assertNotNull(stmt.getRecentPayment());
				assertNotNull(stmt.getRecentPaymentDate());
			}

			account = "874399272";
			statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 1);
			stmt = statements.get(0);
			assertNotNull(stmt);
			assertEquals(stmt.getAccountNumber(), account);
			assertEquals(stmt.getPaymentCurrency(), "USD");
			assertNull(stmt.getStatementDate());
			assertNotNull(stmt.getTotalBill());
			assertNull(stmt.getPeriodStart());
			assertNull(stmt.getPeriodEnd());
			assertNotNull(stmt.getDueDate());
			assertNotNull(stmt.getRecentPayment());
			assertNotNull(stmt.getRecentPaymentDate());

			ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, null);
			assertEquals(resultCode, ResultCode.ACQUISITION_FAILURE);

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testExtractStructureFailure() {
		try {
			Extract extract = JsonFileExtractSource.get().getExtract("extractFail1.json");

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = AccountNumberUtils.normalizeAccountNumber("115668223-0891662-8");
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 1);
			Statement stmt = statements.get(0);
			assertNotNull(stmt);
			assertEquals(stmt.getAccountNumber(), account);
			assertEquals(stmt.getPaymentCurrency(), "USD");
			assertNotNull(stmt.getStatementDate());
			assertNotNull(stmt.getTotalBill());
			assertNotNull(stmt.getDueDate());
			assertNull(stmt.getPeriodStart());
			assertNull(stmt.getPeriodEnd());
			assertNull(stmt.getRecentPayment());
			assertNull(stmt.getRecentPaymentDate());

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testBadStmtDateFormat() {
		try {
			Extract extract = JsonFileExtractSource.get().getExtract("badStmtDate.json");

			ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
			assertEquals(resultCode, ResultCode.ACQUISITION_FAILURE);

			TransformationUtils.transformExtract(extract, FormatterFactory.getFormatter());

		} catch (Exception e) {
			// ensure we get an exception on the StatementDate, not something
			// else
			if (e instanceof FormatException) {
				assertTrue(e.getMessage().contains("1of6 Suping Lou 474802718 Aug 09- Sep 08 Sep 12, 2015"));
				return;
			} else {
				fail();
			}
		}

		fail("Statement Date should have thrown an exception during parsing (during transformExtract())");
	}

	@Test
	public void missingTotalAmount() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("missingTotalAmt.json");

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = "474802718";
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 24);
			for (int i = 0; i < 24; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNotNull(stmt.getStatementDate());
				assertNull(stmt.getTotalBill());
				// assertNull(stmt.getDueDate());
				assertNotNull(stmt.getPeriodStart());
				// assertNotNull(stmt.getPeriodEnd());
				// assertNotNull(stmt.getRecentPayment());
				// assertNotNull(stmt.getRecentPaymentDate());
				assertNotNull(stmt.getAddress());
			}

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void totalAmountZero() {

		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("amtDueZero.json");

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = "474802718";
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 4);
			for (int i = 0; i < 4; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNotNull(stmt.getStatementDate());
				assertEquals(stmt.getTotalBill().signum(), 0);
				assertNotNull(stmt.getDueDate());
				assertNotNull(stmt.getPeriodStart());
				assertNotNull(stmt.getPeriodEnd());
				assertNotNull(stmt.getRecentPayment());
				assertNotNull(stmt.getRecentPaymentDate());
				assertNotNull(stmt.getAddress());
			}

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void totalAmountNegative() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("amtDueNegative.json");

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = "474802718";
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 4);
			for (int i = 0; i < 4; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNotNull(stmt.getStatementDate());
				assertTrue(stmt.getTotalBill().compareTo(BigDecimal.ZERO) < 0);
				assertNotNull(stmt.getDueDate());
				assertNotNull(stmt.getPeriodStart());
				assertNotNull(stmt.getPeriodEnd());
				assertNotNull(stmt.getRecentPayment());
				assertNotNull(stmt.getRecentPaymentDate());
				assertNotNull(stmt.getAddress());
			}

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testStatementDate() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("potentialStatementDateFail3.json");

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = "874399272";
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 15);
			for (int i = 0; i < 15; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNotNull(stmt.getStatementDate());
				assertNotNull(stmt.getTotalBill());
				assertNotNull(stmt.getPeriodStart());
				assertNotNull(stmt.getPeriodEnd());
				assertNotNull(stmt.getRecentPayment());
				assertNotNull(stmt.getRecentPaymentDate());
				assertNotNull(stmt.getAddress());
			}

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testMissingPeriodEndMissingStatementDate() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("missingStmtmissingPeriodEnd.json");

			Map<String, List<Statement>> map = TransformationUtils.transformExtract(extract,
					FormatterFactory.getFormatter());
			assertNotNull(map);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = AccountNumberUtils.normalizeAccountNumber("473066384-00001");
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 7);
			for (int i = 0; i < 7; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNull(stmt.getStatementDate());
				assertNotNull(stmt.getTotalBill());
				assertNotNull(stmt.getDueDate());
				assertNotNull(stmt.getPeriodStart());
				assertNull(stmt.getPeriodEnd());
				assertNotNull(stmt.getRecentPayment());
				// assertNotNull(stmt.getRecentPaymentDate());
				assertNotNull(stmt.getAddress());
			}

			ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
			assertEquals(resultCode, ResultCode.ACQUISITION_FAILURE);

		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testPeriodFilter() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("bifrostResult2.json");

			Date start = new LocalDate(2015, 3, 1).toDate();
			Date end = new LocalDate(2015, 10, 1).toDate();

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = AccountNumberUtils.normalizeAccountNumber("473066384-00001");
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 7);
			for (int i = 0; i < 7; i++) {
				Statement stmt = statements.get(i);
				assertNotNull(stmt);
				assertEquals(stmt.getAccountNumber(), account);
				assertEquals(stmt.getPaymentCurrency(), "USD");
				assertNotNull(stmt.getStatementDate());
				assertNotNull(stmt.getTotalBill());
				assertNotNull(stmt.getDueDate());
				assertNotNull(stmt.getPeriodStart());
				assertNotNull(stmt.getPeriodEnd());
				assertTrue(stmt.getStatementDate().after(start));
				assertTrue(stmt.getStatementDate().before(end));
				assertNotNull(stmt.getRecentPayment());
				// assertNotNull(stmt.getRecentPaymentDate());
				// assertNotNull(stmt.getAddress());
			}

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testLeapDay() throws FormatException {
		String dateStr = "Feb 29";
		Date date = TransformationUtils.parseDate(dateStr, null, null, false, FormatterFactory.getFormatter());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		// Ensure we extract 2/29 correctly, with a year old enough to detect
		// that it isn't correct
		assertEquals(1, cal.get(Calendar.MONTH));
		assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
		assertTrue(cal.get(Calendar.YEAR) <= 1972);
	}

	@Test
	public void testNonStandardMonthAbbrev() throws FormatException {
		String dateStr = "Sept 30";
		Date date = TransformationUtils.parseDate(dateStr, null, null, false, FormatterFactory.getFormatter());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		// Ensure we extract 9/30 correctly, with a year old enough to detect
		// that it isn't correct
		assertEquals(8, cal.get(Calendar.MONTH));
		assertEquals(30, cal.get(Calendar.DAY_OF_MONTH));
		assertTrue(cal.get(Calendar.YEAR) <= 1972);
	}

	@Test
	public void testJustMonth() throws FormatException {
		String dateStr = "Nov";
		String formatHint = "MMM";
		Date date = TransformationUtils.parseDate(dateStr, formatHint, null, false, FormatterFactory.getFormatter());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		assertEquals(10, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(1970, cal.get(Calendar.YEAR));
	}

	@Test
	public void reconcileYearFromLaterReferenceDate() throws FormatException {
		String dateStr = "Jan 1";
		String formatHint = "MMM dd";
		Calendar cal = Calendar.getInstance();
		cal.set(2015, 2, 1);
		Date referenceDate = cal.getTime();

		Date date = TransformationUtils.parseDate(dateStr, formatHint, referenceDate, false,
				FormatterFactory.getFormatter());

		cal.setTime(date);

		assertEquals(0, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(2015, cal.get(Calendar.YEAR));
	}

	@Test
	public void reconcileYearFromEarlierReferenceDate() throws FormatException {
		String dateStr = "June 1";
		String formatHint = "MMM dd";
		Calendar cal = Calendar.getInstance();
		cal.set(2015, 2, 1);
		Date referenceDate = cal.getTime();

		Date date = TransformationUtils.parseDate(dateStr, formatHint, referenceDate, false,
				FormatterFactory.getFormatter());

		cal.setTime(date);

		assertEquals(5, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(2015, cal.get(Calendar.YEAR));
	}

	@Test
	public void reconcileYearFromLaterReferenceDateForceAfter() throws FormatException {
		String dateStr = "Jan 1";
		String formatHint = "MMM dd";
		Calendar cal = Calendar.getInstance();
		cal.set(2015, 2, 1);
		Date referenceDate = cal.getTime();

		Date date = TransformationUtils.parseDate(dateStr, formatHint, referenceDate, true,
				FormatterFactory.getFormatter());

		cal.setTime(date);

		assertEquals(0, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(2016, cal.get(Calendar.YEAR));
	}

	@Test
	public void reconcileYearFromEarlierReferenceDateForceAfter() throws FormatException {
		String dateStr = "March First";
		String formatHint = "MMM dd";
		Calendar cal = Calendar.getInstance();
		cal.set(2015, 1, 1, 0, 0, 0);
		cal.set(Calendar.MILLISECOND, 0);
		Date referenceDate = cal.getTime();

		Date date = TransformationUtils.parseDate(dateStr, formatHint, referenceDate, true,
				FormatterFactory.getFormatter());

		cal.setTime(date);

		assertEquals(2, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(2015, cal.get(Calendar.YEAR));
	}

	@Test
	public void reconcileYearFromSameReferenceDateForceAfter() throws FormatException {
		String dateStr = "March First";
		String formatHint = "MMM dd";
		Calendar cal = Calendar.getInstance();
		cal.set(2015, 2, 1);
		Date referenceDate = cal.getTime();

		Date date = TransformationUtils.parseDate(dateStr, formatHint, referenceDate, true,
				FormatterFactory.getFormatter());

		cal.setTime(date);

		assertEquals(2, cal.get(Calendar.MONTH));
		assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
		assertEquals(2015, cal.get(Calendar.YEAR));
	}

	@Test
	public void testInvalidAddress() {
		Extract extract;
		try {
			extract = JsonFileExtractSource.get().getExtract("invalidAddress.json");
			Date start = new LocalDate(2015, 3, 1).toDate();
			Date end = new LocalDate(2015, 10, 1).toDate();

			Map<String, List<Statement>> map = TransformationUtils.processExtract(extract, ResultCode.SUCCESS);
			assertNotNull(map);
			assertNotNull(map.keySet());
			assertNotNull(map.entrySet());

			String account = AccountNumberUtils.normalizeAccountNumber("473066384-00001");
			List<Statement> statements = map.get(account);
			assertNotNull(statements);
			assertEquals(statements.size(), 1);

			Statement stmt = statements.get(0);
			assertNotNull(stmt);
			assertEquals(stmt.getAccountNumber(), account);
			assertEquals(stmt.getPaymentCurrency(), "USD");
			assertNotNull(stmt.getStatementDate());
			assertNotNull(stmt.getTotalBill());
			assertNotNull(stmt.getDueDate());
			assertNotNull(stmt.getPeriodStart());
			assertNotNull(stmt.getPeriodEnd());
			assertTrue(stmt.getStatementDate().after(start));
			assertTrue(stmt.getStatementDate().before(end));
			assertNotNull(stmt.getRecentPayment());
			assertNull(stmt.getAddress());

		} catch (Exception e) {
			fail(e.toString());
		}
	}

	@Test
	public void testResultCodeSuccess() {
		// All 16 statements in this woot are valid
		Extract extract = WootFileExtractSource.get().getExtract("extracts/validExtractWithStatements.wt");
		ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
		assertEquals(resultCode, ResultCode.SUCCESS);
	}

	// Not sure why builder1 can't run this
	@Ignore
	@Test
	public void testResultCodeSuccess2() {
		// All 18 statements in this woot are valid
		Extract extract = WootFileExtractSource.get().getExtract("extracts/validExtractWithStatements_2.wt");
		ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
		assertEquals(resultCode, ResultCode.SUCCESS);
	}

	@Test
	public void testResultCodeSuccessPartialDelivery() {
		// 2 out of 16 statements throws validation errors
		Extract extract = WootFileExtractSource.get().getExtract("extracts/validExtractWithPartialDelivery.wt");
		ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
		assertEquals(resultCode, ResultCode.PARTIAL_DELIVERY);
	}

	@Test
	public void testResultCodeAcquisitionFailure() {
		// All 16 statements throws validation errors
		Extract extract = WootFileExtractSource.get().getExtract("extracts/extractWithAcquisitionFailure.wt");
		ResultCode resultCode = TransformationUtils.validateRequiredFields(extract, formatter);
		assertEquals(resultCode, ResultCode.ACQUISITION_FAILURE);
	}

	@Test
	public void findBillingAddressGroup() throws Exception {

		// Given
		Extract addressGroup1 = new Extract();
		addressGroup1.addValue(AddressKeys.ADDRESS_TYPE_ID.getValue(), DataValues.BILLING_ADDRESS.getValue());
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_1.getValue(), "correct");

		Extract addressGroup2 = new Extract();
		addressGroup2.addValue(AddressKeys.ADDRESS_TYPE_ID.getValue(), DataValues.SERVICE_ADDRESS.getValue());
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_1.getValue(), "incorrect");

		Extract parentExtract = new Extract();
		parentExtract.addExtract(addressGroup1, new GroupPolicy(GroupingKeys.ADDRESS_GROUP.getValue()));
		parentExtract.addExtract(addressGroup2, new GroupPolicy(GroupingKeys.ADDRESS_GROUP.getValue()));

		Extract grandParentExtract = new Extract();
		grandParentExtract.addExtract(parentExtract);

		// When
		Extract billingAddressGroup = TransformationUtils.findBillingAddressGroup(grandParentExtract);

		// Then
		assertEquals(addressGroup1.getValue(AddressKeys.ADDRESS_RAW_1.getValue()),
				billingAddressGroup.getValue(AddressKeys.ADDRESS_RAW_1.getValue()));
	}

	@Test
	public void parseAddress_ShouldDistinguishBillingFromServiceAddress() throws Exception {

		// Given
		Extract addressGroup1 = new Extract();
		addressGroup1.addValue(AddressKeys.ADDRESS_TYPE_ID.getValue(), DataValues.BILLING_ADDRESS.getValue());
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_1.getValue(), "BOB DOLE");
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_2.getValue(), "1234 OLD TOWN RD");
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_3.getValue(), "APT 2");
		addressGroup1.addValue(AddressKeys.ADDRESS_RAW_4.getValue(), "ABINGDON, VA 24211-1234");

		Extract addressGroup2 = new Extract();
		addressGroup2.addValue(AddressKeys.ADDRESS_TYPE_ID.getValue(), "service_address");
		addressGroup2.addValue(AddressKeys.ADDRESS_RAW_1.getValue(), "567 DIFFERENT RD");
		addressGroup2.addValue(AddressKeys.ADDRESS_RAW_2.getValue(), "ABINGDON, VA 12345-5678");

		Extract statementGroup = new Extract();
		statementGroup.addExtract(addressGroup1, new GroupPolicy(GroupingKeys.ADDRESS_GROUP.getValue()));
		statementGroup.addExtract(addressGroup2, new GroupPolicy(GroupingKeys.ADDRESS_GROUP.getValue()));

		// When
		Address address = TransformationUtils.parseAddress(statementGroup);

		// Then
		assertEquals(addressGroup1.getValue(AddressKeys.ADDRESS_RAW_1.getValue()), address.getBillingName());
		assertEquals(addressGroup1.getValue(AddressKeys.ADDRESS_RAW_2.getValue()), address.getBillingStreet1());
		assertEquals(addressGroup1.getValue(AddressKeys.ADDRESS_RAW_3.getValue()), address.getBillingStreet2());
		assertEquals("ABINGDON", address.getBillingCity());
		assertEquals("VA", address.getBillingState());
		assertEquals("24211-1234", address.getBillingPostalCode());
	}
}