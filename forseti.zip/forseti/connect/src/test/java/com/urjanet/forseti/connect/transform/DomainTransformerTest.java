package com.urjanet.forseti.connect.transform;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.transform.extract.WootFileExtractSource;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;

import urjanet.pull.core.Extract;

public class DomainTransformerTest {
    
    private DomainTransformer domainTransformer;
    
    @Before
    public void setup() throws Exception {
        domainTransformer = new DomainTransformer();
    }
    
    @After
    public void teardown() throws Exception {
         // ???
    }
    
    @Test
    public void testTransformExtractSuccess_SingleAccount() throws ParseException {
        Extract extract = WootFileExtractSource.get().getExtract(
                "extracts/validExtractWithStatements.wt");
        BifrostRequest bifrostRequest = createValidBifrostRequest();
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, ResultCode.SUCCESS, 
                bifrostRequest, extract);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS.toString()));
        assertNull(pdrComplete.getCompletionStatusDetail());
        assertTrue(pdrComplete.getStatements().size()==16);
    }
    
    @Test
    public void testTransformExtractSuccess_MultipleAccounts() throws ParseException {
        Extract extract = WootFileExtractSource.get().getExtract(
                "extracts/validExtractWithMultipleAccounts.wt");
        BifrostRequest bifrostRequest = createValidBifrostRequest();
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, ResultCode.SUCCESS, 
                bifrostRequest, extract);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS.toString()));
        assertNull(pdrComplete.getCompletionStatusDetail());
        assertTrue(pdrComplete.getStatements().size()==12);
    }
    
    @Test
    public void testTransformExtract_SuccessNoStatementsInPeriod() throws ParseException {
        Extract extract = WootFileExtractSource.get().getExtract(
                "extracts/validExtractWithStatements.wt");
        BifrostRequest bifrostRequest = createBifrostRequest_NoStatementsInPeriod();
        
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, ResultCode.SUCCESS, 
                bifrostRequest, extract);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS.toString()));
        assertTrue(pdrComplete.getCompletionStatusDetail().equals(
                PDRCompletionStatusDetail.NO_STATEMENTS_IN_PERIOD.toString()));
        assertNull(pdrComplete.getStatements());
    }
    
    @Test
    public void testTransformExtract_SuccessFewerStatementsInPeriod() throws ParseException {
        Extract extract = WootFileExtractSource.get().getExtract("extracts/validExtractWithStatements.wt");
        BifrostRequest bifrostRequest = createBifrostRequest_FewerStatementsInPeriod();
        
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, ResultCode.SUCCESS, 
                bifrostRequest, extract);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.SUCCESS.toString()));
        assertNull(pdrComplete.getCompletionStatusDetail());
        assertTrue(pdrComplete.getStatements().size() == 5);
    }
    
    @Test
    public void testTransformExtract_FailureAccountNotFound() throws ParseException {
        Extract extract = WootFileExtractSource.get().getExtract("extracts/validExtractWithStatements.wt");
        
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, ResultCode.SUCCESS, 
                createBifrostRequest_InvalidAccountNumber(), extract);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.FAILURE.toString()));
        assertTrue(pdrComplete.getCompletionStatusDetail().equals(
                PDRCompletionStatusDetail.ACCOUNT_NOT_FOUND.toString()));
        assertNull(pdrComplete.getStatements());
    }
    
    @Test
    public void test_ResultCodeLimitedAccess() throws ParseException {
        PDRCompletionDTO pdrComplete = createPDRCompletionDTO();
        pdrComplete = domainTransformer.transformExtractIntoPDSDO(pdrComplete, 
        		ResultCode.LIMITED_ACCESS, null, null);
        
        assertTrue(pdrComplete.getCompletionStatus().equals(PDRCompletionStatus.FAILURE.toString()));
        assertTrue(pdrComplete.getCompletionStatusDetail().equals(
        		ResultCode.LIMITED_ACCESS.toString()));
        assertNull(pdrComplete.getStatements());
    }
    
    
    // Helper functions to create objects required for tests
    private PDRCompletionDTO createPDRCompletionDTO() {
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setBifrostId("fake-bifrost-id");
        pdrComplete.setCompletedAt(new Date());
        pdrComplete.setSourceTree("fake-source-tree");
        pdrComplete.setLogsId("fake-logs-id");
        return pdrComplete;
    }
    
    private BifrostRequest createValidBifrostRequest() throws ParseException {
        BifrostRequest bifrostRequest = new BifrostRequest();
        bifrostRequest.setAccountNumbers(new HashSet<String>(
                Arrays.asList(new String[]{ "874399272" })));
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String periodStart = "01/01/2014";
        String periodEnd = "01/01/2019";
        bifrostRequest.setPeriodStart(sdf.parse(periodStart));
        bifrostRequest.setPeriodEnd(sdf.parse(periodEnd));
        
        return bifrostRequest;
    }
    
    private BifrostRequest createBifrostRequest_InvalidAccountNumber() throws ParseException {
        BifrostRequest bifrostRequest = new BifrostRequest();
        bifrostRequest.setAccountNumbers(new HashSet<String>(
                Arrays.asList(new String[]{ "1234" })));
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String periodStart = "01/01/2015";
        String periodEnd = "01/01/2019";
        bifrostRequest.setPeriodStart(sdf.parse(periodStart));
        bifrostRequest.setPeriodEnd(sdf.parse(periodEnd));
        
        return bifrostRequest;
    }
    
    private BifrostRequest createBifrostRequest_NoStatementsInPeriod() throws ParseException {
        BifrostRequest bifrostRequest = new BifrostRequest();
        
        bifrostRequest.setAccountNumbers(new HashSet<String>(
                Arrays.asList(new String[]{ "874399272" })));
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String periodStart = "02/02/2014";
        String periodEnd = "03/01/2014";
        bifrostRequest.setPeriodStart(sdf.parse(periodStart));
        bifrostRequest.setPeriodEnd(sdf.parse(periodEnd));
        
        return bifrostRequest;
    }
    
    private BifrostRequest createBifrostRequest_FewerStatementsInPeriod() throws ParseException {
        BifrostRequest bifrostRequest = new BifrostRequest();
        
        bifrostRequest.setAccountNumbers(new HashSet<String>(
                Arrays.asList(new String[]{ "874399272" })));
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String periodStart = "01/05/2016";
        String periodEnd = "01/10/2016";
        bifrostRequest.setPeriodStart(sdf.parse(periodStart));
        bifrostRequest.setPeriodEnd(sdf.parse(periodEnd));
        
        return bifrostRequest;
    }
    
}
