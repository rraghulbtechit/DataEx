package com.urjanet.forseti.connect.transform.extract;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.keys.DomainKeys;
import urjanet.pull.core.Extract;
import urjanet.pull.core.ExtractValue;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.reference.ReferenceKey;

/**
 * Convert a text extract format i.e. [woot][/woot] format of the extract output
 * into an extract object.
 * 
 * @author sriram
 *
 */
public class ExtractWootizer {

	private static final Logger log = LoggerFactory.getLogger(ExtractWootizer.class);
	private final String WOOT_END = "[/woot]";
	private static ExtractWootizer instance = new ExtractWootizer();

	private ExtractWootizer() {
	}

	public static ExtractWootizer getInstance() {
		return instance;
	}

	public Extract getExtractForPath(String path) throws Exception {

		BufferedReader in = new BufferedReader(new FileReader(path));
		List<Extract> extractList = new ArrayList<Extract>();
		populateExtractFromText(in, extractList);
		return extractList.get(0);

	}
	
	public Extract getExtractFromInputStream(InputStream in) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		List<Extract> extractList = new ArrayList<Extract>();
		populateExtractFromText(reader, extractList);
		return extractList.get(0);
	}

	private void populateExtractFromText(BufferedReader in, List<Extract> extractList) throws Exception {
		String groupName;
		String line;

		DomainKeys key = null;
		while ((line = in.readLine()) != null) {
			line = line.trim();

			int equalsIdx = -1;
			if (!line.startsWith("[/") && line.startsWith("[")) {
				Extract currentExtract = new Extract();

				// Add references
				if (line.indexOf("->") != -1) {
					ExtractValue reference = null;
					String[] refs = StringUtils.splitByWholeSeparator(line, "->");
					for (int i=1; i<refs.length; ++i) {
						String[] referenceValues = StringUtils.substringsBetween(refs[i], "[", "]");
						ReferenceKey referenceKey = new ReferenceKey();
						for (String referenceValue : referenceValues) {
							String scopeToken = "scope:";
							int index = referenceValue.indexOf(scopeToken);
							if (index > -1) {
								referenceKey.setScopeId(referenceValue.substring(index + scopeToken.length()));
							} else {
								reference = new ExtractValue();
								reference.setName(StringUtils.substringBetween(referenceValue, "name:", " value:"));
								reference.setValue(StringUtils.substringBetween(referenceValue, "value:", " formatHint:"));
								reference.setFormatHint(StringUtils.substringAfter(referenceValue, "formatHint:"));
								referenceKey.addIdentifier(reference);
							}
						}
						currentExtract.addReference(referenceKey);
					}
				}
				
				extractList.add(currentExtract);
				
			} else if (line.startsWith("[/")) {
				if (!line.equals(WOOT_END)) {
					groupName = line.substring(2, line.length() - 2);
					extractList.get(extractList.size() - 2).addExtract(extractList.get(extractList.size() - 1), new GroupPolicy(groupName));
					extractList.remove(extractList.size() - 1);
				}
			} else if ((equalsIdx = line.indexOf("=")) != -1) {
				String formatHint = null;
				int formatIdx;
				if ((formatIdx = line.indexOf("fh = ")) != -1) {
					formatHint = line.substring(formatIdx + "fh = ".length());
					line = line.substring(0, formatIdx - 2);
				}

				String keyName = line.substring(0, equalsIdx).trim();
				String keyVal = line.substring(equalsIdx+1).trim();
				
//				DomainKeys prevKey = key;
//				key = KeyManager.getInstance().getKeyForName(keyName);
//				if (key == null) {
//					log.error("No domain key found for - " + keyName + ". Adding value to previous key");
//					// Add the value to the existing key, usually this is the case with message values
//					key = prevKey;
//					String val = extractList.get(extractList.size() - 1).getValue(key.getValue());
//					val = val + "\n" + line;
//					extractList.get(extractList.size() - 1).addValue(key.getValue(), val);
//				} else {
					if (!keyVal.isEmpty()) {
						extractList.get(extractList.size() - 1).addValue(keyName, keyVal, formatHint);
					} else {
						log.error("Value for domain key - " + keyName + " is empty.");
						extractList.get(extractList.size() - 1).addValue(keyVal, "", formatHint);
					}
//				}
			} else if (key != null) {
				// Add the value to the existing key, usually this is the case with message values
				String val = extractList.get(extractList.size() - 1).getValue(key.getValue());
				val = val + "\n" + line;
				extractList.get(extractList.size() - 1).addValue(key.getValue(), val);
			}
		}
	}
}
