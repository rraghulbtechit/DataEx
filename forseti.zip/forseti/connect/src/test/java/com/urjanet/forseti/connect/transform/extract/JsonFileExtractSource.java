package com.urjanet.forseti.connect.transform.extract;

import java.io.File;
import java.net.URL;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import urjanet.UrjanetRuntimeException;
import urjanet.pull.core.Extract;

public class JsonFileExtractSource implements ExtractSource {

	private static final JsonFileExtractSource onlyOne = new JsonFileExtractSource();
	private static ObjectMapper jsonMapper = null;
	
	static {
	    jsonMapper = new ObjectMapper();
        jsonMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        jsonMapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
        jsonMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        jsonMapper.enable(SerializationFeature.INDENT_OUTPUT);
        jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	private JsonFileExtractSource() {
	}

	public static JsonFileExtractSource get() {
		return onlyOne;
	}

	/**
	 * @param resourcePath relative path of json file within the resource directory
	 * ie. for src/test/resources/v1/extracts/file.json, give "v1/extracts/file.json"
	 */
	public Extract getExtract(String resourcePath) {
		return getExtractFromFile(resourcePath);
	}

    private Extract getExtractFromFile(String resourcePath) {
        try {
            URL url = getClass().getClassLoader().getResource("extracts/" + resourcePath);
            return jsonMapper.readValue(new File(url.getFile()), Extract.class);
        } catch (Exception e) {
            throw new UrjanetRuntimeException("Failed to load Extract from woot file " + resourcePath, e);
        }
    }
	
}
