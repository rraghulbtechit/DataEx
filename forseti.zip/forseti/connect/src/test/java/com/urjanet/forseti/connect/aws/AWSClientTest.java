package com.urjanet.forseti.connect.aws;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.listener.aws.AWSClient;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.model.PDR;

public class AWSClientTest {
    
    private AWSClient awsClient;
    
    @Before
    public void setup() throws Exception {
    	awsClient = new AWSClient();
    }
    
    @After
    public void teardown() throws Exception {
         // ???
    }
    
    @Test
    public void testTrue_publishFailureMessage_UC1() {
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.PARTIAL_DELIVERY.name());
        
        assertTrue(awsClient.shouldPublishFailureMessage(false, new PDR(), pdrComplete));
    }
    
    @Test
    public void testTrue_publishFailureMessage_UC2() {
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.name());
        
        assertTrue(awsClient.shouldPublishFailureMessage(false, new PDR(), pdrComplete));
    }
    
    @Test
    public void testTrue_publishFailureMessage_UC3() {
    	PDR pdr = new PDR();
        pdr.setRetryCount(10);
         
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.PARTIAL_DELIVERY.name());
        
        // final failure
        assertTrue(awsClient.shouldPublishFailureMessage(false, pdr, pdrComplete));
    }
    
    @Test
    public void testTrue_publishFailureMessage_UC4() {
    	PDR pdr = new PDR();
    	// initial failure
        pdr.setRetryCount(null);
         
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.PARTIAL_DELIVERY.name());
        
        assertTrue(awsClient.shouldPublishFailureMessage(true, pdr, pdrComplete));
    }
    
    @Test
    public void testFalse_publishFailureMessage_UC1() {
        PDR pdr = new PDR();
        pdr.setRetryCount(10);
        
        assertFalse(awsClient.shouldPublishFailureMessage(false, pdr, new PDRCompletionDTO()));
    }
    
    @Test
    public void testFalse_publishFailureMessage_UC2() {
        PDR pdr = new PDR();
        pdr.setRetryCount(10);
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        
        assertFalse(awsClient.shouldPublishFailureMessage(false, pdr, new PDRCompletionDTO()));
    }
    
    @Test
    public void testFalse_publishFailureMessage_UC3() {
        PDR pdr = new PDR();
        pdr.setRetryCount(10);
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.CREDENTIALS_INVALID.name());
        
        assertFalse(awsClient.shouldPublishFailureMessage(false, pdr, new PDRCompletionDTO()));
    }
    
    @Test
    public void testFalse_publishFailureMessage_UC4() {
        PDR pdr = new PDR();
        pdr.setRetryCount(10);
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.PARTIAL_DELIVERY.name());
        
        assertFalse(awsClient.shouldPublishFailureMessage(true, pdr, pdrComplete));
    }
    
    @Test
    public void testFalse_publishFailureMessage_UC5() {
        PDR pdr = new PDR();
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        
        assertFalse(awsClient.shouldPublishFailureMessage(true, pdr, pdrComplete));
    }
    
}