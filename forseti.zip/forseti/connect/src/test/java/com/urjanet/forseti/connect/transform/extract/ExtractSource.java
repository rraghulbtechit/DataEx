package com.urjanet.forseti.connect.transform.extract;

import urjanet.pull.core.Extract;

/**
 *
 * @author rburson
 */
public interface ExtractSource {

	public Extract getExtract(String extractId);

}
