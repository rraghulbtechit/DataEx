package com.urjanet.forseti.connect.transform;

import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import com.urjanet.bifrost.sdk.ResultCode;
import com.urjanet.forseti.connect.listener.JobStatusListener;
import com.urjanet.forseti.helpers.PDRCompletionDTO;
import com.urjanet.forseti.model.PDR;

public class JobStatusListenerTest {
    
    private JobStatusListener jobStatusListener;
    
    @Before
    public void setup() throws Exception {
        jobStatusListener = new JobStatusListener();
    }
    
    @After
    public void teardown() throws Exception {
         // ???
    }
    
    @Test
    public void testFalse_isThisPDRRetryable_NotFailure() {
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.SUCCESS.name());
        
        assertFalse(jobStatusListener.isThisPDRRetryable(pdrComplete, new PDR()));
    }
    
    @Test
    public void testFalse_isThisPDRRetryable_NotGeneralFailure() {
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.SUCCESS.name());
        
        assertFalse(jobStatusListener.isThisPDRRetryable(pdrComplete, new PDR()));
    }
    
    @Test
    public void testFalse_isThisPDRRetryable_InvalidExpirationDate1() {
        PDR pdr = new PDR();
        pdr.setExpirationDate(new Date());
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.name());
        
        assertFalse(jobStatusListener.isThisPDRRetryable(pdrComplete, pdr));
    }
    
    @Test
    public void testFalse_isThisPDRRetryable_InvalidExpirationDate2() {
        PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 1);
        pdr.setExpirationDate(cal.getTime());
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.name());
        
        assertFalse(jobStatusListener.isThisPDRRetryable(pdrComplete, pdr));
    }
    
    @Test
    public void testFalse_isThisPDRRetryable_InvalidExpirationDate3() {
        PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, -1);
        pdr.setExpirationDate(cal.getTime());
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.name());
        
        assertFalse(jobStatusListener.isThisPDRRetryable(pdrComplete, pdr));
    }
    
    @Test
    public void testTrue_isThisPDRRetryable() {
        PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 5);
        pdr.setExpirationDate(cal.getTime());
        
        PDRCompletionDTO pdrComplete = new PDRCompletionDTO();
        pdrComplete.setCompletionStatus(ResultCode.FAILURE.name());
        pdrComplete.setCompletionStatusDetail(ResultCode.GENERAL_FAILURE.name());
        
        assertTrue(jobStatusListener.isThisPDRRetryable(pdrComplete, pdr));
    }
    
    @Test
    public void testCalculateNextRetryDate_NullDate() {
    	PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 1);
        pdr.setExpirationDate(cal.getTime());
        
        Date nextRetryAt = jobStatusListener.calculateNextRetryDate(pdr);
        assertTrue(nextRetryAt == null);
    }
    
    @Test
    public void testCalculateNextRetryDate_Timeout6hours() {
    	PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 6);
        pdr.setExpirationDate(cal.getTime());
        
        Date now = new Date();
        Calendar calNow = Calendar.getInstance();
        calNow.setTime(now);
        
        Date nextRetryAt = jobStatusListener.calculateNextRetryDate(pdr);
        assertTrue(nextRetryAt != null);
        assertTrue(nextRetryAt.getTime() > calNow.getTime().getTime());
        assertTrue(nextRetryAt.getTime() < pdr.getExpirationDate().getTime());
    }
    
    @Test
    public void testCalculateNextRetryDate_Timeout16hours() {
    	PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 16);
        pdr.setExpirationDate(cal.getTime());
        
        Date now = new Date();
        Calendar calNow = Calendar.getInstance();
        calNow.setTime(now);
        
        Date nextRetryAt = jobStatusListener.calculateNextRetryDate(pdr);
        assertTrue(nextRetryAt != null);
        assertTrue(nextRetryAt.getTime() > calNow.getTime().getTime());
        assertTrue(nextRetryAt.getTime() < pdr.getExpirationDate().getTime());
    }
    
    @Test
    public void testCalculateNextRetryDate_Timeout25hours() {
    	PDR pdr = new PDR();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, 25);
        pdr.setExpirationDate(cal.getTime());
        
        Date now = new Date();
        Calendar calNow = Calendar.getInstance();
        calNow.setTime(now);
        
        Date nextRetryAt = jobStatusListener.calculateNextRetryDate(pdr);
        assertTrue(nextRetryAt != null);
        assertTrue(nextRetryAt.getTime() > calNow.getTime().getTime());
        assertTrue(nextRetryAt.getTime() < pdr.getExpirationDate().getTime());
    }
}
