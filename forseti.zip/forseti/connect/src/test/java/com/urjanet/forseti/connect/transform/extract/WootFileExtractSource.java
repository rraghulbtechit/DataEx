package com.urjanet.forseti.connect.transform.extract;

import java.io.File;

import urjanet.UrjanetRuntimeException;
import urjanet.pull.core.Extract;
import urjanet.util.ClasspathResourceUtil;

/**
 *
 * @author rburson
 */
public class WootFileExtractSource implements ExtractSource {

	private static final WootFileExtractSource onlyOne = new WootFileExtractSource();

	private WootFileExtractSource() {
	}

	public static WootFileExtractSource get() {
		return onlyOne;
	}

	/**
	 * @param resourcePath relative path of woot file within the resource directory
	 * ie. for src/test/resources/v1/extracts/woot.wt, give "v1/extracts/woot.wt"
	 */
	public Extract getExtract(String resourcePath) {
		return getExtractFromFile(resourcePath);
	}

	private Extract getExtractFromFile(String resourcePath) {
		try {
			File file = ClasspathResourceUtil.getFileOrDirectoryForResource(resourcePath);
			return ExtractWootizer.getInstance().getExtractForPath(file.getAbsolutePath());

		} catch (Exception e) {
			throw new UrjanetRuntimeException("Failed to load Extract from woot file " + resourcePath, e);
		}
	}

	
	
}
