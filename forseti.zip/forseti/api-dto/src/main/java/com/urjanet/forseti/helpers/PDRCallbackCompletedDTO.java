package com.urjanet.forseti.helpers;

public class PDRCallbackCompletedDTO {

	private Integer completionCallbackResult;

	public PDRCallbackCompletedDTO() {
	}

	public Integer getCompletionCallbackResult() {
		return completionCallbackResult;
	}
	
	public void setCompletionCallbackResult(Integer completionCallbackResult) {
		this.completionCallbackResult = completionCallbackResult;
	}
}
