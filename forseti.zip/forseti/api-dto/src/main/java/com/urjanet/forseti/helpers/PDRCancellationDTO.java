package com.urjanet.forseti.helpers;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PDRCancellationDTO {

	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String status;

	public PDRCancellationDTO() {
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getStatus() {
		return status;
	}
	
}
