package com.urjanet.forseti.helpers;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PDRSubmittedAcquisitionDTO {

	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String bifrostId;

	public String getBifrostId() {
		return bifrostId;
	}

	public void setBifrostId(String bifrostId) {
		this.bifrostId = bifrostId;
	}
	
}
