package com.urjanet.forseti.helpers;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.Size;

public class StatementDTO {
	
	@Size(max=255, message="The field must be less than 255 characters")
    private String billingName;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingStreet1;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingStreet2;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingCity;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingState;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingCountry;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingPostalCode;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingPhone;
	
	private Date dueDate;
	
	@Size(max=32, message="The field must be less than 32 characters")
	private String paymentCurrency;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String accountNumber;
	
	private Date statementDate;
	private BigDecimal totalBill;
	private BigDecimal recentPayment;
    private Date recentPaymentDate;
    
    // This is a csv list of sourceId nodes to this point source
    private String sourceIds;
	
	public StatementDTO() {
	    
	}

	public String getBillingName() {
		return billingName;
	}

	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}

	public String getBillingStreet1() {
		return billingStreet1;
	}

	public void setBillingStreet1(String billingStreet1) {
		this.billingStreet1 = billingStreet1;
	}

	public String getBillingStreet2() {
		return billingStreet2;
	}

	public void setBillingStreet2(String billingStreet2) {
		this.billingStreet2 = billingStreet2;
	}

	public String getBillingCity() {
		return billingCity;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public String getBillingState() {
		return billingState;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public String getBillingCountry() {
		return billingCountry;
	}

	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	public String getBillingPhone() {
		return billingPhone;
	}

	public void setBillingPhone(String billingPhone) {
		this.billingPhone = billingPhone;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public Date getStatementDate() {
		return statementDate;
	}
	
	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getTotalBill() {
        return totalBill;
    }

    public void setTotalBill(BigDecimal totalBill) {
        this.totalBill = totalBill;
    }

    public BigDecimal getRecentPayment() {
        return recentPayment;
    }

    public void setRecentPayment(BigDecimal recentPayment) {
        this.recentPayment = recentPayment;
    }

    public Date getRecentPaymentDate() {
        return recentPaymentDate;
    }

    public void setRecentPaymentDate(Date recentPaymentDate) {
        this.recentPaymentDate = recentPaymentDate;
    }
    
    public String getSourceIds() {
		return sourceIds;
	}
    
    public void setSourceIds(String sourceIds) {
		this.sourceIds = sourceIds;
	}
}
