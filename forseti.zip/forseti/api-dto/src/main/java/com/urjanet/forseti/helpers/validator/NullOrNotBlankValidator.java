package com.urjanet.forseti.helpers.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NullOrNotBlankValidator implements ConstraintValidator<NullOrNotBlank, String> {

  public void initialize(NullOrNotBlank field) {
    // nothing to initialize
  }

  public boolean isValid(String field, ConstraintValidatorContext cvc) {
	  if (field == null)
		  return true;
	  
	  if (field.trim().length() >0)
		  return true;
	  
	  return false;
  }
  
  
}  