package com.urjanet.forseti.helpers;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.beans.BeanUtils;

import com.urjanet.forseti.helpers.StatementDTO;
import com.urjanet.forseti.model.Statement;

public class DTOUtils {

	public static Statement statementFromDTO(StatementDTO dto, long pdrId) {
		
		Statement stmt = new Statement();
		BeanUtils.copyProperties(dto, stmt);
		stmt.setPdrID(pdrId);
		stmt.setCreatedDate(new Date());

		return stmt;
	}
	
	public static String fromISODate(Date datetime) {
		return ISODateTimeFormat.date().print(new DateTime(datetime));
	}
	
	public static Date toISODate(String date) {
		return ISODateTimeFormat.date().parseDateTime(date).toDate();
	}
	
}
