package com.urjanet.forseti.helpers;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.URL;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;

import com.urjanet.forseti.helpers.validator.NullOrNotBlank;

public class PDRDTO {

	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String accountNumber;
	
	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String username;
	
	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String password;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String password2;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String correlationId;

	@Pattern(message="Valid format is YYYY-MM-DD" , regexp="^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
	private String periodStart = new DateTime().minusMonths(1).toString("yyyy-MM-dd"); // default to the previous month

	@Pattern(message="Valid format is YYYY-MM-DD" , regexp="^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
	private String periodEnd = new DateTime().toString("yyyy-MM-dd");
	
	@Min(value = 0)
	@Max(value = DateTimeConstants.SECONDS_PER_WEEK * 3)
	private int timeout = new Integer(DateTimeConstants.SECONDS_PER_WEEK * 3);
	
	@Size(max=255, message="The field must be less than 255 characters")
	@URL(message="The field must be a valid URL")
	@NullOrNotBlank
	private String completionCallbackUrl;
	
	private Boolean historyEnabled = Boolean.TRUE;


	public PDRDTO() {
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword2() {
		return password2;
	}
	
	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(String periodStart) {
		this.periodStart = periodStart;
	}

	public String getPeriodEnd() {
		return periodEnd;
	}

	public void setPeriodEnd(String periodEnd) {
		this.periodEnd = periodEnd;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	public String getCompletionCallbackUrl() {
		return completionCallbackUrl;
	}

	public void setCompletionCallbackUrl(String completionCallbackUrl) {
		this.completionCallbackUrl = completionCallbackUrl;
	}
	
	public boolean isHistoryEnabled() {
		return historyEnabled;
	}

	public void setHistoryEnabled(boolean historyEnabled) {
		this.historyEnabled = historyEnabled;
	}

}
