package com.urjanet.forseti.helpers;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

public class PDRCompletionDTO {

	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String completionStatus;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String completionStatusDetail;

	@NotNull
	@Size(max=255, message="The field must be less than 255 characters")
	private String bifrostId;

	@NotNull
	@Past
	private Date completedAt;

	private Set<StatementDTO> statements = new HashSet<>();
	
	// S3 id of the navigation tree (this data is compressed)
	private String sourceTree;
	
	// S3 id of bifrost engine logs (this data is compressed)
	private String logsId;
	
	public PDRCompletionDTO() {
	}

	public String getCompletionStatus() {
		return completionStatus;
	}

	public void setCompletionStatus(String completionStatus) {
		this.completionStatus = completionStatus;
	}

	public String getCompletionStatusDetail() {
		return completionStatusDetail;
	}

	public void setCompletionStatusDetail(String completionStatusDetail) {
		this.completionStatusDetail = completionStatusDetail;
	}

	public String getBifrostId() {
		return bifrostId;
	}

	public void setBifrostId(String bifrostId) {
		this.bifrostId = bifrostId;
	}

	public Date getCompletedAt() {
		return completedAt;
	}

	public void setCompletedAt(Date completedAt) {
		this.completedAt = completedAt;
	}

	public Set<StatementDTO> getStatements() {
		return statements;
	}

	public void setStatements(Set<StatementDTO> statements) {
		this.statements = statements;
	}
	
	public String getSourceTree() {
		return sourceTree;
	}
	
	public void setSourceTree(String sourceTree) {
		this.sourceTree = sourceTree;
	}
	
	public String getLogsId() {
		return logsId;
	}
	
	public void setLogsId(String logsId) {
		this.logsId = logsId;
	}
}
