package com.urjanet.forseti.utils;

import java.io.IOException;

import com.amazonaws.util.EC2MetadataUtils;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractFieldJsonProvider;
import net.logstash.logback.composite.JsonWritingUtils;

public class Ec2InstanceJsonProvider extends
		AbstractFieldJsonProvider<ILoggingEvent> {

	private static String instanceId = EC2MetadataUtils.getInstanceId();
	private static String amiId = EC2MetadataUtils.getAmiId();
	private static String region = EC2MetadataUtils.getEC2InstanceRegion();
	private static String instanceType = EC2MetadataUtils.getInstanceType();
	private static String availabilityZone = EC2MetadataUtils.getAvailabilityZone();

	public Ec2InstanceJsonProvider() {
	}

	@Override
	public void writeTo(JsonGenerator generator, ILoggingEvent event)
			throws IOException {

		JsonWritingUtils.writeStringField(generator, "instance", instanceId);
		JsonWritingUtils.writeStringField(generator, "ami", amiId);
		JsonWritingUtils.writeStringField(generator, "region", region);
		JsonWritingUtils.writeStringField(generator, "type", instanceType);
		JsonWritingUtils.writeStringField(generator, "az", availabilityZone);
	}

}