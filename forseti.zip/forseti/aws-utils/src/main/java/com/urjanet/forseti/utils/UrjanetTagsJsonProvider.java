package com.urjanet.forseti.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.logstash.logback.composite.AbstractFieldJsonProvider;
import net.logstash.logback.composite.JsonWritingUtils;
import ch.qos.logback.classic.spi.ILoggingEvent;

import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.util.EC2MetadataUtils;
import com.fasterxml.jackson.core.JsonGenerator;

public class UrjanetTagsJsonProvider extends
		AbstractFieldJsonProvider<ILoggingEvent>  {

	private static String instanceId = EC2MetadataUtils.getInstanceId();
	
	private static Map<String, String> tags = new HashMap<>();
	
	static {

		if (instanceId != null) {
			AmazonEC2Client client = new AmazonEC2Client();

			DescribeInstancesRequest req = new DescribeInstancesRequest()
					.withInstanceIds(instanceId);
			DescribeInstancesResult res = client.describeInstances(req);
			Reservation me = res.getReservations().get(0);
			List<Instance> instances = me.getInstances();
			for (Tag tag : instances.get(0).getTags()) {
				//ignore aws default tags for logging. We set stack name ourselves in CF script
				if (!tag.getKey().startsWith("aws:")) {
					tags.put(tag.getKey(), tag.getValue());
				}
			}
		}
	}
	
	public UrjanetTagsJsonProvider() {
	}

	@Override
	public void writeTo(JsonGenerator generator, ILoggingEvent event)
			throws IOException {
		for (String tag : tags.keySet()) {
			JsonWritingUtils.writeStringField(generator, tag, tags.get(tag));
		}
	}
}
