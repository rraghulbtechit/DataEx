package com.urjanet.forseti.scheduler.job;

import java.util.Date;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.aws.core.env.ResourceIdResolver;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.util.EC2MetadataUtils;

@Component
public class HeartbeatJob {

    private static final Logger LOG = LoggerFactory.getLogger(HeartbeatJob.class);

    private static String HEARTBEAT_SNS_TOPIC_ID = "ForsetiHeartbeatTopic";

    @Autowired
    private ResourceIdResolver resourceIdResolver;

    @SuppressWarnings("unchecked")
    @Scheduled(fixedRate = 60000)
    public void execute() throws Exception {

        String snsTopicArn = resourceIdResolver.resolveToPhysicalResourceId(HEARTBEAT_SNS_TOPIC_ID);

        AmazonSNSClient client = new AmazonSNSClient();
        LOG.debug("Publishing a heartbeat message to topic {}", snsTopicArn);

        JSONObject data = new JSONObject();
        try {
            String instanceId = EC2MetadataUtils.getInstanceId();
            data.put("data", instanceId + new Date());
        } catch (Exception e) {
            e.printStackTrace();
            data.put("data", new Date());
        }

        PublishRequest pubRequest = new PublishRequest(snsTopicArn, data.toJSONString());
        client.publish(pubRequest);
    }

}