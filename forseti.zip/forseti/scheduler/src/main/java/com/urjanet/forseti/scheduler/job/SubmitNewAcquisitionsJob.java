package com.urjanet.forseti.scheduler.job;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.aws.core.env.ResourceIdResolver;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.forseti.Util;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.rest.RestConfig;
import com.urjanet.forseti.service.PDRService;

@Component
public class SubmitNewAcquisitionsJob {

	//rest template must be autowired for Sleuth to inject the HTTP headers properly
	@Autowired
	RestTemplate halJsonRestTemplate;
	
	private static final Logger LOG = LoggerFactory.getLogger(SubmitNewAcquisitionsJob.class);
	
	@Autowired
	private Tracer tracer;
	
	@Autowired
	private PDRService pdrService;

	@Autowired
	RestConfig restConfig;

	@Autowired
	private ResourceIdResolver resourceIdResolver;

	// This job runs once every minute, and submits NEW jobs to bifrost to be processed.
	@Scheduled(fixedRate = 60000)  // once every minute
	public void execute() {

		// 1. Get a list of new PDRs to be submited to bifrost
		LOG.debug("Get a list of new PDRs to be submmited to bifrost");
		List<PDR> list = new ArrayList<PDR>();
		Page<PDR> page = pdrService.findNewPDRsToSubmitAcquisition(new PageRequest(0, Util.RESULTS_PER_PAGE));
		while (page != null && page.getNumberOfElements() > 0) {
			for (PDR pdr: page.getContent()) {
				list.add(pdr);
			}
			page = pdrService.findNewPDRsToSubmitAcquisition(new PageRequest(page.getNumber()+1, Util.RESULTS_PER_PAGE));
		}
		if (list.size() > 0)
			LOG.info("Processing {} new PDRs to submit to bifrost", list.size());

		// Save original span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);

		// 2. For each PDR, call Bifrost to submit PDR
		for (PDR pdr: list) {
			Span span = null;
			try {
				//manually create a new span for Sleuth
				Long traceId = Span.hexToId(pdr.getTraceId());
				Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiScheduler:SubmitNewAcquisitionsJob");
				span = builder.build();
				//continue the span within the tracer so it shows up in the logs
				tracer.continueSpan(span);
				LOG.trace("Continuing span " + Span.idToHex(span.getSpanId()));

				String providerId = pdr.getProviderId();
				String snsTopicArn = resourceIdResolver.resolveToPhysicalResourceId(Util.FORSETI_SNS_TOPIC_ID);
				BifrostRequest jsonObject = Util.createBifrostRequest(pdr, providerId, snsTopicArn);

				String bifrostApiUrl = restConfig.getBifrostApiUrl() + Util.BIFROST_EXTRACT_URL;

				// 2.1. Call Bifrost to submit PDR
				LOG.info("Calling Bifrost at {} to submit *new* PDR {} with {}", bifrostApiUrl, pdr.getId(), jsonObject);
				try {
					ResponseEntity<JSONObject> entityPost = halJsonRestTemplate.exchange(bifrostApiUrl,
							HttpMethod.POST,
							new HttpEntity<>(jsonObject, restConfig.createHeadersAcceptHalAndJSON()),
										new ParameterizedTypeReference<JSONObject>() {});
					LOG.debug("Response from Bifrost = {}", entityPost);

					if (entityPost.getStatusCode().is2xxSuccessful()) {
						
						// 2.2. Update new PDR in database
						String bifrostId = entityPost.getBody().get(Util.BIFROST_JOBID).toString();
						pdr.setBifrostId(bifrostId);
						pdr.setStartedAt(new Date());
						pdrService.save(pdr);
						LOG.info("Updated *new* PDR {} with bifrostId={}, startedAt={}", 
								pdr.getId(), bifrostId, pdr.getStartedAt());

					} else {
						LOG.error("Encountered error in SubmitNewAcquisitions {}", entityPost.getBody());
					}
				} catch (Exception e) {
					LOG.error("Encountered error in SubmitNewAcquisitions job {}", e);
				}
			} finally {
				if (span != null) {
					tracer.detach(span);
					LOG.trace("Detached span " +  Span.idToHex(span.getSpanId()));
				}
			}
		}

		// Reattach original span
		tracer.continueSpan(originalSpan);
	}
}
