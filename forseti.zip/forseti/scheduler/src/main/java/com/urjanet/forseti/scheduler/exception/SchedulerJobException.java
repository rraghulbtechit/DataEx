package com.urjanet.forseti.scheduler.exception;

/**
 * Replaced the Quartz JobExecutionException.
 *
 * Created by bwilson on 12/14/16.
 */
public class SchedulerJobException extends Exception {

    public SchedulerJobException(String message) {
        super(message);
    }
}
