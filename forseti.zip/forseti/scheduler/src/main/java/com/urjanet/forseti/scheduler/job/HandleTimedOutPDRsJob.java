package com.urjanet.forseti.scheduler.job;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.urjanet.forseti.Util;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.service.PDRService;

@Component
public class HandleTimedOutPDRsJob {
	
	private static final Logger LOG = LoggerFactory.getLogger(HandleTimedOutPDRsJob.class);

	@Autowired
	private Tracer tracer;
	
	@Autowired
	private PDRService pdrService;

	// This job runs once every minute and handles timed out PDRs.
	// A PDR is said to be in TIMEOUT state when forseti has not submitted it to bifrost.
	@Scheduled(fixedRate = 60000)  // once every minute
	public void execute() {
		
		// 1. Get a list of PDRs to timeout
		LOG.debug("Get a list of PDRs to timeout");
		List<PDR> list = new ArrayList<PDR>();
		Page<PDR> page = pdrService.findPDRsToTimeout(new PageRequest(0, Util.RESULTS_PER_PAGE));
		while (page != null && page.getNumberOfElements() > 0) {
			for (PDR pdr: page.getContent()) {
				list.add(pdr);
			}
			page = pdrService.findPDRsToTimeout(new PageRequest(page.getNumber()+1, Util.RESULTS_PER_PAGE));
		}
		if (list.size( )> 0)
			LOG.info("Processing {} PDRs to timeout", list.size());
		
		// Save original span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);
		
		// 2. For each PDR, call timeout
		for (PDR pdr: list) {
			Span span = null;
			try {
				//manually create a new span for Sleuth
				Long traceId = Span.hexToId(pdr.getTraceId());
				Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiScheduler:HandleTimedoutPDRsJob");
				span = builder.build();
				//continue the span within the tracer so it shows up in the logs
				tracer.continueSpan(span);

				// Call timeout and Update database
				pdrService.timeout(pdr);
				LOG.info("Updated PDR {} with completionStatus=TIMEOUT. This change in status triggers a callback.", pdr.getId());
				
			} finally {
				if (span != null) {
					tracer.detach(span);
				}
			}
		}

		// Reattach original span
		tracer.continueSpan(originalSpan);
	}
}
