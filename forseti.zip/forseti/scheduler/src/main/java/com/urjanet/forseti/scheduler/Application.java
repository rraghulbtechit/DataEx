package com.urjanet.forseti.scheduler;

import com.urjanet.forseti.service.impl.PIBServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com.urjanet.forseti.repository")
@ComponentScan(basePackages = {"com.urjanet.forseti.*"}, excludeFilters={
		@ComponentScan.Filter(type=FilterType.ASSIGNABLE_TYPE, value=PIBServiceImpl.class)})
@EntityScan("com.urjanet.forseti.*")
public class Application {
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		System.out.println("Starting up forseti-scheduler");
	}
}