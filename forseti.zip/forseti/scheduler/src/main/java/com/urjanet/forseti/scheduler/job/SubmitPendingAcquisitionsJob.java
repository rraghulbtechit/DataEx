package com.urjanet.forseti.scheduler.job;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.urjanet.forseti.Util;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.service.PDRService;

@Component
public class SubmitPendingAcquisitionsJob {
	
	//rest template must be autowired for Sleuth to inject the HTTP headers properly
	@Autowired
	RestTemplate halJsonRestTemplate;
	
	private static final Logger LOG = LoggerFactory.getLogger(SubmitPendingAcquisitionsJob.class);
	
	@Autowired
	private Tracer tracer;
	
	@Autowired
	private PDRService pdrService;
	
	/* This job runs once every hour, and submits PENDING jobs to bifrost to be retried.
	 * Each PDR will be retried at least once every 24 hours till it finishes 
	 * with a valid (success or failure) status.
	 */
	@Scheduled(fixedRate = 60*60000)  // once every 1 hour
	public void execute() {

		// 1. Get a list of pending PDRs to submit to bifrost
		LOG.debug("Get a list of pending PDRs to submit to bifrost");
		List<PDR> list = new ArrayList<PDR>();
		Page<PDR> page = pdrService.findPendingPDRsToSubmitAcquisition(new PageRequest(0, Util.RESULTS_PER_PAGE));
		while (page != null && page.getNumberOfElements() > 0) {
			for (PDR pdr: page.getContent()) {
				list.add(pdr);
			}
			page = pdrService.findPendingPDRsToSubmitAcquisition(new PageRequest(page.getNumber()+1, Util.RESULTS_PER_PAGE));
		}
		if (list.size() > 0)
			LOG.info("Processing {} pending PDRs to submit to bifrost", list.size());
		
		// Save original span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);

		// 2. For each PDR, call retry 
		for (PDR pdr: list) {
			pdrService.triggerRetry(pdr);
		}

		// Reattach original span
		tracer.continueSpan(originalSpan);
	}
}
