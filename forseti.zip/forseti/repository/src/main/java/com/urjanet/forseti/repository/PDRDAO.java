package com.urjanet.forseti.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.urjanet.forseti.model.PDR;

@Repository
public interface PDRDAO extends PagingAndSortingRepository<PDR, Long>,
		JpaSpecificationExecutor<PDR> {

	Page<PDR> findAllByCorrelationId(Pageable pageable, String correlationId);

	Page<PDR> findAllByBifrostId(Pageable pageable, String jobId);

	@Query("select p from PDR p where p.completionStatus IS NULL and CURRENT_TIMESTAMP >= p.expirationDate")
	Page<PDR> findPDRsToTimeout(Pageable pageable);

	@Query("select p from PDR p where p.completionStatus IS NOT NULL and p.completionCallbackUrl IS NOT NULL and p.completionCallbackResult IS NULL")
	Page<PDR> findPDRsToCallback(Pageable pageable);
	
	@Query("select p from PDR p where p.bifrostId IS NULL and p.completionStatus IS NULL and CURRENT_TIMESTAMP < p.expirationDate")
	Page<PDR> findNewPDRsToSubmitAcquisition(Pageable pageable);
	
	@Query("select p from PDR p where p.bifrostId IS NOT NULL and p.completionStatus='PENDING' and "
	        + "( (p.lastRetriedAt IS NULL and TIMESTAMPDIFF(HOUR, CURRENT_TIMESTAMP, p.expirationDate)<=4) OR "
	        + "(p.lastRetriedAt IS NOT NULL and TIMESTAMPDIFF(MINUTE, p.lastRetriedAt, p.lastReceivedAt)>0 and "
	        + "(TIMESTAMPDIFF(HOUR, p.lastRetriedAt, CURRENT_TIMESTAMP)>=24 OR TIMESTAMPDIFF(HOUR, CURRENT_TIMESTAMP, p.expirationDate)<=4)))")
	@Deprecated
	Page<PDR> findPendingAndExpiringPDRsToSubmitAcquisition(Pageable pageable);
	
	@Query("select p from PDR p where p.bifrostId IS NOT NULL and p.completionStatus='PENDING' and "
	        + "p.retryAt IS NOT NULL and TIMESTAMPDIFF(MINUTE, CURRENT_TIMESTAMP, p.retryAt) <= 0")
	Page<PDR> findPendingPDRsToSubmitAcquisition(Pageable pageable);
	
	PDR findByIdAndOrganizationId(long id, long organizationId);

	Page<PDR> findAllByOrganizationId(Pageable pageable, long organizationId);

	Page<PDR> findAllByCorrelationIdAndOrganizationId(Pageable pageable, String correlationId, long organizationId);

}
