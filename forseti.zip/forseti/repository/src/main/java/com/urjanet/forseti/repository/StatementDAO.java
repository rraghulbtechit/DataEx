package com.urjanet.forseti.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.urjanet.forseti.model.Statement;

@Repository
public interface StatementDAO extends PagingAndSortingRepository<Statement, Long>{
	
	Page<Statement> findByPdrID(Pageable page, long id);
	
	
}
