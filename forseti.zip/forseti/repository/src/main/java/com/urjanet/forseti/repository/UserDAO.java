package com.urjanet.forseti.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.urjanet.forseti.model.User;


@Repository
public interface UserDAO extends PagingAndSortingRepository<User, Long>,
JpaSpecificationExecutor<User>{

}
