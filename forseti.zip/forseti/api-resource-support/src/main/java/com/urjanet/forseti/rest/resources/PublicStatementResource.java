package com.urjanet.forseti.rest.resources;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class PublicStatementResource extends ResourceSupport {

	private BigDecimal totalBill;
	private BigDecimal recentPayment;
	
	private String billingName;
	private String billingStreet1;
	private String billingStreet2;
	private String billingCity;
	private String billingState;
	private String billingCountry;
	private String billingPostalCode;
	private String paymentCurrency;
	
	@JsonSerialize(using = ISODateSerializer.class)
	private Date recentPaymentDate;
	
	@JsonSerialize(using = ISODateSerializer.class)
	private Date dueDate;
	
	@JsonSerialize(using = ISODateSerializer.class)
	private Date statementDate;
	private Date lastModified;
	private Date createdDate;
	
	public PublicStatementResource() {
		super();
	}


	public BigDecimal getTotalBill() {
		return totalBill;
	}


	public void setTotalBill(BigDecimal totalBill) {
		this.totalBill = totalBill;
	}
	
	public BigDecimal getRecentPayment() {
		return recentPayment;
	}


	public void setRecentPayment(BigDecimal recentPayment) {
		this.recentPayment = recentPayment;
	}


	public String getBillingName() {
		return billingName;
	}

	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}
	
	public String getBillingStreet1() {
		return billingStreet1;
	}
	
	public void setBillingStreet1(String billingStreet1) {
		this.billingStreet1 = billingStreet1;
	}
	
	public String getBillingStreet2() {
		return billingStreet2;
	}
	
	public void setBillingStreet2(String billingStreet2) {
		this.billingStreet2 = billingStreet2;
	}

	public String getBillingCity() {
		return billingCity;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public String getBillingState() {
		return billingState;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public String getBillingCountry() {
		return billingCountry;
	}

	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getStatementDate() {
		return statementDate;
	}
	
	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


    public Date getRecentPaymentDate() {
        return recentPaymentDate;
    }


    public void setRecentPaymentDate(Date recentPaymentDate) {
        this.recentPaymentDate = recentPaymentDate;
    }

	
	
}
