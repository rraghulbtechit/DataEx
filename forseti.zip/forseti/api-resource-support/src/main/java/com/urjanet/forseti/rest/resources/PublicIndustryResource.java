package com.urjanet.forseti.rest.resources;

import java.util.Date;

import org.springframework.hateoas.ResourceSupport;

public class PublicIndustryResource extends ResourceSupport {

	private String name;
	private Date lastModified;
	private Date createdDate;

	public PublicIndustryResource() {
		super();
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getLastModified() {
		return lastModified;
	}


	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	

}
