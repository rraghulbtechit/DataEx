package com.urjanet.forseti.rest.resources;

import java.util.Date;

public class PrivatePDRResource extends PublicPDRResource {

	private String source;
	
	private String bifrostId;
	
	private Date startedAt;

	private String traceId;
	@Deprecated
	private String organizationName;
	
	private String sourceTree;
	
	private String logsId;
	
	private String providerName;

	private Date completedAt;
   
	
	// Fields for enhanced error handling
	@Deprecated
	private Date lastRetriedAt;
	@Deprecated
	private Date lastReceivedAt;
	private Integer retryCount;
	private Date retryAt;
	
	public PrivatePDRResource() {
		super();
		
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	
	public String getBifrostId() {
		return bifrostId;
	}
	
	public void setBifrostId(String bifrostId) {
		this.bifrostId = bifrostId;
	}
	
	public Date getStartedAt() {
		return startedAt;
	}
	
	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}
	
	public String getTraceId() {
		return traceId;
	}
	
	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
	
	public String getOrganizationName() {
		return organizationName;
	}
	
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getSourceTree() {
		return sourceTree;
	}
	
	public void setSourceTree(String sourceTree) {
		this.sourceTree = sourceTree;
	}
	
	public String getLogsId() {
		return logsId;
	}
	
	public void setLogsId(String logsId) {
		this.logsId = logsId;
	}
	
	public String getProviderName() {
		return providerName;
	}
	
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	
	public Date getLastRetriedAt() {
		return lastRetriedAt;
	}

	public void setLastRetriedAt(Date lastRetriedAt) {
		this.lastRetriedAt = lastRetriedAt;
	}
	
	public Date getLastReceivedAt() {
		return lastReceivedAt;
	}

	public void setLastReceivedAt(Date lastReceivedAt) {
		this.lastReceivedAt = lastReceivedAt;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}
	
	public Date getRetryAt() {
		return retryAt;
	}
	
	public void setRetryAt(Date retryAt) {
		this.retryAt = retryAt;
	}

	public Date getCompletedAt() {
		return completedAt;
	}

	public void setCompletedAt(Date completedAt) {
		this.completedAt = completedAt;
	}

}
