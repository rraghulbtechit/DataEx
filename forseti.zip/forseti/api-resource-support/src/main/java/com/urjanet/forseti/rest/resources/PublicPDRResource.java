package com.urjanet.forseti.rest.resources;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class PublicPDRResource extends ResourceWithEmbeddeds {
	
	private String accountNumber;
	private String username;
	private String password;
	private String password2;
	private String correlationId;
	private String completionStatus;
	private String completionStatusDetail;
	private Date createdDate;
	private Date lastModified;
	
	@JsonSerialize(using = ISODateSerializer.class)
	private Date periodStart;

	@JsonSerialize(using = ISODateSerializer.class)
	private Date periodEnd;
	
	private Date expirationDate;
	private String completionCallbackUrl;
	private Integer completionCallbackResult;
	
	private Integer statementCount;

	public PublicPDRResource() {
		super();
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword2() {
		return password2;
	}
	
	public void setPassword2(String password2) {
		this.password2 = password2;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getCompletionStatus() {
		return completionStatus;
	}

	public void setCompletionStatus(String completionStatus) {
		this.completionStatus = completionStatus;
	}

	public String getCompletionStatusDetail() {
		return completionStatusDetail;
	}

	public void setCompletionStatusDetail(String completionStatusDetail) {
		this.completionStatusDetail = completionStatusDetail;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public Date getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(Date periodStart) {
		this.periodStart = periodStart;
	}

	public Date getPeriodEnd() {
		return periodEnd;
	}

	public void setPeriodEnd(Date periodEnd) {
		this.periodEnd = periodEnd;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getCompletionCallbackUrl() {
		return completionCallbackUrl;
	}

	public void setCompletionCallbackUrl(String completionCallbackUrl) {
		this.completionCallbackUrl = completionCallbackUrl;
	}

	public Integer getCompletionCallbackResult() {
		return completionCallbackResult;
	}

	public void setCompletionCallbackResult(Integer completionCallbackResult) {
		this.completionCallbackResult = completionCallbackResult;
	}
	
	public Integer getStatementCount() {
		return statementCount;
	}
	
	public void setStatementCount(Integer statementCount) {
		this.statementCount = statementCount;
	}

}
