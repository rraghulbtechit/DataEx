package com.urjanet.forseti.rest.resources;


import com.fasterxml.jackson.annotation.JsonUnwrapped;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.core.EmbeddedWrapper;

/**
 * Resource support class for handling embedded resources.
 *
 * Based on https://github.com/nicusX/spring-hateoas-sample
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 * 
 * Implementation from Heimdallr 
 */
public abstract class ResourceWithEmbeddeds extends ResourceSupport {
    @JsonUnwrapped
    private Resources<EmbeddedWrapper> embeddeds;

    public Resources<EmbeddedWrapper> getEmbeddeds() {
        return embeddeds;
    }

    public void setEmbeddeds(Resources<EmbeddedWrapper> embeddeds) {
        this.embeddeds = embeddeds;
    }
}

