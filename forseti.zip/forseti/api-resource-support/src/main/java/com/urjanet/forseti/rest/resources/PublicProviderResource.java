package com.urjanet.forseti.rest.resources;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

public class PublicProviderResource extends ResourceSupport {

	private String name;
	private String description;
	private Date lastModified;
	private Date createdDate;
	
	private boolean loginFailuresReported;
	private String url;
	
	private List<String> requiredFields = new ArrayList<String>();
	
	public PublicProviderResource() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public boolean isLoginFailuresReported() {
		return loginFailuresReported;
	}

	public void setLoginFailuresReported(boolean loginFailuresReported) {
		this.loginFailuresReported = loginFailuresReported;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	public List<String> getRequiredFields() {
		return requiredFields;
	}
	
	public void setRequiredFields(List<String> requiredFields) {
		this.requiredFields = requiredFields;
	}
	
}
