package com.urjanet.forseti.rest.resources;


public class PrivateStatementResource extends PublicStatementResource {

	private long pdrID;
	private String sourceIds;
	
	public PrivateStatementResource() {
		super();
	}
	
	public long getPdrID() {
		return pdrID;
	}
	
	public void setPdrID(long pdrID) {
		this.pdrID = pdrID;
	}
	
	public String getSourceIds() {
		return sourceIds;
	}
	
	public void setSourceIds(String sourceIds) {
		this.sourceIds = sourceIds;
	}
	
}
