package com.urjanet.forseti.service.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.aws.core.env.ResourceIdResolver;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.UnknownHttpStatusCodeException;

import com.urjanet.bifrost.sdk.BifrostJsonUtils;
import com.urjanet.bifrost.sdk.BifrostMidgardDocumentUtils;
import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.BifrostSourceRendererRequest;
import com.urjanet.bifrost.sdk.BifrostTreeNode;
import com.urjanet.bifrost.sdk.Tree;
import com.urjanet.forseti.Util;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;
import com.urjanet.forseti.model.Statement;
import com.urjanet.forseti.repository.PDRDAO;
import com.urjanet.forseti.repository.StatementDAO;
import com.urjanet.forseti.rest.RestConfig;
import com.urjanet.forseti.rest.RestHelper;
import com.urjanet.forseti.service.EntityNotFoundException;
import com.urjanet.forseti.service.PDRService;
import com.urjanet.midgard.sdk.storage.MidgardStorageKey;
import com.urjanet.midgard.sdk.storage.MidgardStorageManagerFactory;

@Service
@Transactional
public class PDRServiceImpl implements PDRService {

	private static final Logger LOG = LoggerFactory.getLogger(PDRServiceImpl.class);
	
	@Autowired
	private Tracer tracer;
	
	@Autowired
	RestConfig restConfig;
	
	@Autowired
	private PDRDAO pdrDAO;

	@Autowired
	private StatementDAO statementDAO;
	
	@Autowired
	private ResourceIdResolver resourceIdResolver;

	@Value("${bifrost.api.url}")
	private String bifrostUrl;
	
	//rest template must be autowired for Sleuth to inject the HTTP headers properly
	@Autowired
	RestTemplate halJsonRestTemplate;
	
	@Override
	public PDR findByID(long id) {
		PDR pdr = pdrDAO.findOne(id);
		if (pdr == null) {
			throw new EntityNotFoundException();
		}
		
		return pdr;
	}

	@Override
	public PDR findByIdAndOrganizationId(long id, long org) {
		PDR pdr = pdrDAO.findByIdAndOrganizationId(id,org);
		if (pdr == null) {
			throw new EntityNotFoundException();
		}
		
		return pdr;
	}
	
	@Override
	public Page<PDR> findAll(Pageable p) {
		return pdrDAO.findAll(p);
	}

	@Override
	public Page<PDR> findAllByCorrelationId(Pageable pageable,
			String correlationId) {
		return pdrDAO.findAllByCorrelationId(pageable,correlationId);
	}

	@Override
	public Page<PDR> findAllByBifrostId(Pageable pageable,
			String jobId) {
		// TODO This should only return a single item using findOne in the repo
		return pdrDAO.findAllByBifrostId(pageable,jobId);
	}

	@Override
	public PDR requestAcquisition(PDR pdr) {
		PDR newPDR =  pdrDAO.save(pdr);
		return newPDR;
	}

	@Override
	public PDR cancelAcquisition(PDR pdr) {
		if (pdr.getCompletionStatus() == null) {
			pdr.setCompletionStatus(PDRCompletionStatus.CANCELLED);
			pdr.setCompletedAt(new Date());
			pdr = pdrDAO.save(pdr);
			sendCancelToBifrost(pdr.getId(), pdr.getBifrostId());
		}
		return pdr;
	}
	
	@Override
	public Page<Statement> findStatementsByPDRID(Pageable pageable, long pdrId) {
		PDR pdr = findByID(pdrId);
		if (pdr == null) {
			throw new EntityNotFoundException();
		} else {
			Page<Statement> stmts = statementDAO.findByPdrID(pageable,pdrId);
			return stmts;
		}
	}
	
	@Override
	public Statement findStatementByID(long id) {
		Statement s = statementDAO.findOne(id);
		if (s == null) {
			throw new EntityNotFoundException();
		}
		return s;
	}

	@Override
	public void registerCompletion(PDR pdr) {
		pdrDAO.save(pdr);
	}

	@Override
	public void delete(long pdrId) {
		pdrDAO.delete(pdrId);
	}
	
	/* This function times out a PDR.
	 * It changes the status to TIMEOUT, sends a cancel to
	 * bifrost, and then triggers a callback.
	 */
	@Override
	public PDR timeout(PDR pdr) {
		pdr.setCompletionStatus(PDRCompletionStatus.TIMEOUT);
		pdr.setCompletedAt(new Date());
		pdr = pdrDAO.save(pdr);
		triggerCallback(pdr);
		sendCancelToBifrost(pdr.getId(), pdr.getBifrostId());
		return pdr;
	}

	/* This function finds all the PDRS that need to be TIMED OUT.
	 * A PDR is said to TIMEOUT if the request was never sent from 
	 * forseti to bifrost within the given timeout period.
	 */
	@Override
	public Page<PDR> findPDRsToTimeout(Pageable pageable) {
		return pdrDAO.findPDRsToTimeout(pageable);
	}

	/* This function finds all the PDRs that need callbacks sent to
	 * externally customer-supplied urls.
	 */
	@Override
	public Page<PDR> findPDRsToCallback(Pageable pageable) {
		return pdrDAO.findPDRsToCallback(pageable);
	}
	
	/* This function finds all PDRs that need to be submitted
	 * to bifrost for the first time.
	 * 
	 * The criteria for new PDRs is 
	 *	 1. bifrostId IS NULL and 
	 *	 2. completionStatus IS NULL and 
	 *	 3. CURRENT_TIMESTAMP < expirationDate
	 */
	@Override
	public Page<PDR> findNewPDRsToSubmitAcquisition(Pageable pageable) {
		return pdrDAO.findNewPDRsToSubmitAcquisition(pageable);
	}

	/* This function finds all PDRs that need to be retried by PDS.
	 * 
	 * A PDR is said to be in PENDING state if it was processed by 
	 * bifrost and it failed with FAILURE | GENERAL_FAILURE.
	 * 
	 * A PDR is said to be EXPIRING if its expiration date is 
	 * 4 hours away. 
	 * 
	 * The sql criteria for pending and expiring PDRs is
	 *  1. bifrostId IS NOT NULL and
	 *  2. completionStatus='PENDING' and
	 *  3. One of the following is true:
	 *	  3.1. lastRetriedAt IS NULL AND expirationDate - CURRENT_TIMESTAMP <= 4hours  
	 *		  OR
	 *	  3.2. one of the following is true:
	 *	  3.2.1. lastRetriedAt IS NOT NULL and 
	 *	  3.2.2. lastReceivedAt > lastRetriedAt and 
	 *	  3.2.3. one of the following is true:
	 *	  3.2.3.1. CURRENT_TIMESTAMP - lastRetriedAt >= 24hours OR 
	 *	  3.2.3.2. expirationDate - CURRENT_TIMESTAMP <= 4hours
	 *	  
	 */
	@Deprecated
	@Override
	public Page<PDR> findPendingAndExpiringPDRsToSubmitAcquisition(Pageable pageable) {
		return pdrDAO.findPendingAndExpiringPDRsToSubmitAcquisition(pageable);
	}

	/* This function finds all PDRs that need to be retried by PDS.
	 * 
	 * A PDR is said to be in PENDING state if it was processed by 
	 * bifrost and it failed with FAILURE | GENERAL_FAILURE.
	 * 
	 * A PDR is said to be EXPIRING if its expiration date is 
	 * 4 hours away. 
	 * 
	 * The sql criteria for pending and expiring PDRs is
	 *  1. bifrostId IS NOT NULL and
	 *  2. completionStatus='PENDING' and
	 *  3. retryAt <= CURRENT_TIMESTAMP
	 *	  
	 */
	@Override
	public Page<PDR> findPendingPDRsToSubmitAcquisition(Pageable pageable) {
		return pdrDAO.findPendingPDRsToSubmitAcquisition(pageable);
	}
	
	@Override
	public PDR save(PDR pdr) {
		return pdrDAO.save(pdr);
	}
	
	// This function sends cancel to bifrost given a pdr.
	private void sendCancelToBifrost(Long pdrId, String bifrostId) {
		if (bifrostId == null)
			return;
		
		String url = bifrostUrl + "/v1/extract/" + bifrostId;
		LOG.info("For PDR {}, sending cancel to Bifrost at {}", pdrId, url);
		RestTemplate restTemplate = RestHelper.getRestTemplate();
		try {
			ResponseEntity<String> entityCallback = restTemplate.exchange(
															url, 
															HttpMethod.PATCH, 
															null,
															String.class);
			LOG.info("Response from Bifrost after sending cancel = {}", entityCallback);
		} catch (RestClientException e) {
			LOG.error(e.getLocalizedMessage());
		}
	}

	@Override
	public Page<PDR> findAllByOrganizationId(Pageable pageable,
			long organizationId) {
		return pdrDAO.findAllByOrganizationId(pageable, organizationId);
	}

	@Override
	public Page<PDR> findAllByCorrelationIdAndOrganizationId(Pageable pageable,
			String correlationId, long organizationId) {
		return pdrDAO.findAllByCorrelationIdAndOrganizationId(pageable, correlationId, organizationId);
	}
	
	public String getSourceTree(PDR pdr) throws Exception {
		Tree<BifrostTreeNode> tree = BifrostMidgardDocumentUtils.getAcquisitionResult(pdr.getSourceTree());
		String json = BifrostJsonUtils.toJson(tree);
		return json;
	}
	
	/* This function returns the logs for a given PDR. 
	 * It uses midgard-sdk to retrieve the compressed log from S3, and
	 * returns it decompressed.
	 */
	public ResponseEntity<byte[]> getLogs(PDR pdr) throws IOException {
		byte[] logBytes = null;
		
		if (! StringUtils.isEmpty(pdr.getLogsId()) ) {
			MidgardStorageKey logKey = MidgardStorageKey.fromString(pdr.getLogsId());
			logBytes = MidgardStorageManagerFactory.get().getSource(logKey);
		}
		
		return new ResponseEntity<byte[]>(logBytes, HttpStatus.OK);
	}
	
	/* This function returns the statement sources given the pdr and statement.
	 * It internally calls bifrost to handle the source rendering.
	 */
	public ResponseEntity<byte[]> getStatementSource(PDR pdr, Statement statement) {
		ResponseEntity<byte[]> response = null;
		
		if (! StringUtils.isEmpty(statement.getSourceIds())) {
			RestTemplate restTemplate = RestHelper.getRestTemplate();
			restTemplate.getMessageConverters().add(new ByteArrayHttpMessageConverter());
					
			BifrostSourceRendererRequest bsrr = new BifrostSourceRendererRequest(pdr.getOrganizationName(), pdr.getProviderId());
			bsrr.setSourceIds(Arrays.asList(statement.getSourceIds().split("\\s*,\\s*")));
			
			String url = bifrostUrl + "/v1/render/";
			LOG.info("Sending source render request {} to Bifrost at {}", bsrr, url);
			
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON));
			
			try {
				response = restTemplate.exchange(url, 
												HttpMethod.POST, 
												new HttpEntity<>(bsrr, headers), 
												byte[].class);
			} catch (RestClientException e) {
				LOG.error(e.getLocalizedMessage());
			}
		}
		
		return response;
	}
	
	/* This function calls an external callback url to post the PDRs' completion status.
	 * Forseti only tries to post to the callback url once, and saves the response from the 
	 * POST in the pdr table.
	 * 
	 * TODO - Add retry algorithm if the response from POST is 4xx or 5xx
	 */
	@Override
	public PDR triggerCallback(PDR pdr) {
		if (StringUtils.isBlank(pdr.getCompletionCallbackUrl())) {
			LOG.warn("Can not trigger callback for PDR {} since completionCallbackUrl is empty", pdr.getId());
			return pdr;
		}
		
		RestTemplate restTemplateJSON = RestConfig.getRestTemplate(MediaType.APPLICATION_JSON_VALUE);

		// Sleuth - detach original span, and continue PDRs' span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);
		Long traceId = Span.hexToId(pdr.getTraceId());
		Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiService:TriggerCallback");
		Span span = builder.build();
		tracer.continueSpan(span);

		// Call the external completionCallbackUrl
		LOG.debug("For PDR {}, POSTing completion status to the callback url at {}", 
				pdr.getId(), pdr.getCompletionCallbackUrl());
		Integer resultFromCallback = 0;
		JSONObject jsonObject = Util.createExternalCallbackObject(pdr, restConfig.getForsetiApiUrl());

		try {
			ResponseEntity<String> entityCallback = restTemplateJSON.exchange(
					pdr.getCompletionCallbackUrl(),
					HttpMethod.POST,
					new HttpEntity<>(jsonObject, restConfig.createHeadersAcceptJSON()),
					String.class);
			resultFromCallback = entityCallback.getStatusCode().value();

		} catch (RestClientException e) {
			LOG.warn("Encountered error {} for PDR {} when POSTing to callback url {}",
					e.getMessage(), pdr.getId(), pdr.getCompletionCallbackUrl());

			// Save the result even if the POST fails
			if (e instanceof HttpStatusCodeException) {
				resultFromCallback = ((HttpStatusCodeException) e).getStatusCode().value();
			} else if (e instanceof UnknownHttpStatusCodeException) {
				resultFromCallback = ((UnknownHttpStatusCodeException) e).getRawStatusCode();
			} else {
				resultFromCallback = 404;
			}
		}
		LOG.debug("For PDR {}, response from callbackURL = {}", pdr.getId(), resultFromCallback);

		// Update database
		LOG.info("Updating PDR {} with completionCallbackResult={} from POSTing at {} ",
				pdr.getId(), resultFromCallback, pdr.getCompletionCallbackUrl());

		// refresh PDR from database to avoid OptimisticLockingFailureException
		pdr = findByID(pdr.getId());
		pdr.setCompletionCallbackResult(resultFromCallback);
		save(pdr);

		// Sleuth - detach PDRs' span and continue original span
		tracer.detach(span);
		tracer.continueSpan(originalSpan);
		
		return pdr;
	}
	
	/* This function re-submits a PDR to bifrost.
	 */
	@Override
	public PDR triggerRetry(PDR pdr) {
		
		if ( pdr.getCompletionStatus() == null ||
				(! pdr.getCompletionStatus().equals(PDRCompletionStatus.PENDING)) ||
				StringUtils.isBlank(pdr.getBifrostId()) ) {
				
			LOG.warn("PDR {} can not be retried", pdr.getId());
			return pdr;
		}
		
		// Sleuth - detach original span, and continue PDRs' span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);
		Long traceId = Span.hexToId(pdr.getTraceId());
		Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiService:TriggerRetry");
		Span span = builder.build();
		tracer.continueSpan(span);
		
		String providerId = pdr.getProviderId();
		String snsTopicArn = resourceIdResolver.resolveToPhysicalResourceId(Util.FORSETI_SNS_TOPIC_ID);
		BifrostRequest jsonObject = Util.createBifrostRequestToRetryPDR(pdr, providerId, snsTopicArn);
		String bifrostApiUrl = restConfig.getBifrostApiUrl() + Util.BIFROST_EXTRACT_URL;

		// Call Bifrost to submit PDR
		LOG.info("Calling Bifrost at {} to submit *pending* PDR {} with {}", bifrostApiUrl, pdr.getId(), jsonObject);
		try {
			ResponseEntity<JSONObject> entityPost = halJsonRestTemplate.exchange(bifrostApiUrl,
					HttpMethod.POST,
					new HttpEntity<>(jsonObject, restConfig.createHeadersAcceptHalAndJSON()),
								new ParameterizedTypeReference<JSONObject>() {});
			LOG.debug("Response from Bifrost = {}", entityPost);

			if (entityPost.getStatusCode().is2xxSuccessful()) {
				
				// Update pending PDR in database
				pdr.setLastRetriedAt(new Date());
				pdr.setRetryCount((pdr.getRetryCount()==null) ? 1 : pdr.getRetryCount()+1);
				pdr.setRetryAt(null);
				save(pdr);
				LOG.info("Updated *pending* PDR {} with lastRetriedAt={}, retryCount={}", 
						pdr.getId(), pdr.getLastRetriedAt(), pdr.getRetryCount());

			} else {
				LOG.error("Encountered error in submitting pending PDR {} - {}", pdr.getId(), entityPost.getBody());
			}
		} catch (Exception e) {
			LOG.error("Encountered error in submitting pending PDR {} - {}", pdr.getId(), e);
		}
		
		// Sleuth - detach PDRs' span and continue original span
		tracer.detach(span);
		tracer.continueSpan(originalSpan);
		
		return pdr;
	}
	
	/* This function changes the completion status fields on a PDR
	 * from PENDING | RETRYING_UNTIL_EXPIRATION to
	 * FAILURE | CREDENTIALS_INVALID
	 */
	@Override
	public PDR changeStatusFields(PDR pdr, PDRCompletionStatus status, PDRCompletionStatusDetail statusDetail) {
		
		if ( pdr.getCompletionStatus() == null ||
				(! pdr.getCompletionStatus().equals(PDRCompletionStatus.PENDING)) ||
				StringUtils.isBlank(pdr.getBifrostId()) ) {
				
			LOG.warn("The completion status fields for PDR {} can not be changed.", 
					pdr.getId());
			return null;
		}
		
		// Sleuth - detach original span, and continue PDRs' span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);
		Long traceId = Span.hexToId(pdr.getTraceId());
		Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiService:ChangeStatusFields");
		Span span = builder.build();
		tracer.continueSpan(span);
		
		// Update status fields and Trigger a callback
		pdr.setCompletionStatus(status);
		pdr.setCompletionStatusDetail(statusDetail.name());
		save(pdr);
		triggerCallback(pdr);
		
		// Sleuth - detach PDRs' span and continue original span
		tracer.detach(span);
		tracer.continueSpan(originalSpan);
		
		return pdr;
	}
	
	/* This function sends a replay request for 
	 * a PDR or a Statement to Bifrost.
	 * 
	 * This is only an internal function, and will not be exposed
	 * to external customers. Furthermore, forseti will not process
	 * bifrosts' results from this job. We will be able to look up
	 * the logs from Kibana and the MidgardDocument for troubleshooting
	 * purposes using the traceid.
	 * 
	 */
	@Override
	public PDR replay(PDR pdr, Statement statement) {
		
		// Sleuth - detach original span, and continue PDRs' span
		Span originalSpan = tracer.getCurrentSpan();
		tracer.detach(originalSpan);
		Long traceId = Span.hexToId(pdr.getTraceId());
		Span.SpanBuilder builder = Span.builder().traceId(traceId).spanId(traceId).name("ForsetiService:PDRReplay");
		Span span = builder.build();
		tracer.continueSpan(span);
		
		String providerId = pdr.getProviderId();
		String snsTopicArn = resourceIdResolver.resolveToPhysicalResourceId(Util.FORSETI_SNS_TOPIC_ID);
		BifrostRequest jsonObject = Util.createBifrostRequestToReplayPDR(pdr, providerId, snsTopicArn, statement);
		String bifrostApiUrl = restConfig.getBifrostApiUrl() + Util.BIFROST_REPLAY_URL;

		// Call Bifrost to replay PDR/Statement
		LOG.info("Calling Bifrost at {} to *replay* PDR {} with {}", bifrostApiUrl, pdr.getId(), jsonObject);
		try {
			ResponseEntity<JSONObject> entityPost = halJsonRestTemplate.exchange(bifrostApiUrl,
					HttpMethod.POST,
					new HttpEntity<>(jsonObject, restConfig.createHeadersAcceptHalAndJSON()),
								new ParameterizedTypeReference<JSONObject>() {});
			LOG.debug("Response from Bifrost = {}", entityPost);

			if (entityPost.getStatusCode().is2xxSuccessful()) {
				// TODO - Update replayed PDR/statement in database???
				LOG.info("Successfully sent replay request to Bifrost");
			} else {
				LOG.error("Encountered error in replaying PDR {} - {}", pdr.getId(), entityPost.getBody());
			}
		} catch (Exception e) {
			LOG.error("Encountered error in replaying PDR {} - {}", pdr.getId(), e);
		}
		
		// Sleuth - detach PDRs' span and continue original span
		tracer.detach(span);
		tracer.continueSpan(originalSpan);
		
		return pdr;
	}
	
	
}
