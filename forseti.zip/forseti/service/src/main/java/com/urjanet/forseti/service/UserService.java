package com.urjanet.forseti.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.urjanet.forseti.model.User;


public interface UserService{

	public abstract User findByID(long id);
	
	public abstract Page<User> findAll(Pageable p);
	
	public abstract User save(User user);
	
	public abstract User createUserIfNotFound(Long id, String username, Long orgId, String orgName);

}
