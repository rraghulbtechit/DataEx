package com.urjanet.forseti.service;

import java.util.Collection;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.model.nondatabase.Provider;

/* Dev Note: 
 * 
 * Forseti API 1.1+
 * The public PDS API exposes endpoints to only read provider and industry data.
 * 		Forseti uses PIB to retrieve this information.
 * The private PDS APIs that used to support PATCH/POST to create/update/delete 
 * have been deprecated in earlier releases, and deleted from this release.
 */
public interface PIBService {

	// TODO - Change ids to UUID?
	
	// Industry API
	public abstract Industry findIndustryByID(String id, Collection<String> userRoles);
	
	public abstract Page<Provider> findProvidersForIndustry(Pageable p, String id, Collection<String> userRoles) throws Exception;
	
	public abstract Page<Industry> findAllIndustries(Pageable p, Collection<String> userRoles) throws Exception;

	public Page<Industry> findAllIndustriesWithNameContaining(Pageable p, String name, Collection<String> userRoles) throws Exception;
 
	// Provider API
	public abstract Provider findProviderByID(String id, Collection<String> userRoles);
	
	public abstract Page<Industry> findIndustriesForProvider(Pageable p, String id, Collection<String> userRoles) throws Exception;
	
	public abstract Page<Provider> findAllProviders(Pageable p, Collection<String> userRoles) throws Exception;

	public Page<Provider> findAllProvidersWithNameContaining(Pageable pageable, String name, Collection<String> userRoles) throws Exception;

}