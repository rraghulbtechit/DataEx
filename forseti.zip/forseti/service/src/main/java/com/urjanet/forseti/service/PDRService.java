package com.urjanet.forseti.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.PDRCompletionStatus;
import com.urjanet.forseti.model.PDRCompletionStatusDetail;
import com.urjanet.forseti.model.Statement;

public interface PDRService {

	public abstract PDR findByID(long id);
	
	public abstract Page<PDR> findAll(Pageable p);

	public abstract Page<PDR> findAllByCorrelationId(Pageable pageable,
			String correlationId);

	public abstract PDR requestAcquisition(PDR pdr);

	public abstract PDR cancelAcquisition(PDR pdr);
	
	public abstract String getSourceTree(PDR pdr) throws Exception;
	
	public abstract ResponseEntity<byte[]> getLogs(PDR pdr) throws Exception;
	
	public abstract ResponseEntity<byte[]> getStatementSource(PDR pdr, Statement statement);

	public abstract Page<Statement> findStatementsByPDRID(Pageable pageable, long pdrId);
	public abstract Statement findStatementByID(long id);

	public abstract void registerCompletion(PDR pdr);

	public abstract Page<PDR> findAllByBifrostId(Pageable pageable, String jobId);

	public abstract void delete(long pdrId);
	
	public abstract PDR save(PDR pdr);
	
	public abstract PDR timeout(PDR pdr);
	
	public abstract Page<PDR> findPDRsToTimeout(Pageable pageable);

	public abstract Page<PDR> findPDRsToCallback(Pageable pageable);
	
	public abstract Page<PDR> findNewPDRsToSubmitAcquisition(Pageable pageable);
	
	@Deprecated
	public abstract Page<PDR> findPendingAndExpiringPDRsToSubmitAcquisition(Pageable pageable);
	
	public abstract Page<PDR> findPendingPDRsToSubmitAcquisition(Pageable pageable);

	public abstract PDR findByIdAndOrganizationId(long id, long org);

	public abstract Page<PDR> findAllByOrganizationId(Pageable pageable,
			long organization);
	
	public abstract Page<PDR> findAllByCorrelationIdAndOrganizationId(Pageable pageable, String correlation,
			long organization);

	public abstract PDR triggerCallback(PDR pdr);
	
	public abstract PDR triggerRetry(PDR pdr);
	
	public abstract PDR replay(PDR pdr, Statement statement);
	
	public abstract PDR changeStatusFields(PDR pdr, PDRCompletionStatus status, 
			PDRCompletionStatusDetail statusDetail);
	
}