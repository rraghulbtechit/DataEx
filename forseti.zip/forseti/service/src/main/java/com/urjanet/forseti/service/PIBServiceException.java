package com.urjanet.forseti.service;

@SuppressWarnings("serial")
public class PIBServiceException extends RuntimeException {

	public PIBServiceException() {
	}

	public PIBServiceException(String message) {
		super(message);
	}

}
