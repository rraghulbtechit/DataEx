package com.urjanet.forseti.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.urjanet.forseti.model.User;
import com.urjanet.forseti.repository.UserDAO;
import com.urjanet.forseti.service.UserService;



@Service
@Transactional
public class UserServiceImpl implements UserService{
		
	@Autowired
	private UserDAO userDAO;
	
	@Override
	public User findByID(long id) {
		return userDAO.findOne(id);
	}
	
	@Override
	public Page<User> findAll(Pageable p) {
		return userDAO.findAll(p);
	}
	
	@Override
	public User save(User user) {
		User newUser =  userDAO.save(user);
		return newUser;
	}

	@Override
	public User createUserIfNotFound(Long id, String username, Long orgId, String orgName)
	{
		User user = findByID(id);
		
		if(null == user)
		{
			//user not found, insert new user into user table
			user = new User();
			user.setId(id);
			user.setUsername(username);
			user.setOrganizationId(orgId);
			user.setOrganizationName(orgName);
			userDAO.save(user);
		}
		
		return user;		
	}
	
}
