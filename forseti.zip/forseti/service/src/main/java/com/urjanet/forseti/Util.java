package com.urjanet.forseti;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;

import com.urjanet.bifrost.sdk.BifrostRequest;
import com.urjanet.bifrost.sdk.WebAcquisitionMetadata;
import com.urjanet.forseti.model.PDR;
import com.urjanet.forseti.model.Statement;

import org.apache.commons.lang3.StringUtils;

public class Util {
	
	public static int RESULTS_PER_PAGE = 10;
	
	private static String PUBLIC_PDR_URL = "/v1/public/pdrs/";
	
	public static String TIMEOUT_JOB_KEY = "timeoutcount";
	public static String CALLBACK_JOB_KEY = "callbackcount";
	public static String SUBMIT_ACQ_JOB_KEY = "submitacqcount";
	public static String HEARTBEAT_JOB_KEY = "heartbeatcount";
	
	public static String FORSETI_SNS_TOPIC_ID = "ForsetiResponseTopic";
	public static String BIFROST_EXTRACT_URL = "/v1/extract/";
	public static String BIFROST_REPLAY_URL = "/v1/extract/replay";
	public static String BIFROST_JOBID = "jobId";

	// Helper method to create the json object for POSTing to the external callbackurl
	@SuppressWarnings("unchecked")
	public static JSONObject createExternalCallbackObject(PDR pdr, String forsetiApiUrl) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("pdrUri", forsetiApiUrl + PUBLIC_PDR_URL + pdr.getId());
		jsonObject.put("correlationId", pdr.getCorrelationId());
		jsonObject.put("completionStatus", pdr.getCompletionStatus());
		jsonObject.put("completionStatusDetail", pdr.getCompletionStatusDetail());
		return jsonObject;
	}
	
	// TODO - Populate application information as needed by Bifrost and Ymir
	// Helper method to create the object to send a request to Bifrost
	public static BifrostRequest createBifrostRequest(PDR pdr, String providerId, String snsTopic) {
		BifrostRequest bifrostRequest = new BifrostRequest();
		
		WebAcquisitionMetadata metadata = new WebAcquisitionMetadata(pdr.getUsername(),
																	pdr.getPassword(),
																	pdr.getPassword2());
		bifrostRequest.setAcquisitionMetadata(metadata);
		bifrostRequest.setAccountNumbers(new HashSet<String>(Arrays.asList(new String[] 
														{ pdr.getAccountNumber()})));
		bifrostRequest.setProviderId(providerId);
		
		// Calculate timeout in seconds 
		Calendar calExpiration = Calendar.getInstance();
		calExpiration.setTime(pdr.getExpirationDate());
		Calendar calCreated = Calendar.getInstance();
		calCreated.setTime(pdr.getCreatedDate());
		long timeout = (calExpiration.getTimeInMillis() - calCreated.getTimeInMillis()) / 1000;
		bifrostRequest.setTimeout(timeout);
		
		bifrostRequest.setPeriodStart(pdr.getPeriodStart());
		bifrostRequest.setPeriodEnd(pdr.getPeriodEnd());
		
		bifrostRequest.setSnsTopic(snsTopic);
		
		// Always set historyEnabled for PDS - this changes when history is exposed via PDS API
		bifrostRequest.setHistoryEnabled(Boolean.TRUE);
		
		bifrostRequest.setCustomer(pdr.getOrganizationName());
		
		bifrostRequest.setReplayRun(Boolean.FALSE);
		
		return bifrostRequest;
	}
	
	// Helper method to create the object to send a request to Bifrost
	public static BifrostRequest createBifrostRequestToRetryPDR(PDR pdr, String providerId, String snsTopic) {
		
		BifrostRequest bifrostRequest = createBifrostRequest(pdr, providerId, snsTopic);
		bifrostRequest.setBifrostId(pdr.getBifrostId());
		
		return bifrostRequest;
	}
	
	// Helper method to create the object to send a request to Bifrost
	public static BifrostRequest createBifrostRequestToReplayPDR(PDR pdr, String providerId, 
													String snsTopic, Statement statement) {
		
		BifrostRequest bifrostRequest = createBifrostRequest(pdr, providerId, snsTopic);
		bifrostRequest.setReplayRun(Boolean.TRUE);
		bifrostRequest.setBifrostId(pdr.getBifrostId());
		
		List<String> sourceIds = new ArrayList<String>();
		if (statement != null) {
			if (StringUtils.isNotBlank(statement.getSourceIds()))
				sourceIds.addAll(Arrays.asList(statement.getSourceIds().split("\\s*,\\s*")));
		} else {
			Set<Statement> statements = pdr.getStatements();
			for (Statement s: statements)
				if (StringUtils.isNotBlank(s.getSourceIds()))
					sourceIds.addAll(Arrays.asList(s.getSourceIds().split("\\s*,\\s*")));
		}
		bifrostRequest.setSourceIds(sourceIds);
		return bifrostRequest;
	}
}
