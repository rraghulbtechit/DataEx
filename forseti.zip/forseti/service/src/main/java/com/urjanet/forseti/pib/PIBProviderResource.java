package com.urjanet.forseti.pib;

import java.util.Date;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

@Relation(value="provider", collectionRelation="providers")
public class PIBProviderResource extends ResourceSupport {

    private String uuid;
    private String alias;
    private String name;
    private String classification;
    private Boolean history;
    private Boolean tracksLoginFailure;
    private String website;
    private Date created;
    private Date modified;
    
    
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String providerAlias) {
        this.alias = providerAlias;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String providerName) {
        this.name = providerName;
    }
    
    public String getClassification() {
        return classification;
    }
    
    public void setClassification(String classification) {
        this.classification = classification;
    }
    
	public Boolean getHistory() {
		return history;
	}

	public void setHistory(Boolean history) {
		this.history = history;
	}

	public Boolean getTracksLoginFailure() {
		return tracksLoginFailure;
	}

	public void setTracksLoginFailure(Boolean tracksLoginFailure) {
		this.tracksLoginFailure = tracksLoginFailure;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getModified() {
		return modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}
    
}
