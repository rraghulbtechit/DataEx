package com.urjanet.forseti.pib;

import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.urjanet.forseti.model.nondatabase.Attribute;

public class PIBTemplateResource extends ResourceSupport {

	private String templateName;
	private String templateType;
	private List<Attribute> attributes;;

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	
	public List<Attribute> getAttributes() {
		return attributes;
	}
	
	public void setAttributes(List<Attribute> attributes) {
		this.attributes = attributes;
	}
}
