package com.urjanet.forseti.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.urjanet.forseti.model.nondatabase.Attribute;
import com.urjanet.forseti.model.nondatabase.Industry;
import com.urjanet.forseti.model.nondatabase.Provider;
import com.urjanet.forseti.pib.PIBProviderResource;
import com.urjanet.forseti.pib.PIBServiceTypeResource;
import com.urjanet.forseti.pib.PIBTemplateResource;
import com.urjanet.forseti.service.BadRequestException;
import com.urjanet.forseti.service.EntityNotFoundException;
import com.urjanet.forseti.service.PIBService;
import com.urjanet.forseti.service.PIBServiceException;

@Service
@Transactional
public class PIBServiceImpl implements PIBService {

	private static final Logger LOG = LoggerFactory.getLogger(PDRServiceImpl.class);
		
	@Value("${pib.api.url}")
	String pibUrl;
	
	@Autowired
	RestTemplate pibRestTemplate;
	
	/* Dev Note 1: 
	 * 	PDS API needs to be able to filter providers and industries based on Roles.
	 * 
	 * 	Default Behavior - The default role provides access to industries and providers
	 * 	that are hard-coded in static hash maps. This list is the initial set of providers
	 * 	that we *know* works!
	 * 
	 * 	ROLE_FSTI_TEMP_ACCESS_ALL_MIDGARD - This special (and maybe temporary) role provides 
	 * 	access to industries and providers that we *assume* works (templates still support history, 
	 * 	web and pdf extraction). This temporary solution is in lieu of provider/template confidence 
	 * 	scores exposed and queryable via PIB.
	 */
	
	// Default Behavior - Industries supported by PDS
	private final static List<String> pdsSupportedIndustries = Arrays.asList(
			"56568480-389a-11e6-b821-00e04c6801d0",				// Mobile Phone 
			"6681833d-389a-11e6-b821-00e04c6801d0", 			// Cable
			"5efe0f4a-389a-11e6-b821-00e04c6801d0",				// Satellite TV
			"73247876-389a-11e6-b821-00e04c6801d0",				// Internet
			"6cedb306-389a-11e6-b821-00e04c6801d0"				// Land Line Phone
			);
	 
	// Default Behavior - Providers supported by PDS
	private final static List<String> pdsSupportedProviders = Arrays.asList(   
			"1e60a473-7f13-d8f2-a038-22000b109b8b",				// Verizon	
			"1e60a473-7de7-d436-a038-22000b109b8b",				// ATT	
			"1e60a473-7e15-da68-a038-22000b109b8b",				// TMobile
			"153a90d3-a41a-11e1-993e-12313d02ea33",				// Mock	aka NewMexicoGas
			"1e60a473-7eee-df00-a038-22000b109b8b",				// Comcast
			"1e60a473-7e8f-db8c-a038-22000b109b8b",				// DirecTV
			"1e60a473-7e66-d37a-a038-22000b109b8b"				// Charter
			);
		
	/* Dev Note 2: 
	 * 	PDS API will query PIB twice for every provider API request.
	 * 	One is to get the provider info, and the second is to get the required fields
	 * 	using the template link on the provider response.
	 */
	// PIB Constants
	private static final String BEST_ACQUISITION_TEMPLATES_LINK_NAME = "bestAcquisitionTemplates";
	private static final String CONSTRAINT_REQUIRED = "REQUIRED";
	@SuppressWarnings("serial")
	public static final HashMap<String , String> INPUT_KEYS_MAP = new HashMap<String , String>() {{
			    put("LOGIN_ID", "username");
			    put("LOGIN_PASS", "password");
			    put("LOGIN_PASS_2", "password2");
	}};;
	
	// Industry API
	@Override
	public Industry findIndustryByID(String id, Collection<String> userRoles) {
		
		if (userHasSpecialMidgardRole(userRoles) || 
				 (!userHasSpecialMidgardRole(userRoles) && pdsSupportedIndustries.contains(id))) {
			
			String url = String.format(pibUrl + "/serviceTypes/%s", id);
			try {
				PIBServiceTypeResource resource = executeGet(url, 
	                new ParameterizedTypeReference<PIBServiceTypeResource>(){}, 
	                Collections.emptyMap());
				
				if (resource != null)
					return mapPIBEntityToIndustry(resource);
				
			} catch (Exception e) {
				if (e instanceof PIBServiceException)
					throw new PIBServiceException(e.getMessage());
			}
		}
		
		throw new EntityNotFoundException();
	}
	
	@Override
	public Page<Provider> findProvidersForIndustry(Pageable pageable, String id,
			Collection<String> userRoles) throws Exception {
		
		List<Provider> list = new ArrayList<Provider>();
		PagedResources<PIBProviderResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles) || 
				 (!userHasSpecialMidgardRole(userRoles) && pdsSupportedIndustries.contains(id))) {
			
			String url = String.format(pibUrl 
					+ "/serviceTypes/%s/providers?history=true&page=%d&size=%d", 
					id, pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
	
			resources = executeGet(url, 
	                new ParameterizedTypeReference<PagedResources<PIBProviderResource>>(){}, 
	                Collections.emptyMap());
			
			for (PIBProviderResource resource: resources) {
				list.add(mapPIBEntityToProvider(resource));
			}
		}
		
		return new PageImpl<Provider>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}
	
	@Override
	public Page<Industry> findAllIndustries(Pageable pageable, 
			Collection<String> userRoles) throws Exception {
		
		List<Industry> list = new ArrayList<Industry>();
		PagedResources<PIBServiceTypeResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles)) {
			String url = String.format(pibUrl 
					+ "/serviceTypes?history=true&page=%d&size=%d", 
					pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
			
			resources = executeGet(url, 
	                new ParameterizedTypeReference<PagedResources<PIBServiceTypeResource>>(){}, 
	                Collections.emptyMap());
			
			for (PIBServiceTypeResource resource: resources) {
				list.add(mapPIBEntityToIndustry(resource));
			}
			
		} else {
			for (String uuid: pdsSupportedIndustries) {
				list.add(findIndustryByID(uuid, userRoles));
			}
		}
		
		return new PageImpl<Industry>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}	

    @Override
	public Page<Industry> findAllIndustriesWithNameContaining(Pageable pageable, String name,
			Collection<String> userRoles) throws Exception {
		
		List<Industry> list = new ArrayList<Industry>();
		PagedResources<PIBServiceTypeResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles)) {
			String url = String.format(pibUrl 
					+ "/serviceTypes?history=true&name=%s&page=%d&size=%d", 
					name, pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
			
			resources = executeGet(url, 
	                new ParameterizedTypeReference<PagedResources<PIBServiceTypeResource>>(){}, 
	                Collections.emptyMap());
			
			for (PIBServiceTypeResource resource: resources) {
				list.add(mapPIBEntityToIndustry(resource));
			}
			
		} else {
			for (String uuid: pdsSupportedIndustries) {
				list.add(findIndustryByID(uuid, userRoles));
			}
		}
	
		Iterator<Industry> iter = list.iterator();
		while (iter.hasNext()) {
			Industry i = iter.next();
			if (! (i.getName().toLowerCase().contains(name.toLowerCase())) ) {
				iter.remove();
			}		
		}
		return new PageImpl<Industry>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}

	// Provider API
	@Override
	public Provider findProviderByID(String id, Collection<String> userRoles)  {
		
		if (userHasSpecialMidgardRole(userRoles) || 
			 (!userHasSpecialMidgardRole(userRoles) && pdsSupportedProviders.contains(id))) {
				 
			String url = String.format(pibUrl + "/providers/%s", id);
			try {
				PIBProviderResource resource = executeGet(url, 
	                new ParameterizedTypeReference<PIBProviderResource>(){}, 
	                Collections.emptyMap());
				
				if (resource != null) {
					return mapPIBEntityToProviderThrowsException(resource);
				}
				
			} catch (Exception e) {
				if (e instanceof PIBServiceException)
					throw new PIBServiceException(e.getMessage());
				
				if (e instanceof BadRequestException)
					throw new BadRequestException(e.getMessage());
			}
		}
		throw new EntityNotFoundException(); 
	}

	@Override
	public Page<Industry> findIndustriesForProvider(Pageable pageable, String id,
			Collection<String> userRoles) throws Exception {
		
		List<Industry> list = new ArrayList<Industry>();
		PagedResources<PIBServiceTypeResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles)|| 
				 (!userHasSpecialMidgardRole(userRoles) && pdsSupportedProviders.contains(id))) {
		
			String url = String.format(pibUrl 
					+ "/providers/%s/serviceTypes?history=true&page=%d&size=%d",
					id, pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
			
			 resources = executeGet(url,
		                new ParameterizedTypeReference<PagedResources<PIBServiceTypeResource>>(){}, 
		                Collections.emptyMap());
			
			for (PIBServiceTypeResource resource: resources) {
			    list.add(mapPIBEntityToIndustry(resource));
			}
		} 
		
		return new PageImpl<Industry>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}

	@Override
	public Page<Provider> findAllProviders(Pageable pageable, 
			Collection<String> userRoles) throws Exception {
		
		List<Provider> list = new ArrayList<Provider>();
		PagedResources<PIBProviderResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles)) {
			String url = String.format(pibUrl 
					+ "/providers?history=true&page=%d&size=%d", 
					pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
			
			resources = executeGet(url, 
	                new ParameterizedTypeReference<PagedResources<PIBProviderResource>>(){}, 
	                Collections.emptyMap());
			
			for (PIBProviderResource resource: resources) {
				list.add(mapPIBEntityToProvider(resource));
			}
			
		} else {
			for (String uuid: pdsSupportedProviders) {
				list.add(findProviderByID(uuid, userRoles));
			}
		}
		
		return new PageImpl<Provider>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}

	@Override
	public Page<Provider> findAllProvidersWithNameContaining(Pageable pageable, String name, 
			Collection<String> userRoles) throws Exception {
		
		List<Provider> list = new ArrayList<Provider>();
		PagedResources<PIBProviderResource> resources = null;
		
		if (userHasSpecialMidgardRole(userRoles)) {
			String url = String.format(pibUrl 
					+ "/providers?history=true&alias=%s&page=%d&size=%d", 
					name, pageable.getPageNumber(), pageable.getPageSize()) + addSortParameter(pageable.getSort());
			
			resources = executeGet(url, 
	                new ParameterizedTypeReference<PagedResources<PIBProviderResource>>(){}, 
	                Collections.emptyMap());
			
			for (PIBProviderResource resource: resources) {
				list.add(mapPIBEntityToProvider(resource));
			}
			
		} else {
			for (String uuid: pdsSupportedProviders) {
				list.add(findProviderByID(uuid, userRoles));
			}
		}
	
		Iterator<Provider> iter = list.iterator();
		while (iter.hasNext()) {
			Provider p = iter.next();
			if (! (p.getName().toLowerCase().contains(name.toLowerCase()) || 
					(p.getDescription()!=null && p.getDescription().toLowerCase().contains(name.toLowerCase())))) {
				iter.remove();
			}		
		}
		return new PageImpl<Provider>(list, pageable, 
				(resources==null) ? list.size() : resources.getMetadata().getTotalElements());
	}
	
	private <T> T executeGet(String url, ParameterizedTypeReference<T> clazz, Object... urlParams) 
			throws Exception {
		
		try {
			LOG.info("Calling PIB at {}", url);
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(new HttpHeaders());
		
			ResponseEntity<T> response = pibRestTemplate.exchange(url, HttpMethod.GET, requestEntity, clazz, urlParams);
	    	LOG.info("Received response from PIB: {}, {}", response.getStatusCode(), response.getBody());
	    	
	    	// Return response only if PIB returns 2xx.
	    	if (response.getStatusCode().is2xxSuccessful()) {
	    		return response.getBody();
	    	}
	    	
	    } catch (Exception e) {
	    	LOG.error("Error communicating with PIB at {} - {}", url, e.getMessage());
	    	
	    	// If PIB responds with a 404, we propogate that status to the caller
	    	if (e instanceof HttpClientErrorException) {
	    		if (((HttpClientErrorException) e).getStatusCode() == HttpStatus.NOT_FOUND)
	    			throw new EntityNotFoundException();
	    	}
	    }
		
		// In all other cases, throw a PIBServiceException => return 500 to the caller
	    throw new PIBServiceException("PIB Communication Error");
	}
	
	private Industry mapPIBEntityToIndustry(PIBServiceTypeResource resource) {
		
		return new Industry(resource.getUuid(), resource.getName(), 
					resource.getCreated(), resource.getModified());
	}

	/* This function maps a PIBProviderResource to a Provider. 
	 * Forseti makes another call to PIB to validate the provider. This function throws 
	 * a BadRequestException if the provider is not supported by PDS i.e. if the template
	 * does not support history and web as a acquisitionType.
	 * 
	 * This might look hacky! 2 reasons:
	 * 	1. PIB does not support a search on providers AND templates.
	 * 	2. If a provider is not supported by PDS, Foresti needs to return BadRequestException ONLY on getProviderByID,
	 * 		 but not on getAllProviders.
	 */
	private Provider mapPIBEntityToProviderThrowsException(PIBProviderResource resource) 
			throws BadRequestException {

		Provider provider = new Provider(resource.getUuid(), resource.getAlias(), resource.getWebsite(),
				resource.getName(), resource.getTracksLoginFailure(), resource.getCreated(), resource.getModified());

		// Query PIB for required fields using the AcquisitionTemplate link. 
		// This call will throw a BadRequestException if PDS does not support this provider
		provider.setRequiredFields(
				getRequiredFieldsForAcquisition(resource.getLink(BEST_ACQUISITION_TEMPLATES_LINK_NAME)));

		return provider;
	}

	/* This function maps a PIBProviderResource to a Provider. 
	 * Forseti makes another call to PIB to validate the provider.
	 * This function will NOT throw any exception if the provider is not supported by PDS.
	 */ 
	private Provider mapPIBEntityToProvider(PIBProviderResource resource) {

		Provider provider = new Provider(resource.getUuid(), resource.getAlias(), resource.getWebsite(),
				resource.getName(), resource.getTracksLoginFailure(), resource.getCreated(), resource.getModified());

		try {
			// Query PIB for required fields using the AcquisitionTemplate link.
			provider.setRequiredFields(getRequiredFieldsForAcquisition(resource.getLink(BEST_ACQUISITION_TEMPLATES_LINK_NAME)));
			
		} catch (Exception e) {
			// ignore
		}

		return provider;
	}

	// This function retrieves all required fields by following the acquisitionTemplates PIB link
	private List<String> getRequiredFieldsForAcquisition(Link link) {
		List<String> requiredFields = new ArrayList<String>();
		List<Attribute> attributes = getAcquisitionTemplateAttributes(link);
		for (Attribute attribute : attributes) {
			if (attribute.getConstraint().equalsIgnoreCase(CONSTRAINT_REQUIRED)) {
				if (INPUT_KEYS_MAP.containsKey(attribute.getName())) {
					requiredFields.add(INPUT_KEYS_MAP.get(attribute.getName()));
				}
			}
		}
		return requiredFields;
	}

	// This function follows the PIB acquisition template link to get attributes
	private List<Attribute> getAcquisitionTemplateAttributes(Link link) {
		List<Attribute> attributes = new ArrayList<Attribute>();

		String templateUrl = link.getHref() + "?history=true&acquisitionType=web&page=0&size=1";
		PagedResources<PIBTemplateResource> pagedResources = null;
		try {
			pagedResources = executeGet(templateUrl,
					new ParameterizedTypeReference<PagedResources<PIBTemplateResource>>() {
					}, Collections.emptyMap());
		} catch (Exception e) {
			if (e instanceof PIBServiceException)
				throw new PIBServiceException(e.getMessage());
		}
		
		// If PDS doesn't support this provider, throw a BadRequestException
		if (pagedResources != null && pagedResources.getMetadata().getTotalElements()==0) {
			LOG.warn("PDS does not support this provider since {} returned zero elements.", templateUrl);
			throw new BadRequestException("Provider not supported by PDS");
		}
		
		if (pagedResources != null && pagedResources.getMetadata().getTotalElements() == 1) {
			PIBTemplateResource templateResource = (PIBTemplateResource) pagedResources.getContent().toArray()[0];
			attributes = templateResource.getAttributes();
		}
						
		return attributes;
	}

	private boolean userHasSpecialMidgardRole(Collection<String> userRoles) {
		return userRoles.contains("ROLE_FSTI_TEMP_ACCESS_ALL_MIDGARD");
	}
	
	// This function adds the sort parameter when making a call to the PIB API
	private String addSortParameter(Sort sort) {
        if (sort == null)
            return "";
        
        String result = "";
        Iterator<Order> iterator = sort.iterator();
        while (iterator.hasNext()) {
            Order order = iterator.next();
            result = "&sort=" + order.getProperty() + "," + order.getDirection();
        }
        return result;
    }
}
