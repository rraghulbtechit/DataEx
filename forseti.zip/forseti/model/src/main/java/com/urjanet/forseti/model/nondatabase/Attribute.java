package com.urjanet.forseti.model.nondatabase;

public class Attribute {

	private String name;
    private String description;
    private String constraint; // REQUIRED, NOT_USED  
    
    public Attribute() {
		super();
	}
    
	public Attribute(String name, String description, String constraint) {
		this.name = name;
		this.description = description;
		this.constraint = constraint;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getConstraint() {
		return constraint;
	}
	
	public void setConstraint(String constraint) {
		this.constraint = constraint;
	}
    
}
