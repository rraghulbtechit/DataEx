package com.urjanet.forseti.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.urjanet.forseti.model.database.BaseEntity;


@Entity
@Table(name="statement")
public class Statement extends BaseEntity {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "pdr_id")
	private long pdrID;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingName;
	
	@Column(name = "billing_street_1")
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingStreet1;
	
	@Column(name = "billing_street_2")
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingStreet2;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingCity;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingState;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingCountry;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingPostalCode;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String billingPhone;
	
	private Date dueDate;
	
	@Size(max=32, message="The field must be less than 32 characters")
	private String paymentCurrency;
	
	private Date recentPaymentDate;
	
	private Date statementDate;
	
	private BigDecimal totalBill;
	
	private BigDecimal recentPayment;
	
	// csv of sourceIds for this pointsource
	private String sourceIds;

	public Long getId() {
		return id;
	}

	public long getPdrID() {
		return pdrID;
	}

	public void setPdrID(long pdrID) {
		this.pdrID = pdrID;
	}

	public String getBillingName() {
		return billingName;
	}

	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}

	public String getBillingStreet1() {
		return billingStreet1;
	}

	public void setBillingStreet1(String billingStreet1) {
		this.billingStreet1 = billingStreet1;
	}

	public String getBillingStreet2() {
		return billingStreet2;
	}

	public void setBillingStreet2(String billingStreet2) {
		this.billingStreet2 = billingStreet2;
	}

	public String getBillingCity() {
		return billingCity;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public String getBillingState() {
		return billingState;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public String getBillingCountry() {
		return billingCountry;
	}

	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	public String getBillingPhone() {
		return billingPhone;
	}

	public void setBillingPhone(String billingPhone) {
		this.billingPhone = billingPhone;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public Date getStatementDate() {
		return statementDate;
	}
	
	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

    public BigDecimal getTotalBill() {
        return totalBill;
    }

    public void setTotalBill(BigDecimal totalBill) {
        this.totalBill = round(totalBill);
    }

    public BigDecimal getRecentPayment() {
        return recentPayment;
    }

    public void setRecentPayment(BigDecimal recentPayment) {
        this.recentPayment = round(recentPayment);
    }

    private static BigDecimal round(BigDecimal in) {
    	return in != null?in.setScale(2, RoundingMode.HALF_EVEN): null;
    }

    public Date getRecentPaymentDate() {
        return recentPaymentDate;
    }

    public void setRecentPaymentDate(Date recentPaymentDate) {
        this.recentPaymentDate = recentPaymentDate;
    }
    
    public String getSourceIds() {
		return sourceIds;
	}
    
    public void setSourceIds(String sourceIds) {
		this.sourceIds = sourceIds;
	}
	
}