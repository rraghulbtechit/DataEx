package com.urjanet.forseti.model.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;

public class AESCyptographyService {
	
    private static final String ALGORITHM = "AES";
    private static final String KEY = "1Hbfh667adfDEJ78";	// TODO - make this safer?
    
    private static final Logger LOG = LoggerFactory.getLogger(AESCyptographyService.class);
    
    private static Key generateKey() throws Exception {
        Key key = new SecretKeySpec(AESCyptographyService.KEY.getBytes(),AESCyptographyService.ALGORITHM);
        return key;
    }
    
    public static String encrypt(String value) {
    	String encryptedValue64 = null;
    	if (value != null) {
	    	try {
	        	Key key = generateKey();
	        	Cipher cipher = Cipher.getInstance(AESCyptographyService.ALGORITHM);
	        	cipher.init(Cipher.ENCRYPT_MODE, key);
	        	byte [] encryptedByteValue = cipher.doFinal(value.getBytes("utf-8"));
				encryptedValue64 = Base64.getEncoder().encodeToString(encryptedByteValue);
	        } catch (Exception e) {
				LOG.error(e.getMessage());
			}
    	}
        return encryptedValue64;          
    }
    
    public static String decrypt(String value) {
    	String decryptedValue = null;
    	if (value != null) {
	    	try {
		        Key key = generateKey();
		        Cipher cipher = Cipher.getInstance(AESCyptographyService.ALGORITHM);
		        cipher.init(Cipher.DECRYPT_MODE, key);
				byte [] decryptedValue64 = Base64.getDecoder().decode(value);
		        byte [] decryptedByteValue = cipher.doFinal(decryptedValue64);
		        decryptedValue = new String(decryptedByteValue,"utf-8");
	    	} catch (Exception e) {
				LOG.error(e.getMessage());
			}
    	}
        return decryptedValue;
    }    
}