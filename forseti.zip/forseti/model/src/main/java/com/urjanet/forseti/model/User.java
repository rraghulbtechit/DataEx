package com.urjanet.forseti.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "user")
public class User{

	@Id
	private Long id;
	@Size(max=50, message="The field must be less than 50 characters")
	@NotBlank
	private String username;
	@NotNull
	private Long organizationId;
	@NotBlank
	@Size(max=100, message="The field must be less than 100 characters")
	private String organizationName;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="owner", cascade = CascadeType.ALL)
	private Set<PDR> pdrs = new HashSet<PDR>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public Long getOrganizationId() {
		return organizationId;
	}
	
	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}
	
	public String getOrganizationName() {
		return organizationName;
	}
	
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public Set<PDR> getPdrs() {
		return pdrs;
	}
	
	public void setPdrs(Set<PDR> pdrs) {
		this.pdrs = pdrs;
	}

}
