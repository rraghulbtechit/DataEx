package com.urjanet.forseti.model.nondatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Provider {

    private String uuid;
    private String name;
    private String url;
    private String description;
    private boolean loginFailuresReported = false;
    private Date createdDate;
    private Date lastModified;
    
    private List<String> requiredFields = new ArrayList<String>();
    

	public Provider(String uuid, String name, String url, String description, boolean loginFailuresReported,
			Date createdDate, Date lastModified) {
		super();
		this.uuid = uuid;
		this.name = name;
		this.url = url;
		this.description = description;
		this.loginFailuresReported = loginFailuresReported;
		this.createdDate = createdDate;
		this.lastModified = lastModified;
	}

	public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean getLoginFailuresReported() {
		return loginFailuresReported;
	}

	public void setLoginFailuresReported(boolean loginFailuresReported) {
		this.loginFailuresReported = loginFailuresReported;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	public List<String> getRequiredFields() {
		return requiredFields;
	}
	
	public void setRequiredFields(List<String> requiredFields) {
		this.requiredFields = requiredFields;
	}

}
