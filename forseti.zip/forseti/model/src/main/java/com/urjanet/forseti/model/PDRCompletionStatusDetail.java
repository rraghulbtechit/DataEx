package com.urjanet.forseti.model;

public enum PDRCompletionStatusDetail {

    // completionStatus = SUCCESS
    NO_STATEMENTS_IN_PERIOD, 
    PARTIAL_DELIVERY, 
    
    // completionStatus = FAILURE
    ACCOUNT_NOT_FOUND,
    CREDENTIALS_INVALID, 
    GENERAL_FAILURE, 
    UNSUPPORTED_ACCOUNT_PREPAID,
    USER_ACTION_REQUIRED,
    LIMITED_ACCESS,
    WEBSITE_DOWN,
    
    // completionStatus = PENDING
    RETRYING_UNTIL_EXPIRATION
}
