package com.urjanet.forseti.model;

public enum PDRCompletionStatus {

	 SUCCESS, FAILURE, CANCELLED, TIMEOUT, PENDING
	
}
