package com.urjanet.forseti.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.urjanet.forseti.model.database.BaseEntity;
import com.urjanet.forseti.model.security.AESCyptographyService;

@Entity
@Table(name = "pdr")
/**
 * Short for Payment Data Request
 * 
 *
 */
public class PDR extends BaseEntity {

	@Id
	@GeneratedValue
	private Long id;

	private String providerId;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String providerName;

	@Size(max=255, message="The field must be less than 255 characters")
	private String correlationId;

	@Size(max=255, message="The field must be less than 255 characters")
	private String username;

	@Size(max=255, message="The field must be less than 255 characters")
	private String password;
	
	@Size(max=255, message="The field must be less than 255 characters")
	private String password2;

	@Size(max=255, message="The field must be less than 255 characters")
	private String accountNumber;

	private Date periodStart;

	private Date periodEnd;

	private Date expirationDate;

	@Size(max=255, message="The field must be less than 255 characters")
	private String completionCallbackUrl;

	private Integer completionCallbackResult;

	@Size(max=255, message="The field must be less than 255 characters")
	private String source;

	@Size(max=255, message="The field must be less than 255 characters")
	private String bifrostId;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "pdr_id", insertable = true, updatable = false)
	private Set<Statement> statements = new HashSet<Statement>(0);

	@Enumerated(EnumType.STRING)
	private PDRCompletionStatus completionStatus;

	@Size(max=255, message="The field must be less than 255 characters")
	private String completionStatusDetail;

	private Date startedAt;

	private Date completedAt;

	@Deprecated
	private Long organizationId;
	
	@Deprecated
	private String organizationName;

	private String traceId;
	
	@ManyToOne(optional=false)
	@JoinColumn(name="owner_id")
	private User owner;
		
	// S3 id of the navigation tree
	private String sourceTree;
	
	// S3 id of bifrost engine logs
	private String logsId;
	
	// Fields for enhanced error handling
	@Deprecated
	private Date lastRetriedAt;
	@Deprecated
	private Date lastReceivedAt;
	private Integer retryCount;
	private Date retryAt;
	

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public Long getId() {
		return id;
	}
	
	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public String getUsername() {
		return AESCyptographyService.decrypt(username);
	}

	public String getPassword() {
		return AESCyptographyService.decrypt(password);
	}
	
	public String getPassword2() {
		return AESCyptographyService.decrypt(password2);
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public Date getPeriodStart() {
		return periodStart;
	}

	public Date getPeriodEnd() {
		return periodEnd;
	}

	public String getCompletionCallbackUrl() {
		return completionCallbackUrl;
	}

	public Integer getCompletionCallbackResult() {
		return completionCallbackResult;
	}

	public String getSource() {
		return source;
	}

	public String getBifrostId() {
		return bifrostId;
	}

	public PDRCompletionStatus getCompletionStatus() {
		return completionStatus;
	}

	public String getCompletionStatusDetail() {
		return completionStatusDetail;
	}

	public Date getStartedAt() {
		return startedAt;
	}

	public Date getCompletedAt() {
		return completedAt;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public void setUsername(String username) {
		this.username = AESCyptographyService.encrypt(username);
	}

	public void setPassword(String password) {
		this.password = AESCyptographyService.encrypt(password);
	}
	
	public void setPassword2(String password2) {
		this.password2 = AESCyptographyService.encrypt(password2);
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setPeriodStart(Date periodStart) {
		this.periodStart = periodStart;
	}

	public void setPeriodEnd(Date periodEnd) {
		this.periodEnd = periodEnd;
	}

	public void setCompletionCallbackUrl(String completionCallbackUrl) {
		this.completionCallbackUrl = completionCallbackUrl;
	}

	public void setCompletionCallbackResult(int completionCallbackResult) {
		this.completionCallbackResult = completionCallbackResult;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setBifrostId(String bifrostId) {
		this.bifrostId = bifrostId;
	}

	public void setCompletionStatus(PDRCompletionStatus completionStatus) {
		this.completionStatus = completionStatus;
	}

	public void setCompletionStatusDetail(String completionStatusDetail) {
		this.completionStatusDetail = completionStatusDetail;
	}

	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}

	public void setCompletedAt(Date completedAt) {
		this.completedAt = completedAt;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	
	public String getProviderName() {
		return providerName;
	}
	
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}

	public Set<Statement> getStatements() {
		return statements;
	}

	public void setStatements(Set<Statement> statements) {
		this.statements = statements;
	}

	public String getOrganizationName() {
		return organizationName;
	}
	
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getSourceTree() {
		return sourceTree;
	}
	
	public void setSourceTree(String sourceTree) {
		this.sourceTree = sourceTree;
	}
	
	public String getLogsId() {
		return logsId;
	}
	
	public void setLogsId(String logsId) {
		this.logsId = logsId;
	}

	public Date getLastRetriedAt() {
		return lastRetriedAt;
	}

	public void setLastRetriedAt(Date lastRetriedAt) {
		this.lastRetriedAt = lastRetriedAt;
	}

	public Date getLastReceivedAt() {
		return lastReceivedAt;
	}

	public void setLastReceivedAt(Date lastReceivedAt) {
		this.lastReceivedAt = lastReceivedAt;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}
	
	public Date getRetryAt() {
		return retryAt;
	}
	
	public void setRetryAt(Date retryAt) {
		this.retryAt = retryAt;
	}


	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}	
}
