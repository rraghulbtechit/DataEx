package com.urjanet.forseti.model.nondatabase;

import java.util.Date;

public class Industry {

	private String uuid;
	private String name;
	private Date createdDate;
	private Date lastModified;
	
	
	public Industry(String uuid, String name) {
		super();
		this.uuid = uuid;
		this.name = name;
	}
	
	public Industry(String uuid, String name, Date createdDate, Date lastModified) {
		super();
		this.uuid = uuid;
		this.name = name;
		this.createdDate = createdDate;
		this.lastModified = lastModified;
	}

	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getLastModified() {
		return lastModified;
	}
	
	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}