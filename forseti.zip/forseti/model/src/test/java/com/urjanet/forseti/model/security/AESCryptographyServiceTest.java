package com.urjanet.forseti.model.security;

import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class AESCryptographyServiceTest {

    @Test
    public void encryptAndDecrypt() {
        String value = "testing string";
        String encrypted = AESCyptographyService.encrypt(value);
        String decrypted = AESCyptographyService.decrypt(encrypted);
        assertThat(value).isEqualTo(decrypted);
    }
}