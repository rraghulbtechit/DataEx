package urjanet.devPortal.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Catalyst {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer catalystId;

	@Column
	private String catalystName;

	public Integer getCatalystId() {
		return catalystId;
	}
	@OneToMany(mappedBy="catalystId")
	private List<Slainfo> slainfo ;

	public void setCatalystId(Integer catalystId) {
		this.catalystId = catalystId;
	}

	public String getCatalystName() {
		return catalystName;
	}

	public void setCatalystName(String catalystName) {
		this.catalystName = catalystName;
	}

	

}
