# README #

### What is this repository for? ###

Holds classes necessary to construct a template (navigation and extraction), including:
* Template interfaces
* DataTargets
* NavTargets
* DataTargetQualifiers

### How do I get set up? ###

Run 'gradle eclipse' to create eclipse project files and import the project into your workspace
