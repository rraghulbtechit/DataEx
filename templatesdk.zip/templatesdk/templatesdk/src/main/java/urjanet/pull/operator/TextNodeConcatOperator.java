package urjanet.pull.operator;

import java.util.Arrays;
import java.util.List;

import com.gargoylesoftware.htmlunit.html.DomNode;

public class TextNodeConcatOperator implements ExtractOperator{

	private List<String> xPaths;
	private String delimiter;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private TextNodeConcatOperator() {
		
	}
	
	public TextNodeConcatOperator(String ... xPaths) {
		this.xPaths = Arrays.asList(xPaths);
		delimiter = "";
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {
		Object arg = operand.getResult() == null ? operand.getStringResult() : operand.getResult();
		
		if (arg instanceof DomNode) {
			DomNode node = (DomNode)arg;
			String concatinatedText = "";
			int index = 0;
			for (String xPath : xPaths) {
				List<?> nodes = node.getByXPath(xPath);
				
				for (Object o : nodes) {
					if (o instanceof DomNode) {
						DomNode text = (DomNode)o;
						if (text.getTextContent() != null && !text.getTextContent().equals("")) {
							if (index == 0)
								concatinatedText += text.getTextContent();
							else
								concatinatedText += delimiter + text.getTextContent();
							index++;
						}
					} else if (o instanceof String) {
						
						if (index == 0)
							concatinatedText += (String)o;
						else
							concatinatedText += delimiter + (String)o;
						index++;
					}
				}
			}
			return new ExtractOperand((String)concatinatedText);
		}
		
		return operand;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public TextNodeConcatOperator setDelimiter(String delimiter) {
		this.delimiter = delimiter;
		return this;
	}

	/**
	 * @return the xPaths
	 */
	public List<String> getxPaths() {
		return xPaths;
	}
	
	/**
	 * @param xPaths the xPaths to set
	 */
	public TextNodeConcatOperator setxPaths(List<String> xPaths) {
		this.xPaths = xPaths;
		return this;
	}
	
}
