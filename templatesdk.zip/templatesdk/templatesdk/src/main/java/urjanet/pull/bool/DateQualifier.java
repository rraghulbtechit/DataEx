package urjanet.pull.bool;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.web.DataTarget;

/**
 * 
 * @author xavierd
 * 
 * <p>
 * 	The operator will be evaluated against the target1's extracted value and the target2's extracted value.
 *  The operand for the operator is two data target's values.
 *  By default the StringQualifier will take the Equals operation if there is no explicit operators are mentioned.
 * 	NOTE: The type of target1 and target2 should be identical.
 * </p>
 *
 */
public class DateQualifier extends ComparisonDataTargetQualifier {

	private static final Logger log = LoggerFactory.getLogger(DateQualifier.class);
	
	private DateFormat dateFormat;
	
	//This will be called from Hit for create an instance.
	@SuppressWarnings("unused")
	private DateQualifier() {
		
	}
	
	public DateQualifier(ComparisonOperator operator, DateFormat format, DataTarget target1, DataTarget target2) {
		super(operator, target1, target2);
		this.dateFormat = format;
	}
	
	public DateQualifier(DateFormat format, DataTarget target1, DataTarget target2) {
		this(ComparisonOperator.EQUAL_TO, format, target1, target2);
	}
	
	public DateQualifier(ComparisonOperator operator, DataTarget target1, DataTarget target2) {
		this(operator, new SimpleDateFormat("MM/dd/yyyy"), target1, target2);
	}
	
	public DateQualifier(DataTarget target1, DataTarget target2) {
		this(ComparisonOperator.EQUAL_TO, new SimpleDateFormat("MM/dd/yyyy"), target1, target2);
	}
	
	public DateFormat getDateFormat() {
		return dateFormat;
	}
	
	public DateQualifier setDateFormat(DateFormat dateFormat) {
		this.dateFormat = dateFormat;
		return this;
	}

	@Override
	public int compareTo(String value1, String value2) {
		
		try {
			return dateFormat.parse(value1).compareTo(dateFormat.parse(value2));
		} catch (ParseException e) {
			log.error("Unable to parse Date : " + e.getMessage());
		}
		
		return -2;
	}
}
