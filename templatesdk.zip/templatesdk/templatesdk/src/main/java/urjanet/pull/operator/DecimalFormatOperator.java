package urjanet.pull.operator;

import java.math.RoundingMode;
import java.text.DecimalFormat;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

public class DecimalFormatOperator implements ExtractOperator {
	
	private DecimalFormat formatter;
	private RoundingMode mode;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private DecimalFormatOperator() {
		
	}
	
	public DecimalFormatOperator(String pattern, RoundingMode mode) {
		formatter = new DecimalFormat(pattern);
		this.mode = mode;
	}
	
	public DecimalFormatOperator(String pattern) {
		this(pattern, null);
	}
	
	public DecimalFormat getFormatter() {
		return formatter;
	}
	
	public DecimalFormatOperator setFormatter(DecimalFormat formatter) {
		this.formatter = formatter;
		return this;
	}
	
	public RoundingMode getMode() {
		return mode;
	}
	
	public DecimalFormatOperator setMode(RoundingMode mode) {
		this.mode = mode;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("RegExOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

			try {
				if(mode != null && mode instanceof RoundingMode) {
					formatter.setRoundingMode(mode);
				}
				return new ExtractOperand(formatter.format(Double.parseDouble(text)));
			} catch (Exception e) {
				throw new OperatorException("Regular expression error: " + e);
			}
	}
}
