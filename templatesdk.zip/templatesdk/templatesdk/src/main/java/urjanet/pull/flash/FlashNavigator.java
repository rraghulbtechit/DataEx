package urjanet.pull.flash;

import java.util.List;

/**
 * 
 * @author willie
 *
 *
 * All classes implementing this interface should be named: <ProviderID>FlashNavigator.java
 *
 */
public interface FlashNavigator {
	
	void downloadMostRecent(List<String> users, List<String> passwords, String dlDir);
	void downloadAll(List<String> users, List<String> passwords, String dlDir);
	
}
