package urjanet.pull.web.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.web.htmlunit.HtmlUnitCache;

import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;

/**
 * If Harry Potter had a cache...
 *
 * @author rburson
 */
public class MagicCache {

	private static Logger log = LoggerFactory.getLogger(MagicCache.class);

	private HtmlUnitCache htmlUnitCache;
	private List<? extends CacheRule> rules = new ArrayList<CacheRule>();
	private CacheDrawer cacheDrawer = new CacheDrawer();

	public MagicCache(HtmlUnitCache htmlUnitCache) {
		this.htmlUnitCache = htmlUnitCache;
	}

	public List<? extends CacheRule> getRules() {
		return rules;
	}

	public void setRules(List<? extends CacheRule> rules) {
		this.rules = rules;
	}

	public static class Entry<T>{

		private T it;

		public Entry(T it) {
			this.it = it;
		}



	}

	public static class CacheDrawer{

		private Map<String, Entry>  entries = new HashMap<String, Entry>();
		//this may be used to create a 'smart' cache, in the future
		//private Map<Integer, List<Entry>> entriesByContentLength = new HashMap<Integer, List<Entry>>();

		public Map<String, Entry> getEntries() {
			return entries;
		}

		public void setEntries(Map<String, Entry> entries) {
			this.entries = entries;
		}

	}

	public WebResponse cache(WebRequest settings, WebResponse response){

		WebResponse cachedResponse = null;
		for(CacheRule r : this.rules){
			cachedResponse = r.tryToCache(settings, response, cacheDrawer);
			if(response != null) return cachedResponse;
		}

		return response;

	}

	public WebResponse get(WebRequest settings){

		WebResponse cachedResponse = null;
		for(CacheRule r : this.rules){
			cachedResponse = r.tryToGet(settings, cacheDrawer);
			if(cachedResponse != null) return cachedResponse;
		}

		return null;

	}

	public boolean checkUrlQualifies(WebRequest settings){

		for(CacheRule r : this.rules){
			if(r.getUrlMatch().matcher(settings.getUrl().toString()).find()) return true;
		}

		return false;

	}

}
