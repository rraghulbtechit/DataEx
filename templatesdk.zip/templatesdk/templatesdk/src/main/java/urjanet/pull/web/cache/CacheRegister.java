package urjanet.pull.web.cache;

import java.io.IOException;

import urjanet.pull.web.intercept.Interceptor;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;

/**
 *
 * @author rburson
 */
public class CacheRegister extends Interceptor {

	private MagicCache magicCache;

	public CacheRegister(WebConnection webConnection, WebClient webClient, MagicCache magicCache) throws IllegalArgumentException {
		super(webConnection, webClient, null);
		this.magicCache = magicCache;
	}

	@Override
	public WebResponse getResponse(final WebRequest request) throws IOException {

		WebResponse response = null;
		if (this.magicCache.checkUrlQualifies(request)) {
			response = this.magicCache.get(request);
			if (response == null) {
				WebResponse realResponse = super.getResponse(request);
				response = this.magicCache.cache(request, realResponse);
				return response == null ? realResponse : response;
			}
		}else{
			response = super.getResponse(request);
		}

		return response;
	}
}
