package urjanet.pull.web.reference;

import java.util.Arrays;
import java.util.List;

import urjanet.keys.GroupingKeys;
import urjanet.pull.web.DataTarget;


public class GroupReference {
	
	private List<DataTarget> targets;
	private GroupingKeys scope = null;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private GroupReference() {
		
	}
	
	public GroupReference(DataTarget ... target) {
		this.targets = Arrays.asList(target);
	}
	
	public GroupReference(GroupingKeys scope, DataTarget ... target) {
		this(target);
		this.scope = scope;
	}
	
	public GroupingKeys getScope() {
		return scope;
	}
	
	/**
	 * @param scope the scope to set
	 */
	public GroupReference setScope(GroupingKeys scope) {
		this.scope = scope;
		return this;
	}
	
	public List<DataTarget> getTargets() {
		return targets;
	}
	
	/**
	 * @param targets the targets to set
	 */
	public GroupReference setTargets(List<DataTarget> targets) {
		this.targets = targets;
		return this;
	}
	
}
