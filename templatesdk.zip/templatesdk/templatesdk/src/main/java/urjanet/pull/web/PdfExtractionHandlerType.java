package urjanet.pull.web;

public enum PdfExtractionHandlerType {
	XML_HANDLER,
	COORDINATE_HANDLER,
	CONTEXT_HANDLER
}
