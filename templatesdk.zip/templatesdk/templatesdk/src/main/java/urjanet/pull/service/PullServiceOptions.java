package urjanet.pull.service;

import java.util.HashMap;
import java.util.Map;

public class PullServiceOptions {

	private Map<ServiceOption, Object> serviceOptions = new HashMap<ServiceOption, Object>();
	
	public PullServiceOptions() {
		setServiceOption(ServiceOption.RUN_HISTORY, false);
		setServiceOption(ServiceOption.USE_DATABASE_AS_SOURCE, false);
		setServiceOption(ServiceOption.DOCUMENT_CLASSIFICATION_MODE, false);
		setServiceOption(ServiceOption.POST_STORAGE_AUDITS, false);
		setServiceOption(ServiceOption.PROCESS_IMAGE_BILLS, false);
		setServiceOption(ServiceOption.CONCURRENCY, 3);
		setServiceOption(ServiceOption.RUN_PULLSOURCE, false);
		setServiceOption(ServiceOption.SKIP_EXTRACTION, false);
		setServiceOption(ServiceOption.FORCE_OVERRIDE_ERRORS, false);
		setServiceOption(ServiceOption.RUN_DAQ_CHILD_JOB, false);
		setServiceOption(ServiceOption.DAQ_JOB_THRESHOLD_LIMIT, 500);
		setServiceOption(ServiceOption.DISABLE_DAQ_SPLIT_JOB, false);
		setServiceOption(ServiceOption.HIGHLIGHT_MODE, false);
		setServiceOption(ServiceOption.HIGH_PRIORITY,false);
		setServiceOption(ServiceOption.BUILD_EXTRACTION_WITH_TREE_NODE, false);
	}
	
	public boolean isServiceOption(ServiceOption serviceOption) {
		Object option  = serviceOptions.get(serviceOption);
		
		if (option != null) {
			
			if (option instanceof Boolean)
				return ((Boolean)option).booleanValue();

			return true;
			
		} else
			return false;
	}
	
	public Object getServiceOption(ServiceOption serviceOption) {
		return serviceOptions.get(serviceOption);
	}
	
	public void setServiceOption(ServiceOption serviceOption, Object flag) {
		serviceOptions.put(serviceOption, flag);
	}
	
	public enum ServiceOption {
		
		RUN_HISTORY,
		USE_DATABASE_AS_SOURCE,
		USE_DIRECTORY_AS_SOURCE,
		USE_DAQ_AS_SOURCE,
		SOURCE_NODES,
		POST_STORAGE_AUDITS,
		GET_REPLAY_DIRECT,
		CONCURRENCY,
		TEMPLATE_NAME,
		USE_ACCOUNT_TRACKING,
		RUN_OCR,
		OCR_PROFILE,
		FORCE_EXTRACTION,
		DAQ_PIPELINE_IDS,
		DAQ_RERUN_ACCESS_CHANNEL,
		DOCUMENT_CLASSIFICATION_MODE,
		PROCESS_IMAGE_BILLS,
		DISABLE_IMAGE_BINARIZATION_FOR_OCR,
		ENABLE_IMAGE_DESCREEN_FOR_OCR,
		ENABLE_IMAGE_DITHERING_FOR_OCR,
		RUN_PULLSOURCE,
		DAQ_TIMEOUT_OVERRIDE,
		DUMP_PDF_SOURCES,
		HIGHLIGHT_MODE,
		USE_FILE_AS_SOURCE,
		REPLAY_STATEMENT_ID_MAP,
		SKIP_EXTRACTION,
		DUMP_WEB_SOURCES,
		FORCE_OVERRIDE_ERRORS,
		TRACKING_INSTRUCTIONS,
		USE_INVOICE_NUMBER_RECONCILIATION,
		FORCE_EDI_CONVERSION,
		FORCE_OCR_CONVERSION,

		/**
		 * Currently only honored by BifrostEngine
		 */
		SKIP_IMAGES,
		/**
		 * Currently only honored by BifrostEngine
		 */
		SKIP_CSS,
		
		/**
		 * Run the large DaqPipeline Jobs into multiple small child jobs.
		 */
		RUN_DAQ_CHILD_JOB,
		
		/**
		 * A threshold limit for a Daq split job.
		 */
		DAQ_JOB_THRESHOLD_LIMIT,
		
		/**
		 * It's just a incoming build parameters from a parent job and 
		 * that can be used for all child jobs to run in parallel.
		 */
		BUILD_PARAMETERS,
		
		/**
		 * Disables the Daq split job (child job process).
		 */
		DISABLE_DAQ_SPLIT_JOB,
		/**
		 * Additional MetaData for Priority Scheduling Cases
		 */
		HIGH_PRIORITY,

		/**
		 * An option to build the extraction using {@link TreeNode} 
		 */
		BUILD_EXTRACTION_WITH_TREE_NODE
	}
	
}
