package urjanet.pull.bool;

/**
 * Defines a condition that a page must meet in order to evaluate to true
 *
 * @author rburson
 */
public interface PageCondition {

}
