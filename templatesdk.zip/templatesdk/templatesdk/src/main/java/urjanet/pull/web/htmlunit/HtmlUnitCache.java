package urjanet.pull.web.htmlunit;

import com.gargoylesoftware.htmlunit.Cache;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;

/**
 *
 * @author rburson
 */
public class HtmlUnitCache extends Cache{

	public boolean htmlUnitWillCache(final WebRequest request, final WebResponse response){

		return isCacheable(request, response);

	}


}
