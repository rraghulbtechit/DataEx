package urjanet.pull.template;

import urjanet.pull.JobRunnerInput;

import urjanet.pull.core.PullJobTemplate;


/**
 *
 * @author rburson
 */
public interface TemplateProvider extends JobRunnerInput {

    public static final String _author = "$LastChangedBy$";
    public static final String _version = "$LastChangedRevision$";

    public PullJobTemplate getTemplate();
}
