package urjanet.pull.web.pdf;

import java.util.Arrays;
import java.util.List;

import urjanet.DataTargetType;
import urjanet.keys.DomainKeys;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.pdf.filter.ContextFilter;

public class PdfDataTarget extends DataTarget {
	
	protected List<? extends ContextFilter> filters;
	private String contextLabel;
	
	protected PdfDataTarget() {
		
	}
	
	private PdfDataTarget(List<? extends ContextFilter> filters, GroupPolicy groupPolicy, String key, List<? extends DataTarget> relativeDataTargets) {
		
		if (groupPolicy != null)
			setGroupPolicy(groupPolicy);
		
		if (key != null)
			setName(key);
		
		if (relativeDataTargets != null)
			setRelativeDataTargets(relativeDataTargets);
		
		this.filters = filters;
	}
	
	/**
	 * 
	 * These constructors are used if you want grab the current value of the context and set it as the key
	 * 
	 */
	public PdfDataTarget(List<? extends ContextFilter> filters, String key) {
		this(filters, null, key, null);
	}
	public PdfDataTarget(List<? extends ContextFilter> filters, DomainKeys key) {
		this(filters, null, key.getValue(), null);
	}
	public PdfDataTarget(ContextFilter filters, String key) {
		this(Arrays.asList(filters), null, key, null);
	}
	public PdfDataTarget(ContextFilter filters, DomainKeys key) {
		this(Arrays.asList(filters), null, key.getValue(), null);
	}
	public PdfDataTarget(DomainKeys key) {
		this(null, null, key.getValue(), null);
	}
	public PdfDataTarget(String key) {
		this(null, null, key, null);
	}

	/**
	 * These constructors will always have relative datatargets
	 * they are meant to narrow the context which you are looking at
	 */
	public PdfDataTarget(List<? extends ContextFilter> filters, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(filters, groupPolicy, null, relativeDataTargets);
	}
	public PdfDataTarget(ContextFilter filters, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(Arrays.asList(filters), groupPolicy, null, relativeDataTargets);
	}
	public PdfDataTarget(List<? extends ContextFilter> filters, List<? extends DataTarget> relativeDataTargets) {
		this(filters, null, relativeDataTargets);
	}
	public PdfDataTarget(ContextFilter filters, List<? extends DataTarget> relativeDataTargets) {
		this(filters, null, relativeDataTargets);
	}
	public PdfDataTarget(ContextFilter filters, DataTarget ... relativeDataTargets) {
		this(filters, null, Arrays.asList(relativeDataTargets));
	}
	
	public PdfDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(null, groupPolicy, null, relativeDataTargets);
	}
	public PdfDataTarget(GroupPolicy groupPolicy, DataTarget ... relativeDataTargets) {
		this(null, groupPolicy, null, Arrays.asList(relativeDataTargets));
	}
	public PdfDataTarget(List<? extends DataTarget> relativeDataTargets) {
		this(null, null, null, relativeDataTargets);
	}

	@Override
	public PdfDataTarget setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

	@Override
	public PdfDataTarget setFormatHint(String formatHint) {
		this.formatHint = formatHint;
		return this;
	}

	@Override
	public PdfDataTarget setQualifier(DataTargetQualifier qualifier) {
		this.qualifier = qualifier;
		return this;
	}

	@Override
	public PdfDataTarget setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
		return this;
	}
	
	public PdfDataTarget setDefaultValue(DomainKeys defaultValueKey) {
		this.defaultValue = defaultValueKey.getValue();
		return this;
	}

	@Override
	public PdfDataTarget setGroupingTarget(boolean groupingTarget) {
		this.groupingTarget = groupingTarget;
		return this;
	}

	@Override
	public PdfDataTarget setVariable(String variableName) {
		this.variableName = variableName;
		return this;
	}
	
	public List<? extends ContextFilter> getFilters() {
		return filters;
	}

	/**
	 * @param filters the filters to set
	 */
	public PdfDataTarget setFilters(List<? extends ContextFilter> filters) {
		this.filters = filters;
		return this;
	}
	

	@Override
	public PdfDataTarget setDefaultValue(String ... defaultValue) {
		String tempValue = defaultValue[0];
		
		for(int i = 1; i < defaultValue.length; i++)
			tempValue += "||" + defaultValue[i];

		return this.setDefaultValue(tempValue);
	}
	
	public PdfDataTarget setDefaultValue(DomainKeys ... defaultValueKeys) {
		String tempValue = defaultValueKeys[0].getValue();
		
		for(int i = 1; i < defaultValueKeys.length; i++)
			tempValue += "||" + defaultValueKeys[i].getValue();

		return this.setDefaultValue(tempValue);
	}
	
	@Override
	public PdfDataTarget setType(DataTargetType type) {
		this.type = type;
		return this;
	}

	/**
	 * 
	 * @return the context label 
	 */
	public String getContextLabel() {
		return contextLabel;
	}

	/**
	 * Sets the context label
	 * 
	 * @param contextLabel
	 * @return
	 */
	public DataTarget setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
		return this;
	}

}
