package urjanet.pull.enrollment.util;

public interface EbillDeEnroller {

	public boolean ebillDeEnroll ( EnrollmentInputs enrollmentInput );
	
}
