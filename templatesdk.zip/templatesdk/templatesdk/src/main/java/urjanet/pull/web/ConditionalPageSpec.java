package urjanet.pull.web;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.bool.PageCondition;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.TargetGroup;

/**
 *
 * This class allows for the logical selection of one of two underlying PageSpec objects.
 * The selection is based on a PageCondition object which defines a boolean condition for a particular page.
 * This allows for a single PageSpec to handle several differnt configurations (PageSpecs) for single page, based
 * on the data available on the page.
 *
 * @author rburson
 */
public class ConditionalPageSpec implements PageSpec{

	private PageCondition pageCondition;
	private PageSpec conditionTrueSpec;
	private PageSpec conditionFalseSpec;
	private PageSpec targetSpec;
	
	public ConditionalPageSpec() {
	}

	/**
	 * Create a new ConditionalPageSpec
	 *
	 * @param pageCondition the condition on which to base the resulting PageSpec
	 * @param conditionTrueSpec the PageSpec returned if the condition is met (true)
	 * @param conditionFalseSpec the PageSpec returned if the condition is not met (false)
	 * @param expectedContentType the expected content type of the page
	 */
	public ConditionalPageSpec(PageCondition pageCondition, PageSpec conditionTrueSpec, PageSpec conditionFalseSpec) {
		this.pageCondition = pageCondition;
		this.conditionTrueSpec = conditionTrueSpec;
		this.conditionFalseSpec = conditionFalseSpec;
	}

	@Override
	public ContentType getExpectedContentType() {
		if (targetSpec != null)
			return this.targetSpec.getExpectedContentType();
		
		return null;
	}

	public PageCondition getPageCondition() {
		return pageCondition;
	}
	
	public PageSpec getConditionTrueSpec() {
		return conditionTrueSpec;
	}

	public PageSpec getConditionFalseSpec() {
		return conditionFalseSpec;
	}
	
	public void setTargetSpec(PageSpec targetSpec) {
		this.targetSpec = targetSpec;
	}

	public PageSpec getTargetSpec() {
		return targetSpec;
	}
	
	@Override
	public void setExpectedContentType(ContentType expectedContentType) {
		this.targetSpec.setExpectedContentType(expectedContentType);
	}

	@Override
	public ConfigOptions getConfigOptions() {
		if (targetSpec != null)
			return this.targetSpec.getConfigOptions();
		
		return null;
	}

	@Override
	public void setConfigOptions(ConfigOptions configOptions) {
		this.targetSpec.setConfigOptions(configOptions);
	}

    public List<PageSpec> getAllPageSpecs() {
        List<PageSpec> allSpecs = new ArrayList<PageSpec>();
        
        if (conditionFalseSpec != null)
        	allSpecs.add(conditionFalseSpec);
		if (conditionTrueSpec != null)
			allSpecs.add(conditionTrueSpec);
		
        return allSpecs;
    }

	@Override
	public List<TargetGroup> getAllTargetGroups() {
		List<TargetGroup> allGroups = new ArrayList<TargetGroup>();
		
		if (conditionFalseSpec != null)
			allGroups.addAll(conditionFalseSpec.getAllTargetGroups());
		if (conditionTrueSpec != null)
			allGroups.addAll(conditionTrueSpec.getAllTargetGroups());
		
		return allGroups;
	}
	
	public ConditionalPageSpec setConditionTrueSpec(PageSpec conditionTrueSpec) {
		this.conditionTrueSpec = conditionTrueSpec;
		return this;
	}
	
	public ConditionalPageSpec setConditionFalseSpec(PageSpec conditionFalseSpec) {
		this.conditionFalseSpec = conditionFalseSpec;
		return this;
	}
	
	public ConditionalPageSpec setPageCondition(PageCondition pageCondition) {
		this.pageCondition = pageCondition;
		return this;
	}
	
}
