package urjanet.pull.web;

/**
 *
 * @author rburson
 */
public class GroupPolicy {

	private String groupName;
	private GroupAction action;
	
	public GroupPolicy() {
		
	}

	public GroupPolicy(String groupName) {
		this(groupName, GroupAction.ENUMERATE_NEXT);
	}

	public GroupPolicy(String groupName, GroupAction action) {
		this.groupName = groupName;
		this.action = action;
	}

	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public GroupPolicy setGroupName(String groupName) {
		this.groupName = groupName;
		return this;
	}
	
	/**
	 * @return the action
	 */
	public GroupAction getAction() {
		return action;
	}
	
	/**
	 * @param action the action to set
	 */
	public GroupPolicy setAction(GroupAction action) {
		this.action = action;
		return this;
	}
	
	public boolean isCreate() {
		switch(action) {
		
			case JOIN_EXISTING_ON_SUBGROUP:
			case JOIN_EXISTING_ONVARIABLE:
				return false;
			default:
				return true;
				
		}
	}
	
	public boolean onVariable() {
		switch(action) {
		
			case JOIN_EXISTING_OR_CREATE_ONVARIABLE:
			case JOIN_EXISTING_OR_CREATE_ONVARIABLE_NOOVERWRITE:
			case JOIN_EXISTING_ONVARIABLE:
				return true;
			default:
				return false;
				
		}
	}
	
	public boolean onSubgroup() {
		switch(action) {
		
			case JOIN_EXISTING_OR_CREATE_ON_SUBGROUP:
			case JOIN_EXISTING_ON_SUBGROUP:
				return true;
			default:
				return false;
				
		}
	}
	
	public boolean noOverwrite() {
		switch(action) {
		
			case JOIN_EXISTING_OR_CREATE_NOOVERWRITE:
			case JOIN_EXISTING_OR_CREATE_ONVARIABLE_NOOVERWRITE:
				return true;
			default:
				return false;
				
		}
	}

	/**
	 * Defines the way in which an item should be 'grouped' when added to an extract
	 */
	public enum GroupAction{
		/**
		 * If a group (of the same name) exists, add the new elements to it, otherwise create a new group with this name
		 */
		JOIN_EXISTING_OR_CREATE,
		
		/**
		 * Same as JOIN_EXISTING_OR_CREATE but does not overwrite values
		 */
		JOIN_EXISTING_OR_CREATE_NOOVERWRITE,
		/**
		 * Joining based on a variable
		 */
		JOIN_EXISTING_OR_CREATE_ONVARIABLE,
		/**
		 * Joining based on a variable but does not overwrite values
		 */
		JOIN_EXISTING_OR_CREATE_ONVARIABLE_NOOVERWRITE, 
		
		/**
		 * Join on a vaiable but only if the group exists
		 */
		JOIN_EXISTING_ONVARIABLE,
		
		/**
		 * Joining based on a sub group which should have a groupAction as  JOIN_EXISTING_ONVARIABLE or JOIN_EXISTING_OR_CREATE_ONVARIABLE
		 */
		JOIN_EXISTING_ON_SUBGROUP,
		
		/**
		 * JOIN_EXISTING_ON_SUBGROUP if a subgroup exist or create a new one
		 */
		JOIN_EXISTING_OR_CREATE_ON_SUBGROUP,
		
		/**
		 * Do not add the new items to an existing group.  Instead, add the new items to a new
		 * group with the 'next sequence number' appended to the group name
		 */
		ENUMERATE_NEXT;
	}

}
