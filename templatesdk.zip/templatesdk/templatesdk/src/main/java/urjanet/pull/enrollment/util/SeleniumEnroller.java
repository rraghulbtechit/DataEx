package urjanet.pull.enrollment.util;

import urjanet.pull.enrollment.util.keys.Input;

/**
 * @author sethuramanv
 *
 */
//It should be implemented by all the enrollment class
public interface SeleniumEnroller {
	
	public static final String TAB = "\t";
	
	public static final String DELIM = "_";
	
	public static final EnrollmentUtils enrollment = EnrollmentUtils.getInstance();
	
	public boolean start ( Input enrollmentOption ,EnrollmentInputs enrollmentInputSet);
	
}
