package urjanet.pull.conversion.document;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * Configuration parameters for PDF/Image spliting. (A file having multiple invoices)
 * 
 * @author raghul ravichandran
 *
 */

public enum SplitPDFConfigurationParameters implements ConverterConfigurationParameters{


	/**
	 * By using this pattern, to split the pdf(multiple invoices)
	 */
	PDF_SPLIT_PATTERN("pdf_split_pattern"),
	
	/**
	 * Direction to split(either forward or backward)
	 * Boolean flag. If true, that will be forward split. i.e. Process from page 1(Start page of the pdf) to page n(End page of the pdf).
         * If false, that will be backward split. i.e Process from page n(End page of the pdf) to 1(Start page of the pdf)
	 */
	PDF_SPLIT_FORWARD("pdf_split_forward");

	private String paramName;

	private SplitPDFConfigurationParameters(String paramName) {
		this.paramName = paramName;
	}
	
	@Override
	public String getParameterName() {
		return paramName;
	}

}
