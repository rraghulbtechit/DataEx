package urjanet.pull.operator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

public class DateOperator implements ExtractOperator {
	
	public static enum DateOperation {ADD_DAY, ADD_MONTH, ADD_YEAR, STANDARDIZE, CURRENT_DATE, MAX_DAY, MIN_DAY, SET_DAY,START_DAY_OF_WEEK};
	
	private DateOperation operation;
	private int value;
	private DateFormat inputFormat;
	private DateFormat outputFormat;
	
	//This constructor will be used in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private DateOperator() {
		
	}
	
	public DateOperator(DateOperation operation) {
		this(operation, 0);
	}
	
	public DateOperator(DateOperation operation, DateFormat outputFormat) {
		this(operation, 0, new SimpleDateFormat("MM/dd/yyyy"), outputFormat);
	}
	
	public DateOperator(DateOperation operation, DateFormat inputFormat, DateFormat outputFormat) {
		this(operation, 0, inputFormat, outputFormat);
	}
	
	public DateOperator(DateOperation operation, int value) {
		this(operation, value, new SimpleDateFormat("MM/dd/yyyy"));
	}
	
	public DateOperator(DateOperation operation, int value, DateFormat inputFormat) {
		this(operation, value, inputFormat, inputFormat);
	}
	
	public DateOperator(DateOperation operation, int value, DateFormat inputFormat, DateFormat outputFormat) {
		this.operation = operation;
		this.value = value;
		this.inputFormat = inputFormat;
		this.outputFormat = outputFormat;
	}

	public DateOperation getOperation() {
		return operation;
	}

	public DateOperator setOperation(DateOperation operation) {
		this.operation = operation;
		return this;
	}
	
	public int getValue() {
		return value;
	}
	
	public DateOperator setValue(int value) {
		this.value = value;
		return this;
	}

	public DateFormat getInputFormat() {
		return inputFormat;
	}
	
	public DateOperator setInputFormat(DateFormat inputFormat) {
		this.inputFormat = inputFormat;
		return this;
	}

	public DateFormat getOutputFormat() {
		return outputFormat;
	}
	
	public DateOperator setOutputFormat(DateFormat outputFormat) {
		this.outputFormat = outputFormat;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {			
				
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("RegExOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

		Calendar cal = Calendar.getInstance();
		
		try {
			if(operation == DateOperation.CURRENT_DATE) {
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			}
			cal.setTime(inputFormat.parse(text));
			if (operation == DateOperation.ADD_DAY) {
				cal.add(Calendar.DATE, value);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.ADD_MONTH){
				cal.add(Calendar.MONTH, value);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.ADD_YEAR) {
				cal.add(Calendar.YEAR, value);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.STANDARDIZE) {
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.MAX_DAY) {
				int max = cal.getActualMaximum(Calendar.DATE);
				cal.set(Calendar.DATE, max);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.MIN_DAY) {
				int min = cal.getActualMinimum(Calendar.DATE);
				cal.set(Calendar.DATE, min);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			} else if (operation == DateOperation.SET_DAY) {
				cal.set(Calendar.DATE, value);
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			}else if (operation == DateOperation.START_DAY_OF_WEEK) {
				cal.add( Calendar.DAY_OF_WEEK, -(cal.get(Calendar.DAY_OF_WEEK)-1));
				return new ExtractOperand(outputFormat.format(cal.getTime()));
			}
			else
				throw new OperatorException("Operation Unsupported Exception: " + operation);
		} catch (Exception e) {
			throw new OperatorException("Possible date parsing or extract operand error:\n" + e);
		}
	}
}
