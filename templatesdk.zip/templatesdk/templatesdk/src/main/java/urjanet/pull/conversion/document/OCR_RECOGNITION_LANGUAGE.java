package urjanet.pull.conversion.document;


public enum OCR_RECOGNITION_LANGUAGE{
	
	ENGLISH("English"),
	FRENCH("French"),
	SPANISH("Spanish"),
	GERMAN("German"),
	CHINESEPRC("ChinesePRC"),
	CHINESEPRCENGLISH("ChinesePRC+English"),
	DUTCH("Dutch"),
	FINNISH("Finnish"),
	GREEK("Greek"),
	ITALIAN("Italian"),
	TURKISH("Turkish"),
	SLOVENIAN("Slovenian"),
	POLISH("Polish"),
	CZECH("Czech"),
	SWEDISH("Swedish"),
	PORTUGUESE("PortugueseStandard"),
	JAPANESE("Japanese"),
	JAPANESEENGLISH("Japanese+English"),
	QUECHUA("Quechua"),
	AYMARA("Aymara"),
	KOREAN("Korean"),
	MAORI("Maori"),
	SLOVAK("Slovak"),
	ROMANIAN("Romanian"),
	NORWEGIANBOKMAL("NorwegianBokmal"),
	ARABIC("Arabic"),
	HEBREW("Hebrew"),
	CROATIAN("Croatian");
	
    private String  language;
  
    public String getValue() {
    	return language;
    }

	private OCR_RECOGNITION_LANGUAGE(String language) {
	        this.language = language;
    }
	
}
