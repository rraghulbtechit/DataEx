package urjanet.pull;

import urjanet.UrjanetException;

public class PullException extends UrjanetException{

	public PullException(){
		this("General PullException", null);
	}

	public PullException(Throwable t){
		this("General PullException", t);
	}

	public PullException(String message, Throwable t){
		super(message, t);
	}

	public PullException(String message){
		this(message, null);
	}

}
