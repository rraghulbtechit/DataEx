package urjanet.pull.web;

import java.util.List;

import urjanet.DataTargetType;
import urjanet.pull.operator.ExtractOperator;

/**
 *
 * Represents a target found within an Xml document.
 * The path to the element is specified by an 'xpath' String and can be further refined by
 * specifying any number of 'operators' that are applied to
 * the data found at the location specified by the 'xpath'
 * It also allows for specifying a list of relative sub-targets via relativeDataTargets, which allows
 * for the building a relatively complex extraction instructions, especially when coupled with an ExpandableDataTarget.
 *
 * @author rbursons
 * @see ExpandableDataTarget
 */
public class XmlDataTarget extends DataTarget{

	private String xPath;
	private List<String> alternateXPaths;
	private boolean variableSubstitution = false;
	private boolean reinitializeVariable;
	private int index;

	public XmlDataTarget() {
	}

	public XmlDataTarget(String name){
		super(name);
	}

	public XmlDataTarget(GroupPolicy groupPolicy, String name, String xPath) {
		super(groupPolicy, name);
		this.xPath = xPath;
	}

	/**
	 *
	 * Create a new XmlDataTarget without any sub-targets
	 *
	 * @param name the name (or key) of this target value
	 * @param xPath the xpath to this target value
	 * @param operator a list of ExtractOperators, applied to the target value
	 */
	public XmlDataTarget(String name, String xPath, ExtractOperator operator) {
		super(name, operator);
		this.xPath = xPath;
	}

	/**
	 * Create a new XmlDataTarget without any sub-targets, data type, or operators
	 * Useful in a simply scenario for grabbing a single textnode() value
	 *
	 * @param name the name (or key) of this target value
	 * @param xPath the xpath to this target value
	 */
	public XmlDataTarget(String name, String xPath) {
		super(name);
		this.xPath = xPath;
	}

	public XmlDataTarget(List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
	}

	/**
	 * Create a new XmlDataTarget to hold relative sub-targets
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param xPath the xpath to the relative node
	 * @param relativeDataTargets the sub-targets that relative to this node
	 */
	public XmlDataTarget(String xPath, List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
		this.xPath = xPath;
	}

	public XmlDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
	}

	/**
	 * Create a new XmlDataTarget to hold relative sub-targets and assign it a GroupPolicy that puts it in a
	 * Collection Subgroup.
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param xPath the xpath to the relative node
	 * @param relativeDataTargets the sub-targets that relative to this node
	 * @param id the subgroup to put this target and all of it's sub-targets in
	 */
	public XmlDataTarget(GroupPolicy groupPolicy, String xPath, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
		this.xPath = xPath;
	}

	/**
	 *
	 * A non-public constructor to all for the cloning of this object.
	 * Should be moved to a clone() implementation.
	 *
	 * @param xPath the xpath to the relative node
	 * @param relativeDataTargets the sub-targets that relative to this node
	 * @param id the subgroup to put this target and all of it's sub-targets in
	 * @param name the name (or key) of this target value
	 * @param type the datatype of this target value
	 * @param framePath the framePath (if any)
	 * @param operator a list of ExtractOperators, applied to the target value
	 *
	 */
	XmlDataTarget(GroupPolicy groupPolicy, String xPath, List<? extends DataTarget> relativeDataTargets, DataTargetType type, String name, String framePath, ExtractOperator operator) {
		super(groupPolicy, relativeDataTargets, type, name, framePath, operator);
		this.xPath = xPath;
	}


	public XmlDataTarget(String name, ExtractOperator operator) {
		super(name, operator);
	}

	/**
	 *
	 * @return the xpath to the target
	 */
	public String getxPath() {
		return xPath;
	}

	/**
	 *
	 * @param xPath the xpath to the target
	 */
	public XmlDataTarget setxPath(String xPath) {
		this.xPath = xPath;
		return this;
	}

	/**
	 * @return A List of alternative xpaths the will applied if the 'primary' xpath isn't found until and xpath is found or all the supplied xpaths have been attempted
	 */
	public List<String> getAlternateXPaths() {
		return alternateXPaths;
	}

	/**
	 *
	 * @param alternateXPaths A List of alternative xpaths the will applied if the 'primary' xpath isn't found until and xpath is found or all the supplied xpaths have been attempted
	 */
	public XmlDataTarget setAlternateXPaths(List<String> alternateXPaths) {
		this.alternateXPaths = alternateXPaths;
		return this;
	}

	@Override
	public String toString() {
		if(this.name != null){
			return "[" + this.name + "]";
		}else if(this.xPath != null){
			return "[" + this.xPath + "]";
		}else{
			return super.toString();
		}
	}

	@Override
	public XmlDataTarget setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

	@Override
	public XmlDataTarget setFormatHint(String formatHint) {
		this.formatHint = formatHint;
		return this;
	}

	@Override
	public XmlDataTarget setQualifier(DataTargetQualifier qualifier) {
		this.qualifier = qualifier;
		return this;
	}

	@Override
	public XmlDataTarget setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
		return this;
	}

	@Override
	public XmlDataTarget setGroupingTarget(boolean groupingTarget) {
		this.groupingTarget = groupingTarget;
		return this;
	}

	@Override
	public XmlDataTarget setVariable(String variableName) {
		return setVariable(variableName, false);
	}
	
	/**
	 * 
	 * @param variableName
	 * @param doReinitialization
	 * @return
	 */
	public XmlDataTarget setVariable(String variableName, boolean doReinitialization) {
		this.variableName = variableName;
		this.reinitializeVariable = doReinitialization;
		
		return this;
	}
	
	public boolean isReinitializeVariable() {
		return reinitializeVariable;
	}

	public boolean isVariableSubstitution() {
		return variableSubstitution;
	}

	public XmlDataTarget setVariableSubstitution(boolean variableSubstitution) {
		this.variableSubstitution = variableSubstitution;
		return this;
	}
	
	public int getXpathNodeIndex() {
		return index;
	}

	public XmlDataTarget setXpathNodeIndex(int index) {
		this.index = index;
		return this;
	}

	@Override
	public XmlDataTarget setDefaultValue(String... defaultValue) {
		String tempValue = defaultValue[0];
		
		for(int i = 1; i < defaultValue.length; i++)
			tempValue += "||" + defaultValue[i];
		
		return this.setDefaultValue(tempValue);
	}
}
