package urjanet.pull.web.pdf.filter;

public class NegativeFilter extends ContextFilter {
	
	private ContextFilter filterToNegate;
	
	private OverlapPosition overlapTextPosition;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private NegativeFilter() {
		
	}
	
	public NegativeFilter(ContextFilter filterToNegate) {
		this.filterToNegate = filterToNegate;
	}
	
	public ContextFilter getFilterToNegate() {
		return filterToNegate;
	}

	public void setFilterToNegate(ContextFilter filterToNegate) {
		this.filterToNegate = filterToNegate;
	}

	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}

	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public NegativeFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public NegativeFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
}
