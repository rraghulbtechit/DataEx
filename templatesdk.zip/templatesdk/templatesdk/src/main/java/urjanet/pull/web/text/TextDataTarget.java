package urjanet.pull.web.text;

import java.util.List;

import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;

public class TextDataTarget extends DataTarget implements DataTargetQualifier {

	private String searchLabel;
	private boolean includeWholeLine;
	private TextTargetDefinition targetDefinition;

	//This constructor will be called from Hit to create an instance through reflection.
	protected TextDataTarget() {
		
	}
	
	public TextDataTarget(String name) {
		super(name);
	}
	
	public TextDataTarget(String name, String searchLabel) {
		super(name);
		this.setSearchLabel(searchLabel);
	}

	public TextDataTarget(String name, String searchLabel, TextTargetDefinition targetDefinition) {
		super(name);
		this.setSearchLabel(searchLabel);
		this.setTargetDefinition(targetDefinition);
	}

	public TextDataTarget(GroupPolicy groupPolicy, String name, String searchLabel, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
		this.setName(name);
		this.setSearchLabel(searchLabel);
	}

	public TextDataTarget(GroupPolicy groupPolicy, String searchLabel, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
		this.setSearchLabel(searchLabel);
	}

	public TextDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
	}

	public TextDataTarget(List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
	}
	
	public TextDataTarget(String searchLabel, List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
		this.setSearchLabel(searchLabel);
	}
	
	public TextDataTarget(String name, String searchLabel, ExtractOperator operator) {
		super(name, operator);
		this.setSearchLabel(searchLabel);
	}

	public TextDataTarget(String name, String searchLabel, ExtractOperator operator, TextTargetDefinition targetDefinition) {
		super(name, operator);
		this.setSearchLabel(searchLabel);
		this.setTargetDefinition(targetDefinition);
	}

	public TextDataTarget(String name, ExtractOperator operator) {
		super(name, operator);
	}

	public TextDataTarget(String name, TextTargetDefinition targetDefinition) {
		super(name);
		this.setTargetDefinition(targetDefinition);
	}

	public TextDataTarget(String name, ExtractOperator operator, TextTargetDefinition targetDefinition) {
		super(name, operator);
		this.setTargetDefinition(targetDefinition);
	}

	public TextDataTarget(String name, String searchLabel, List<? extends DataTarget> relativeDataTargets, ExtractOperator operator) {
		super(name, operator);
		this.setRelativeDataTargets(relativeDataTargets);
		this.setSearchLabel(searchLabel);
	}

	public TextDataTarget(String name, String searchLabel, List<? extends DataTarget> relativeDataTargets, ExtractOperator operator, TextTargetDefinition targetDefinition) {
		super(name, operator);
		this.setRelativeDataTargets(relativeDataTargets);
		this.setSearchLabel(searchLabel);
		this.setTargetDefinition(targetDefinition);
	}

	public TextDataTarget(GroupPolicy groupPolicy, String searchLabel, List<? extends DataTarget> relativeDataTargets, TextTargetDefinition targetDefinition) {
		super(groupPolicy, relativeDataTargets);
		this.setSearchLabel(searchLabel);
		this.setTargetDefinition(targetDefinition);
	}
	
	public TextDataTarget(String searchLabel, List<? extends DataTarget> relativeDataTargets, TextTargetDefinition targetDefinition) {
		super(relativeDataTargets);
		this.setSearchLabel(searchLabel);
		this.setTargetDefinition(targetDefinition);
	}
	
	public TextDataTarget setSearchLabel(String label) {
		this.searchLabel = label;
		return this;
	}

	public String getSearchLabel() {
		return searchLabel;
	}

	public boolean isIncludeWholeLine() {
		return includeWholeLine;
	}

	public TextDataTarget setIncludeWholeLine(boolean includeWholeLine) {
		this.includeWholeLine = includeWholeLine;
		return this;
	}
	
	public TextDataTarget setTargetDefinition(TextTargetDefinition targetDefinition) {
		this.targetDefinition = targetDefinition;
		return this;
	}

	public TextTargetDefinition getTargetDefinition() {
		return targetDefinition;
	}
	
	@Override
	public TextDataTarget setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

	@Override
	public TextDataTarget setFormatHint(String formatHint) {
		this.formatHint = formatHint;
		return this;
	}

	@Override
	public TextDataTarget setQualifier(DataTargetQualifier qualifier) {
		this.qualifier = qualifier;
		return this;
	}

	@Override
	public TextDataTarget setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
		return this;
	}

	@Override
	public TextDataTarget setGroupingTarget(boolean groupingTarget) {
		this.groupingTarget = groupingTarget;
		return this;
	}

	@Override
	public TextDataTarget setVariable(String variableName) {
		this.variableName = variableName;
		return this;
	}

	@Override
	public TextDataTarget setDefaultValue(String... defaultValue) {
		String tempValue = defaultValue[0];
		
		for(int i = 1; i < defaultValue.length; i++)
			tempValue += "||" + defaultValue[i];
		
		return this;
	}

}
