package urjanet.pull.web.coordinate;

import urjanet.pull.web.coordinate.CoordinateKey.KeyStructure;


public class CoordinateSearchTargetDefinition extends CoordinateTargetDefinition {
	
	public static enum SearchType {VERTICAL_SEARCH_BOUNDED, VERTICAL_SEARCH_UNBOUNDED, HORIZONTAL_SEARCH, BOX_SEARCH, EXPANDABLE_SEARCH, LINE_SEARCH};
	
	private double firstBuffer, secondBuffer;
	
	private double x, y, width, height;
	
	private SearchType searchType;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private CoordinateSearchTargetDefinition() {
		
	}
	
	public CoordinateSearchTargetDefinition(String searchKey, String endKey, Direction direction, SearchType searchType) {
		this(new CoordinateKey(searchKey, KeyStructure.IN_ORDER), new CoordinateKey(endKey, KeyStructure.IN_ORDER), direction, searchType);
	}
	
	public CoordinateSearchTargetDefinition(CoordinateKey searchKey, CoordinateKey endKey, Direction direction, SearchType searchType) {
		super(searchKey, endKey, direction);
		
		this.searchType = searchType;
		this.firstBuffer = this.secondBuffer = 0.0;
		
	}
	
	public CoordinateSearchTargetDefinition(CoordinateKey searchKey,Direction direction, SearchType searchType) {
		this(searchKey, null, direction, searchType);
	}
	
	public CoordinateSearchTargetDefinition(CoordinateKey searchKey, SearchType searchType) {
		this(searchKey, null, Direction.BELOW, searchType);
	}
	
	public CoordinateSearchTargetDefinition(String searchKey, String endKey, Direction direction, SearchType searchType, double secondBuffer) {
		this(new CoordinateKey(searchKey, KeyStructure.IN_ORDER), new CoordinateKey(endKey, KeyStructure.IN_ORDER), direction, searchType, 0, secondBuffer);
	}
	
	public CoordinateSearchTargetDefinition(CoordinateKey searchKey, CoordinateKey endKey, Direction direction, SearchType searchType, double firstBuffer, double secondBuffer) {
		super(searchKey, endKey, direction);
		
		this.searchType = searchType;
		this.firstBuffer = firstBuffer;
		this.secondBuffer = secondBuffer;
		
	}
	
	public CoordinateSearchTargetDefinition(double x, double y, double width, double height) {
		searchType = SearchType.BOX_SEARCH;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public double getFirstBuffer() {
		return firstBuffer;
	}

	public CoordinateSearchTargetDefinition setFirstBuffer(double firstBuffer) {
		this.firstBuffer = firstBuffer;
		return this;
	}

	public double getSecondBuffer() {
		return secondBuffer;
	}

	public CoordinateSearchTargetDefinition setSecondBuffer(double secondBuffer) {
		this.secondBuffer = secondBuffer;
		return this;
	}

	public double getX() {
		return x;
	}

	public CoordinateSearchTargetDefinition setX(double x) {
		this.x = x;
		return this;
	}

	public double getY() {
		return y;
	}

	public CoordinateSearchTargetDefinition setY(double y) {
		this.y = y;
		return this;
	}

	public double getWidth() {
		return width;
	}

	public CoordinateSearchTargetDefinition setWidth(double width) {
		this.width = width;
		return this;
	}

	public double getHeight() {
		return height;
	}

	public CoordinateSearchTargetDefinition setHeight(double height) {
		this.height = height;
		return this;
	}

	public SearchType getSearchType() {
		return searchType;
	}

	public CoordinateSearchTargetDefinition setSearchType(SearchType searchType) {
		this.searchType = searchType;
		return this;
	}

}
