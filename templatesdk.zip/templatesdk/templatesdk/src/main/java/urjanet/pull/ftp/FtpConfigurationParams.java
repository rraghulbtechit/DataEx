package urjanet.pull.ftp;

/**
 * Configuration parameters for FTP, FTPS and SFTP access
 * 
 * @author sriram
 *
 */
public enum FtpConfigurationParams {
	SERVER_ADDRESS,
	USERNAME,
	PASSWORD,
	SOURCE_DIR,
	AFTER_READ_DIR, 
	FTP_TYPE,
	RECEIPT_DIR,
	PRIVATE_KEY_PATH,
	PRIVATE_KEY
}


