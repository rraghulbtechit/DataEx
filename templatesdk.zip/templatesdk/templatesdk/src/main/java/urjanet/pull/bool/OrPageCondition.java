package urjanet.pull.bool;

/**
 *
 * @author rburson
 */
public class OrPageCondition implements PageCondition{

	private PageCondition c1, c2;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private OrPageCondition() {
		
	}
	
	public OrPageCondition(PageCondition c1, PageCondition c2) {
		this.c1 = c1;
		this.c2 = c2;
	}

	public PageCondition getC1() {
		return c1;
	}
	
	public OrPageCondition setC1(PageCondition c1) {
		this.c1 = c1;
		return this;
	}

	public PageCondition getC2() {
		return c2;
	}

	public OrPageCondition setC2(PageCondition c2) {
		this.c2 = c2;
		return this;
	}
	
}
