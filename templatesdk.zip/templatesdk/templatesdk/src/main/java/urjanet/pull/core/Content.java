package urjanet.pull.core;

/**
 *
 * Represents any type of content or data source from which navigation or extraction might take place.
 *
 * @author rburson
 */
public interface Content {
}
