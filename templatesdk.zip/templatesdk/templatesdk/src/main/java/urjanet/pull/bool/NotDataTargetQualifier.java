package urjanet.pull.bool;

import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.DataTargetQualifier;

public class NotDataTargetQualifier extends BaseDataTargetQualifier {
	
	private DataTargetQualifier target;

	//This will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private NotDataTargetQualifier() {

	}
	
	public NotDataTargetQualifier(String qualifierName, DataTargetQualifier target) {
		super(qualifierName);
		this.target = target;
	}
	
	public NotDataTargetQualifier(DataTargetQualifier target) {
		this(null, target);
	}
	
	public DataTargetQualifier getTarget() {
		return target;
	}
	
	public NotDataTargetQualifier setTarget(DataTargetQualifier target) {
		this.target = target;
		return this;
	}

}
