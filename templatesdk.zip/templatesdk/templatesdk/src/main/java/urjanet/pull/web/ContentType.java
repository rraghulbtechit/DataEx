package urjanet.pull.web;

import urjanet.pull.core.PageSpec;
import urjanet.pull.template.WootTemplateProvider;
import urjanet.pull.template.content.CsvPageSpecProvider;
import urjanet.pull.template.content.EdiPageSpecProvider;
import urjanet.pull.template.content.HtmlPageSpecProvider;
import urjanet.pull.template.content.IntervalPageSpecProvider;
import urjanet.pull.template.content.PdfPageSpecProvider;
import urjanet.pull.template.content.PrintFilePageSpecProvider;
import urjanet.pull.template.content.XlsPageSpecProvider;

/**
 *
 * @author rburson
 */
public enum ContentType {

	PDF("application/pdf"),
	INSERT_BILL("application/insert"),
	XML("text/xml"),
	HTML("text/html"),
	HTML_PDF("text/html"),
    CSV("text/csv"),
    XLS("application/vnd.ms-excel"),
    XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    EDI("application/txt"),
    PRINT_FILE("application/txt"),
    MSG("application/octet-stream"),
    GREEN_BUTTON("application/green-button"),
    ENERGY_PROFILER_ONLINE("application/energy_profiler_online"),
    SPREADSHEET_INTERVAL_DATA("application/spreadsheet-interval-data"),
    WOOT("application/woot");

	private final String value;

	private ContentType(String value){
		this.value = value;
	}

	public String getValue(){
		return this.value;
	}

	public static PageSpec getPageSpecForContentType(ContentType contentType, Object pageSpecProvider) {
		
		switch(contentType) {
			case PDF:
				return ((PdfPageSpecProvider)pageSpecProvider).getPdfPageSpec();
			case EDI:
				return ((EdiPageSpecProvider)pageSpecProvider).getEdiPageSpec();
			case PRINT_FILE:
				return ((PrintFilePageSpecProvider)pageSpecProvider).getPrintFilePageSpec();
			case CSV:
				return ((CsvPageSpecProvider)pageSpecProvider).getCsvPageSpec();
			case SPREADSHEET_INTERVAL_DATA:
				return ((IntervalPageSpecProvider)pageSpecProvider).getIntervalPageSpec();
			case GREEN_BUTTON:
				return ((IntervalPageSpecProvider)pageSpecProvider).getIntervalPageSpec();
			case XLS:
				return ((XlsPageSpecProvider)pageSpecProvider).getXlsPageSpec();
			case XLSX:
				return ((XlsPageSpecProvider)pageSpecProvider).getXlsPageSpec();
			case WOOT:
				return WootTemplateProvider.createWootPageSpec();
			case HTML:
				return ((HtmlPageSpecProvider)pageSpecProvider).getHtmlPageSpec();
			case HTML_PDF:
				return ((PdfPageSpecProvider)pageSpecProvider).getPdfPageSpec();
			default:
				return null;
		}
	}

}
