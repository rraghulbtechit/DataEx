package urjanet.pull.web;

import com.gargoylesoftware.htmlunit.html.HtmlPage;

public interface ConditionalNavigation {
	
	public boolean shouldContinue(HtmlPage page, NavTarget navTarget, SessionContext context);

}
