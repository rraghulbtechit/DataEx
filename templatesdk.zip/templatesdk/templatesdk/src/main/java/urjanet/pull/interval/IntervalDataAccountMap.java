package urjanet.pull.interval;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import urjanet.keys.InputKeys;
import urjanet.pull.web.SessionContext;

public class IntervalDataAccountMap {
	
	private SimpleDateFormat timestampFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
	private SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
	private Map<String, DateRange> accountMap = new HashMap<String, DateRange>();
	private Date lowestEarliest, highestEarliest;
	private Date lowestLatest, highestLatest;
	
	public IntervalDataAccountMap(String serializedMap) {
		
		if (serializedMap == null || serializedMap.isEmpty())
			return;
		
		String[] accounts = serializedMap.split("&");
		for (String account : accounts) {
			try {
				String[] accountToTimes = account.split("=");
				String accountNumber = accountToTimes[0];
				String[] times = accountToTimes[1].split("\\|");
				addNewDateRange(accountNumber, times[0], times[1]);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public IntervalDataAccountMap(Map<String, String> accountTimesMap) {
		
		if (accountTimesMap == null)
			return;
		
		for (Map.Entry<String, String> entry : accountTimesMap.entrySet()) {
			try {
				String accountNumber = entry.getKey();
				String[] times = entry.getValue().split("\\|");
				addNewDateRange(accountNumber, times[0], times[1]);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public IntervalDataAccountMap() {

	}
	
	public void addNewDateRange(String accountNumber, String earliestTime, String latestTime) throws ParseException {
		Date earliest = timestampFormatter.parse(earliestTime);
		Date latest = timestampFormatter.parse(latestTime);
		addNewDateRange(accountNumber, earliest, latest);
	}
	
	public void addNewDateRange(String accountNumber, Date earliest, Date latest) {
		
		if (lowestEarliest == null || lowestEarliest.after(earliest))
			lowestEarliest = earliest;
		
		if (highestEarliest == null || highestEarliest.before(earliest))
			highestEarliest = earliest;
		
		if (lowestLatest == null || lowestLatest.after(latest))
			lowestLatest = latest;
		
		if (highestLatest == null || highestLatest.before(latest))
			highestLatest = latest;
		
		accountMap.put(accountNumber, new DateRange(earliest, latest));
	}
	
	public String serialize() {
		StringBuilder builder = new StringBuilder();
		
		for (Map.Entry<String, DateRange> entry : accountMap.entrySet()) {
			builder.append(entry.getKey());
			builder.append("=");
			builder.append(entry.getValue());
			builder.append("&");
		}
		
		return builder.toString();
	}
	
	public boolean containsAccount(String accountNumber) {
		for (String key : accountMap.keySet()) {
			String[] parts = key.split(":");
			for (String part : parts)
				if (accountNumber.contains(part))
					return true;
		}
		return false;
	}
	
	public boolean containsAccountMeter(String accountNumber, String meterNumber) {
		for (String key : accountMap.keySet()) {
			if (key.contains(accountNumber + ":" + meterNumber))
				return true;
		}
		return false;
	}
	
	public boolean isEmpty() {
		return accountMap.isEmpty();
	}
	
	public Date getEarliest(String accountNumber) {
		return accountMap.get(accountNumber).getEarliest();
	}
	
	public Date getLatest(String accountNumber) {
		return accountMap.get(accountNumber).getLatest();
	}
	
	public String getEarliestAsString(String accountNumber) {
		return timestampFormatter.format(getEarliest(accountNumber));
	}
	
	public String getLatestAsString(String accountNumber) {
		return timestampFormatter.format(getLatest(accountNumber));
	}
	
	public Date getLowestEarliest() {
		return lowestEarliest;
	}

	public Date getHighestEarliest() {
		return highestEarliest;
	}

	public Date getLowestLatest() {
		return lowestLatest;
	}

	public Date getHighestLatest() {
		return highestLatest;
	}

	public boolean setInputKeysForAccount(String accountNumber, SessionContext context) {
		return setInputKeysForAccount(accountNumber, context, null);
	}
	public boolean setInputKeysForAccount(String accountNumber, SessionContext context, Date availableDate) {

		Date latestAvailable = new Date();
		if (availableDate!=null && latestAvailable.after(availableDate))
			latestAvailable = availableDate;

		for (String key : accountMap.keySet()) {
			String[] parts = key.split(":");
			for (String part : parts)
				if (accountNumber.contains(part)) {
					DateRange dr = accountMap.get(key);
					if (!latestAvailable.after(dr.getLatest()))
						return false;
					setInputKeys(context, dr.getLatest(), latestAvailable);
					return true;
				}
		}

		return false;

	}
	
	/**
	 * 
	 * @param accountNumber
	 * @return
	 * <p> 
	 * This return the latest date for the specified account number but it won't match the exact account number.
	 * It will check whether the map contains the part of account number in it. Because the account number may be the 
	 * combination of AccountNumber:MeterNumber
	 * </p>
	 */
	public Date getLatestDateForAccount(String accountNumber) {
		
		for(String key:accountMap.keySet()) {
			String[] parts = key.split(":");
			for(String part:parts) {
				if(part.equals(accountNumber)) {
					return accountMap.get(key).getLatest();
				}
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param accountNumber
	 * @return
	 * <p> 
	 * This return the earliest date for the specified account number but it won't match the exact account number.
	 * It will check whether the map contains the part of account number in it. Because the account number may be the 
	 * combination of AccountNumber:MeterNumber
	 * </p>
	 */
	public Date getEarliestDateForAccount(String accountNumber) {
		
		for(String key:accountMap.keySet()) {
			String[] parts = key.split(":");
			for(String part:parts) {
				if(part.equals(accountNumber)) {
					return accountMap.get(key).getEarliest();
				}
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param accountMeter
	 * @param context
	 * @param availableDate - Date data is available until
	 * @return
	 */
	public boolean setInputKeysForAccountMeter(String accountNumber, String meterNumber, SessionContext context, Date availableDate) {
		
		Date latestAvailable = new Date();
		if (availableDate!=null && latestAvailable.after(availableDate))
			latestAvailable = availableDate;

		for (String key : accountMap.keySet()) {
			if (key.contains(accountNumber + ":" + meterNumber)) {
				DateRange dr = accountMap.get(key);
				if (!latestAvailable.after(dr.getLatest()))
					return false;
				setInputKeys(context, dr.getLatest(), latestAvailable);
				return true;
			}
		}
		
		return false;
	}
	public boolean setInputKeysForAccountMeter(String accountNumber, String meterNumber, SessionContext context) {
		return setInputKeysForAccountMeter(accountNumber, meterNumber, context, null);
	}
	
	public void setInputKeys(SessionContext context, Date start, Date end) {
		setStartDate(context, start);
		setEndDate(context, end);		
	}
	
	public void setStartDate(SessionContext context, Date date) {
		Calendar c = Calendar.getInstance();
		
		if (date != null) {
			context.setContextValue(/*IntervalKeys.INTERVAL_START.getValue()*/ "interval_start", date);		// TODO: hacky. We need to come back and decompose this class..
			context.setContextValue(InputKeys.STMT_PERIOD_START_DATE.getValue(), dateFormatter.format(date));
			c.setTime(date);
			context.setContextValue(InputKeys.STMT_START_MONTH.getValue(), (c.get(Calendar.MONTH) + 1) + "");
			context.setContextValue(InputKeys.STMT_START_DAY.getValue(), c.get(Calendar.DATE) + "");
			context.setContextValue(InputKeys.STMT_START_YEAR.getValue(), c.get(Calendar.YEAR) + "");
		}
	}
	
	public void setEndDate(SessionContext context, Date date) {
		Calendar c = Calendar.getInstance();
		
		if (date != null) {
			context.setContextValue(/*IntervalKeys.INTERVAL_END.getValue()*/ "interval_end", date);
			context.setContextValue(InputKeys.STMT_PERIOD_END_DATE.getValue(), dateFormatter.format(date));
			c.setTime(date);
			context.setContextValue(InputKeys.STMT_END_MONTH.getValue(), (c.get(Calendar.MONTH) + 1) + "");
			context.setContextValue(InputKeys.STMT_END_DAY.getValue(), c.get(Calendar.DATE) + "");
			context.setContextValue(InputKeys.STMT_END_YEAR.getValue(), c.get(Calendar.YEAR) + "");
		}
	}
	
	
	private static class DateRange {
		
		private SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		
		private Date earliest, latest;
		
		public DateRange(Date earliest, Date latest) {
			this.earliest = earliest;
			this.latest = latest;
		}

		public Date getEarliest() {
			return earliest;
		}

		public Date getLatest() {
			return latest;
		}
		
		public String toString() {
			return formatter.format(earliest) + "|" + formatter.format(latest);
		}
	}

	@Override
	public String toString() {
		return accountMap.toString();
	}

}
