package urjanet.pull.web.htmlunit;

import java.io.IOException;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.RefreshHandler;
import com.gargoylesoftware.htmlunit.WaitingRefreshHandler;

public class MaxTimeRefreshHandler implements RefreshHandler {
	
    /** Logging support. */
    private static final Log LOG = LogFactory.getLog(MaxTimeRefreshHandler.class);

    private final int maxTime;

    /**
     * Creates a new refresh handler that will wait whatever time the server or content asks, unless
     * it it longer than <tt>maxwait</tt>. A value of <tt>maxwait</tt> that is less than <tt>1</tt>
     * will cause the refresh handler to always wait for whatever time the server or content requests.
     *
     * @param maxwait the maximum wait time before the refresh (in seconds)
     */
    public MaxTimeRefreshHandler(final int maxTime) {
    	this.maxTime = maxTime;
    }

    /**
     * Creates a new refresh handler that will always wait whatever time the server or content asks.
     */
    public MaxTimeRefreshHandler() {
    	maxTime = 0;
    }
    
    public void handleRefresh(final Page page, final URL url, final int seconds) throws IOException {
    	
    	if (seconds <= maxTime) {
    		new WaitingRefreshHandler().handleRefresh(page, url, seconds);
    	}
    }

}
