package urjanet.pull.web.coordinate;

public class CoordinateTargetDefinition {
	
	public static enum Direction {ABOVE, BELOW, LEFT, RIGHT, SELF};
	public static enum Formatting {SPACE_DELIMITED, SAME_LINE, NONE};
	
	private Formatting formatting;
	
	private Direction direction;
	private double maxDistance;

	private CoordinateKey searchKey;
	private CoordinateKey endKey;
	
	private String regExQualifier;
	
	private String regExOutputApplicator;
	
	//private CoordinateKey verticalCrossSectionKey;
	
	
	public CoordinateTargetDefinition(CoordinateKey searchKey, CoordinateKey endKey, Direction direction) {
		this.searchKey = searchKey;
		this.endKey = endKey;
		this.formatting = Formatting.NONE;
		this.maxDistance = 0;
	}
	

	public CoordinateTargetDefinition(CoordinateKey searchKey, Direction direction) {
		this.searchKey = searchKey;
		this.direction = direction;
		this.formatting = Formatting.NONE;
		this.maxDistance = 0;
	}
	
	public CoordinateTargetDefinition(CoordinateKey searchKey) {
		this.searchKey = searchKey;
		this.formatting = Formatting.NONE;
		this.maxDistance = 0;
	}
	
	public CoordinateTargetDefinition(){}

	public Direction getDirection() {
		return direction;
	}

	public CoordinateTargetDefinition setDirection(Direction direction) {
		this.direction = direction;
		return this;
	}

	public CoordinateKey getSearchKey() {
		return searchKey;
	}

	public CoordinateTargetDefinition setSearchKey(CoordinateKey searchKey) {
		this.searchKey = searchKey;
		return this;
	}

	public CoordinateKey getEndKey() {
		return endKey;
	}

	public CoordinateTargetDefinition setEndKey(CoordinateKey endKey) {
		this.endKey = endKey;
		return this;
	}


	public Formatting getFormatting() {
		return formatting;
	}


	public CoordinateTargetDefinition setFormatting(Formatting formatting) {
		this.formatting = formatting;
		return this;
	}


	public String getRegExQualifier() {
		return regExQualifier;
	}

	public CoordinateTargetDefinition setRegExQualifier(String regEx) {
		this.regExQualifier = regEx;
		return this;
	}


	public String getRegExOutputApplicator() {
		return regExOutputApplicator;
	}


	public CoordinateTargetDefinition setRegExOutputApplicator(String regExOutputApplicator) {
		this.regExOutputApplicator = regExOutputApplicator;
		return this;
	}


	public double getMaxDistance() {
		return maxDistance;
	}


	public CoordinateTargetDefinition setMaxDistance(double maxDistance) {
		this.maxDistance = maxDistance;
		return this;
	}
	
}
