package urjanet.pull.web.intercept;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gargoylesoftware.htmlunit.Cache;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebResponseData;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import urjanet.pull.web.SessionContext;
import urjanet.pull.web.htmlunit.HtmlUnitCache;
import urjanet.util.UFileInputStream;

/**
 *
 * @author rburson
 */
public abstract class Interceptor implements WebConnection {

	private static final Logger log = LoggerFactory.getLogger(Interceptor.class);
	
	protected WebConnection webConnection;
	protected WebClient webClient;
	protected SessionContext context;
	protected List<FileMetaData> tmpFiles;

	public Interceptor(WebConnection webConnection, WebClient client, SessionContext context) throws IllegalArgumentException {
		this.webConnection = webConnection;
		this.webClient = client;
		this.context = context;
	}
	
	// NOTE: subclasses *must* call super.getResponse(), or they will lose the javascript blacklist feature
	
	@Override
    public WebResponse getResponse(final WebRequest request) throws IOException {
    	
    	if (JavaScriptGlobalBlacklist.isBlacklisted(request.getUrl())) {
        	log.debug("suppressing javascript: " + request.getUrl().toString());    		
    		return createWebResponse(request, "", "application/javascript");
    	}
    	
    	WebResponse response = webConnection.getResponse(request);
    	addFileMetaData(response, request);
    	
        return response;
    }
        
    /**
     * Creates a faked WebResponse for the request with the provided content.
     * @param wr the web request for which a response should be created
     * @param content the content to place in the response
     * @param contentType the content type of the response
     * @return a web response with the provided content
     * @throws IOException if an encoding problem occurred
     */
    protected WebResponse createWebResponse(final WebRequest wr, final String content,
            final String contentType) throws IOException {
        return createWebResponse(wr, content, contentType, 200, "OK");
    }

    /**
     * Creates a faked WebResponse for the request with the provided content.
     * @param wr the web request for which a response should be created
     * @param content the content to place in the response
     * @param contentType the content type of the response
     * @param responseCode the HTTP code for the response
     * @param responseMessage the HTTP message for the response
     * @return a web response with the provided content
     * @throws IOException if an encoding problem occurred
     */
    protected WebResponse createWebResponse(final WebRequest wr, final String content,
            final String contentType, final int responseCode, final String responseMessage) throws IOException {
        final List<NameValuePair> headers = new ArrayList<>();
        final String encoding = "UTF-8";
        headers.add(new NameValuePair("content-type", contentType + "; charset=" + encoding));
        final byte[] body = content.getBytes(encoding);
        final WebResponseData wrd = new WebResponseData(body, responseCode, responseMessage, headers);
        return new WebResponse(wrd, wr.getUrl(), wr.getHttpMethod(), 0);
    }
    
	public WebConnection getWebConnection() {
		return webConnection;
	}

	public void setWebConnection(WebConnection webConnection) {
		this.webConnection = webConnection;
	}

	public WebClient getWebClient() {
		return webClient;
	}

	public void setWebClient(WebClient webClient) {
		this.webClient = webClient;
	}
	
	@Override
	public void close() {
		
	}
	
	/**
	 * Clear all the associated files for the current Web Connection.
	 */
	public synchronized void clearTempFiles() {
		
		if(tmpFiles == null || tmpFiles.size() == 0) {
    		return;
    	}
    	for(FileMetaData metaData:tmpFiles) {
    		if(!metaData.isCacheable()) {
    			File file = new File(metaData.getFilePath());
        		if(!file.exists()) {
        			continue;
        		}
        		if(file.delete()) {
        			log.trace("Htmlunit temporary file is deleted : " + file.getName() + " Content Type : " + metaData.getContentType());
        		} else {
        			file.deleteOnExit();
        		}
    		}
    	}
    	tmpFiles.clear();
	}
	
	/**
	 * This will clear only PDF file in the list of files.
	 */
	protected void clearOnlyPdfs() {
		
		if(tmpFiles == null || tmpFiles.size() == 0) {
    		return;
    	}
    	for(FileMetaData metaData:tmpFiles) {
    		if(!metaData.isCacheable()) {
    			File file = new File(metaData.getFilePath());
        		if(!file.exists()) {
        			continue;
        		}
        		if(isPdfContent(metaData.getContentType()) && file.delete()) {
        			log.trace("Htmlunit temporary file is deleted : " + file.getName() + " Content Type : " + metaData.getContentType());
        		} else {
        			file.deleteOnExit();
        		}
    		}
    	}
    	tmpFiles.clear();
	}
	
	/**
	 * 
	 * @param contentType
	 * @param fileName
	 * @return
	 */
	private boolean isPdfContent(String contentType) {
		
		if(contentType.equals("application/pdf")) {
			return true;
		} else if(contentType.equals("application/octet-stream")) {
			return true;
		} else if(contentType.equals("binary/octet-stream")) {
			return true;
		} else if(contentType.equals("application/force-download")) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * 
	 * @param in
	 * @throws IOException 
	 */
	protected synchronized void addFileMetaData(final WebResponse response, final WebRequest request) throws IOException {
		
		InputStream in = response.getContentAsStream();
		if(in instanceof UFileInputStream) {
			UFileInputStream fis = (UFileInputStream)in;
			if(tmpFiles == null) {
				tmpFiles = new ArrayList<FileMetaData>();
			}
			FileMetaData fmetaData = new FileMetaData(fis.getAbsolutePath(), response.getContentType());
			Cache cache = webClient.getCache();
			if(cache instanceof HtmlUnitCache) {
				fmetaData.setCacheable(((HtmlUnitCache)cache).htmlUnitWillCache(request, response));
			}
			tmpFiles.add(fmetaData);
		}
	}
	
	protected class FileMetaData {
		
		private String filePath;
		private String contentType;
		private boolean isCacheable;
		
		public FileMetaData(String filePath, String contentType) {
			this.setFilePath(filePath);
			this.setContentType(contentType);
		}

		public String getFilePath() {
			return filePath;
		}

		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}

		public String getContentType() {
			return contentType;
		}

		public void setContentType(String contentType) {
			this.contentType = contentType;
		}

		public boolean isCacheable() {
			return isCacheable;
		}

		public void setCacheable(boolean isCacheable) {
			this.isCacheable = isCacheable;
		}
	}
}
