package urjanet.pull.web.pdf.filter;

import urjanet.pull.web.pdf.key.ContextKey;

public class VerticalFilter extends ContextFilter {

	private ContextKey startKey;
	private double leftBuffer, rightBuffer;
	private double forceLeftCoordinate, forceRightCoordinate;
	private boolean forward;
	private double maxDistance;
	private OverlapPosition overlapTextPosition;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private VerticalFilter() {
		
	}
	
	public VerticalFilter(ContextKey startKey, double leftBuffer, double rightBuffer, boolean forward) {
		super();
		this.startKey = startKey;
		this.leftBuffer = leftBuffer;
		this.rightBuffer = rightBuffer;
		this.forward = forward;
	}
	
	public VerticalFilter(ContextKey startKey, double leftBuffer, double rightBuffer) {
		this(startKey, leftBuffer, rightBuffer, true);
	}
	
	public VerticalFilter(ContextKey startKey, double rightBuffer) {
		this(startKey, 0.0, rightBuffer, true);
	}
	
	public VerticalFilter(ContextKey startKey) {
		this(startKey, 0.0, 0.0, true);
	}

	public ContextKey getStartKey() {
		return startKey;
	}

	/**
	 * @param startKey the startKey to set
	 */
	public VerticalFilter setStartKey(ContextKey startKey) {
		this.startKey = startKey;
		return this;
	}

	public double getLeftBuffer() {
		return leftBuffer;
	}

	/**
	 * @param leftBuffer the leftBuffer to set
	 */
	public VerticalFilter setLeftBuffer(double leftBuffer) {
		this.leftBuffer = leftBuffer;
		return this;
	}
	
	public double getRightBuffer() {
		return rightBuffer;
	}

	/**
	 * @param rightBuffer the rightBuffer to set
	 */
	public VerticalFilter setRightBuffer(double rightBuffer) {
		this.rightBuffer = rightBuffer;
		return this;
	}
	
	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}

	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public VerticalFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}

	public double getMaxDistance() {
		return maxDistance;
	}

	public VerticalFilter setMaxDistance(double maxDistance) {
		this.maxDistance = maxDistance;
		return this;
	}
	
	public double getForceLeftCoordinate() {
		return forceLeftCoordinate;
	}

	public VerticalFilter setForceLeftCoordinate(double forceLeftCoordinate) {
		this.forceLeftCoordinate = forceLeftCoordinate;
		return this;
	}

	public double getForceRightCoordinate() {
		return forceRightCoordinate;
	}

	public VerticalFilter setForceRightCoordinate(double forceRightCoordinate) {
		this.forceRightCoordinate = forceRightCoordinate;
		return this;
	}

	public boolean isForward() {
		return forward;
	}

	public VerticalFilter setForward(boolean forward) {
		this.forward = forward;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public VerticalFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}

	public String toString() {
		return "Vertical Context Filter - " + ((startKey==null)?"":startKey.toString()) 
		+ ", left - " + leftBuffer + ", right - " + rightBuffer + ", forward - " + forward + ", maxDistance - " + maxDistance;
	}
}
