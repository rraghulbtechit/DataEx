package urjanet.pull.conversion.spreadsheet;

public enum CSVEscapeCharacter {

	NULL_CHARACTER('\0'),
	DEFAULT_ESCAPE_CHARACTER('\\');

    private final char escapeCharacter;
	
    private CSVEscapeCharacter(char escapeCharacter) {
		this.escapeCharacter = escapeCharacter;
	}
	
    public char getValue() {
        return escapeCharacter;
    }
	
}
