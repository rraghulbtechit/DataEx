package urjanet.pull.web.pdf.key;

import urjanet.pull.web.coordinate.CoordinateTargetDefinition.Direction;

public class RectKey extends WordContextKey {

	private double x, y, width, height;
	private Direction expandingDirection = Direction.RIGHT;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private RectKey() {
		
	}
	
	/**
	 * Constrain the current context by specifying the bottom-left coordinates and width/height of a rectangle
	 * On linux, use the tool PDFEdit to get the coordinates. Ensure your "Length units" is set to "pt : point" in 'Tools > Options'
	 * then hover over the area of your PDF - the coordinates will be shown in the bottom-right of the PDF
	 * 
	 * ie.)
	 * 
	 *    [---]  width = 5
	 * _____________
	 * |           |
	 * |           |
	 * |  xxxxx    |                =
	 * |  x   x    |                |   height = 3
	 * |  xxxxx    |  =   y = 4     =
	 * |           |  |
	 * |           |  |
	 * |           |  |
	 * |___________|  =
	 * ^
	 * (0,0)
	 * 
	 * [--]  x = 2
	 * 
	 * Assuming all characters are 1 "pt" in length, you'd specify:
	 * x = 2
	 * y = 4
	 * width = 5
	 * height = 3
	 * 
	 * **NOTE** - Constrain your context to the page you're working with first! If multiple pages are in your context,
	 * you will get really weird results - we try to process all pages at once as if they were laid on top of eachother
	 * 
	 * @param x Bottom-left x coordinate of the rectangle - measured from the bottom-left of the PDF to the right
	 * @param y Bottom-left y coordinate of the rectangle - measured from the bottom-left of the PDF upwards 
	 * @param width - width of the rectangle context, measured to the right of x,y
	 * @param height - height of the rectangle context, measured up from x,y
	 */
	public RectKey(double x, double y, double width, double height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public double getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public RectKey setX(double x) {
		this.x = x;
		return this;
	}
	
	public double getY() {
		return y;
	}
	
	/**
	 * @param y the y to set
	 */
	public RectKey setY(double y) {
		this.y = y;
		return this;
	}

	public double getWidth() {
		return width;
	}
	
	/**
	 * @param width the width to set
	 */
	public RectKey setWidth(double width) {
		this.width = width;
		return this;
	}

	public double getHeight() {
		return height;
	}

	/**
	 * @param height the height to set
	 */
	public RectKey setHeight(double height) {
		this.height = height;
		return this;
	}

	public Direction getExpandingDirection() {
		return expandingDirection;
	}

	public RectKey setExpandingDirection(Direction expandingDirection) {
		this.expandingDirection = expandingDirection;
		return this;
	}

	public String toString() {
		return "RectContextKey: x - " + x + ", y - " + y + ", width - " + width + ", height - " + height;
	}
	
}
