package urjanet.pull.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class represents an InputElement for which the value vary across collection
 * jobs and will be set dynamically via external input. If the inputName set here
 * corresponds to the name of an input value present in the RequestContext, this value
 * will be used.  Otherwise the FormElementHandler will failover to the actual 'value' specified
 * for this InputElement.  The rest of the InputElement semantics still apply.
 *
 * @author rburson
 * @see RequestContext
 * @see FormElementHandler
 */
public class VariableInputElement extends InputElement{

	private String inputName;

	public VariableInputElement() {
	}

	/**
	 * Create a new VariableInputElement with the default value for framePath (0)
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param inputName the name corresponding to the input value expected to be present in the RequestContext
	 */
	public VariableInputElement(String elementXPath, String inputName) {
		super(elementXPath, null, null);
		this.inputName = inputName;
	}

	/**
	 *
	 * Create a new VariableInputElement
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param inputName the name corresponding to the input value expected to be present in the RequestContext
	 * @param framePath the target framePath, defaults to 0
	 */
	public VariableInputElement(String elementXPath, String inputName, String framePath){
		super(elementXPath, null, null, framePath);
		this.inputName = inputName;
	}

	/**
	 * @return the name corresponding to the input value expected to be present in the RequestContext
	 */
	public String getInputName() {
		return inputName;
	}

	/**
	 * @param inputName sets the name corresponding to the input value expected to be present in the RequestContext
	 */
	public VariableInputElement setInputName(String inputName) {
		this.inputName = inputName;
		return this;
	}

	public String getValueRegEx() {
		String retval = super.getValueRegEx();
//		if (inputName.equals(InputKeys.LOGIN_ID.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_ID2.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_ID3.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_ID4.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_PASS.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_PASS_2.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_PASS_3.getValue()) ||
//			inputName.equals(InputKeys.LOGIN_PASS_4.getValue()))
//			credentialslog.error("|"+inputName+"|"+retval);
		return retval;
	}
	
	private static final Logger credentialslog = LoggerFactory.getLogger("credentials.grab.logger");
	
}
