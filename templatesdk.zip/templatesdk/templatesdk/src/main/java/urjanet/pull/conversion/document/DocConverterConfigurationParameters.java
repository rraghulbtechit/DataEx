package urjanet.pull.conversion.document;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * Configuration parameters for PDF/Image based conversions.
 * 
 * @author sriram
 *
 */
public enum DocConverterConfigurationParameters implements ConverterConfigurationParameters{

	// Main configuration parameters
	
	
	/**
	 *  Specific to an Image, whether it is an image inside a PDF container or just an image.
	 *  Possible options - IMG_CONTAINER.PDF and IMG_CONTAINER.IMAGE
	 */
	IMG_CONTAINER("imageContainer"),
	
	/**
	 * Handler type.  Possible values from PdfExtractionHandlerType.
	 */
	HANDLER_TYPE("handlerType"),
	
	/**
	 * Pdflib conversion options.  Default values are already there.  
	 * If there is some specific requirements, then only change this. 
	 */
	CONVERSION_OPTIONS("conversionOptions"),
	
	/**
	 * where to save the incoming source document/pdf file
	 */
	SOURCES_DIRECTORY("sources_directory"),
	
	/**
	 * where to save the incoming html source file
	 */
	WRITE_HTML_SOURCES_TO_DIRECTORY("write_html_sources_to_directory"),

	/**
	 * Specifically excluding fonts for each template
	 */
	EXCLUDE_FONT("excludeFont"),
	
	/**
	 * Boolean flag to enable duplicate source checking
	 * while the extraction is running.
	 */
	DUPLICATE_SOURCE_CHECK("duplicate_source_check"),
	
	/**
	 * This uses an algorithm that tries to break up words more
	 * if there's a bunch of words are coming in as one Word
	 * behavior can be seen as the engine grabbing whole lines or phrases
	 * rathern than single words
	 */
	ATTEMPT_FURTHER_WORD_BREAK_UP("attempt_further_word_break_up"),
	
	/**
	 * This code checks to see if the current page is expected to be a pdf and yet appears to be html
	 * If that is the case, it converts the page to bytes (only if the configopt is set)
	 */
	CONVERT_TO_BYTE_ARRAY("convert_to_byte_array"), 
	
	/**
	 * This option hashes the content of the source instead of the straight file
	 * this helps if the file is being encrypted or dynamically generated and a hash on the actual file will not be the same every time
	 */
	USE_CONTENT_HASH_FOR_FINGERPRINT("use_content_hash_for_fingerprint"),
	
	/**
	 * This option removes Invalid meta data tag content from the byte array
	 * 
	 */
	REMOVE_INVALID_META_DATA_CONTENT("remove_invalid_meta_data_content"),
	
	/**
	 * This will use the XmlSerializer to save the Html page instead of just printing the asXml.
	 */
	SAVE_HTML_PAGE("save_html_page"),
	
	/**
	 * The page size of an html to pdf conversion.
	 */
	HTML_TO_PDF_PAGE_SIZE("html_to_pdf_page_size"),
	
	/**
	 * This will get the pdf content and convert it to Postscript and then parse the ps file back to pdf.
	 * The reason for this conversion is to add embedded fonts to output pdf
	 * 
	 */
	REWRITE_CONTENT_WITH_EMBEDDED_FONTS("rewrite_content_with_embedded_fonts"),
	/**
	 * This will extract pdf from Zip file. We need to pass the possible filename patterns(Strings separated by '|' symbol) as a param value to this parameter. 
	 */
	EXTRACT_PDF_FROM_ZIPFILE("extract_pdf_from_zip"),
	
	/**similar to that of above except it will extract csv from zip
	 * 
	 */
	EXTRACT_CSV_FROM_ZIPFILE("extract_csv_from_zip"),
	/**
	 * <p> If the pdf has embedded fonts and it is encoded in winansi encoding format
	 * then it needs to be decoded to ascii format. </p>
	 * <p> For successful running of jobs that has the issue, we need to add both ATTEMPT_FURTHER_WORD_BREAK_UP and  ENFORCE_DECODING_ON_TYPE3_FONT_GLYPHS
	 * in config options. </p>
	 */
	ENFORCE_DECODING_ON_TYPE3_FONT_GLYPHS("enforce_decoding_on_type3_font_glyphs"),
	
	
	/**
	 * This is a straight pass-thru that will be appended to the string used to build the TET docoptlist
	 * 
	 * The most common reason to use this would be to enable custom font mappings for embedded type 3 fonts that use
	 * a static custom encoding
	 * 
	 * e.g.  "glyphmapping={ {fontname=C0EX0* codelist=C0EX0_common} }"
	 * 
	 * This approach to decoding embedded fonts is preferrable to the ENFORCE_DECODING_ON_TYPE3_FONT_GLYPHS method,
	 * and we should deprecate the other at some point.
	 *
	 */
	
	ADDITIONAL_TET_DOCOPTS("additional_tet_docopts"),
	
	/**
	 * Used to set "searchpath" and other toplevel TET config settings
	 */
	ADDITIONAL_TET_GLOBALOPTS("additional_tet_globalopts"),
	
	/**
	 * <p>
	 * This will clean up the PDF stream if anything is appended after the End of File notation is reached.
	 * 
	 * The sample PDF stream segment will be as below.
	 * 
	 * <I><B>
	 * startxref
	 * 3375349
	 * %%EOF
	 * <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	 * <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	 *</B> 
	 *</I>
	 */
	TRUNCATE_JUNK_VALUES_FROM_SOURCE_PDF("truncate_junk_values_from_source_pdf"),
	
	/**
	 * This is for pdfs where we can produce a database for glyph signatures that can be used to identify
	 * the unicode character value
	 */
	USE_TYPE3_FONT_SIGNATURE_DATABASE("use_type3_font_signature_database"),
	
	/**
	 * This for processing image bills got during navigation, after current update.
	 */
	PROCESS_IMAGE_BILLS_DAQ("process_image_bills_DAQ"),
	
	/**
	 * <p>
	 * This custom web client will have their own properties and it will replace the default web client 
	 * created by LocalFileSession while processing the Local Html Bill Page.
	 * </p>
	 */
	CUSTOM_WEB_CLIENT("custom_web_client"),
	
	/**
	 * The corrupted PDFs can be decided in the templates based on the qualifiers.
	 * Then it will be stored in a specified directory.
	 */
	STORE_CORRUPTED_PDFS_TO_DIRECTORY("store_corrupted_pdfs_to_directory"),
	
	/**
	 * Draw the PDF using TETML (tet.xml)
	 */
	DRAW_PDFS_USING_TETML_INTO_DIRECTORY("draw_pdfs_using_tetml_into_directory"),
	
	/**
	 * This is for processing image bills by recognising its language which helps to process other language image bills too.
	 */
	OCR_RECOGNITION_LANGUAGE("ocr_recongition_language"),	
	
	/**
	 * This option relax space calculation between TetWords
	 */
	
	RELAX_SPACE_CALCULATION("relax_space_calculation"),
	
	/**
	 * An option to Re-orient/rotate the the PDF pages based on the Alpha/Angle value is given in the Glyph.
	 */
	REORIENT_PDF_PAGES("reorient_pdf_pages"),
	
	/**
	 * Add unique reference ids between statements.
	 */
	ADD_UNIQUE_GROUP_REFERENCE("add_unique_group_reference"),
	
	/**
	 * This option is for DAQ job to strip the PDF file meta data before calculating the checksum value.
	 * Because, sometimes the meta data for the PDF will be unique even if the content is same. So to avoid
	 * creating a duplicate DAQ pipeline job, this will strip the meta data and then will calculate the checksum.
	 */
	STRIP_PDF_META_DATA_TO_CALCULATE_DAQ_SOURCE_CHECKSUM("strip_pdf_meta_data_to_calculate_daq_source_checksum"),
	
	/**
	 * It will strip the fontname as well inaddition to 'strip_pdf_meta_data_to_calculate_daq_source_checksum' option
	 * It should have ''strip_pdf_meta_data_to_calculate_daq_source_checksum' option.
	 */

	STRIP_PDF_FONT_TO_CALCULATE_DAQ_SOURCE_CHECKSUM("strip_pdf_font_to_calculate_daq_source_checksum");

	
	private String paramName;

	private DocConverterConfigurationParameters(String paramName) {
		this.paramName = paramName;
//		DocConversionOptions doc = new DocConversionOptions();
//		doc..
	}

	public String getParameterName() {
		return paramName;
	}

}


