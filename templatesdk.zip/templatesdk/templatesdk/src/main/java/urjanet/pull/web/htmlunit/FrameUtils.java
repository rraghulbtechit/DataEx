package urjanet.pull.web.htmlunit;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class FrameUtils {

    public static Page getFrameFromPath(String framePath, HtmlPage page) {

        Page result = page;
        String[] path = framePath.split("\\.");
        for (String node : path) {
                int index = Integer.parseInt(node);
                // if index is -1, get the last frame
                if (index != -1) {
                        index = index - 1;
                        result = ((HtmlPage) result).getFrames().get(index).getEnclosedPage();
                } else {
                        index = ((HtmlPage) result).getFrames().size()-1;
                        result = ((HtmlPage) result).getFrames().get(index).getEnclosedPage();
                }
        }
        
        return result;
	
    }
}
