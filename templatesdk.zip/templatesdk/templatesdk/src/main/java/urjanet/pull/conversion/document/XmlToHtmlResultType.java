package urjanet.pull.conversion.document;

public enum XmlToHtmlResultType {
	RESULT_LIST, RESULT_TABLE, RESULT_LINES
}