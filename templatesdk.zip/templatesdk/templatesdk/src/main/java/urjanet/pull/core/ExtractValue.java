package urjanet.pull.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import urjanet.DataTargetType;
import urjanet.pull.web.DataTargetOperationType;
import urjanet.pull.web.reference.GroupReferable;
import urjanet.pull.web.reference.ReferenceKey;

/**
 *
 * Represents an extracted value.
 *
 * @author rburson
 */
@Entity
public class ExtractValue implements Serializable, GroupReferable {

	@Version
	@Column(name = "modified")
	private java.sql.Timestamp version;

	@Id
	@GeneratedValue
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(columnDefinition="timestamp")
	private Date created = new Date();

	private String name;
	private String value;
	private String formatHint;
	
	@Transient
	private DataTargetType targetType = DataTargetType.TEXT;

	@Transient
	private DataTargetOperationType operationType;
	
	@Transient
	private List<ExtractCoordinates> extractCoordinates;
	
	@Transient
	List<ReferenceKey> references = new ArrayList<ReferenceKey>();

	public ExtractValue(){}

	public ExtractValue(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public ExtractValue(String name, String value, String formatHint) {
		this.name = name;
		this.value = value;
		this.formatHint = formatHint;
	}
	
	public ExtractValue(String name, String value, String formatHint, DataTargetOperationType operationType) {
		this.name = name;
		this.value = value;
		this.formatHint = formatHint;
		this.operationType = operationType;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the formatHint
	 */
	public String getFormatHint() {
		return formatHint;
	}

	/**
	 * @param formatHint the formatHint to set
	 */
	public void setFormatHint(String formatHint) {
		this.formatHint = formatHint;
	}
	
	public DataTargetType getTargetType() {
		return targetType;
	}
	
	public void setTargetType(DataTargetType targetType) {
		this.targetType = targetType;
	}
	
	/**
	 * 
	 * @param dataTargetOperationType
	 * @return
	 * 
	 * Sets the operation type for this Extract Value
	 */
	public ExtractValue setDatTargetOperationType(DataTargetOperationType dataTargetOperationType) {
		this.operationType = dataTargetOperationType;
		return this;
	}
	
	/**
	 * 
	 * @return
	 * 
	 * Gets the operation type of this Extract Value
	 */
	public DataTargetOperationType getDataTargetOperationType() {
		return operationType;
	}

	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder(32);
		sb.append("[name:").append(name).append(" value:").append(value).append(" formatHint:").append(formatHint).append("]");
		
		for (ReferenceKey key : references) {
			sb.append(" -> (");
			for (String hashKey : key.getIdentifier().keySet()) {
				ExtractValue value = key.getIdentifier().get(hashKey);
				sb.append(value.toString());
			}
			sb.append(")");
		}
		return sb.toString();
	}

	@Override
	public List<ReferenceKey> getReferenceKeys() {
		return references;
	}

	@Override
	public void addReference(ReferenceKey key) {
		if (!references.contains(key))
			references.add(key);
	}
	
	public List<ExtractCoordinates> getExtractCoordinates() {
		return this.extractCoordinates;
	}

	public void setExtractCoordinates(List<ExtractCoordinates> extractCoordinates) {
		this.extractCoordinates = extractCoordinates;
	}
	
}
