package urjanet.pull.enrollment.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

import urjanet.pull.enrollment.util.keys.StatusKeys;

/**
 * 
 * @author sethuramanv
 * 
 */
//singleton class
public class EnrollmentUtils {

	public static DateFormat dateFormat = new SimpleDateFormat("MM_dd_yyy");
	public static DateFormat timeFormat = new SimpleDateFormat("HH_mm_ss_SS");
	private static EnrollmentUtils enrollment = new EnrollmentUtils();
	private static final Logger log = LoggerFactory.getLogger(EnrollmentUtils.class);
	private TreeMap<String, Set<String>> toProcessUserAccount = null;
	private TreeMap<String, String> toProcessUserNamePassword = null;
	private TreeMap<String, String> accountNumberLineMap = null;
	private TreeMap<String, Set<String>> lastRanToProcessUserAccount = null;
	private TreeMap<String, String> statusMap = null;
    public static final String TAB = "\t";
    int givenCount = 0;
	public static EnrollmentUtils getInstance() {

		return enrollment;
	}

	private EnrollmentUtils() {

	}
	/** 
	 * prints a HtmlPage text content in a file with strFileName.html
	 * in given dir
	 */

	/**
	 * @param page
	 * @param strFileName
	 * @param dir
	 */
	
	public void logTextPage(HtmlPage page, String strFileName, File dir) {

		File logFile = new File(dir, strFileName + ".html");
		PrintWriter logHtml = null;
		try {
			logHtml = new PrintWriter(new FileOutputStream(logFile));
		} catch (FileNotFoundException e) {
			log.error("(!)Failed creating Html log file");
		}
		if (page != null) {
			logHtml.println(page.asText());
		}
		logHtml.close();
	}

	/**
	 * prints a HtmlPage source in a file with strFileName.html
	 * in given dir
	 */
	/**
	 * @param htmlPage
	 * @param strFileName
	 * @param dir
	 */
	public void logHtmlPage(HtmlPage htmlPage, String strFileName, File dir) {

		File logFile = new File(dir, strFileName+".html");
		PrintWriter logHtml = null;
		try {
			logHtml = new PrintWriter(new FileOutputStream(logFile));
		} catch (FileNotFoundException e) {
			log.error("(!)Failed while creating Html log file");
		}
		
		if (htmlPage != null) {
			logHtml.println(htmlPage.asXml());
		}
		logHtml.close();
	}

	/**
	 * logs the message in the given file by append or create new file/overwrite
	 * 
	 * @param file
	 * @param append
	 * @param message
	 */

	public void logToFile(File file, boolean append, String message) {

		PrintWriter pwLog = null;
		try {
			pwLog = new PrintWriter(new BufferedWriter(new FileWriter(file, append)));
			pwLog.println(message);
			pwLog.close();
		} catch (IOException e) {
			log.error("(!)Failed while writing to file "+file.getAbsolutePath());
		}

	}

	/**
	 * @param webClient
	 * @param elementInFrameXPath
	 *            -> xpath for element with in a frame
	 * @return frame as HtmlPage
	 */

	public HtmlPage getFrameAsHtmlPage(WebClient webClient, String elementInFrameXPath) {

		HtmlPage frame = null;
		for (int i = 0; i < webClient.getWebWindows().size(); i++) {
			HtmlPage page = (HtmlPage) webClient.getWebWindows().get(i).getEnclosedPage();
			if (page.getFirstByXPath(elementInFrameXPath) != null) {
				frame = page;
				break;
			}
		}
		return frame;
	}

	/**
	 * 
	 * @param brInputFile
	 * @param lastRanFile
	 * @param type
	 *            1 - only 1st line
	 *            2 - 1st line and 2nd line (credential -/ count) signed.
	 *             -> to create new user with the count
	 *            - -> to login using existing user with the count
	 *            3 - 1st line and list of accounts
	 * @param list
	 *            - lost to store last ran values
	 * @return 1 - only 1st line
	 *         2 - 1st line and account count separated by ~
	 */

	public String getLastRan(BufferedReader brInputFile, File lastRanFile, int type, List<String> list) {

		final String DELIMITER = "~";
		final String LINE_FEED = "\r\n";

		if ((type >= 0 && type <= 3) == false) {
			log.error("(!)Invalid last ran type: ");
			log.error("1 - only 1st line"+"2 - 1st line and 2nd line (credential -/ count) signed"+"3 - 1st line and list of accounts");
			return null;
		}

		BufferedReader brCredential = brInputFile;
		String details = null;
		String skip = null;
		BufferedReader brLastRan = null;
		// checking last ran log
		if (lastRanFile.isFile()) {
			
			try {
				brLastRan = new BufferedReader(new FileReader(lastRanFile));
			} catch (FileNotFoundException e) {
				log.error("(!)Given last ran file "+lastRanFile.getAbsolutePath()+" is missing");
				return null;
			}

			try {
				if ((skip = brLastRan.readLine()) == null || (skip.trim().isEmpty())) {
					log.error("(!)No content in "+lastRanFile.getAbsolutePath()+LINE_FEED+TAB+"*please add appropriate content"+LINE_FEED+TAB+"*if it is an intial run please remove the file");
					try {
						brLastRan.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					return null;
				}
			} catch (IOException e) {
				log.error("(!)Failed while reading "+lastRanFile.getAbsolutePath()+" first line");
				try {
					brLastRan.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return null;
			}
			
			if (skip.trim().equals("null")) {
				log.error("()All credentials processed"+TAB+"*if it is an intial run please remove the file "+lastRanFile.getAbsolutePath());
				try {
					brLastRan.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return null;
			}

			log.debug("Searching: "+skip);
			// traversing credential file to the processed account
			try {
				boolean isLineFound = false;
				while ((details = brCredential.readLine()) != null) {
					if (details.contains(skip)) {
						isLineFound = true;
						break;
					}
				}
				if (isLineFound == false) {
					log.error("(!)Credentail line in "+lastRanFile.getAbsolutePath()+" is not present in given credential file ");
					try {
						brLastRan.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					return null;
				}
			} catch (IOException e) {
				log.error("(!)Failed while reading credentials file in search of "+skip);
			}

			if (type == 1) {
				// only 1st line
				try {
					brLastRan.close();
				} catch (IOException e) {
					log.error("(!)Failed while closing "+lastRanFile.getAbsolutePath());
				}
			} else if (type == 2) {
				// getting credential count -/
				int userCount = 0;
				try {
					if ((skip = brLastRan.readLine()) != null) {
						userCount = Integer.valueOf(skip);
					} else {
						log.error("(!)User count is not specified in second line of "+lastRanFile.getAbsolutePath());
						return null;
					}
					brLastRan.close();
				} catch (IOException e) {
					log.error("(!)Failed while reading credential count from "+lastRanFile.getAbsolutePath());
					return null;
				}
				log.error("Credential count: "+userCount);
				details = DELIMITER+userCount;
			} else if (type == 3) {

				if (list != null) {
					log.debug("List values:");
					try {
						while ((skip = brLastRan.readLine()) != null) {
							list.add(skip);
							log.debug(skip);
						}
						brLastRan.close();
					} catch (IOException e) {
						log.error("(!)Failed while reading accounts to skip from last ran file");
						return null;
					}
				} else {
					log.error("(!)Please give a array list for string list of value from "+lastRanFile.getAbsolutePath());
				}
			}
			
		} else {
			if (type == 2) {
				log.error(lastRanFile.getAbsolutePath()+" is mandatory. Please add below details"+LINE_FEED + TAB+"1 input sheet line to start with in first line"+LINE_FEED + TAB+"2 credentials count in second line"+LINE_FEED);
				return null;
			}
			// if initial run, reads credentials 1st line
			try {
				details = brCredential.readLine();
			} catch (IOException e) {
				log.error("(!)Failed reading 1st line of credential file during initial run");
				return null;
			}
		}
		return details;
	}

	/**
	 * @param number
	 * @param length
	 * 
	 * to modify String to fixed length with Zero appending or reducing to fixed length 
	 * @return
	 */
	public String addLeadingZeros(String string , int size) {
		return StringUtils.leftPad(string, size, "0");
	}

	
	/**
	 * @param toProcessFile
	 * @param lastRanFile
	 * to create userNamePassword map and userName accountNumberMap
	 */
	public void getMyAccountDetails( File toProcessFile , File lastRanFile) {
	      getMyAccountDetails(toProcessFile, lastRanFile, null, null);	
	}
	
	/**
	 * @param toProcessFile
	 * @param lastRanFile
	 * @param accountAdition
	 */
	public void getMyAccountDetails( File toProcessFile , File lastRanFile , boolean accountAdition) {
	      getMyAccountDetails(toProcessFile, lastRanFile, accountAdition, null, null);	
	}
	
	/**
	 * @param toProcessFile
	 * @param lastRanFile
	 * @param accountNumberLength
	 * @param key
	 * to create userNamePassword map and userName accountNumberMap and modify accountNumber with fixed length to add or remove
	 */
	public void getMyAccountDetails( File toProcessFile, File lastRanFile, AccountNumberUtil type , AccountNumberManupulationUtils accountNumberManuplulation) {
	      getMyAccountDetails(toProcessFile, lastRanFile, false, type , accountNumberManuplulation);	
	}
	
	/**
	 * 
	 * @param toProcessFile
	 * @param lastRanFile
	 * @param 
	 * toProcessFile has 
	 *        0th position - accountNumber
	 *        1st position - userName
	 *        2nd position - password
	 *        above 2nd position is required for accountAddition and it varies according to template
	 * lastRanFile has 
	 *        0th position - accountNumber
	 *        1st position - userName
	 *        2nd position - password
	 *        3rd position - Status
	 * @param accountNumberLength - to limit the accountNumer length
	 * @param accountAddition is made true for accountAddition templates
	 * Creates lastRanToProcessUserAccount from lastRanFile
	 * Creates statusMap from lastRanFile
	 * Creates toProcessUserAccount from toProcessFile
	 * Creates toProcessUserNamePassword from toProcessFile
	 * Creates accountNumberLineMap from toProcessFile only for AccountAdditon , it contains accountNumber and complete Line 
	 * @return void
	 */

	public void getMyAccountDetails( File toProcessFile, File lastRanFile, boolean accountAdition, AccountNumberUtil type, AccountNumberManupulationUtils accountNumberManupulation) {
		
		toProcessUserAccount = new TreeMap<String, Set<String>>();
		toProcessUserNamePassword = new TreeMap<String, String>();
		if ( accountAdition ) {
			accountNumberLineMap = new TreeMap<String, String>();
		}
	    if ( toProcessFile.exists() ) {

			try {

				BufferedReader toProcess = new BufferedReader(new FileReader(toProcessFile));
				String line = null;
				String userName = null;
				String pass = null;
				String accountNumber = null;
				String emptyStringPattern = "^\\s*$";

				while ( ( line = toProcess.readLine() ) != null ) {
					// userName
					userName = line.split(TAB)[1];
					//password
					pass = line.split(TAB)[2];

					if ( userName != null && userName.matches(emptyStringPattern) ) {
						log.error("(!)User name is not specified for "+line);
						userName = "not_given";
					}
					//account number

					accountNumber = line.split(TAB)[0];
					if ( accountNumber != null && accountNumber.matches(emptyStringPattern) ) {
						log.error("(!)Account numbers is not specified for "+line);
						continue;
					} else if ( accountNumber.contains("-") ) {
						accountNumber = accountNumber.replaceAll("-", "");
					}
					accountNumber = accountNumber.replaceAll(" ", "");
					/*** adding new account number based on userName key in a map ***/
					
					if ( type == AccountNumberUtil.TRIM_TO_FIXEDLENGTH ) {
						accountNumber = accountNumberManupulation.trimToFixedLength(accountNumber);
					} else if ( type == AccountNumberUtil.ADD_ZEROS ) {
						accountNumber = accountNumberManupulation.addLeadingZeros(accountNumber);
					} else if ( type == AccountNumberUtil.REMOVE_LASTDIGIT ) {
						accountNumber = accountNumberManupulation.removeLastDigit(accountNumber);
					} else if ( type == AccountNumberUtil.ADD_ZEROS_AND_REMOVE_LASTDIGIT ) {
						accountNumber = accountNumberManupulation.addZerosAndRemoveLastDigit(accountNumber);
					} else if ( type == AccountNumberUtil.ADD_ZEROS_AND_TRIM_TO_FIXEDLENGTH ) {
						accountNumber = accountNumberManupulation.addZerosAndTrimToFixedLength(accountNumber);
					}
					
					if ( accountAdition ) {
						accountNumberLineMap.put(accountNumber, line);
					}
					if ( toProcessUserAccount.containsKey(userName) ) {
						// key already available
						toProcessUserAccount.get(userName).add(accountNumber);
					} else {
						// adding new key with new hashset
						Set<String> newSet = new HashSet<String>();
						newSet.add(accountNumber);
						toProcessUserAccount.put(userName, newSet);
						toProcessUserNamePassword.put(userName, pass);
					}
				}
				toProcess.close();
			} catch (FileNotFoundException e) {
				log.error("(!)File "+toProcessFile+" not found");
				System.exit(2);
			} catch (IOException e) {
				log.error("(!)Failed reading "+toProcessFile);
				System.exit(2);
			}
		}
	    
		lastRanToProcessUserAccount = new TreeMap<String, Set<String>>();
		statusMap = new TreeMap<String, String>();
		
	    if ( lastRanFile.exists() ) {
			BufferedReader brLastRan;
			try {
				brLastRan = new BufferedReader(new FileReader(lastRanFile)); 
				String skip = null;
				String lastRanUserName = null;
				String lastRanAccountNumber = null;
				String lastRanStatus = null;
				
				while( (skip = brLastRan.readLine()) != null){
					lastRanAccountNumber = skip.split(TAB)[0];
					lastRanUserName = skip.split(TAB)[1];
					lastRanStatus = skip.split(TAB)[3];
					
					if ( lastRanToProcessUserAccount.containsKey(lastRanUserName) ) {
						// key already available
						lastRanToProcessUserAccount.get(lastRanUserName).add(lastRanAccountNumber);
						statusMap.put(lastRanAccountNumber, lastRanStatus);
					} else {
						// adding new key with new hashset
						Set<String> newSet1 = new HashSet<String>();
						newSet1.add(lastRanAccountNumber);
						lastRanToProcessUserAccount.put(lastRanUserName, newSet1);
						statusMap.put(lastRanAccountNumber, lastRanStatus);
					}
				}

				brLastRan.close();
			} catch (IOException e) {
				log.error("Throws an exception in last ran file");
				e.printStackTrace();
			}
		}
	}
	
	public boolean displaySummary( File toProcessFile , File lastRanFile  ) {
		return displaySummary(toProcessFile, lastRanFile, null, null);	
	}
	
	
	/**
	 * to display the status summary once it is completed for the given file
	 * @param toProcessFile
	 * @param lastRanFile
	 * @param accountNumberLength
	 */
	public boolean displaySummary( File toProcessFile, File lastRanFile, AccountNumberUtil stringKey, AccountNumberManupulationUtils accountNumberManupulation) {
		
		getMyAccountDetails( toProcessFile, lastRanFile, stringKey , accountNumberManupulation);
		int compltedNowCount = 0;
	    int alreadyCompletedCount = 0;
	    int failedCount = 0;
		int total = 0;
		givenCount = 0;
			for( String key : toProcessUserAccount.keySet() ) {
				String userName = key;
				Iterator<String> accountNumber = toProcessUserAccount.get(userName).iterator();
				 while (accountNumber.hasNext()) {
					String processingAccountNumber = accountNumber.next();
					givenCount++;
					if ( lastRanToProcessUserAccount.containsKey(userName) ) {
						if ( lastRanToProcessUserAccount.get(userName).contains(processingAccountNumber) ) {
							if ( statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.ENROLLED_NOW.getValue()) || statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.DEENROLLED_NOW.getValue()) || statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.REMOVED_NOW.getValue()) ) {
								compltedNowCount++;
							} else if ( statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.ALREADY_ENROLLED.getValue()) || statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.ALREADY_DeENROLLED.getValue()) ) {
								alreadyCompletedCount++;
							} else if ( statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.ACCOUNT_NOT_FOUND.getValue()) || statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.FAILED.getValue()) || statusMap.get(processingAccountNumber).equalsIgnoreCase(StatusKeys.LOGIN_FAILED.getValue()) ) {
								failedCount++;
							}
						} else {
							if ( statusMap.get(lastRanToProcessUserAccount.get(userName).toArray()[0]).equalsIgnoreCase(StatusKeys.LOGIN_FAILED.getValue())) {
								logToFile(lastRanFile, true, processingAccountNumber + TAB + userName + TAB + toProcessUserNamePassword.get(userName) + TAB + StatusKeys.LOGIN_FAILED.getValue() );
								failedCount++;
							} else {
								logToFile(lastRanFile, true, processingAccountNumber + TAB + userName + TAB + toProcessUserNamePassword.get(userName) + TAB + StatusKeys.ACCOUNT_NOT_FOUND.getValue() );
								failedCount++;
							}
						}
					} else {
						logToFile(lastRanFile, true, processingAccountNumber + TAB + userName + TAB + toProcessUserNamePassword.get(userName) + TAB + StatusKeys.ACCOUNT_NOT_FOUND.getValue() );
						failedCount++;
					}
				 }
			}
			total = compltedNowCount + alreadyCompletedCount + failedCount ;
			
		log.info("Status");
		log.info("Number of Accounts Given : " + givenCount);
		log.info("Number of Accounts Completed Now : " + compltedNowCount);
		log.info("Number of Accounts Already Completed : " + alreadyCompletedCount);
		log.info("Number of Accounts Failed : " + failedCount);
		log.info("Total : " + total);
		if ( total == givenCount ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @return toProcessUserAccount
	 * toProcessUserAccount has username and accountNumber
	 */
	public TreeMap<String, Set<String>> getToProcessUserNameAccountMap() {
		return toProcessUserAccount;
	}

	/**
	 * @return toProcessUserNamePassword
	 * toProcessUserNamePassword has username and Password 
	 */
	public TreeMap<String, String> getToProcessUserNamePassword() {
		return toProcessUserNamePassword;
	}
	
	/**
	 * @return accountNumberLineMap
	 * accountNumberLineMap has account Number and Line 
	 */
	public TreeMap<String, String> getAccountNumberLineMap() {
		return accountNumberLineMap;
	}
	
	/**
	 * @return statusMap
	 * statusMap contains accountNumber and its status
	 */
	public TreeMap<String, String> getstatusMap() {
		return statusMap;
	}
	
	/**
	 * @return lastRanToProcessUserAccount
	 * lastRanToProcessUserAccount contains username and accountNumber
	 */
	public TreeMap<String, Set<String>> getLastRanToProcessUserAccount() {
		return lastRanToProcessUserAccount;
	}


	/**
	 * waits for a given time and checks for xpath to appear or disappear
	 * 
	 * @param webClient
	 * @param timeInMilliSec
	 * @param XPathList
	 * @param toAppear
	 * 				 => true - appear; false - disappear;
	 * @return if any one xpath is found - true or not found - false
	 */
	public boolean webClientWaitForXpaths(WebClient webClient, long timeInMilliSec, List<String> XPathList, boolean toAppear) {

		if ((XPathList == null) || XPathList != null && XPathList.size() == 0) {
			log.error("Check the xpath list");
			return false;
		}

		StringBuilder completeXpath = new StringBuilder();
		
		for (int i = 0; i < XPathList.size(); i++) {
			
			if (i == 0) {
				// to avoid leading '|' symbol
				completeXpath.append(XPathList.get(i));
			} else {
				completeXpath.append("|").append(XPathList.get(i));
			}
			
		}

		long waitTime = System.currentTimeMillis() + timeInMilliSec;
		
		if (toAppear) {
			// appears
			boolean notLoaded = false;
			while (waitTime > System.currentTimeMillis() && (notLoaded = ((HtmlPage) webClient.getCurrentWindow().getEnclosedPage()).getFirstByXPath(completeXpath.toString()) == null))
				;
			if (!notLoaded) {
				return true;
			} else {
				return false;
			}
		} else {
			// disappears
			boolean notPresent = false;
			while (waitTime > System.currentTimeMillis() && (notPresent = ((HtmlPage) webClient.getCurrentWindow().getEnclosedPage()).getFirstByXPath(completeXpath.toString()) != null))
				;
			if (!notPresent) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	/**
	 * This waits for given milliseconds to proceed with next line
	 * 
	 * @param timeInMilliSec
	 */
	public void waitForTime(long timeInMilliSec) {

		long waitTime = System.currentTimeMillis() + timeInMilliSec;
		while (waitTime > System.currentTimeMillis())
			;
	}

	/**
	 * waits for a given time and checks for xpath to appear or disappear
	 * 
	 * @param webDriver
	 * @param timeInMilliSec
	 * @param XPathList
	 * @param toAppear
	 *            => true - appear; false - disappear;
	 * @return if any one xpath is found - true or not found - false
	 */
	public boolean webDriverWaitForXPaths(final WebDriver webDriver, long timeInMilliSec, List<String> XPathList, boolean toAppear) {

		StringBuilder completeXpath = new StringBuilder();

		for (int i = 0; i < XPathList.size(); i++) {

			if (i == 0) {
				// to avoid leading '|' symbol
				completeXpath.append(XPathList.get(i));
			} else {
				completeXpath.append("|").append(XPathList.get(i));
			}
		}

		long waitTime = System.currentTimeMillis() + timeInMilliSec;

		if (toAppear) {
			// appears
			boolean notLoaded = false;
			while (waitTime > System.currentTimeMillis() && (notLoaded = webDriver.findElements(By.xpath(completeXpath.toString())).size() == 0))
				;
			if (!notLoaded) {
				return true;
			} else {
				return false;
			}
		} else {
			// disappears
			boolean notPresent = false;
			while (waitTime > System.currentTimeMillis() && (notPresent = webDriver.findElements(By.xpath(completeXpath.toString())).size() > 0))
				;
			if (!notPresent) {
				return true;
			} else {
				return false;
			}
		}
	}
	/**
	 * Saves the screen shot in the given file path
	 * 
	 * @param webDriver
	 * @param imageDirectory
	 * @param imageName
	 */
	 public void saveScreenShot(final WebDriver webDriver, File imageDirectory, String imageName)  {
		 
		 File tempFile = ((TakesScreenshot)webDriver).getScreenshotAs(OutputType.FILE);
		 File imageFile =  new File(imageDirectory, imageName + ".png");
		 FileUtils.deleteQuietly(imageFile);
		 try {
			FileUtils.moveFile(tempFile, imageFile);
		} catch (IOException e) {
			log.error("Failed to save screen shot for " + imageName);
		}
     }
	 
	 /**
	 * Update the account status for given Enrollment Inputs
	 * 
	 * @param currentEnrollmentInput
	 * @param status
	 */
	public void updateAccountStatus(EnrollmentInputs currentEnrollmentInput, StatusKeys status) {

		for (String accountNumber : currentEnrollmentInput.getEnrollmentAccountMetaData().keySet()) {
				if (currentEnrollmentInput.getEnrollmentAccountMetaData().get(accountNumber).getEbillStatus() == null ) {
					currentEnrollmentInput.getEnrollmentAccountMetaData().get(accountNumber).setEbillStatus(status);
				}
			}
		}
	
	/**
	 * Check the webDriver is present and close it.
	 * 
	 * @param webdriver
	 */
	public void closeWebdriver(WebDriver webdriver) {
		
		if ( webdriver != null ) {
			webdriver.quit();
		}
	}
}