package urjanet.pull.bool;

import urjanet.pull.core.PageSpec;

/**
 * This PageCondition Used to map PageCondition and PageSpec.
 * This is mainly used for SwitchConditionalPageSpec.
 *
 * @author venkadeshaperumal
 */
public class SwitchPageCondition implements PageCondition{

	private PageCondition conditionList;
	private PageSpec targetPageSpec;

	
	public SwitchPageCondition(PageCondition conditionList, PageSpec targetPageSpec) {
		this.conditionList = conditionList;
		this.setTargetPageSpec(targetPageSpec);
	}
	

	public PageCondition getConditionList() {
		return conditionList;
	}


	public SwitchPageCondition setConditionList(PageCondition conditionList) {
		this.conditionList = conditionList;
		return this;
	}


	public PageSpec getTargetPageSpec() {
		return targetPageSpec;
	}


	public SwitchPageCondition setTargetPageSpec(PageSpec targetPageSpec) {
		this.targetPageSpec = targetPageSpec;
		return this;
	}

}
