package urjanet.pull.web.intercept.sites;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import urjanet.pull.web.SessionContext;
import urjanet.pull.web.intercept.SubstitutionInterceptor;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebResponseData;

/**
 * 
 * @author xavierd
 * 
 */
public class WebResponseLoader extends SubstitutionInterceptor {
	
	protected Set<WebResponse> responseSet = new HashSet<WebResponse>();
	
	public WebResponseLoader(WebConnection webConnection, WebClient webClient, SessionContext context) throws IllegalArgumentException {
		super(webConnection, webClient, context);
	}

	@Override
	public void doSubstitutionOnRequest(WebRequest request) {
	}
	
	@Override
	public WebResponse doSubstitutionOnResponse(WebResponse response, WebRequest request) throws IOException {
		
		if (response.getContentAsString() != null) {
			//Empty the response data. Add only the meta data about the WebResponse.
			WebResponseData emptyResponseData = new WebResponseData(new byte[]{}, response.getStatusCode(), response.getStatusMessage(), response.getResponseHeaders());
			WebResponse newResponse = new WebResponse(emptyResponseData, response.getWebRequest(), response.getLoadTime());
			responseSet.add(newResponse);
		}
		return response;
	}
	
	/**
	 * 
	 * @param searchPattern
	 * @return
	 * <p> This will return the WebResponse of the current WebConnection <p>
	 */
	public WebResponse getWebResponse(String searchPattern) {
		
		for(WebResponse response:responseSet) {
			String url = response.getWebRequest().getUrl().toString();
			Pattern pattern = Pattern.compile(searchPattern);
			Matcher value = pattern.matcher(url);
			if(value.find()) {
				return response;
			} else if(url.contains(searchPattern)) {
				return response;
			}
		}
		return null;
	}
	
	/**
	 * This will clear all the elements from the response set.
	 */
	public void clearWebResponseSet() {
		responseSet.clear();
	}
}
