package urjanet.pull.web.pdf.filter;

/**
 * 
 * @author xavierd
 *
 */
public enum OverlapPosition {
	
	/**
	 * <p>
	 * Removes the Left word if the lower left x coordinate of the Left word is lesser than the lower left x coordinate of the Right word.
	 * Otherwise removes the Right word.
	 * </p> 
	 */
	LEFT_WORD,
	
	/**
	 * <p>
	 * Removes the Right word if the upper right x coordinate of the Right word is exceeds the upper right x coordinate of the Left word.
	 * Otherwise removes the Left word.
	 * </p>
	 */
	RIGHT_WORD,
	
	/**
	 * <p>
	 * Removes the Left word if the upper right y coordinate of the Left word exceeds the Upper right y coordinate of the Right word.
	 * Otherwise removes the Right word.
	 * </p>
	 */
	TOP_WORD,
	
	/**
	 * <p>
	 * Removes the Left word if the lower left y coordinate of the Left word is lower than the lower left y coordinate of the Right word.
	 * Otherwise removes the Right word.
	 * </p>
	 */
	BOTTOM_WORD,
	
	/**
	 *<p>
	 * Removes the top overlapping line. Its based on the first word's position.
	 * </p>
	 */
	TOP_LINE,
	
	/**
	 * <p>
	 * Removes the bottom overlapping line. Its based on the first word's position.
	 * </p>
	 */
	BOTTOM_LINE
}
