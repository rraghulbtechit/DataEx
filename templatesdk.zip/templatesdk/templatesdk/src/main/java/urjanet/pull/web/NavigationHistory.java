package urjanet.pull.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author rburson
 */
public class NavigationHistory {

	List<NavTarget> targets;

	public NavigationHistory(){
		this.targets = new ArrayList<NavTarget>();
	}

	private NavigationHistory(List<NavTarget> targets){
		this.targets = targets;
	}

	public List<NavTarget> getTargets() {
		return targets;
	}

	public void setTargets(List<NavTarget> targets) {
		this.targets = targets;
	}

	public NavigationHistory copy(){
		return new NavigationHistory(new ArrayList(targets));
	}

}
