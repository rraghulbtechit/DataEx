package urjanet.pull.web;

import java.util.List;

import urjanet.pull.core.PageSpec;

/**
 * The NavTarget is an abstract base class for navigation targets.
 * Represents a single point of traversal for a given type of content.
 * For example, a link or <a href/> element in a web page.
 * It also provides the 'next' instruction set to apply to the content (page) resulting from the navigation
 * via the PageSpec
 *
 * @author rburson
 */
public abstract class NavTarget {

	private GroupPolicy groupPolicy;
	private PageSpec targetPageSpec;
	private ConditionalNavigation condition;
	
	private DataTarget xPathDataTarget;
	private String waitForXPathDataTargetStringToAppear;
	private int waitForXPathTimeoutMS = 80000;
	private boolean currentPageAsEnclosedPage = false;
	
	/**
	 * Specific NavigationOptions set for this NavTarget. It remains unsafe to call any getters
	 *   on the NavigationOptions until merge() is called (see NavTargetHandler within expandTargets())
	 */
	private NavigationOptions navOptionOverrides = new NavigationOptions();
	
	
	@Deprecated
	private long waitForAsyncLoad;
	
	
	public NavTarget(){}

	/**
	 *
	 * Create a new NavTarget and specify it's membership in a Collection Subgroup via it's groupPolicy
	 *
	 * @param groupPolicy an groupPolicy for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param concurrentAccessOk can this NavTarget be safely accessed concurrently with others
	 */
	public NavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, boolean concurrentAccessOk) {
		this.groupPolicy = groupPolicy;
		this.targetPageSpec = targetPageSpec;
		navOptionOverrides.setConcurrentAccessOk(concurrentAccessOk);
	}

	/**
	 *
	 * Create a new NavTarget and specify it's membership in a Collection Subgroup via it's groupPolicy
	 *
	 * @param groupPolicy an groupPolicy for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 * @param targetPageSpec the page spec to apply to the resulting content
	 */
	public NavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec) {
		this(groupPolicy, targetPageSpec, false);
	}

	/**
	 * Create a new NavTarget
	 *
	 * @param targetPageSpec the page spec to apply to the resulting content
	 */
	public NavTarget(PageSpec targetPageSpec) {
		this(null, targetPageSpec);
	}

	
	
	public abstract boolean isDynamicTarget();
	
	public void setNavigationOptions(NavigationOptions navOptions) {
		this.navOptionOverrides = navOptions;
	}
	public NavigationOptions getNavigationOptions() {
		return navOptionOverrides;
	}

	/**
	 * Whether the NavTarget is setup to use Basic Auth. Will be nice if we could name the method <i>usingBasicAuth?</i> 
	 * @return true if using Basic Auth, false otherwise
	 */
	public boolean isUseBasicAuth() {
		return navOptionOverrides.getUseBasicAuth();
	}

	/**
	 * Whether to use Basic Auth. Though an ancient web server setting based technique that has been superseded by form based authentication or open auth, this is still in 
	 * existence in places and has to be supported.
	 * @param useCredentials 	if true use Basic Auth, not if false
	 * @return 
	 */
	public NavTarget useBasicAuth(boolean useCredentials) {
		navOptionOverrides.setUseBasicAuth(useCredentials);
		return this;
	}

	/**
	 *
	 * @return the PageSpec apply to the resulting content
	 */
	public PageSpec getTargetPageSpec() {
		return targetPageSpec;
	}

	/**
	 *
	 * @param targetPageSpec the PageSpec to apply to the resulting content
	 */
	public NavTarget setTargetPageSpec(PageSpec targetPageSpec) {
		this.targetPageSpec = targetPageSpec;
		return this;
	}

	/**
	 *
	 * @return an groupPolicy for this NavTarget
	 */
	public GroupPolicy getGroupPolicy() {
		return groupPolicy;
	}

	/**
	 * @param groupPolicy an groupPolicy for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 */
	public NavTarget setGroupPolicy(GroupPolicy groupPolicy) {
		this.groupPolicy = groupPolicy;
		return this;
	}
 	
	public boolean isClearCookies() {
		return navOptionOverrides.getClearCookies();
	}

	public NavTarget setClearCookies(boolean isClearCookies) {
		navOptionOverrides.setClearCookies(isClearCookies);
		return this;
	}

	/**
	 * @return the concurrentAccessOk
	 */
	public boolean isConcurrentAccessOk() {
		return navOptionOverrides.getConcurrentAccessOk();
	}

	/**
	 * @param concurrentAccessOk the concurrentAccessOk to set
	 */
	public NavTarget setConcurrentAccessOk(boolean concurrentAccessOk) {
		navOptionOverrides.setConcurrentAccessOk(concurrentAccessOk);
		return this;
	}

	/**
	 * @return how long to wait in millis after 'clicking', to get the returned page
	 */
	/**
	 * @return how long to wait in millis after 'clicking', to get the returned page
	 */
	@Deprecated
	public long getWaitForAsyncLoad() {
		return waitForAsyncLoad;
	}

	/**
	 * This option is useful for links that navigation (refresh, request) the page
	 * asynchronously.  Setting this option instructs the engine to 'wait' the specified
	 * amount of time for the page to refresh, before returning the target page
	 *
	 *
	 * @param waitForAsyncLoad how long to wait in millis after 'clicking', to get the returned page
	 */
	/**
	 * This option is useful for links that navigation (refresh, request) the page
	 * asynchronously.  Setting this option instructs the engine to 'wait' the specified
	 * amount of time for the page to refresh, before returning the target page
	 *
	 *
	 * @param waitForAsyncLoad how long to wait in millis after 'clicking', to get the returned page
	 */
	@Deprecated
	public void setWaitForAsyncLoad(long waitForAsyncLoad) {
		this.waitForAsyncLoad = waitForAsyncLoad;
	}

	public boolean isIgnoreSubsequentRefresh() {
		return navOptionOverrides.getIgnoreSubsequentRefresh();
	}

	public NavTarget setIgnoreRefresh(boolean ignoreSubsequentRefresh) {
		navOptionOverrides.setIgnoreSubsequentRefresh(ignoreSubsequentRefresh);
		return this;
	}
	
	public NavTarget setUseThreadRefreshHandler(boolean isUseThreadRefreshHandler) {
		navOptionOverrides.setUseThreadRefreshHandler(isUseThreadRefreshHandler);
		return this;
	}

	public NavTarget setCssEnabled(boolean isCssEnabled) {
		navOptionOverrides.setCssEnabled(isCssEnabled);
		return this;
	}
	
	public boolean isCssEnabled() {
		return navOptionOverrides.isCssEnabled();
	}
	
	public String getInterceptorName() {
		return navOptionOverrides.getInterceptorName();
	}

	public NavTarget setInterceptorName(String interceptorName) {
		navOptionOverrides.setInterceptorName(interceptorName);
		return this;
	}


	/*
	 	* This addresses some bugs in HtmlUnit
	 	* It should be used to address the following situation(s):
	 	* 1) An iframe is inserted by Javascript dynamically
	 	* This should be re-evaluated when upgrading HtmlUnit
	 */
	public boolean needsReinitialization() {
		return navOptionOverrides.getNeedsReinitialization();
	}


	/*
	 	* This addresses some bugs in HtmlUnit
	 	* It should be used to address the following situation(s):
	 	* 1) An iframe is inserted by Javascript dynamically
	 	* This should be re-evaluated when upgrading HtmlUnit
	 */
	public NavTarget setNeedsReinitialization(boolean needsReinitialization) {
		navOptionOverrides.setNeedsReinitialization(needsReinitialization);
		return this;
	}

	public boolean isRetryOnScriptException() {
		return navOptionOverrides.getRetryOnScriptException();
	}

	public NavTarget setRetryOnScriptException(boolean retryOnScriptException) {
		navOptionOverrides.setRetryOnScriptException(retryOnScriptException);
		return this;
	}

	public int getTimeout() {
		return navOptionOverrides.getTimeout();
	}

	public NavTarget setTimeout(int timeout) {
		navOptionOverrides.setTimeout(timeout);
		return this;
	}

	public AgentVersion getAgentVersion() {
		return navOptionOverrides.getAgentVersion();
	}

	public NavTarget setAgentVersion(AgentVersion agentVersion) {
		navOptionOverrides.setAgentVersion(agentVersion);
		return this;
	}

	public boolean isClearCache() {
		return navOptionOverrides.getClearCache();
	}

	public NavTarget setClearCache(boolean clearCache) {
		navOptionOverrides.setClearCache(clearCache);
		return this;
	}
	
	/**
	 * When the page needs to be refreshed by the server before
	 * performing further action on the page.
	 * 
	 * @param refreshResponseFromServer
	 */
	public NavTarget setRefreshResponseFromServer(boolean refreshResponseFromServer) {
		navOptionOverrides.setRefreshResponseFromServer(refreshResponseFromServer);
		return this;
	}

	/**
	 * When the page needs to be refreshed by the server before
	 * performing further action on the page.
	 * 
	 * @return
	 */
	public boolean refreshResponseFromServer() {
		return navOptionOverrides.getRefreshResponseFromServer();
	}

	public long getWaitForJavascript() {
		return navOptionOverrides.getWaitForJavascript();
	}

	public NavTarget setWaitForJavascript(long waitForJavascript) {
		navOptionOverrides.setWaitForJavascript(waitForJavascript);
		return this;
	}

	public long getWaitForJavascriptBefore() {
		return navOptionOverrides.getWaitForJavascriptBefore();
	}

	public NavTarget setWaitForJavascriptBefore(long waitForJavascriptBefore) {
		navOptionOverrides.setWaitForJavascriptBefore(waitForJavascriptBefore);
		return this;
	}

	public boolean isTryHandleException() {
		return navOptionOverrides.getTryHandleException();
	}

	public NavTarget setTryHandleException(boolean tryHandleException) {
		navOptionOverrides.setTryHandleException(tryHandleException);
		return this;
	}

	public boolean isForceJavaScriptProcessing() {
		return navOptionOverrides.getForceJavaScriptProcessing();
	}

	public NavTarget setForceJavaScriptProcessing(boolean forceJavaScriptProcessing) {
		navOptionOverrides.setForceJavaScriptProcessing(forceJavaScriptProcessing);
		return this;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isDisableJavaScript() {
		return navOptionOverrides.getDisableJavaScript();
	}
	
	/**
	 * 
	 * @param isDisableJavaScript
	 * 
	 * Disable the Javascript processing of the particular navigation target.
	 */
	public NavTarget setDisableJavaScript(boolean isDisableJavaScript) {
		navOptionOverrides.setDisableJavaScript(isDisableJavaScript);
		return this;
	}
	
	public int getHandleRefreshesUpToSeconds() {
		return navOptionOverrides.getHandleRefreshesUnderSeconds();
	}

	public NavTarget setHandleRefreshesUpToSeconds(int handleRefreshesUnderSeconds) {
		navOptionOverrides.setHandleRefreshesUnderSeconds(handleRefreshesUnderSeconds);
		return this;
	}

	public int getNumberOfRetries() {
		return navOptionOverrides.getNumberOfRetries();
	}

	public NavTarget setNumberOfRetries(int numberOfRetries) {
		navOptionOverrides.setNumberOfRetries(numberOfRetries);
		return this;
	}

	public boolean isRerenderAjax() {
		return navOptionOverrides.getRerenderAjax();
	}

	public NavTarget setRerenderAjax(boolean rerenderAjax) {
		navOptionOverrides.setRerenderAjax(rerenderAjax);
		return this;
	}	
	
	public DataTarget getXPathDataTarget() {
		return xPathDataTarget;
	}

	/**
	 * Set the resultant/target page xPathDataTarget value. 
	 * Useful to select the page to process based on xPath instead of window number 
	 * when multiple pages are opened during navigation. Setting the xPathDataTarget will 
	 * traverse all the pages and return the page which has the xPathDataTarget set in this NavTarget.
	 * If the xPath does not exist in any of the pages, navigation will fail.
	 * 
	 * @param xPathDataTarget
	 * 
	 */
	public NavTarget setXPathDataTarget(DataTarget xPathDataTarget) {
		this.xPathDataTarget = xPathDataTarget;
		return this;
	}

	public String getWaitForXPathDataTargetStringToAppear() {
		return waitForXPathDataTargetStringToAppear;
	}

	public NavTarget setWaitForXPathDataTargetStringToAppear(String waitForXPathDataTargetStringToAppear) {
		this.waitForXPathDataTargetStringToAppear = waitForXPathDataTargetStringToAppear;
		return this;
	}
	
	public NavTarget setWaitForXPathDataTargetStringToAppear(
			String xPath, int timeoutMS) {
		this.waitForXPathDataTargetStringToAppear = xPath;
		this.waitForXPathTimeoutMS = timeoutMS;
		return this;
	}
	
	public int getWaitForXPathTimeout() {
		return this.waitForXPathTimeoutMS;
	}

	public boolean isDisableAjaxController() {
		return navOptionOverrides.getDisableAjaxController();
	}

	public NavTarget setDisableAjaxController(boolean disableAjaxController) {
		navOptionOverrides.setDisableAjaxController(disableAjaxController);
		return this;
	}

	/**
	 * @return the waitForJavascriptOnOriginalPage
	 */
	public boolean isWaitForJavascriptOnOriginalPage() {
		return navOptionOverrides.getWaitForJavascriptOnOriginalPage();
	}

	/**
	 * @param waitForJavascriptOnOriginalPage
	 */
	public NavTarget setWaitForJavascriptOnOriginalPage(boolean waitForJavascriptOnOriginalPage) {
		navOptionOverrides.setWaitForJavascriptOnOriginalPage(waitForJavascriptOnOriginalPage);
		return this;
	}

	/**
	 * @return the disableExceptionOnScriptError
	 */
	public boolean isDisableExceptionOnScriptError() {
		return navOptionOverrides.getDisableExceptionOnScriptError();
	}

	/**
	 * @param disableExceptionOnScriptError the disableExceptionOnScriptError to set
	 */
	public NavTarget setDisableExceptionOnScriptError(boolean disableExceptionOnScriptError) {
		navOptionOverrides.setDisableExceptionOnScriptError(disableExceptionOnScriptError);
		return this;
	}

	public ConditionalNavigation getCondition() {
		return condition;
	}

	public NavTarget setCondition(ConditionalNavigation condition) {
		this.condition = condition;
		return this;
	}

	/**
	 * @return the doNotCloseAllWindows
	 */
	public boolean isDoNotCloseAllWindows() {
		return navOptionOverrides.getDoNotCloseAllWindows();
	}

	/**
	 * @param doNotCloseAllWindows the doNotCloseAllWindows to set
	 */
	public NavTarget setDoNotCloseAllWindows(boolean doNotCloseAllWindows) {
		navOptionOverrides.setDoNotCloseAllWindows(doNotCloseAllWindows);
		return this;
	}

	/**
	 * @return the allowedStatusCodes
	 */
	public List<Integer> getAllowedStatusCodes() {
		return navOptionOverrides.getAllowedStatusCodes();
	}

	/**
	 * @param allowedStatusCodes the allowedStatusCodes to set
	 */
	public NavTarget setAllowedStatusCodes(List<Integer> allowedStatusCodes) {
		navOptionOverrides.setAllowedStatusCodes(allowedStatusCodes);
		return this;
	}

	/**
	 * @return the webClientInstance
	 */
	public WebClientInstance getWebClientInstance() {
		return navOptionOverrides.getWebClientInstance();
	}

	/**
	 * @param webClientInstance the webClientInstance to set
	 */
	public NavTarget setWebClientInstance(WebClientInstance webClientInstance) {
		navOptionOverrides.setWebClientInstance(webClientInstance);
		return this;
	}

	/**
	 * @return the handleJavascriptAlerts
	 */
	public List<String> getHandleJavascriptAlerts() {
		return navOptionOverrides.getHandleJavascriptAlerts();
	}

	/**
	 * @param handleJavascriptAlerts the handleJavascriptAlerts to set
	 * <p>
	 * This will handle the javascript's alerts. 
	 * The list should be the list of messages displayed by the alerts.
	 * </p>
	 */
	public NavTarget setHandleJavascriptAlerts(List<String> handleJavascriptAlerts) {
		navOptionOverrides.setHandleJavascriptAlerts(handleJavascriptAlerts);
		return this;
	}

	/**
	 * @return the currentPageAsEnclosedPage
	 */
	public boolean isCurrentPageAsEnclosedPage() {
		return currentPageAsEnclosedPage;
	}

	/**
	 * @param currentPageAsEnclosedPage the currentPageAsEnclosedPage to set
	 * 
	 */
	public NavTarget setCurrentPageAsEnclosedPage(boolean currentPageAsEnclosedPage) {
		this.currentPageAsEnclosedPage = currentPageAsEnclosedPage;
		return this;
	}

	/**
	 * @return the doNotApplyPageHistory
	 */
	public boolean isDoNotApplyPageHistory() {
		return navOptionOverrides.getDoNotApplyPageHistory();
	}

	/**
	 * @param doNotApplyPageHistory the doNotApplyPageHistory to set
	 */
	public NavTarget setDoNotApplyPageHistory(boolean doNotApplyPageHistory) {
		navOptionOverrides.setDoNotApplyPageHistory(doNotApplyPageHistory);
		return this;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isClearHtmlUnitTemporaryFiles() {
		return navOptionOverrides.getClearHtmlUnitTemporaryFiles();
	}

	/**
	 * 
	 * @param clearHtmlUnitTemporaryFiles
	 */
	public NavTarget setClearHtmlUnitTemporaryFiles(boolean clearHtmlUnitTemporaryFiles) {
		navOptionOverrides.setClearHtmlUnitTemporaryFiles(clearHtmlUnitTemporaryFiles);
		return this;
	}
	
}
