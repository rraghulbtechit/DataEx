package urjanet.pull.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Wrapper object for configuration options.
 *
 * @author Allan Ditzel
 * @since 0.1
 */
public class ConfigOptions {
	
    private Map<String, Object> options;

    public ConfigOptions() {
        options = new HashMap<String, Object>();
    }
    
    public Object getOption(String key) {
        return options.get(key);
    }

    public ConfigOptions addOption(String key, Object value) {
        options.put(key, value);
        return this;
    }
    
    public Iterator<Map.Entry<String, Object>> iterator() {
        return options.entrySet().iterator();
    }
    
    @Override
    public String toString() {
    	return options.toString();
    }
    
}
