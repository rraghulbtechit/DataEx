package urjanet.pull.web.pdf.key;

import urjanet.pull.web.pdf.context.TargetContext;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.format.TargetFormat;

public abstract class ContextKey extends ContextFilter {

	public static enum KeyIncludeBehavior {INCLUDE_KEY, EXCLUDE_KEY};
	
	protected TargetContext searchContext;
	private KeyIncludeBehavior includeBehavior;
	
	protected TargetFormat keyFormat;
	
	protected int occuranceOfKey;
	

	public ContextKey() {
		searchContext = new TargetContext();
		includeBehavior = KeyIncludeBehavior.EXCLUDE_KEY;
		occuranceOfKey = 0;
	}
	
	public KeyIncludeBehavior getIncludeBehavior() {
		return includeBehavior;
	}
	
	public TargetContext getSearchContext() {
		return searchContext;
	}
	

	public TargetFormat getKeyFormat() {
		return keyFormat;
	}
	

	public int getOccuranceOfKey() {
		return occuranceOfKey;
	}

	public ContextKey setIncludeBehavior(KeyIncludeBehavior includeBehavior) {
		this.includeBehavior = includeBehavior;
		return this;
	}

	public ContextKey setSearchContext(TargetContext searchContext) {
		this.searchContext = searchContext;
		return this;
	}

	public ContextKey setKeyFormat(TargetFormat keyFormat) {
		this.keyFormat = keyFormat;
		return this;
	}

}
