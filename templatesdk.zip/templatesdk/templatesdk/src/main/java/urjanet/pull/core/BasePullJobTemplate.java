package urjanet.pull.core;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BasePullJobTemplate implements PullJobTemplate {
	
	private static final Logger log = LoggerFactory.getLogger(BasePullJobTemplate.class);
	
	private static HashMap<String, String> emails = new HashMap<String, String>();
	
	//TODO: author and revision stuff needs to be deprecated, it's a relic from the Unfuddle/SVN days...
	
	static {
		//Ideally, get this from Unfuddle
		emails.put("default", "shanker.janakiraman@urjanet.com");
		emails.put("jchambers", "jason.chambers@urjanet.com");
		emails.put("niranjang", "niranjan.g@droisys.com");
		emails.put("prasannab", "prasanna.b@droisys.com");
		emails.put("pugas", "puga.s@droisys.com");
		emails.put("rburson", "rob.burson@urjanet.com");
		emails.put("shankerj", "shanker.janakiraman@urjanet.com");
		emails.put("sriram", "sriram.viswanathan@urjanet.com");
		emails.put("thanigaivelm", "thanigaivel.m@droisys.com");
		emails.put("tliu", "tim.liu@urjanet.com");
		emails.put("kstewart", "kenneth.stewart@urjanet.com");
		emails.put("wowens", "willie.owens@urjanet.com");
		emails.put("jmangiameli", "josiah.mangiameli@urjanet.com");
		emails.put("xavierd", "xavier.d@droisys.com");		
	}
	
	private PageSpec pageSpec;
	private String id;
	private String email;
	private String version;
	
	protected BasePullJobTemplate() {
		
	}
	
	public BasePullJobTemplate(PageSpec pageSpec, String id, String author, String revision) {
		this.pageSpec = pageSpec;
		this.id = id;
		this.email = getAuthorEmail(author);
		this.version = getRevisionNumber(revision);
	}

	@Override
	public String getId() {
		return id;
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public BasePullJobTemplate setId(String id) {
		this.id = id;
		return this;
	}
	
	@Override
	public PageSpec getPageSpec() {
		return pageSpec;
	}

	/**
	 * 
	 * @param pageSpec
	 * @return
	 */
	public BasePullJobTemplate setPageSpec(PageSpec pageSpec) {
		this.pageSpec = pageSpec;
		return this;
	}
	
	@Override
	public String getVersion() {
		return version;
	}

	/**
	 * 
	 * @param revision
	 * @return
	 */
	public BasePullJobTemplate setVersion(String revision) {
		this.version = getRevisionNumber(revision);
		return this;
	}
	
	@Override
	public String getOwnerEmail() {
		return email;
	}
	
	/**
	 * 
	 * @param author
	 * @return
	 */
	public BasePullJobTemplate setEmail(String author) {
		this.email = getAuthorEmail(author);
		return this;
	}
	
	private String getAuthorEmail(String author) {		
		if (author == null)
			return null;
		
		try {
			return "$LastChangedBy$".equals(author) ? emails.get("default") : emails.get(author.substring("$LastChangedBy: ".length(), author.length() - " $".length()));
		} catch (Exception e) {
			log.trace("Failed to parse [" + author + "] for a username.. using the default (" + emails.get("default") + ")", e);
			return emails.get("default");
		}
	}
	
	private String getRevisionNumber(String revision) {
		if (revision == null)
			return null;
		
		try {
			return "$LastChangedRevision$".equals(revision) ? "1.0" : revision.substring("$LastChangedRevision: ".length(), revision.length() - " $".length());
		} catch (Exception e) {
			log.trace("Failed to parse [" + revision + "] for revision.. using the default (1.0)", e);
			return "1.0";
		}
	}
}
