package urjanet.pull.web.pdf.key;

public class IndexedRegExKey extends WordContextKey {

	private String key;
	private boolean inverseSearchDirection;
	private RegExSearchContext regexSearchContext = RegExSearchContext.LINE_BY_LINE;

	public enum RegExSearchContext { LINE_BY_LINE, WHOLE_CONTEXT }
    
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private IndexedRegExKey() {	
	}
	
	public IndexedRegExKey(String key, int n) {
		super();
		this.key = key;
		this.occuranceOfKey = n;
	}
    
	public IndexedRegExKey(String key) {
		this(key, 0);
	}

	public IndexedRegExKey(String key, int n, RegExSearchContext searchContext) {
		this(key, n);
		this.regexSearchContext = searchContext;
	}

	public IndexedRegExKey(String key, RegExSearchContext searchContext) {
		this(key, 0, searchContext);
	}

	public boolean getInverseSearchDirection() {
		return inverseSearchDirection;
	}

	/**
	 *
	 * The regex search operation will happen from the end.
	 *
	 * @param inverseSearchDirection
	 * @return
	 *
	 */
	public IndexedRegExKey setInverseSearchDirection(boolean inverseSearchDirection) {
		this.inverseSearchDirection = inverseSearchDirection;
		return this;
	}

	public String toString() {
		return "IndexedRegExContextKey: key - " + key;
	}

	public String getKey() {
		return key;
	}
    
	public IndexedRegExKey setKey(String key) {
		this.key = key;
		return this;
	}
    
	public IndexedRegExKey setOccuranceOfKey(int occuranceOfKey) {
		this.occuranceOfKey = occuranceOfKey;
		return this;
	}
	
	public RegExSearchContext getRegExSearchContext() {
		return regexSearchContext;
	}

	public IndexedRegExKey setRegexSearchContext(RegExSearchContext regexSearchContext) {
		this.regexSearchContext = regexSearchContext;
		return this;
	}
}
