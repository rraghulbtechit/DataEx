package urjanet.pull.web.cache;

import java.util.regex.Pattern;

import urjanet.pull.web.cache.MagicCache.CacheDrawer;

import com.gargoylesoftware.htmlunit.StringWebResponse;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;

/**
 *
 * @author rburson
 */
public class NoRequestCacheRule extends CacheRule{

	public NoRequestCacheRule(Pattern urlMatch) {
		super(urlMatch);
	}

	@Override
	public WebResponse tryToCache(WebRequest settings, WebResponse response,
			CacheDrawer cacheDrawer) {
		if(getUrlMatch().matcher(settings.getUrl().toString()).find()){
			return new StringWebResponse("",  settings.getUrl());
		}

		return null;

	}

	@Override
	public WebResponse tryToGet(WebRequest settings, CacheDrawer cacheDrawer) {
		if(getUrlMatch().matcher(settings.getUrl().toString()).find()){
			return new StringWebResponse("", settings.getUrl());
		}

		return null;

	}

}
