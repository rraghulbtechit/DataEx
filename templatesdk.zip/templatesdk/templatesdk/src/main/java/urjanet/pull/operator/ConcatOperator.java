package urjanet.pull.operator;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author rburson
 */
public class ConcatOperator implements ExtractOperator {

	private List<? extends ExtractOperator> operators;
	private String delimiter;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private ConcatOperator() {
		
	}
	
	public ConcatOperator(ExtractOperator ... operators){
		this.operators = Arrays.asList(operators);
	}

	public ConcatOperator(String delimiter, ExtractOperator ... operators){
		this.operators = Arrays.asList(operators);
		this.delimiter = delimiter;
	}

	public ConcatOperator(List<? extends ExtractOperator> operators) {
		this.operators = operators;
	}

	public ConcatOperator(String delimiter, List<? extends ExtractOperator> operators) {
		this.operators = operators;
		this.delimiter = delimiter;
	}

	public List<? extends ExtractOperator> getOperators() {
		return operators;
	}

	public ConcatOperator setOperators(List<? extends ExtractOperator> operators) {
		this.operators = operators;
		return this;
	}
	
	public String getDelimiter() {
		return delimiter;
	}

	public ConcatOperator setDelimiter(String delimiter) {
		this.delimiter = delimiter;
		return this;
	}
	
	@Override
	public ExtractOperand apply(ExtractOperand input) throws OperatorException{

		StringBuilder result =  new StringBuilder(50);
		for(ExtractOperator operator : operators){
			if(this.delimiter != null && result.length() > 0) result.append(this.delimiter);
			result.append(operator.apply(input).getTextValue());
		}

		return new ExtractOperand(result.toString());

	}
	
}
