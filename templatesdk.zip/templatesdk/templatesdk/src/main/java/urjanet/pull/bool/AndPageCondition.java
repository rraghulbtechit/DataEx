package urjanet.pull.bool;

/**
 *
 * @author rburson
 */
public class AndPageCondition implements PageCondition{

	private PageCondition c1, c2;

	//This constructor will be called from Hit to create an instance.
	@SuppressWarnings("unused")
	private AndPageCondition() {
		
	}
	
	public AndPageCondition(PageCondition c1, PageCondition c2) {
		this.c1 = c1;
		this.c2 = c2;
	}

	public PageCondition getC1() {
		return c1;
	}
	
	public AndPageCondition setC1(PageCondition c1) {
		this.c1 = c1;
		return this;
	}

	public PageCondition getC2() {
		return c2;
	}

	public AndPageCondition setC2(PageCondition c2) {
		this.c2 = c2;
		return this;
	}
	
}
