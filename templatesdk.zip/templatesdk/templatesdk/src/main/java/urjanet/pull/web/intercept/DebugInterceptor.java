package urjanet.pull.web.intercept;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.LoggerFactory;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.util.Cookie;

import urjanet.pull.web.SessionContext;

/**
 *
 * @author rburson
 */
public class DebugInterceptor extends Interceptor{

	private static final Logger log = LoggerFactory.getLogger(DebugInterceptor.class);

	public DebugInterceptor(WebConnection webConnection, WebClient webClient, SessionContext context){
		super(webConnection, webClient, context);
	}

	@Override
	public WebResponse getResponse(final WebRequest webRequestSettings) throws IOException {

		log.debug("---------------------- Request is ");
		log.debug(webRequestSettings.toString());
		log.debug("Request Body: ");
		log.debug(webRequestSettings.getRequestBody());
		log.debug(("Cookies: "));
		for(Cookie c : webClient.getCookieManager().getCookies()/*.getCookies(webRequestSettings.getUrl())*/){
			log.debug(c.toString());
		}
		log.debug("-----------------------End Request\n");

		WebResponse response = super.getResponse(webRequestSettings);

		log.debug("---------------------- Response for " + webRequestSettings.getUrl() + " " + webRequestSettings.getHttpMethod().toString());

		//summary output
		int contentLength = response.getContentAsString().length();
		int trimlength = contentLength < 100 ? contentLength : 100;
		log.debug(response.getContentAsString().substring(0, trimlength));
		log.debug(response.getContentAsString().substring(contentLength - trimlength));

		//All output
		//log.debug(response.getContentAsString());

		log.debug("----------------------- End Response");


		return response;

	}

}
