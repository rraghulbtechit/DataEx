package urjanet.pull.enrollment.util;

public interface AccountEnrollment {
	public boolean accountEnrollment ( EnrollmentInputs enrollmentInput );
}
