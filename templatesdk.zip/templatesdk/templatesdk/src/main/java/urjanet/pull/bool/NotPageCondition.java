package urjanet.pull.bool;

/**
 * 
 * @author xavierd
 *
 */
public class NotPageCondition implements PageCondition {

	private PageCondition p1;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private NotPageCondition() {
		
	}
	
	public NotPageCondition(PageCondition p1) {
		this.p1 = p1;
	}

	public PageCondition getP1() {
		return p1;
	}
	
	public NotPageCondition setP1(PageCondition p1) {
		this.p1 = p1;
		return this;
	}
	
}