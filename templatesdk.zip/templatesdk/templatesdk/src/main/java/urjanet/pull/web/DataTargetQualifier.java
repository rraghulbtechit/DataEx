package urjanet.pull.web;

/**
 *
 * @author rburson
 */
public interface DataTargetQualifier {
	
	//public boolean targetIsValid(Content content, SessionContext context);
	
}
