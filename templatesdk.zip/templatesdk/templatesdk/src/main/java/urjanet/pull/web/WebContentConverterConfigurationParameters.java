package urjanet.pull.web;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * Configuration parameters for WebContentConverter
 * 
 * @author sriram
 *
 */
public enum WebContentConverterConfigurationParameters implements ConverterConfigurationParameters {

	/**
	 *  Whether the document is inside an frame or not.
	 *  If yes, then specify the path.  For eg. "2.1" for second window and first frame.
	 *  
	 */
	FRAME_PATH("framePath");

	private String paramName;
	
	private WebContentConverterConfigurationParameters(String paramName) {
		this.paramName = paramName;
	}
	
	/**
	 * Get the parameter name.
	 */
	@Override
	public String getParameterName() {
		return paramName;
	}
}


