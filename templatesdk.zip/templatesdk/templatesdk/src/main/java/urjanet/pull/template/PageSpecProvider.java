package urjanet.pull.template;

import urjanet.pull.core.PageSpec;


/**
 *
 * @author rburson
 */
public interface PageSpecProvider {
    public PageSpec getPageSpec();
}
