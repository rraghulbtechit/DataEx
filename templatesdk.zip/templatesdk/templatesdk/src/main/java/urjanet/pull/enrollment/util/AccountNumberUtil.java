package urjanet.pull.enrollment.util;

public enum AccountNumberUtil {
			
	TRIM_TO_FIXEDLENGTH,
	ADD_ZEROS,
	ADD_ZEROS_AND_TRIM_TO_FIXEDLENGTH,
	ADD_ZEROS_AND_REMOVE_LASTDIGIT,
	REMOVE_LASTDIGIT;

}
