package urjanet.pull.bool;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.web.DataTarget;

/**
 * 
 * @author xavierd
 * 
 *  The operator will be evaluated against the target1's extracted value and the target2's extracted value.
 *  The operand for the operator is two data target's values.
 *  By default the StringQualifier will take the Equals operation if there is no explicit operators are mentioned.
 * 	NOTE: The type of target1 and target2 should be identical.
 *
 */
public class NumberQualifier extends ComparisonDataTargetQualifier {

	private static final Logger log = LoggerFactory.getLogger(NumberQualifier.class);
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private NumberQualifier() {

	}
	
	public NumberQualifier(ComparisonOperator operator, DataTarget target1, DataTarget target2) {
		super(operator, target1, target2);
	}
	
	public NumberQualifier(DataTarget target1, DataTarget target2) {
		this(ComparisonOperator.EQUAL_TO, target1, target2);
	}

	@Override
	public int compareTo(String value1, String value2) {
		
		try {
			return new BigDecimal(value1).compareTo(new BigDecimal(value2));
		} catch (Exception e) {
			log.error("Unable to parse the Number " + e.getMessage());
		}
		return -2;
	}
}
