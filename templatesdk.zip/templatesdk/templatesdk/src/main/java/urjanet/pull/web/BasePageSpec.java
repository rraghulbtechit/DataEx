package urjanet.pull.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import urjanet.pull.bool.TrackingNavigationEventPageCondition;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.TargetGroup;

/**
 *
 * A basic PageSpec implementation.
 *
 * @author rburson
 */
public class BasePageSpec implements PageSpec {

	private List<? extends TargetGroup> targetGroups;
	private ContentType expectedContentType;
	private ConfigOptions configOptions;
	private List<TrackingNavigationEventPageCondition> trackingConditions;
	private String specLabel;
	
	public BasePageSpec(){}

	/**
	 * Create a BasicPageSpec
	 *
	 * @param navTargetSpec the NavTargets to traverse on this page
	 * @param dataTargetSpec the DataTargets to extract on this page
	 * @param expectedContentType the type of content expected by this PageSpec
	 */
	public BasePageSpec(ContentType expectedContentType, TargetGroup ... targetGroups) {

		this.targetGroups = Arrays.asList(targetGroups);
		this.expectedContentType = expectedContentType;
	}

	/**
	 * Create a BasicPageSpec
	 *
	 * @param navTargetSpec the NavTargets to traverse on this page
	 * @param dataTargetSpec the DataTargets to extract on this page
	 * @param expectedContentType the type of content expected by this PageSpec
	 * @param trackingConditions the page conditions to track the navigation events like WebSite Down, Bad Login etc.,
	 */
	public BasePageSpec(ContentType expectedContentType, List<TrackingNavigationEventPageCondition> trackingConditions, TargetGroup ... targetGroups) {
		this(expectedContentType, targetGroups);
		this.trackingConditions = trackingConditions;
	}
	
	/**
	 * Create a BasicPageSpec
	 *
	 * @param navTargetSpec the NavTargets to traverse on this page
	 * @param dataTargetSpec the DataTargets to extract on this page
	 * @param expectedContentType the type of content expected by this PageSpec
	 * @param configOptions Configuration options for the conversion process
	 */
	public BasePageSpec(ContentType expectedContentType, ConfigOptions configOptions, TargetGroup ... targetGroups) {

		this(expectedContentType, targetGroups);
		this.configOptions = configOptions;
	}
	
	/**
	 * Create a BasicPageSpec
	 *
	 * @param navTargetSpec the NavTargets to traverse on this page
	 * @param dataTargetSpec the DataTargets to extract on this page
	 * @param expectedContentType the type of content expected by this PageSpec
	 * @param configOptions Configuration options for the conversion process
	 * @param trackingConditions the page conditions to track the navigation events like WebSite Down, Bad Login etc.,
	 */
	public BasePageSpec(ContentType expectedContentType, ConfigOptions configOptions, 
			List<TrackingNavigationEventPageCondition> trackingConditions, TargetGroup ... targetGroups) {
		this(expectedContentType, configOptions, targetGroups);
		this.trackingConditions = trackingConditions;
	}
	
	/**
	 * Create a BasicPageSpec with a default ContentType of HTML
	 *
	 * @param navTargetSpec the NavTargets to traverse on this page
	 * @param dataTargetSpec the DataTargets to extract on this page
	 */
	public BasePageSpec(TargetGroup ... targetGroups) {
		this(ContentType.HTML, targetGroups);
	}
	
	/**
	 * 
	 * @param trackingConditions the page conditions to track the navigation events like WebSite Down, Bad Login etc.,
	 * @param targetGroups
	 */
	public BasePageSpec(List<TrackingNavigationEventPageCondition> trackingConditions, TargetGroup ... targetGroups) {
		this(targetGroups);
		this.trackingConditions = trackingConditions;
	}

	@Override
	public ContentType getExpectedContentType() {
		return expectedContentType;
	}

	@Override
	public void setExpectedContentType(ContentType expectedContentType) {
		this.expectedContentType = expectedContentType;
	}

	@Override
	public ConfigOptions getConfigOptions() {
		return configOptions;
	}

	@Override
	public void setConfigOptions(ConfigOptions configOptions) {
		this.configOptions = configOptions;
	}

	public List<? extends TargetGroup> getTargetGroups() {
		return targetGroups;
	}

	public BasePageSpec setTargetGroups(List<? extends TargetGroup> targetGroups) {
		this.targetGroups = targetGroups;
		return this;
	}
	
	@Override
	public List<TargetGroup> getAllTargetGroups() {
		List<TargetGroup> allGroups = new ArrayList<TargetGroup>();
		allGroups.addAll(this.targetGroups);
		return allGroups;
	}

	/**
	 * 
	 * @return the Tracking Navigation Event Page Conditions
	 */
	public List<TrackingNavigationEventPageCondition> getTrackingConditions() {
		return trackingConditions;
	}

	/**
	 * Sets tracking conditions to track the navigation events like Website down, Bill not available, Bad Login etc.,
	 * 
	 * @param trackingConditions
	 * @return
	 */
	public BasePageSpec setTrackingConditions(List<TrackingNavigationEventPageCondition> trackingConditions) {
		this.trackingConditions = trackingConditions;
		return this;
	}
	
	/**
	 * @return the rootSpecLabel
	 */
	public String getSpecLabel() {
		return specLabel;
	}

	/**
	 * @param specLabel the specLabel to set
	 */
	public BasePageSpec setSpecLabel(String specLabel) {
		this.specLabel = specLabel;
		return this;
	}
	
}
