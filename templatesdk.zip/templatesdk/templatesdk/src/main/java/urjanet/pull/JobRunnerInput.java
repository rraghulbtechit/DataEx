package urjanet.pull;

public interface JobRunnerInput {

}
