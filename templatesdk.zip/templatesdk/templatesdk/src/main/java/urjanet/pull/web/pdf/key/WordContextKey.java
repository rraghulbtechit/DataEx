package urjanet.pull.web.pdf.key;


public abstract class WordContextKey extends ContextKey {
	
}
