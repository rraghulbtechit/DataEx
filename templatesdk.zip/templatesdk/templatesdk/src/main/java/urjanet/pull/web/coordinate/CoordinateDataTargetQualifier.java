package urjanet.pull.web.coordinate;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;

public class CoordinateDataTargetQualifier implements DataTargetQualifier{

	private DataTarget qualifyingTarget;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private CoordinateDataTargetQualifier() {
		
	}

	public CoordinateDataTargetQualifier(DataTarget qualifyingTarget) {
		this.qualifyingTarget = qualifyingTarget;
	}

	public DataTarget getQualifyingTarget() {
		return qualifyingTarget;
	}
	
	/**
	 * @param qualifyingTarget the qualifyingTarget to set
	 */
	public CoordinateDataTargetQualifier setQualifyingTarget(DataTarget qualifyingTarget) {
		this.qualifyingTarget = qualifyingTarget;
		return this;
	}
	
}
