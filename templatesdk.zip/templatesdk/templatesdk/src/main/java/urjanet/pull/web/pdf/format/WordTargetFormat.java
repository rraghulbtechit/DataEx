package urjanet.pull.web.pdf.format;

public abstract class WordTargetFormat extends TargetFormat {

}
