package urjanet.pull.web.pdf.format;

public class LineTargetFormat extends WordTargetFormat {


}
