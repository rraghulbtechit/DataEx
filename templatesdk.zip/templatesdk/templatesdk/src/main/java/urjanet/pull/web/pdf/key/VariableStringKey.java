package urjanet.pull.web.pdf.key;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.pdf.filter.ContextFilter;

public class VariableStringKey extends StringKey {
	
	private List<? extends ContextFilter> filters;
	private ExtractOperator operator;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private VariableStringKey() {
		
	}
	
	public VariableStringKey(ContextFilter ... filters) {
		super(null);
		this.filters = Arrays.asList(filters);
	}

	public List<? extends ContextFilter> getFilters() {
		return filters;
	}

	/**
	 * @param filters the filters to set
	 */
	public VariableStringKey setFilters(List<? extends ContextFilter> filters) {
		this.filters = filters;
		return this;
	}

	public ExtractOperator getOperator() {
		return operator;
	}

	public VariableStringKey setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

}
