package urjanet.pull.operator;

import java.util.List;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import urjanet.pull.PullException;

import com.gargoylesoftware.htmlunit.html.DomNode;

/**
 *
 * @author rburson
 * This Operator allows for the 'script' variable to contain a javascript that has access to the 'current' DomNode.
 * The DomNode is either the targeted node if an xpath was specified, or it represents the entire document.
 *
 * The single variable available to the script is named 'document'. Depending on what is 'targeted' by the 'owning' DataTarget,
 * it is allowed to be of type 'java.lang.String' or of type com.gargoylesoftware.htmlunit.html.DomNode which is
 * also a org.w3c.dom.Node, so all of the methods of both types are available for use.
 *
 * @see http://htmlunit.sourceforge.net/apidocs/index.html
 *
 * If you have specified a text target with an xpath, the document will be of type TextNode
 * To get the String value of a 'TextNode', use node.getData()
 *
 *
 * The script MUST return either a DomNode or a String value.
 */
public class JavaScriptOperator implements ExtractOperator{

	private String script;
	private static final ScriptEngineManager sem = new ScriptEngineManager();

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private JavaScriptOperator() {
		
	}
	
	public JavaScriptOperator(String script) {
		this.script = script;
	}

	public String getScript() {
		return script;
	}

	public JavaScriptOperator setScript(String script) {
		this.script = script;
		return this;
	}
	
	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {
		return getScriptResult(operand);
	}

	private ExtractOperand getScriptResult(ExtractOperand operand) throws OperatorException{

		Object arg = operand.getResult() == null ? operand.getStringResult() : operand.getResult();

		Object result = executeScript(this.script, arg);
		if (result != null) {
			if (!(result instanceof DomNode) && !(result instanceof String) && !(result instanceof List<?>)) {
				throw new OperatorException("JavaScriptOperator must return either a DomNode or a String type or a 'List' of DomNode's!!!");
			}
		} else {
			throw new OperatorException("Result of JavaScriptOperator is null");
		}
		if(result instanceof String){
			return new ExtractOperand((String)result);
		} else if (result instanceof DomNode) {
			return new ExtractOperand((DomNode)result);
		} else {
			try {
				return new ExtractOperand((List<DomNode>)result);
			} catch (PullException e) {
				System.err.println(e.getMessage());
			}
		}
		
		return operand;
	}

	private Object executeScript(String script, Object node) throws OperatorException {

		try {
			ScriptEngine engine = sem.getEngineByName("JavaScript");
			engine.eval("function extract(document){ " + script + " }");
			Invocable invocableEngine = (Invocable) engine;
			return invocableEngine.invokeFunction("extract", node);

		} catch (Exception e) {
			throw new OperatorException("Javascript execution failed for script operator", e);
		}
	}


}
