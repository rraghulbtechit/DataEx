package urjanet.pull.web;

import java.util.List;

import urjanet.pull.core.Extract;
import urjanet.pull.core.PageSpec;
import urjanet.pull.operator.ExtractOperator;

/**
 * This class represents an 'actionable' navigation target on a page.
 * It should be used to specify any type of page navigation included in NavAction.
 * framePath defaults to 0, meaning there are no frames (top-level page)
 * returnWindowNumber defaults to 1, meaning the primary window
 * The provided constructors handle common cases but there are many options that may be set
 * prior to navigation
 *
 * @author rburson
 * @see NavAction
 */
public class ClickableNavTarget extends NavTarget {

	private String xpathTarget;
	private List<? extends InputElement> inputElements;
	/* Frame is 0 by default meaning no frame.
	 * First frame would be specified by 1, second by 2, etc.
	 * A valid frame path is hierarchical and may be separated by a '.'
	 * i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 */
	private String framePath;
	/* Return window is assumed to be 1 if not specified This means 'the same' window.
	 * First popup window would be 2, second popup window would be 3, etc.
	 */
	private int returnWindowNumber = 1;
	/**
	 * TopLevelWindow to close after the current navigation step.
	 * 1-indexed like returnWindowNumber, but refers to the TopLevelWindow
	 * index, NOT the 'Window' index, which includes frames and such... 
	 * 
	 * Use this option to close open windows you no longer need
	 * when using in conjunction with a single WebClient and doNotCloseAllWindows.
	 * It is only safe to close a window if there are no more
	 * navigation steps to perform on that window. (otherwise
	 * you will be navigating on a window/page that is no
	 * longer associated with the current WebClient and 
	 * JavaScript engine).
	 * 
	 * A number <= 0 means don't close any window
	 */
	private int closeReturnWindowNumber = -1;
	
	private NavAction action;
	
	/* If return window for the pdf page is variable, this parameter is 
	 * used to find the appropriate page (cf. ArizonaPublicService)
	 */
	private boolean searchForBinaryStream;
	
	/**
	 * This is a matching regex pattern of the response URL.
	 */
	private String searchKeyForResponseUrl;
	
	/**
	 * If the response set in WebResponseLoader persist duplicate elements then this will helps to clear the duplicate elements.
	 */
	private boolean isClearWebResponseSet;
	
	/**
	 * If you are pointing the xPath at an attribute which calls a url, this will act on the attribute value
	 * before the url is executed
	 */
	private ExtractOperator urlOperator;
	
	private boolean variableSubstitution;
	
	protected DataTarget metaDataTargets;
	
	/**
	 * NOTE - currently only honored by BifrostEngine
	 * wbo 4/13/16
	 */
	private String waitForXPathBeforeClick;

	/**
	 * NOTE - currently only honored by BifrostEngine
	 * wbo 4/13/16
	 */
	private boolean notAlwaysPresent;
	
	@Deprecated
	private Extract resolvedMetaData;

	public ClickableNavTarget(){}

	/**
	 * Create a new NavTarget and specify it's membership in a Collection Subgroup via it's id
	 *
	 * @param id an id for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 * @param inputElements the input elements to populate on the page before navigation
	 * @param concurrentAccessOk can this NavTarget be safely accessed concurrently with others
	 */
	public ClickableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements, boolean concurrentAccessOk) {
		super(groupPolicy, targetPageSpec, concurrentAccessOk);
		this.xpathTarget = xpathTarget;
		this.inputElements = inputElements;
		this.action = NavAction.MOUSE_CLICK;
	}

	/**
	 * Create a new NavTarget and specify it's membership in a Collection Subgroup via it's id
	 *
	 * @param id an id for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 */
	public ClickableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget) {
		super(groupPolicy, targetPageSpec);
		this.xpathTarget = xpathTarget;
		this.action = NavAction.MOUSE_CLICK;
	}

	/**
	 * Create a new NavTarget
	 *
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 * @param inputElements the input elements to populate on the page before navigation
	 */
	public ClickableNavTarget(PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements) {
		super(targetPageSpec);
		this.xpathTarget = xpathTarget;
		this.inputElements = inputElements;
		this.action = NavAction.MOUSE_CLICK;
	}

	/**
	 * Create a new NavTarget and specify it's membership in a Collection Subgroup via it's id
	 *
	 * @param id an id for this NavTarget which puts the resulting content into it's own 'Collection Subgroup'
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 * @param concurrentAccessOk can this NavTarget be safely accessed concurrently with others
	 */
	public ClickableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget, boolean concurrentAccessOk) {
		this(groupPolicy, targetPageSpec, xpathTarget, null, concurrentAccessOk);
	}

	/**
	 * Create a new NavTarget
	 *
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 * @param inputElements the input elements to populate on the page before navigation
	 * @param concurrentAccessOk can this NavTarget be safely accessed concurrently with others
	 */
	public ClickableNavTarget(PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements, boolean concurrentAccessOk) {
		this(null, targetPageSpec, xpathTarget, inputElements, concurrentAccessOk);
	}

	/**
	 * Create a new NavTarget
	 *
	 * @param targetPageSpec the page spec to apply to the resulting content
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 */
	public ClickableNavTarget(PageSpec targetPageSpec, String xpathTarget) {
		this(null, targetPageSpec, xpathTarget);
	}
	
	public ClickableNavTarget setMetaDataTargets(DataTarget metaDataTargets) {
		this.metaDataTargets = metaDataTargets;
		return this;
	}
	
	public DataTarget getMetaDataTargets() {
		return this.metaDataTargets;
	}
	
	/**
	 *
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 */
	public String getXpathTarget() {
		return xpathTarget;
	}

	/**
	 *
	 * @param xpathTarget the xpath to the target element to be acted upon, if xpathTarget is null, the same (existing) page is returned
	 */
	public ClickableNavTarget setXpathTarget(String xpathTarget) {
		this.xpathTarget = xpathTarget;
		return this;
	}

	/**
	 *
	 * @return the input elements to populate on the page before navigation
	 */
	public List<? extends InputElement> getInputElements() {
		return inputElements;
	}

	/**
	 *
	 * @param inputElements the input elements to populate on the page before navigation
	 */
	public ClickableNavTarget setInputElements(List<? extends InputElement> inputElements) {
		this.inputElements = inputElements;
		return this;
	}

	/**  framePath is 0 by default meaning no frame.
	 *  First frame would be specified by 1, second by 2, etc.
	 *  A valid frame path is hierarchical and may be separated by a '.'
	 *  i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 *
	 * @return the target frame number
	 */
	public String getFramePath() {
		return framePath;
	}

	/**  framePath is 0 by default meaning no frame.
	 *  First frame would be specified by 1, second by 2, etc.
	 *  A valid frame path is hierarchical and may be separated by a '.'
	 *  i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 *
	 * @param framePath the target frame number
	 */
	public ClickableNavTarget setFramePath(String framePath) {
		this.framePath = framePath;
		return this;
	}

	/**
	 * @return the navigation action for this NavTarget
	 */
	public NavAction getAction() {
		return action;
	}

	/**
	 *
	 * @param action the navigation action for this NavTarget
	 */
	public ClickableNavTarget setAction(NavAction action) {
		this.action = action;
		return this;
	}

	/** Return window is assumed to be 1 if not specified This means 'the same' window.
	 * First popup window would be 2, second popup window would be 3, etc.
	 *
	 * @return the target window number
	 */
	public int getReturnWindowNumber() {
		return returnWindowNumber;
	}

	/** Return window is assumed to be 1 if not specified This means 'the same' window.
	 * First popup window would be 2, second popup window would be 3, etc.
	 *
	 * @param returnWindowNumber the target window number
	 */
	public ClickableNavTarget setReturnWindowNumber(int returnWindowNumber) {
		this.returnWindowNumber = returnWindowNumber;
		return this;
	}

	public Boolean isCloseReturnWindow() {
		return closeReturnWindowNumber > 0;
	}
	/**
	 * Set to close the 1-indexed TopLevelWindow, closeReturnWindowNumber, after
	 * we've run the current navigation step and kicked off any extraction 
	 * requests for the current page.
	 * This is only safe is no more navigation is to be performed
	 * on the window that we're closing
	 * @param closeReturnWindowNumber
	 */
	public ClickableNavTarget setCloseReturnWindowNumber(int closeReturnWindowNumber) {
		this.closeReturnWindowNumber = closeReturnWindowNumber;
		return this;
	}
	
	public int getCloseReturnWindowNumber() {
		return this.closeReturnWindowNumber;
	}
	
	public ExtractOperator getUrlOperator() {
		return urlOperator;
	}

	public ClickableNavTarget setUrlOperator(ExtractOperator urlOperator) {
		this.urlOperator = urlOperator;
		return this;
	}

	@Override
	public String toString() {
		return "[" + this.xpathTarget + "]";
	}

	public boolean isSearchForBinaryStream() {
		return searchForBinaryStream;
	}

	public ClickableNavTarget setSearchForBinaryStream(boolean searchForBinaryStream) {
		this.searchForBinaryStream = searchForBinaryStream;
		return this;
	}

	public boolean isDoNotReloadOriginalPage() {
		return getNavigationOptions().getDoNotReloadOriginalPage();
	}

	public ClickableNavTarget setDoNotReloadOriginalPage(boolean doNotReloadOriginalPage) {
		getNavigationOptions().setDoNotReloadOriginalPage(doNotReloadOriginalPage);
		return this;
	}
	
	/**
	 * 
	 * @return
	 * <p> Gets the pattern string of the WebResponse's url. <p> 
	 */
	public String getSearchKeyOfResponseUrl() {
		return searchKeyForResponseUrl;
	}
	
	/**
	 * 
	 * @param searchKeyForResponseUrl
	 * 	
	 * <p> The url pattern will be matched with the current WebConnection's WebResponse url. 
	 * If the url is matched with the returned WebReponse's url then the fully qualified url will be loaded again
	 * for getting the desired page. </p>
	 * <li> searchKeyForResponseUrl : is a search pattern.  It may be either regex or string. </li>
	 * <li> <p> Usage : If the response is loaded by webConnection but the webClient is not able to load the page in a new window
	 * then we can use this property. </p> </li>
	 * <li> <p>For loading the webResponse we should add the intercepter [<B>sites.WebResponseLoader</B>] property with the associated NavRequest. </p></li>
	 */
	public ClickableNavTarget setSearchForResponseUrl(String searchKeyForResponseUrl) {
		this.searchKeyForResponseUrl = searchKeyForResponseUrl;
		return this;
	}
	
	/**
	 * 
	 * @param isClearWebResponseSet
	 * 
	 * This will clear the stored elements of the response set from the WebResponseLoader.
	 */
	public ClickableNavTarget clearWebResponseSet(boolean isClearWebResponseSet) {
		this.isClearWebResponseSet = isClearWebResponseSet;
		return this;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isClearWebResponseSet() {
		return isClearWebResponseSet;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isVariableSubstitution() {
		return variableSubstitution;
	}

	/**
	 * 
	 * @param variableSubstitution
	 */
	public ClickableNavTarget setVariableSubstitution(boolean variableSubstitution) {
		this.variableSubstitution = variableSubstitution;
		return this;
	}

	@Override
	public boolean isDynamicTarget() {
		return true;
	}
	
	public String getWaitForXPathBeforeClick() {
		return this.waitForXPathBeforeClick;
	}

	public ClickableNavTarget setWaitForXPathBeforeClick(String waitForXPathBeforeClick) {
		this.waitForXPathBeforeClick = waitForXPathBeforeClick;
		return this;
	}
	
	public boolean isNotAlwaysPresent() {
		return notAlwaysPresent;
	}
	
	public ClickableNavTarget setNotAlwaysPresent(boolean notAlwaysPresent) {
		this.notAlwaysPresent = notAlwaysPresent;
		return this;
	}

	@Deprecated
	public Extract getResolvedMetaData() {
		return resolvedMetaData;
	}

	@Deprecated
	public void setResolvedMetaData(Extract resolveMetaData) {
		this.resolvedMetaData = resolveMetaData;
	}

}
