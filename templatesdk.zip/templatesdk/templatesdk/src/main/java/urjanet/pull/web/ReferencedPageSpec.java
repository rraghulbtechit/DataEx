package urjanet.pull.web;

import java.util.List;

import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.TargetGroup;

/**
 * 
 * @author xavierd
 *
 *	The page spec to look back the original pageSpec which contains the corresponding label.
 *	
 */
public final class ReferencedPageSpec implements PageSpec {

	private final String targetPageSpecLabel;
	
	public ReferencedPageSpec(String targetPageSpecLabel) {
		this.targetPageSpecLabel = targetPageSpecLabel;
	}
	
	@Override
	public ContentType getExpectedContentType() {
		throw new UnsupportedOperationException("Getting expected content type operation is not allowed in ReferencedPageSpec!!");
	}

	@Override
	public void setExpectedContentType(ContentType contentType) {
		throw new UnsupportedOperationException("Setting expected content type operation is not allowed in ReferencedPageSpec!!");
	}

	@Override
	public ConfigOptions getConfigOptions() {
		throw new UnsupportedOperationException("Getting config options operation is not allowed in ReferencedPageSpec!!");
	}

	@Override
	public void setConfigOptions(ConfigOptions configOptions) {
		throw new UnsupportedOperationException("Setting config options operation is not allowed in ReferencedPageSpec!!");
	}

	@Override
	public List<TargetGroup> getAllTargetGroups() {
		throw new UnsupportedOperationException("Getting target groups operation is not allowed in ReferencedPageSpec!!");
	}

	public String getTargetPageSpecLabel() {
		return targetPageSpecLabel;
	}

}
