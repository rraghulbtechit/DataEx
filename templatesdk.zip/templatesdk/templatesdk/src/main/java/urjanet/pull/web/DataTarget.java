package urjanet.pull.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import urjanet.DataTargetType;
//import urjanet.pull.core.Extract;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.reference.GroupReference;


/**
 * This class represents a 'generic' data target.
 * It specfies the name and type of the desired target but does not specify it's location.
 *
 * @author rbursons
 */
public abstract class DataTarget {

	private GroupPolicy groupPolicy;
	
	private List<GroupReference> references = new ArrayList<GroupReference>();
	
	protected boolean groupingTarget = false;
		
	protected String variableName;
	
	/**
	 * The name of the target value
	 */
	protected String name;

	protected String defaultValue;

	/**
	 *
	 * The expected data type of the target value
	 *
	 */
	protected DataTargetType type;

	private List<? extends DataTarget> relativeDataTargets;

	protected ExtractOperator operator;

	private DataTarget parentDataTarget;
	private boolean multipleParents = false;

	protected DataTargetQualifier qualifier;

	/*
	 * A hint for the formatter
	 */
	protected String formatHint;

	 /**
	 * Frame number is assumed to be 0 if not specified.
	 * This means that are no internal frames and that this doc is the
	 * top-level document in the window.
	 *
	 *  A valid frame path is hierarchical and may be separated by a '.'
	 *  i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 */
	private String framePath;
	
	private DataTargetOperationType operationType;
	
	private boolean isCorruptedPdf;
	
	public DataTarget(){ }

	/**
	 *
	 * @param name
	 * @param type
	 */
	public DataTarget(String name, DataTargetType type) {
		this.name = name;
		this.type = type;
	}

	/**
	 *
	 * @param name
	 */
	public DataTarget(String name) {
		this.name = name;
	}

	public DataTarget(GroupPolicy groupPolicy, String name) {
		this.groupPolicy = groupPolicy;
		this.name = name;
	}

	/**
	 *
	 * Create a new DataTarget without any sub-targets
	 *
	 * @param name the name (or key) of this target value
	 * @param operator a list of Regular Expressions, applied in squence and cumulatively to the target value
	 * @param operator a list of ExtractOperators, applied to the target value
	 */
	public DataTarget(String name, ExtractOperator operator) {
		this(name);
		this.operator = operator;
	}

	/**
	 * Create a new DataTarget to hold relative sub-targets
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param relativeDataTargets the sub-targets that relative to this node
	 */
	public DataTarget(List<? extends DataTarget> relativeDataTargets) {
		setRelativeDataTargets(relativeDataTargets);
	}

	/**
	 * Create a new DataTarget to hold relative sub-targets and assign it an groupPolicy that puts it in a
	 * Collection Subgroup.
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param groupPolicy the subgroup to put this target and all of it's sub-targets in
	 * @param relativeDataTargets the sub-targets that relative to this node
	 */
	public DataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(relativeDataTargets);
		setGroupPolicy(groupPolicy);
	}

	/**
	 *
	 * A non-public constructor to all for the cloning of this object.
	 * Should be moved to a clone() implementation.
	 *
	 * @param groupPolicy the subgroup to put this target and all of it's sub-targets in
	 * @param relativeDataTargets the sub-targets that relative to this node
	 * @param name the name (or key) of this target value
	 * @param type the datatype of this target value
	 * @param framePath the frame path (if any)
	 * @param operator a list of ExtractOperators, applied to the target value
	 *
	 */
	DataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets, DataTargetType type, String name, String framePath, ExtractOperator operator) {
		this(name, type);
		this.framePath = framePath;
		this.operator = operator;
		setRelativeDataTargets(relativeDataTargets);
		setGroupPolicy(groupPolicy);
	}

	/**
	 *
	 * @return the name of this data target
	 */
	public String getName() {
		return name;
	}

	/**
	 *
	 * @param name
	 */
	public DataTarget setName(String name) {
		this.name = name;
		return this;
	}

	/**
	 *
	 * @return the expected data type of this target
	 */
	public DataTargetType getType() {
		return type;
	}

	/**
	 *
	 * @param type
	 */
	public DataTarget setType(DataTargetType type) {
		this.type = type;
		return this;
	};

	/**
	 * @return the groupPolicy
	 */
	public GroupPolicy getGroupPolicy() {
		return groupPolicy;
	}

	/**
	 * @param groupPolicy the groupPolicy to set
	 */
	public DataTarget setGroupPolicy(GroupPolicy groupPolicy) {
		this.groupPolicy = groupPolicy;
		return this;
	}

	/**
	 * @return the formatHint
	 */
	public String getFormatHint() {
		return formatHint;
	}

	/**
	 * @param formatHint the formatHint to set
	 */
	public abstract DataTarget setFormatHint(String formatHint);

	/**
	 *
	 * @return the framePath of this page (0 by default)
	 *  A valid frame path is hierarchical and may be separated by a '.'
	 *  i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 */
	public String getFramePath() {
		return framePath;
	}

	/**
	 * @return the sub-targets
	 */
	public List<? extends DataTarget> getRelativeDataTargets() {
		return relativeDataTargets;
	}

	/**
	 *  A valid frame path is hierarchical and may be separated by a '.'
	 *  i.e. '1.2' means the 2nd nested frame with the first nested frame, etc.
	 *
	 * @param framePath sets the framePath of this page, if any (0 by default)
	 */
	public DataTarget setFrameNumber(String framePath) {
		this.framePath = framePath;
		return this;
	}

	/**
	 * @param relativeDataTargets the sub-targets, relative to this target
	 */
	public DataTarget setRelativeDataTargets(List<? extends DataTarget> relativeDataTargets) {
		
		this.relativeDataTargets = Collections.unmodifiableList(relativeDataTargets);
		for (DataTarget target : this.relativeDataTargets) {
			if (target.getParentDataTarget() != null && !(target.getParentDataTarget() == this))
				target.setMultipleParents(true);
			target.setParentDataTarget(this);
		}
		return this;
	}
	
	private void setMultipleParents(boolean value) {
		this.multipleParents = value;
	}

	/**
	 * @return the parentDataTarget
	 */
	public DataTarget getParentDataTarget() {
		return parentDataTarget;
	}

	/**
	 * @param parentDataTarget the parentDataTarget to set
	 */
	private void setParentDataTarget(DataTarget parentDataTarget) {
		this.parentDataTarget = parentDataTarget;
	}

	public ExtractOperator getOperator() {
		return operator;
	}

	public abstract DataTarget setOperator(ExtractOperator operator);

	/**
	 *
	 * @return a DataTargetQualifier that determines whether or not this DataTarget should actually be 'collected'
	 */
	public DataTargetQualifier getQualifier() {
		return this.qualifier;
	}
	
	/**
	 * Returns the ancestor DataTargetQualifer's name which qualifies the higher-level DataTarget this target is a part of
	 * @return
	 */
	public String getEffectiveQualifierName() {
		String effectiveQualifierName = null;
		
		DataTargetQualifier effectiveQualifier = getQualifier();
		if (effectiveQualifier != null) {
			if (effectiveQualifier instanceof BaseDataTargetQualifier) {
				if (multipleParents) {
					return "Multiple Possible Qualifiers";
				}
				BaseDataTargetQualifier qual = (BaseDataTargetQualifier) effectiveQualifier;
				return qual.getName();
			}
			return "<Qualifier Not Named>";
		}
		
		if (effectiveQualifierName == null && getParentDataTarget() != null) {
			effectiveQualifierName = getParentDataTarget().getEffectiveQualifierName();
		}
		
		return effectiveQualifierName;
	}

	/**
	 * @param qualifier a DataTargetQualifier that determines whether or not this DataTarget should actually be 'collected'
	 */
	public abstract DataTarget setQualifier(DataTargetQualifier qualifier);

	public String getDefaultValue() {
		return defaultValue;
	}

	public boolean isGroupingTarget() {
		return groupingTarget;
	}

	public String getVariableName() {
		return variableName;
	}
	
	public abstract DataTarget setGroupingTarget(boolean groupingTarget);
	
	public abstract DataTarget setVariable(String variableName);
	
	public abstract DataTarget setDefaultValue(String defaultValue);
	
	public abstract DataTarget setDefaultValue(String ... defaultValue);
	
	/**
	 * 
	 * @return the first found key name.
	 */
	public String getFirstName() {
		
		if(this.getName() != null) {
			return this.getName();
		}
		if(relativeDataTargets != null) {
			for(DataTarget dt : relativeDataTargets) {
				String name;
				if((name = dt.getFirstName()) != null) {
					return name;
				}
			}
		}
		return null;
	}

	@Override
	public String toString() {
		if(this.name != null){
			return "[" + this.name + "]";
		}else{
			return super.toString();
		}
	}

	public List<GroupReference> getReferences() {
		return references;
	}

	public DataTarget addReference(GroupReference ... reference) {
		
		if(reference != null) {
			this.references.addAll(Arrays.asList(reference));
		}
		return this;
	}
	
	/**
	 * 
	 * @return
	 * 
	 * Gets the operation type of this Data Target
	 */
	public DataTargetOperationType getDataTargetOperationType() {
		return operationType;
	}
	
	/**
	 * 
	 * @param operationType
	 * @return
	 * 
	 * Sets the operation type for this Data Target
	 */
	public DataTarget setDataTargetOperationType(DataTargetOperationType operationType) {
		this.operationType = operationType;
		return this;
	}

	/**
	 * @return the isCorruptedPdf
	 */
	public boolean isCorruptedPdf() {
		return isCorruptedPdf;
	}

	/**
	 * @param isCorruptedPdf the isCorruptedPdf to set
	 */
	public DataTarget setCorruptedPdf(boolean isCorruptedPdf) {
		this.isCorruptedPdf = isCorruptedPdf;
		return this;
	}
}
