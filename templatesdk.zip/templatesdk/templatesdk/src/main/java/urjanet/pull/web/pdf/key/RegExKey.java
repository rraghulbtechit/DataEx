package urjanet.pull.web.pdf.key;

/**
 * RegExKey is no longer supported.
 * Use @see {@link IndexedRegExKey}
 */
@Deprecated
public class RegExKey extends WordContextKey {
	
	private String key;
	private boolean inverseSearchDirection;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private RegExKey() {
		
	}
	
	public RegExKey(String key, int n) {
		super();
		this.key = key;
		this.occuranceOfKey = n;
	}
	
	public RegExKey(String key) {
		this(key, 0);
	}
	
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public RegExKey setKey(String key) {
		this.key = key;
		return this;
	}

	/**
	 * 
	 * @return
	 */
	public boolean getInverseSearchDirection() {
		return inverseSearchDirection;
	}

	/**
	 * 
	 * @param inverseSearchDirection
	 * @return
	 * 
	 * The regex search operation will happen from the end.
	 */
	public RegExKey setInverseSearchDirection(boolean inverseSearchDirection) {
		this.inverseSearchDirection = inverseSearchDirection;
		return this;
	}
	
	public RegExKey setOccuranceOfKey(int occuranceOfKey) {
		this.occuranceOfKey = occuranceOfKey;
		return this;
	}

	@Override
	public String toString() {
		return "RegExContextKey: key - " + key;
	}
}
