package urjanet.pull.enrollment.util;

public interface EbillEnroller {
	
	public boolean ebillEnroll ( EnrollmentInputs enrollmentInput );
	
}
