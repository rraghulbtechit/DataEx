package urjanet.pull.web.pdf.key;

import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.WordTargetFormat;

public class IndexedKey extends WordContextKey {
	
	private int lineNumber;
	private int wordNumber;
	private WordTargetFormat indexStrategy;
	private boolean inverseLineSearchDirection = false;
	private boolean inverseWordSearchDirection = false;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private IndexedKey() {
		
	}
	
	public IndexedKey(int lineNumber, int wordNumber, WordTargetFormat indexStrategy) {
		this.lineNumber = lineNumber;
		this.wordNumber = wordNumber;
		this.indexStrategy = indexStrategy;
	}
	
	public IndexedKey(int lineNumber, int wordNumber) {
		this(lineNumber, wordNumber, new SingleWordTargetFormat());
	}
	
	public IndexedKey(int lineNumber) {
		this(lineNumber, 0, new LineTargetFormat());
	}
	
	public IndexedKey(int lineNumber, WordTargetFormat wordFormat) {
		this(lineNumber, 0, wordFormat);
	}

	/**
	 * Enable backward line search.
	 *
	 * Search for line from bottom to top.
	 * <pre>
	 * ---- ---- ---- ---- ---- ---- 3
	 * ---- ---- ---- ---- ---- ---- 2  ^
	 * ---- ---- ---- ---- ---- ---- 1  |
	 * ---- ---- ---- ---- ---- ---- 0  |
	 *                               Search Direction
	 * </pre>
	 *
	 */
	public IndexedKey setInverseLineSearchDirection(boolean inverseLineSearchDirection) {
		this.inverseLineSearchDirection = inverseLineSearchDirection;
		return this;
	}
	
	public boolean isInverseLineSearchDirection() {
		return inverseLineSearchDirection;
	}

	/**
	 * Enable backward word search.
	 *
	 * Search for words from left to right.
	 * <pre>
	 *   5    4    3    2    1    0
	 * ---- ---- ---- ---- ---- ----
	 *                          <--- Search Direction
	 * </pre>
	 *
	 */
	public IndexedKey setInverseWordSearchDirection(boolean inverseWordSearchDirection) {
		this.inverseWordSearchDirection = inverseWordSearchDirection;
		return this;
	}
	
	public boolean isInverseWordSearchDirection() {
		return inverseWordSearchDirection;
	}
	
	public int getLineNumber() {
		return lineNumber;
	}
	
	/**
	 * @param lineNumber the lineNumber to set
	 */
	public IndexedKey setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
		return this;
	}

	public int getWordNumber() {
		return wordNumber;
	}
	
	/**
	 * @param wordNumber the wordNumber to set
	 */
	public IndexedKey setWordNumber(int wordNumber) {
		this.wordNumber = wordNumber;
		return this;
	}
	
	public WordTargetFormat getIndexStrategy() {
		return indexStrategy;
	}
	
	/**
	 * @param indexStrategy the indexStrategy to set
	 */
	public IndexedKey setIndexStrategy(WordTargetFormat indexStrategy) {
		this.indexStrategy = indexStrategy;
		return this;
	}

	public String toString() {
		return "IndexedContextKey: Line number - " + lineNumber + ", Word number - " + wordNumber + ", Line Forward - " + inverseLineSearchDirection + ", Word Forward - " + inverseWordSearchDirection;
	}

}
