package urjanet.pull.core;

import urjanet.pull.web.NavTarget;

/**
 * This class defines the overall collection specification for a particular data source
 * (website, part of a website, or other) including where and how to aquire the source,
 * and then how and what to extract from it.
 * <p>
 * The PullJobTemplate also defines the input
 * parameters that it is expecting, but not the actual parameter values, as it is not specific
 * to particular set of input parameters but general representation of 'how to collect from a datasource'.
 * A PullJobSpec combines the PullJobTemplate with a PullJobInput (which contains 'account specific' input parameters).
 *
 * @author rburson
 * @see PullJobSpec
 * @see PullJobInput
 */
public interface PullJobTemplate {

	/**
	 * Get the id of this template.
	 *
	 * @return the id of this template
	 */
	String getId();
	PageSpec getPageSpec();
	String getVersion();
	String getOwnerEmail();


}
