package urjanet.pull.selenium.util;

import java.io.File;
import java.util.Hashtable;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author aravindps
 * 
 */
public class SeleniumWebDriverFactory {

	private final Logger log = LoggerFactory.getLogger(SeleniumWebDriverFactory.class);
	private static final SeleniumWebDriverFactory onlyOne = new SeleniumWebDriverFactory();

	/*
	 * plugins
	 * |--linux
	 * |--firefox+version
	 * |--chromium
	 * |--windows
	 * |--firefox
	 * |--chromium
	 * |--internet_explorer
	 * |--addons
	 */

	private final File PLUGIN = new File("/opt/plugins");
	private final File ADDONS = new File(PLUGIN, "addons");
	// linux
	private final File PLUGIN_LINUX = new File(PLUGIN, "linux");
	// windows
	private final File PLUGIN_WIN = new File(PLUGIN, "windows");

	private final String HOME_URL = "http://urjanet.com/"; /* dummy home url */

	// singleton class
	/**
	 * default constructor
	 */
	private SeleniumWebDriverFactory() {

	}

	/**
	 * 
	 * @return singleton object
	 */
	public static SeleniumWebDriverFactory getInstance() {

		return onlyOne;
	}

	/**
	 * 
	 * @param downloadDirectory
	 * @return
	 */
	public WebDriver firefox(File downloadDirectory) {

		/*
		 * gets system default browser
		 */
		return firefox(downloadDirectory, 0, null, false);
	}

	/**
	 * 
	 * @param downloadDirectory
	 * @param version
	 * @return
	 */
	public WebDriver firefox(File downloadDirectory, int version) {

		
		return firefox(downloadDirectory, version , null, false);
	}

	/**
	 * 
	 * @param downloadDirectory
	 * @param version
	 * @param isProxy
	 * @param firefxProfile
	 * @return
	 */
	public WebDriver firefox(File downloadDirectory, int version, FirefoxProfile firefoxProfile, boolean isProxy) {

		/*
		 * Setting firefox preferences
		 */

		// appends version number to the directory
		SeleniumUtils.getInstance().createDir(downloadDirectory);
		final File FIREFOX_DIRECTORY = new File(PLUGIN_LINUX, "firefox" + ((version != 0) ? version : ""));

		if (!FIREFOX_DIRECTORY.isDirectory() && version != 0) {
			// firefox directory not found
			if (isLinux()) {

				log.error(super.getClass().getName() + " needs firefox " + version + " browser in the directory: " + FIREFOX_DIRECTORY.getAbsolutePath());
				String osType = null;
				log.error("Operating System type: " + System.getProperty("os.arch"));
				if (System.getProperty("os.arch").endsWith("i386")) {
					osType = "linux-i686";
				} else {
					osType = "linux-x86_64";
				}
				log.error("(*) Please download firefox " + version + " browser from URL: [" + String.format("http://ftp.mozilla.org/pub/mozilla.org/firefox/releases/%s/%s/en-US/firefox-%s.tar.bz2", version + ".0", osType, version + ".0") + "]");
				log.error("(*) Extract and place it in " + FIREFOX_DIRECTORY.getAbsolutePath());
				return null;
			} else {
				// windows doesn't have portable version for firefox. So, we have to install the required version in the system
				// setting system default firefox browser
				version = 0;
			}
		}
		
		if ( firefoxProfile == null ) {
			/*
			 * gets system default browser
			 */
			log.debug("Configuring default firefox profile");
			firefoxProfile = new FirefoxProfile();
			try { //TODO: should be enhanced with better options, while refactoring drivers
				firefoxProfile.setPreference("browser.download.folderList", 2);
				firefoxProfile.setPreference("browser.download.manager.showWhenStarting", false);
				firefoxProfile.setPreference("browser.download.dir", downloadDirectory.getAbsolutePath());
				firefoxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/pdf");
				firefoxProfile.setPreference("plugin.disable_full_page_plugin_for_types", "application/pdf");
				firefoxProfile.setPreference("pdfjs.disabled", true);
				firefoxProfile.setPreference("pdfjs.firstRun", false);

				// proxy config
				if (isProxy) {
					String proxyHost = "localhost";
					int proxyPort = 8123;
					firefoxProfile.setPreference("network.proxy.http", proxyHost);
					firefoxProfile.setPreference("network.proxy.http_port", proxyPort);
					firefoxProfile.setPreference("network.proxy.ftp", proxyHost);
					firefoxProfile.setPreference("network.proxy.ftp_port", proxyPort);
					firefoxProfile.setPreference("network.proxy.ssh", proxyHost);
					firefoxProfile.setPreference("network.proxy.ssh_port", proxyPort);
					firefoxProfile.setPreference("network.proxy.ssl", proxyHost);
					firefoxProfile.setPreference("network.proxy.ssl_port", proxyPort);
					firefoxProfile.setPreference("network.proxy.socks", proxyHost);
					firefoxProfile.setPreference("network.proxy.socks_port", proxyPort);
					firefoxProfile.setPreference("network.proxy.type", 1);                                          // Manual proxy
					firefoxProfile.setPreference("network.proxy.share_proxy_settings", true);                       // share the http proxy
				}

				// disable autoupdate
				firefoxProfile.setPreference("app.update.auto", false);
				firefoxProfile.setPreference("app.update.enabled", false);
				// default browser check
				firefoxProfile.setPreference("browser.shell.checkDefaultBrowser", false);
				// disabled profiler log
				firefoxProfile.setPreference("devtools.profiler.enabled", false);
				// this only works with Selenium WebDrivers
				firefoxProfile.setEnableNativeEvents(true);
			} catch (Exception e) {
				log.error("Failed while configuring firefox profile");
				e.printStackTrace();
				return null;
			}
		} else {
			log.debug("User configured firefox profile");
		}
		
		if (ADDONS.isDirectory()) {

			try {
				firefoxProfile.setPreference("extensions.firebug.currentVersion", "1.11.4");
				for (File file : ADDONS.listFiles()) {
					if (file.getName().endsWith(".xpi")) {
						log.debug("Loading addon: " + file.getAbsolutePath());
						firefoxProfile.addExtension(file);
					}
				}
			} catch (Exception e) {
				log.error("Failed loading Firefug & firepath extensions");
				log.error("* Please check the compatible version of firebug for firefox " + version + " browser from " + "https://addons.mozilla.org/en-US/firefox/addon/firebug/");
				log.error("* Download the firebug extension *.xpi from " + "http://getfirebug.com/releases/firebug/" + " and save in " + ADDONS.getAbsolutePath());

				log.error("* Please check the compatible version of firepath for firefox " + version + " browser from " + "https://addons.mozilla.org/en-us/firefox/addon/firepath/versions/");
				log.error("* Download the firepath extension *.xpi by right clicking '+ Add to firefox' -> save link as and save in " + ADDONS.getAbsolutePath());
				e.printStackTrace();
				return null;
			}
		} else {
			log.info("No add-ons are loaded." + " To load add-ons place them in " + ADDONS.getAbsolutePath());
		}

		WebDriver driver = null;
		// opening firefox browser based on version
		if (version != 0) {
			final File firefoxBin = new File(FIREFOX_DIRECTORY, "firefox");
			log.debug("Opening firefox version " + version);
			try {
				driver = new FirefoxDriver(new FirefoxBinary(firefoxBin), firefoxProfile);
			} catch (WebDriverException e) {
				log.error("Failed opening firefox " + version + " browser from " + firefoxBin.getAbsolutePath());
				e.printStackTrace();
				if (driver != null)
					driver.close();
				return null;
			}
		} else {
			log.debug("Opening system default firefox");
			try {
				driver = new FirefoxDriver(firefoxProfile);
			} catch (WebDriverException e) {
				log.error("Failed opening system default firefox browser");
				if (!isLinux()) {
					log.error("(*) Please download firefox " + version + " browser from URL: [http://ftp.mozilla.org/pub/mozilla.org/firefox/releases/]");
					log.error("(*) Install");
				}
				e.printStackTrace();
				if (driver != null)
					driver.close();
				return null;
			}
		}

		return driver;
	}

	/**
	 * checks for os type
	 * 
	 * @return true - linux; false - windows
	 */
	private boolean isLinux() {

		log.debug("Operating system: " + System.getProperty("os.name"));
		if (System.getProperty("os.name").endsWith("Linux")) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * In order to run the chromium driver first install chrome browser in your machine(Default Location).
	 * Download your browser compatible version of chromium driver.
	 * Extract the  chromedriver file in /opt/plugins/linux/chrome folder.
	 * Note:
	 * 		Make sure that chromedriver.exe is executable file.
	 * 		To check the browser supported Version of chromedriver use : https://sites.google.com/a/chromium.org/chromedriver/downloads
	 * 		To Download the appropiate chromedriver use : http://chromedriver.storage.googleapis.com/index.html?path= 
	 * 		If your Browser is not installed in Default Location create symbolic Link of the folder and place that link in folder
	 * 		where your chromedriver.exe placed.
	 *
	 * @param downloadDir
	 * @return
	 */
	public WebDriver chrome(File downloadDir) {

		SeleniumUtils.getInstance().createDir(downloadDir);
		WebDriver driver = null;
		final File CHROMIUM_WIN_BIN = new File(PLUGIN_WIN, "chrome" + File.separator + "chromedriver.exe");
		final File CHROMIUM_DRIVER_LINUX_BIN = new File(PLUGIN_LINUX, "chrome" + File.separator + "chromedriver");
		final File CHROMIUM_LINUX_BIN = new File(File.separator + "usr" + File.separator + "bin" + File.separator + "chromium-browser");
		log.debug("Opening a new chrome browser");
		try {
			System.setProperty("webdriver.chrome.driver", CHROMIUM_DRIVER_LINUX_BIN.getAbsolutePath());
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability("chrome.binary", CHROMIUM_LINUX_BIN);
			
			Map<String, Object> prefs = new Hashtable<String, Object>();
			prefs.put("download.prompt_for_download", false);
			prefs.put("download.default_directory", downloadDir.getAbsolutePath());  
			prefs.put("profile.default_content_settings.popups", 0);    
			prefs.put("plugins.plugins_disabled", new String[] {
				    "Chrome PDF Viewer"
				});
			prefs.put( "profile.content_settings.exceptions.automatic_downloads.*.setting", 1 );
			prefs.put( "profile.content_settings.pattern_pairs.*.multiple-automatic-downloads", 1 );                    
			prefs.put( "browser. download. manager.showWhenStarting", false );                    
			prefs.put("browser.helperApps.neverAsk.saveToDisk", "application/pdf");                    
			prefs.put("plugins.always_open_pdf_externally", true);
			
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);

			driver = new ChromeDriver(capabilities);
		} catch (Exception e) {
			log.error("Failed while getting chrome web driver");
			return null;
		}
		return driver;
	}

	/**
	 * we cannot open multiple tor browser 
	 * Tested only for Linux OS
	 * @param downloadDir
	 * @return
	 */
	public WebDriver tor(File downloadDir) {

		SeleniumUtils.getInstance().createDir(downloadDir);
		final File TOR_DIRECTORY = new File(PLUGIN_LINUX, "tor");

		if (!TOR_DIRECTORY.isDirectory() ) {
			// tor directory not found
			if (isLinux()) {
				log.error(super.getClass().getName() + " needs Tor browser in the directory: " + TOR_DIRECTORY.getAbsolutePath());
				log.error("(*) Download Tor browser , Extract and place it in " + TOR_DIRECTORY.getAbsolutePath());
			} else {
				log.error("Not yet implemented for this OS");
			}
			return null;
		}
		
		FirefoxBinary binary = new FirefoxBinary(new File(TOR_DIRECTORY,"Browser/start-tor-browser")); //works for linux
		FirefoxProfile torProfile = new FirefoxProfile(new File(TOR_DIRECTORY,"Browser/TorBrowser/Data/Browser/profile.default"));
		log.debug("Configuring default Tor profile");
		try { //TODO: should be enhanced with better options, while refactoring drivers
			torProfile.setPreference("browser.download.folderList", 2);
			torProfile.setPreference("browser.download.manager.showWhenStarting", false);
			torProfile.setPreference("browser.download.dir", downloadDir.getAbsolutePath());
			torProfile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/pdf");
			torProfile.setPreference("plugin.disable_full_page_plugin_for_types", "application/pdf");
			torProfile.setPreference("browser.download.useDownloadDir", true);
			//to disable to popup
			torProfile.setPreference("extensions.torbutton.tor_enabled", false);
			torProfile.setPreference("browser.altClickSave", false);
			torProfile.setPreference("pdfjs.disabled", true);
			torProfile.setPreference("pdfjs.firstRun", false);

			// disable autoupdate
			torProfile.setPreference("app.update.auto", false);
			torProfile.setPreference("app.update.enabled", false);
			// default browser check
			torProfile.setPreference("browser.shell.checkDefaultBrowser", false);
			// disabled profiler log
			torProfile.setPreference("devtools.profiler.enabled", false);
			// this only works with Selenium WebDrivers
			torProfile.setEnableNativeEvents(true);
		} catch (Exception e) {
			log.error("Failed while configuring firefox profile");
			e.printStackTrace();
			return null;
		}

		WebDriver driver = null;
		
			try {
				driver = new FirefoxDriver(binary , torProfile);
			} catch (WebDriverException e) {
				log.error("Failed opening system default Tor browser");
				e.printStackTrace();
				if (driver != null)
					driver.close();
				return null;
			}

		return driver;
	}
	
	
	/**
	 * not yet tested
	 * 
	 * @param downloadDir
	 * @return
	 */
	public WebDriver internetExplorer(File downloadDir) {

		SeleniumUtils.getInstance().createDir(downloadDir);
		WebDriver driver = null;
		if (isLinux()) {
			log.error("You can't use interenet explorer in linux machine");
			return null;
		}
		final File IE_WIN_BIN = new File(PLUGIN_WIN, "internet_explorer" + File.separator + "IEDriverServer.exe");
		log.debug("Opening a new internet explorer browser");
		try {
			System.setProperty("webdriver.ie.driver", IE_WIN_BIN.getAbsolutePath());
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability("ignoreProtectedModeSettings", true);
			capabilities.setCapability("nativeEvents", false);
			capabilities.setCapability("unexpectedAlertBehaviour", "accept");
			driver = new InternetExplorerDriver(capabilities);
		} catch (Exception e) {
			log.error("Failed while getting internet explorer web driver");
			log.error("* Download the internet explorer web driver for windows " + (System.getProperty("os.arch").contains("x86") ? "32 bit" : "64 bit") + " [https://code.google.com/p/selenium/downloads/list]" + " and save in " + new File(PLUGIN_WIN, "internet_explorer").getAbsolutePath());
			e.printStackTrace();
			return null;
		}
		return driver;
	}
}
