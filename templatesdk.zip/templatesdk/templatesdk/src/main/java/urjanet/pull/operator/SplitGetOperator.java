package urjanet.pull.operator;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

/**
 *
 * @author rburson
 */
public class SplitGetOperator implements ExtractOperator{

	private static final String defaultDelim = "\\s";

	private String regExDelim;
	private int index;
	private int limit;

	public SplitGetOperator() {
		this(0);
	}

	public SplitGetOperator(int index) {
		this(defaultDelim, index);
	}

	public SplitGetOperator(String regExDelim, int index) {
		this(regExDelim, index, 0);
	}


	public SplitGetOperator(String regExDelim, int index, int limit) {
		this.regExDelim = regExDelim;
		this.index = index;
		this.limit = limit;
	}

	public String getRegExDelim() {
		return regExDelim;
	}

	public SplitGetOperator setRegExDelim(String regExDelim) {
		this.regExDelim = regExDelim;
		return this;
	}

	public int getIndex() {
		return index;
	}

	public SplitGetOperator setIndex(int index) {
		this.index = index;
		return this;
	}

	public int getLimit() {
		return limit;
	}
	
	public SplitGetOperator setLimit(int limit) {
		this.limit = limit;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);

		}catch(ClassCastException cce){
			throw new OperatorException("SplitGetOperator can only be applied to a DomText node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

		try {
			if(text != null){
				String[] result = text.split(regExDelim, limit);
				
				if (index < 0) {
					if (result.length > 0) {
						return new ExtractOperand(result[result.length - 1]);
					}
				} else if (result.length > index){
					return new ExtractOperand(result[index]);
				}
			}
			return new ExtractOperand();

		} catch (Exception e) {
			throw new OperatorException("Error trying to split " + text + " on " + regExDelim + " at index " + index + " with limit " + limit, e);
		}


	}

}
