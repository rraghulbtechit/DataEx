package urjanet.pull.web.pdf.key;

/**
 * 
 * @author xavierd
 *	
 *	<p> This KeyStructure used commonly for both StringKey as well as MutiStringKey.</p>
 */
public enum KeyStructure {
	
	/**
	 * Use this proximity if the key's structure is as like below.
	 * <pre> 
	 * Current            Amount
	 *    Delinquent   After
	 * </pre>
	 */
	PROXIMITY,
	
	/**
	 * Use this In_Order if the key's structure is as like below.
	 * <pre> 
	 * 	Current Amount Delinquent After
	 * </pre>
	 * The key should be in a same line.
	 */
	 IN_ORDER
}