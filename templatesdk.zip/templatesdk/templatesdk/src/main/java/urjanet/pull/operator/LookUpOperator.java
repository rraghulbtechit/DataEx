package urjanet.pull.operator;

import java.util.ArrayList;
import java.util.List;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

/**
 * 
 * @author anbuarasan
 *
 * This is to do case insensitive lookup on a list with name value pair based on extractValue of a datatarget. 
 *
 */
public class LookUpOperator implements ExtractOperator {

	private List<NameValuePair> keyAndValues;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private LookUpOperator() {
		
	}
	
	public LookUpOperator(final List<NameValuePair> searchValues) {

		this.keyAndValues = new ArrayList<NameValuePair>(searchValues);
	}
		
	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("SearchOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

		try{
			if(!keyAndValues.isEmpty()) {
				for(NameValuePair pair : keyAndValues) {
					if(text.equalsIgnoreCase(pair.getName())) {
						return new ExtractOperand(pair.getValue());
					}
				}
			}
		} catch (Exception e) {
			throw new OperatorException("SearchOperator error" + e);
		}
		
		return new ExtractOperand(text);
	}

}