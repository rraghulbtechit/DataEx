package urjanet.pull.web;

import java.util.List;

/**
 *
 * @author rburson
 */
public class ExpandableTargetGroup extends XmlTargetGroup{

	private boolean variableSubstitution;

	public ExpandableTargetGroup(NavTarget[] navTargets) {
		super(navTargets);
	}

	public ExpandableTargetGroup(DataTarget[] dataTargets) {
		super(dataTargets);
	}

	public ExpandableTargetGroup(List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		super(dataTargets, navTargets);
	}

	public ExpandableTargetGroup(String baseXPath, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		super(baseXPath, dataTargets, navTargets);
	}

	public ExpandableTargetGroup(String baseXPath, GroupPolicy groupPolicy, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		super(baseXPath, groupPolicy, dataTargets, navTargets);
	}

	public ExpandableTargetGroup() {
	}

	public boolean isVariableSubsitution() {
		return variableSubstitution;
	}

	public ExpandableTargetGroup setVariableSubsitution(boolean variableSubsitution) {
		this.variableSubstitution = variableSubsitution;
		return this;
	}

}
