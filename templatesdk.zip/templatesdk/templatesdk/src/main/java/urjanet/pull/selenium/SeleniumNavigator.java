package urjanet.pull.selenium;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * 
 * @author aravindps
 *
 * All classes extending this should be named: <ProviderID>SeleniumNavigator.java
 * 
 */

public abstract class SeleniumNavigator {
	
	private String providerAlias;
	private Date historyStartDate;
	private int retryCount = 3;
	private Set<String> givenAccounts;
	
	public abstract boolean downloadMostRecent(String userName, String password);
	public abstract boolean downloadAll(String userName, String password);
	
	public void setProviderAlias(String providerAlias) {
		this.providerAlias = providerAlias;
	}
	public String getProviderAlias() {
		return providerAlias;
	}
	
	public Set<String> getGivenAccounts() {
		return givenAccounts;
	}
	public void setGivenAccounts(Set<String> givenAccounts) {
		this.givenAccounts = givenAccounts;
	}
	
	public void setHistoryStartDate(Date historyStartDate) {
		this.historyStartDate = historyStartDate;
	}
	public Date getHistoryStartDate() {
		return historyStartDate;
	}
	
	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}
	public int getRetryCount() {
		return retryCount;
	}
}
