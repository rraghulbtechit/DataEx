package urjanet.pull.web.htmlunit;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.RefreshHandler;
import java.io.IOException;
import java.net.URL;

/**
 *
 * @author rburson
 */
public class DummyRefreshHandler implements RefreshHandler{

	@Override
	/*
	 * Do nothing
	 */
	public void handleRefresh(Page page, URL url, int seconds) throws IOException {
	}

}
