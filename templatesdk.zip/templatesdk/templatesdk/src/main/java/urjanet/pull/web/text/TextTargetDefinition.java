package urjanet.pull.web.text;


public class TextTargetDefinition {

	public static enum Direction {ABOVE, BELOW, SELF};
	
	private TextKey searchKey;
	private Direction searchDirection;

	//This constructor will be called in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private TextTargetDefinition() {
		
	}
	
	public TextTargetDefinition(TextKey searchKey, Direction direction) {
		this.searchKey = searchKey;
		this.searchDirection = direction;
	}
	
	public TextTargetDefinition(TextKey searchKey) {
		this.searchKey = searchKey;
		this.searchDirection = Direction.SELF;
	}
	
	public TextKey getSearchKey() {
		return this.searchKey;
	}
	
	/**
	 * @param searchKey the searchKey to set
	 */
	public TextTargetDefinition setSearchKey(TextKey searchKey) {
		this.searchKey = searchKey;
		return this;
	}

	public Direction getSearchDirection() {
		return this.searchDirection;
	}

	/**
	 * @param searchDirection the searchDirection to set
	 */
	public TextTargetDefinition setSearchDirection(Direction searchDirection) {
		this.searchDirection = searchDirection;
		return this;
	}
	
}
