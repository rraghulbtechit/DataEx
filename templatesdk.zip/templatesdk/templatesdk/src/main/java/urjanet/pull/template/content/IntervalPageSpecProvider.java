package urjanet.pull.template.content;

import urjanet.pull.core.PageSpec;

public interface IntervalPageSpecProvider {

	public PageSpec getIntervalPageSpec();
}
