package urjanet.pull.template;

import java.util.List;

import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.Content;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.XmlTargetGroup;

public class WootTemplateProvider implements TemplateProvider {

	@Override
	public PullJobTemplate getTemplate() {
		return new PullJobTemplate() {

			@Override
			public String getId() {
				return WootTemplateProvider.class.getName();
			}

			@Override
			public PageSpec getPageSpec() {
				return createWootPageSpec();
			}

			@Override
			public String getVersion() {
				return "1";
			}

			@Override
			public String getOwnerEmail() {
				return "tim.liu@urjanet.com";
			}
			
		};
	}
	
	public static PageSpec createWootPageSpec() {
		return new BasePageSpec(ContentType.WOOT, new ConfigOptions(), new XmlTargetGroup(new DataTarget() {
			
			@Override
			public DataTarget setVariable(String variableName) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setQualifier(DataTargetQualifier qualifier) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setOperator(ExtractOperator operator) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setGroupingTarget(boolean groupingTarget) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setFormatHint(String formatHint) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setDefaultValue(String... defaultValue) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public DataTarget setDefaultValue(String defaultValue) {
				// TODO Auto-generated method stub
				return null;
			}
			
			/*@Override
			public List<?> resolveTargets(Content content) throws PullException {
				// TODO Auto-generated method stub
				return null;
			}*/
		}));
	}

}
