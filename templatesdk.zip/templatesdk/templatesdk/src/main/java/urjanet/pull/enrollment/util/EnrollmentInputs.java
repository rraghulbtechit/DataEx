package urjanet.pull.enrollment.util;

import java.util.HashMap;
import java.util.Map;

public class EnrollmentInputs {

	private final String userName;
	private final String password;
	private final String accessChannel;
	private final String providerId;
	private final Map<String, EnrollmentAccountMetaData> enrollmentAccountMetaData = new HashMap<>();

	public EnrollmentInputs (String accessChannel, String userName , String password, String providerId) {
		this.accessChannel = accessChannel;
		this.userName = userName;
		this.password = password;
		this.providerId = providerId;
	}

	public String getProviderId() {
		return providerId;
	}

	public String getUserName() {
		return userName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getAccessChannel() {
		return accessChannel;
	}

	public Map<String, EnrollmentAccountMetaData> getEnrollmentAccountMetaData() {
		return enrollmentAccountMetaData;
	}
	
	public void setEnrollmentAccountMetaData(final String accountNumber, final EnrollmentAccountMetaData metaData) {
		this.enrollmentAccountMetaData.put(accountNumber, metaData);
	}
	
}
