package urjanet.pull.web;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.bool.PageCondition;

/**
 *
 * @author rburson
 */
public class DataTargetPageCondition implements PageCondition{

	private static final Logger log = LoggerFactory.getLogger(DataTargetPageCondition.class);
	private boolean enforceExtractionHandler;

	//This condition is true if all of these data targets are 'present'
	protected XmlDataTarget dataTargetRequirement;

	public DataTargetPageCondition(){}

	public DataTargetPageCondition(XmlDataTarget dataTargetRequirement, boolean isEnforceExtractionHandler) {
		this.dataTargetRequirement = dataTargetRequirement;
		setXpathNodeIndex(this.dataTargetRequirement);
		this.enforceExtractionHandler = isEnforceExtractionHandler;
	}
	
	public DataTargetPageCondition(XmlDataTarget dataTargetRequirement) {
		this(dataTargetRequirement, false);
	}
	
	public XmlDataTarget getDataTargetRequirement() {
		return dataTargetRequirement;
	}

	/**
	 * @param dataTargetRequirement the dataTargetRequirement to set
	 */
	public DataTargetPageCondition setDataTargetRequirement(XmlDataTarget dataTargetRequirement) {
		this.dataTargetRequirement = dataTargetRequirement;
		return this;
	}

	protected boolean areTargetsValid(List targets) {
		if (targets.size() > 0) 
			return true;
		return false;
	}

	/**
	 * @return the enforceExtractionHandler
	 */
	public boolean isEnforceExtractionHandler() {
		return enforceExtractionHandler;
	}

	/**
	 * @param enforceExtractionHandler the enforceExtractionHandler to set
	 */
	public void setEnforceExtractionHandler(boolean enforceExtractionHandler) {
		this.enforceExtractionHandler = enforceExtractionHandler;
	}
	
	/**
	 * Sets the Xpath Node index for all their relative targets as well.
	 * 
	 * @param dt
	 */
	private void setXpathNodeIndex(XmlDataTarget dt) {
		
		if(dt.getRelativeDataTargets() != null) {
			for(DataTarget currentTarget : dt.getRelativeDataTargets()) {
				if(currentTarget instanceof XmlDataTarget) {
					setXpathNodeIndex((XmlDataTarget)currentTarget);
				}
			}
		} else {
			// A single node match is enough to say the condition is valid or not for Page conditions.
			dt.setXpathNodeIndex(1);
		}
	}
	
}
