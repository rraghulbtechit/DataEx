/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package urjanet.pull.web;

import urjanet.pull.core.PageSpec;

/**
 *
 * @author rburson
 */
public class UrlNavTarget extends NavTarget{

	private String url;

	public UrlNavTarget() {
	}

	public UrlNavTarget(PageSpec targetPageSpec, String url) {
		super(targetPageSpec);
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public UrlNavTarget setUrl(String url) {
		this.url = url;
		return this;
	}

	@Override
	public boolean isDynamicTarget() {
		return false;
	}

}
