package urjanet.pull.core;

public enum ConfigOption {

	DISABLE_DETERMINE_CHARGE_POSITION("disable_determine_charge_position");
	
	private String paramName;
	
	private ConfigOption(String paramName) {
		this.paramName = paramName;
	}
	
	public String getParameterName() {
		return paramName;
	}
	
}
