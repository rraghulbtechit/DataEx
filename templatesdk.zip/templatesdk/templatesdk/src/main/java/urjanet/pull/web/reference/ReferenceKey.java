package urjanet.pull.web.reference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import urjanet.keys.GroupingKeys;
import urjanet.pull.core.ExtractValue;
import urjanet.util.ObjectUtils;

public class ReferenceKey {
	
	private Map<String, ExtractValue> identifiers = new HashMap<String, ExtractValue>();
	
	private String scopeId;
	private GroupingKeys scope;
	
	public ReferenceKey() {
	}
	
	public ReferenceKey(GroupReference reference) {
		scope = reference.getScope();
	}

	public Map<String, ExtractValue> getIdentifier() {
		return identifiers;
	}

	public void addIdentifier(ExtractValue value) {
		this.identifiers.put(value.getName(), value);
	}
	
	public GroupingKeys getScope() {
		return scope;
	}
	
	public String getScopeId() {
		return scopeId;
	}
	
	public void setScopeId(String scopeId) {
		this.scopeId = scopeId;
	}

	
/*	public boolean parentOf(ReferenceKey key) {
		if (isParent() && !key.isParent()) {
			return this.equals(key);
		}
		
		return false;
	}
	
	public boolean childOf(ReferenceKey key) {
		return key.parentOf(this);
	}*/
	
	public boolean equals(Object object) {
		if (object != null && object instanceof ReferenceKey) {
			
			ReferenceKey key = (ReferenceKey)object;
			
			if (!ObjectUtils.equalOrBothNull(this.getScopeId(), key.getScopeId()))
				return false;
			else if (key.getIdentifier().size() != this.getIdentifier().size())
				return false;
			
			List<ExtractValue> traversedValues = new ArrayList<ExtractValue>();
			
			Identifiers:
			for (String hashKey : identifiers.keySet()) {
				ExtractValue value = identifiers.get(hashKey);
				for (String tempHashKey : key.getIdentifier().keySet()) {
					ExtractValue temp = key.getIdentifier().get(tempHashKey);
					if (!traversedValues.contains(temp) 
							&& value.getName().equals(temp.getName()) 
							&& value.getValue().equals(temp.getValue())) {
						traversedValues.add(temp);
						continue Identifiers;
					}
				}
				return false;
			}
			return true;
		} else {
			return super.equals(object);
		}
	}

	@Override
	public String toString() {
		return "ReferenceKey{" + "identifiers=" + identifiers + '}';
	}

}
