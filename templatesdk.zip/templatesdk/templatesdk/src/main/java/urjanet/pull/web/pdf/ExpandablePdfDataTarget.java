package urjanet.pull.web.pdf;

import java.util.List;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.key.ContextKey;

/**
 * This is the ExpandablePdfDataTarget
 * 
 * Basically what it needs is a key that you want to expand on
 * 
 * It will search through the context for every instance of that key and break the context down into parts delimited by the key
 * 
 * The context filters that you put in help to more specifically identify the keys
 * These context filters work differently than in PdfDataTarget because they don't actually affect the resulting sections of the expansion
 * They instead help to give more specific keys
 * 
 * @author tim
 *
 */
public class ExpandablePdfDataTarget extends PdfDataTarget {

	private boolean endExpansionOnKey = false;
	private boolean uniqueExpansionOnKey = false;
	private ContextKey expandableKey;
	
	protected DataTargetQualifier startQualifier;
	protected DataTargetQualifier endQualifier;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private ExpandablePdfDataTarget() {

	}
	
	/**
	 * Just constructors with an expandable key and one filter
	 */
	public ExpandablePdfDataTarget(ContextKey expandableKey, ContextFilter filters, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(filters, groupPolicy, relativeDataTargets);
		this.expandableKey = expandableKey;
	}

	public ExpandablePdfDataTarget(ContextKey expandableKey, ContextFilter filters, List<? extends DataTarget> relativeDataTargets) {
		super(filters, relativeDataTargets);
		this.expandableKey = expandableKey;
	}

	/**
	 * Just constructors with an expandable key and list of filters
	 */
	public ExpandablePdfDataTarget(ContextKey expandableKey, List<? extends ContextFilter> filters, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(filters, groupPolicy, relativeDataTargets);
		this.expandableKey = expandableKey;
	}

	public ExpandablePdfDataTarget(ContextKey expandableKey, List<? extends ContextFilter> filters, List<? extends DataTarget> relativeDataTargets) {
		super(filters, relativeDataTargets);
		this.expandableKey = expandableKey;
	}

	/**
	 * Just constructors with an expandable key
	 */
	public ExpandablePdfDataTarget(ContextKey expandableKey, List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
		this.expandableKey = expandableKey;
	}

	public ExpandablePdfDataTarget(ContextKey expandableKey, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
		this.expandableKey = expandableKey;
	}
	
	public ContextKey getExpandableKey() {
		return expandableKey;
	}

	public ExpandablePdfDataTarget setExpandableKey(ContextKey expandableKey) {
		this.expandableKey = expandableKey;
		return this;
	}

	public ExpandablePdfDataTarget setEndExpansionOnKey(boolean endExpansionOnKey) {
		this.endExpansionOnKey = endExpansionOnKey;
		return this;
	}

	public DataTargetQualifier getStartQualifier() {
		return startQualifier;
	}

	public ExpandablePdfDataTarget setStartQualifier(DataTargetQualifier startQualifier) {
		this.startQualifier = startQualifier;
		return this;
	}

	public DataTargetQualifier getEndQualifier() {
		return endQualifier;
	}

	public ExpandablePdfDataTarget setEndQualifier(DataTargetQualifier endQualifier) {
		this.endQualifier = endQualifier;
		return this;
	}

	public boolean isEndExpansionOnKey() {
		return endExpansionOnKey;
	}
	

	/**
	 * @return the uniqueExpansionOnKey
	 */
	public boolean isUniqueExpansionOnKey() {
		return uniqueExpansionOnKey;
	}

	/**
	 * @param uniqueExpansionOnKey the uniqueExpansionOnKey to set
	 */
	public ExpandablePdfDataTarget setUniqueExpansionOnKey(boolean uniqueExpansionOnKey) {
		this.uniqueExpansionOnKey = uniqueExpansionOnKey;
		return this;
	}
}
