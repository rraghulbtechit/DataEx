package urjanet.pull.web.pdf.filter;

import urjanet.pull.web.coordinate.CoordinateTargetDefinition.Direction;
import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.ContextKey;
import urjanet.pull.web.pdf.key.StringKey;

public class DirectionFilter extends ContextFilter {
	
	private ContextKey key;
	private Direction direction;
	private TargetFormat targetFormat;
	private double maxDistance;
	private OverlapPosition overlapTextPosition;
	
	//TODO so that it doesn't wrap around
	//private boolean trueDirection;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private DirectionFilter() {
		
	}
	
	public DirectionFilter(ContextKey key, Direction direction, TargetFormat targetFormat, double maxDistance) {
		this.direction = direction;
		this.key = key;
		this.targetFormat = targetFormat;
		this.maxDistance = maxDistance;
	}
	
	public DirectionFilter(ContextKey key, Direction direction) {
		this(key, direction, new SingleWordTargetFormat(), 0);
	}
	
	public DirectionFilter(ContextKey key, Direction direction, double maxDistance) {
		this(key, direction, new SingleWordTargetFormat(), maxDistance);
	}
	
	public DirectionFilter(ContextKey key, Direction direction, TargetFormat targetFormat) {
		this(key, direction, targetFormat, 0);
	}

	public static DirectionFilter getDirection(String key, Direction direction, TargetFormat targetFormat) {
		return new DirectionFilter(new StringKey(key), direction, targetFormat);
	}
	
	public static DirectionFilter getDirection(String key, Direction direction) {
		return new DirectionFilter(new StringKey(key), direction);
	}
	
	public static DirectionFilter getLine(String key) {
		return getLine(key, Direction.SELF);
	}
	public static DirectionFilter getLine(String key, Direction direction) {
		return new DirectionFilter(new StringKey(key), direction, new LineTargetFormat());
	}
	
	public ContextKey getKey() {
		return key;
	}
	
	/**
	 * @param key the key to set
	 */
	public DirectionFilter setKey(ContextKey key) {
		this.key = key;
		return this;
	}

	public Direction getDirection() {
		return direction;
	}
	
	/**
	 * @param direction the direction to set
	 */
	public DirectionFilter setDirection(Direction direction) {
		this.direction = direction;
		return this;
	}
	
	public TargetFormat getTargetFormat() {
		return targetFormat;
	}

	/**
	 * @param targetFormat the targetFormat to set
	 */
	public DirectionFilter setTargetFormat(TargetFormat targetFormat) {
		this.targetFormat = targetFormat;
		return this;
	}

	public double getMaxDistance() {
		return maxDistance;
	}
	
	/**
	 * @param maxDistance the maxDistance to set
	 */
	public DirectionFilter setMaxDistance(double maxDistance) {
		this.maxDistance = maxDistance;
		return this;
	}

	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}

	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public DirectionFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public DirectionFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	public String toString() {
		return "DirectionalContextFilter: Direction - " + direction.name() + ", Key - " + key.toString() + ", max-distance - " + maxDistance;
	}

}
