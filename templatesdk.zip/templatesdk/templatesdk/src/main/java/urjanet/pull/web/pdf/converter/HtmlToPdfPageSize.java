package urjanet.pull.web.pdf.converter;

import org.allcolor.yahp.converter.IHtmlToPdfTransformer;
import org.allcolor.yahp.converter.IHtmlToPdfTransformer.PageSize;

/**
 * 
 * @author xavierd
 *
 *	Most commonly used paper sizes only added here.
 */
public enum HtmlToPdfPageSize {
	
	A0L(IHtmlToPdfTransformer.A0L),
	A0P(IHtmlToPdfTransformer.A0P),
	A1L(IHtmlToPdfTransformer.A1L),
	A1P(IHtmlToPdfTransformer.A1P),
	A2L(IHtmlToPdfTransformer.A2L),
	A2P(IHtmlToPdfTransformer.A2P),
	A3L(IHtmlToPdfTransformer.A3L),
	A3P(IHtmlToPdfTransformer.A3P),
	A4L(IHtmlToPdfTransformer.A4L),
	A4P(IHtmlToPdfTransformer.A4P),
	A5L(IHtmlToPdfTransformer.A5L),
	A5P(IHtmlToPdfTransformer.A5P),
	A6L(IHtmlToPdfTransformer.A6L),
	A6P(IHtmlToPdfTransformer.A6P),
	A7L(IHtmlToPdfTransformer.A7L),
	A7P(IHtmlToPdfTransformer.A7P);
	
	private PageSize value;
	private HtmlToPdfPageSize(PageSize value) {
		this.setValue(value);
	}
	
	/**
	 * @return the value
	 */
	public PageSize getValue() {
		return value;
	}
	
	/**
	 * @param value the value to set
	 */
	public void setValue(PageSize value) {
		this.value = value;
	}
}
