package urjanet.pull.ftp;

public enum FtpType {
	FTP, FTPS, SFTP
}
