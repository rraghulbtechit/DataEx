package urjanet.pull.operator;

import java.util.List;

import urjanet.pull.PullException;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

/**
 *
 * @author rburson
 */
public class ExtractOperand {

	private String stringResult;
	private DomNode result;
	private List<DomNode> nodeListResult;
	
	public ExtractOperand() {
	}

	public ExtractOperand(String stringResult) {
		this.stringResult = stringResult;
	}

	public ExtractOperand(DomNode result) {
		this.result = result;
	}

	@SuppressWarnings("unchecked")
	public ExtractOperand(Object o) throws PullException {

		try {
			if (o instanceof DomNode) {
				this.result = (DomNode) o;
			} else if (o instanceof List<?>) {
				this.nodeListResult = (List<DomNode>) o;
			} else if (o instanceof Boolean) {
				this.stringResult = ((Boolean)o).toString();
			} else {
				this.stringResult = o.toString();
			}
		} catch (ClassCastException cce) {
			throw new PullException("Unsuppported Operand Type", cce);
		}
	}

	public DomNode getResult() {
		return result;
	}

	public String getStringResult() {
		return stringResult;
	}

	public boolean isContentsNull() {
		return stringResult == null && result == null;
	}

	public boolean isTextValue() {

		if (result != null) {
			return (result instanceof DomText);
		} else {
			return stringResult != null;
		}
	}

	public String getTextValue() {
		if (result != null) {
			try {
				if (result instanceof DomAttr)
					return ((DomAttr)result).getValue();
				else
					return ((DomText) result).getData();
			} catch (ClassCastException cce) {
				return null;
			}
		} else {
			return stringResult;
		}
	}

	public List<DomNode> getNodeListResult() {
		return nodeListResult;
	}
}
