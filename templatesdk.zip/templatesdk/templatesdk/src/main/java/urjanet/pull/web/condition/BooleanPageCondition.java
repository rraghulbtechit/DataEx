package urjanet.pull.web.condition;

import urjanet.pull.web.DataTargetPageCondition;
import urjanet.pull.web.XmlDataTarget;

public class BooleanPageCondition extends DataTargetPageCondition {
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private BooleanPageCondition() {
		
	}
	
	public BooleanPageCondition(XmlDataTarget target) {
		super(target);
	}
}
