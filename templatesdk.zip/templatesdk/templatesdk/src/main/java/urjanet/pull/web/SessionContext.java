package urjanet.pull.web;

import java.util.HashMap;
import java.util.Map;

import urjanet.event.EventManager;
import urjanet.pull.service.PullServiceOptions;

/*
	Represents the current node of a 'route' or click stream through a site (SiteSession), of which there are many
	Acts as a representaiton of 'state' across concurrent activites
*/
public class SessionContext{

	private Map<String, Object> contextValues;
	private short jobResultMask;
	private EventManager eventManager;
	private PullServiceOptions pullServiceOptions;

	public SessionContext(Map<String, Object> contextValues, EventManager eventManager) {
		this.contextValues = contextValues;
		if(contextValues == null) this.contextValues = new HashMap<String, Object>();
		this.eventManager = eventManager;
	}

	public String toString(){
		return "";
	}

	/**
	 * @return the jobResultMask
	 */
	public short getJobResultMask() {
		return jobResultMask;
	}

	/**
	 * @param jobResultMask the jobResultMask to set
	 */
	public void setJobResultMask(short jobResultMask) {
		this.jobResultMask = jobResultMask;
	}

	public Object getContextValue(String key){
		return contextValues.get(key);
	}

	public void setContextValue(String key, Object value){
		contextValues.put(key, value);
	}

	public void addAllContextValues(Map<String, Object> values){
		contextValues.putAll(values);
	}
	
	public EventManager getEventManager() {
		return eventManager;
	}

	public PullServiceOptions getPullServiceOptions() {
		return pullServiceOptions;
	}

	public void setPullServiceOptions(PullServiceOptions pullServiceOptions) {
		this.pullServiceOptions = pullServiceOptions;
	}

}
