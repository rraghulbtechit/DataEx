package urjanet.pull.web.pdf.key;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class MultiStringKey extends WordContextKey {
	
	private List<String> keys;
	private List<StringKey> stringKeys;
	private boolean inverseSearchDirection;
	private KeyStructure keyStructure = KeyStructure.IN_ORDER;

	/**
	 * Return a match based on the order of the given search keys
	 */
	private boolean isSearchInKeyPrecedence;
	
	//This constructor will be called from Hit to create an instance through reflection
	@SuppressWarnings("unused")
	private MultiStringKey() {
		
	}
	
	public MultiStringKey(String ... keys) {
		super();
		this.keys = Arrays.asList(keys);
	}
	
	public MultiStringKey(StringKey ... stringKeys) {
		super();
		this.stringKeys = Arrays.asList(stringKeys);
	}
	
	public MultiStringKey(Collection<String> keys) {
		this.keys = new ArrayList<String>(keys);
	}

	public List<String> getKeys() {
		return keys;
	}

	/**
	 * @param keys the keys to set
	 */
	public MultiStringKey setKeys(List<String> keys) {
		this.keys = keys;
		return this;
	}
	
	public List<StringKey> getStringKeys() {
		return this.stringKeys;
	}
	
	/**
	 * @param stringKeys the stringKeys to set
	 */
	public MultiStringKey setStringKeys(List<StringKey> stringKeys) {
		this.stringKeys = stringKeys;
		return this;
	}
	
	@Override
	public int getOccuranceOfKey() {
		return occuranceOfKey;
	}
	
	public MultiStringKey setOccuranceOfKey(int occuranceOfKey) {
		this.occuranceOfKey = occuranceOfKey;
		return this;
	}
	
	public boolean getInverseSearchDirection() {
		return inverseSearchDirection;
	}

	public MultiStringKey setInverseSearchDirection(boolean inverseSearchDirection) {
		this.inverseSearchDirection = inverseSearchDirection;
		return this;
	}
	
	public KeyStructure getKeyStructure() {
		return keyStructure;
	}
	
	public MultiStringKey setKeyStructure(KeyStructure keyStructure) {
		this.keyStructure = keyStructure;
		return this;
	}
	
	public boolean isSearchInKeyPrecedence() {

		return isSearchInKeyPrecedence;
	}

	public MultiStringKey setSearchInKeyPrecedence(boolean isSearchInKeyPrecedence) {

		this.isSearchInKeyPrecedence = isSearchInKeyPrecedence;
		return this;
	}

	public String toString() {
		return "MultiStringContextKey: key - " + keys;
	}
}