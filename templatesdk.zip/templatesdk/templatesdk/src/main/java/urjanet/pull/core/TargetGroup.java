package urjanet.pull.core;

import java.util.List;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;

/**
 *
 * @author rburson
 */
public interface TargetGroup {

	public List<? extends DataTarget> getDataTargets();
	public List<? extends NavTarget> getNavTargets();
	public GroupPolicy getGroupPolicy();
	public DataTarget asBaseDataTarget();

}
