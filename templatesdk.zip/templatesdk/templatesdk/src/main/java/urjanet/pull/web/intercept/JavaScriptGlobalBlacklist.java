package urjanet.pull.web.intercept;

import java.net.URL;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

public class JavaScriptGlobalBlacklist {
	
	private static final HashSet<String> blacklistedDomains = new HashSet<String>();
	
	private static final HashSet<String> blacklistedURLKeys = new HashSet<String>();
	
	static {
		
		blacklistedDomains.add("liveperson.net");
		blacklistedDomains.add("googlesyndication.com");
		blacklistedDomains.add("crazyegg.com");
		blacklistedDomains.add("answerscloud.com");
		blacklistedDomains.add("addthis.com");
		blacklistedDomains.add("appspot.com");
		blacklistedDomains.add("qualtrics.com");
		blacklistedDomains.add("adobedtm.com");
		blacklistedDomains.add("cse.google.com");
		blacklistedDomains.add("google-analytics.com");
		blacklistedDomains.add("quantserve.com");
		blacklistedDomains.add("scorecardresearch.com");
        blacklistedDomains.add("optimizely.com");
        blacklistedDomains.add("opinionlab.com");
        blacklistedDomains.add("newrelic.com");
        blacklistedDomains.add("marketo.com");
        blacklistedDomains.add("visualwebsiteoptimizer.com");
        blacklistedDomains.add("googletagmanager.com");
        blacklistedDomains.add("woopra.com");
        blacklistedDomains.add("mouseflow.com");
        blacklistedDomains.add("assets.zendesk.com");
        blacklistedDomains.add("bat.bing.com");
	}
	
	static {
		blacklistedURLKeys.add("_incapsula_resource?swjiylwa=");
	}
	
	public static boolean isBlacklisted(URL url) {
		
		return (isBlackListURL(url.getHost(), blacklistedDomains) || isBlackListURL(url.toString(), blacklistedURLKeys));
	}
	
	public static boolean isBlackListURL(String url, HashSet<String> blackListedSet) {
		
		url = StringUtils.lowerCase(url);
		if (StringUtils.isEmpty(url))
			return false;

		for (String d : blackListedSet) {
			
			if (url.contains(d))
				return true;
		}
				
		return false;
	}

}
