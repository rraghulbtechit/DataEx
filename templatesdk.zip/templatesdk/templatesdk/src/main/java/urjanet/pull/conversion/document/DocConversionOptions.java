package urjanet.pull.conversion.document;

import java.util.HashMap;

/**
 * 
 * @author sriram
 *
 * Options for PDF to TETML (XML) conversion
 */
public class DocConversionOptions {
	private double splitX;
	private double splitY;
	private String includebox;
	private String excludebox;
	private String docstyle;
	private int supertablecolumns;
	private String layoutRowHint;
	private boolean skipImages;
	private String tableMerge;
	private int layoutDetect;
	private int tableDetect;
	private boolean punctuationBreaks;
	private String layoutEffort;
	private int startPage;
	private int endPage;
	private String stylePath;
	private HashMap<String, Object> styleParams;
	private boolean mergePass;
	private String fontSizeRange;
	
	public DocConversionOptions() {
		initOptions();
	}
	
	/**
	 * Initiatlize the default options
	 */
	public void initOptions() {
		splitX = 0;
		splitY = 0;
		includebox = null;
		excludebox = null;
		docstyle = "fancy";
		supertablecolumns = 2;
		layoutRowHint = "full separation=thin";
		skipImages = true;
		tableMerge = "updown";
		layoutDetect = 3;
		tableDetect = 2;
		punctuationBreaks = false;
		layoutEffort="high";
		setStyleParams(new HashMap<String, Object>());
		startPage = 1;
		endPage = 1;
		stylePath = "pdflibstylesheet/tetml2html.xsl";
		setMergePass(true);
		fontSizeRange = " fontsizerange={0 unlimited} ";
	}
	
	/**
	 * Get the configuration options as a String in the required format
	 * 
	 * @return String
	 */
	public String getPdfConfiguration() {
		String conf = "";
		conf += " granularity=word docstyle=" + docstyle;
		conf += fontSizeRange;
		conf += (skipImages)?" skipengines={image}":" ";
		conf += (includebox != null)?" includebox={"+includebox+"}":" ";
		conf += (excludebox != null)?" excludebox={"+excludebox+"}":" ";
		conf += (layoutEffort != null)?" layouteffort="+layoutEffort:" ";
		conf += " tetml={glyphdetails={geometry=true font=true}}";
		conf += " contentanalysis={punctuationbreaks="+punctuationBreaks+" dehyphenate=false}";
		conf += " layoutanalysis={layoutdetect="+layoutDetect+" tabledetect="+tableDetect+" mergetables="+tableMerge+" layoutastable=true";
		conf += " supertablecolumns="+supertablecolumns;
		conf += (splitX != 0 && splitY != 0)?" splithint={x="+splitX+" y="+splitY+"}":"";
		conf += (layoutRowHint != null)?" layoutrowhint={"+layoutRowHint+"}}":"}";
		conf += " structureanalysis={paragraph=true table=true}";		
		return conf;
	}
	
	public void setSplit(double x, double y) {
		splitX = (x>0)?x:0;
		splitY = (y>0)?y:0;
	}
	
	public void setPunctuationBreaks(boolean punctuation) {
		punctuationBreaks = punctuation;
	}
	
	public void setIncludeBox(String include) {
		includebox = include;
	}

	public void setExcludeBox(String exclude) {
		excludebox = exclude;
	}

	public void setLayoutRowHint(String rowHint) {
		layoutRowHint = rowHint;
	}
	
	public void setLayoutDetect(int layout) {
		layoutDetect = (layout>0)?layout:3;
	}

	public void setTableDetect(int table) {
		tableDetect = (table>0)?table:2;
	}

	public void setSuperTableColumns(int cols) {
		supertablecolumns = (cols>0)?cols:2;
	}

	public void setLayoutEffort(String layoutEffort) {
		this.layoutEffort = layoutEffort;
	}
	
	public void skipImages(boolean flag) {
		this.skipImages = flag;
	}

	public void setDocstyle(String docStyleVal) {
		this.docstyle = docStyleVal;
	}

	public void setTableMerge(String tableMergeVal) {
		this.tableMerge = tableMergeVal;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setStylePath(String stylePath) {
		this.stylePath = stylePath;
	}

	public String getStylePath() {
		return stylePath;
	}

	public void setStyleParams(HashMap<String, Object> styleParams) {
		this.styleParams = styleParams;
	}

	public HashMap<String, Object> getStyleParams() {
		return styleParams;
	}

	public void setMergePass(boolean mergePass) {
		this.mergePass = mergePass;
	}

	public boolean isMergePass() {
		return mergePass;
	}

	/**
	 * @return the fontSizeRange
	 */
	public String getFontSizeRange() {
		return fontSizeRange;
	}

	/**
	 * @param fontSizeRange the fontSizeRange to set
	 */
	public void setFontSizeRange(String fontSizeRange) {
		this.fontSizeRange = fontSizeRange;
	}
	
}
