package urjanet.pull.web;

import urjanet.pull.core.PageSpec;
import java.util.List;

/**
 * An ExpandableNavTarget only applies an emblematic distinction to a ClickableNavTarget.
 * It does not add any behavior. It does however, allow for the selection of multiple nodes to
 * be treated as ClickableNavTargets (a list of Links for example).  This is useful for navigating over a series of links that
 * lead to the same target page page but with different data.  For example, one might want to interate through a list of links that represent
 * different accounts but display the same page with different data for each account.
 * An instance of this class specifies that this ExpandableNavTarget will actually be
 * be a set of one or more ClickableNavTargets once the 'xpath' selector is applied to the page.
 * That is, it can be assumed that the xpath statement will select multiple nodes which will then each become
 * a single ClickableNavTarget
 *<p>
 * The expansion for ExpandableNavTarget is handled by NavTargetHandler
 *<p>
 * This class is similar to ExpandableDataTarget and ExpandableInputElement
 *
 * @author rburson
 * @see ExpandableNavTarget
 * @see ExpandableInputElement
 * @see NavTargetHandler
 */
public class ExpandableNavTarget extends ClickableNavTarget{
	
	private boolean doNotUseAbsoluteXPath;

	public ExpandableNavTarget() {
	}

	public ExpandableNavTarget(PageSpec targetPageSpec, String xpathTarget) {
		super(targetPageSpec, xpathTarget);
	}

	public ExpandableNavTarget(PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements) {
		super(targetPageSpec, xpathTarget, inputElements);
	}

	public ExpandableNavTarget(PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements, boolean concurrentAccessOk) {
		super(targetPageSpec, xpathTarget, inputElements, concurrentAccessOk);
	}

	public ExpandableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget, boolean concurrentAccessOk) {
		super(groupPolicy, targetPageSpec, xpathTarget, concurrentAccessOk);
	}

	public ExpandableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget) {
		super(groupPolicy, targetPageSpec, xpathTarget);
	}

	public ExpandableNavTarget(GroupPolicy groupPolicy, PageSpec targetPageSpec, String xpathTarget, List<? extends InputElement> inputElements, boolean concurrentAccessOk) {
		super(groupPolicy, targetPageSpec, xpathTarget, inputElements, concurrentAccessOk);
	}

	public boolean isDoNotUseAbsoluteXPath() {
		return doNotUseAbsoluteXPath;
	}

	public ExpandableNavTarget setDoNotUseAbsoluteXPath(boolean doNotUseAbsoluteXPath) {
		this.doNotUseAbsoluteXPath = doNotUseAbsoluteXPath;
		return this;
	}


}
