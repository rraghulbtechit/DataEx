package urjanet.pull.bool;

import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.DataTargetQualifier;

public class OrDataTargetQualifier extends BaseDataTargetQualifier {
	
	private DataTargetQualifier c1;
	private DataTargetQualifier c2;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private OrDataTargetQualifier() {

	}

	public OrDataTargetQualifier(String qualifierName, DataTargetQualifier c1, DataTargetQualifier c2, DataTargetQualifier... others) {
		super(qualifierName);

		if (others == null || others.length == 0) {
			this.c1 = c1;
			this.c2 = c2;
			return;
		}

		OrDataTargetQualifier q1 = new OrDataTargetQualifier(c1, c2);
		for (int i = 0; i < others.length - 1; i++) {
			q1 = new OrDataTargetQualifier(q1, others[i]);
		}
		this.c1 = q1;
		this.c2 = others[others.length - 1];
	}

	public OrDataTargetQualifier(String qualifierName, DataTargetQualifier c1, DataTargetQualifier c2) {
		this(qualifierName, c1, c2, (DataTargetQualifier[]) null);
	}

	public OrDataTargetQualifier(DataTargetQualifier c1, DataTargetQualifier c2, DataTargetQualifier... others) {
		this(null, c1, c2, others);
	}

	public OrDataTargetQualifier(DataTargetQualifier c1, DataTargetQualifier c2) {
		this(c1, c2, (DataTargetQualifier[]) null);
	}

	public DataTargetQualifier getC1() {
		return c1;
	}

	public OrDataTargetQualifier setC1(DataTargetQualifier c1) {
		this.c1 = c1;
		return this;
	}

	public DataTargetQualifier getC2() {
		return c2;
	}

	public OrDataTargetQualifier setC2(DataTargetQualifier c2) {
		this.c2 = c2;
		return this;
	}
	
}
