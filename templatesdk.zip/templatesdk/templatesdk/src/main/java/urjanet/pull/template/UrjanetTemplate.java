package urjanet.pull.template;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface UrjanetTemplate {

	//url is a required annotation for UrjanetTemplate
	String url();
	
	//This string array defines the ProviderIds which this template is the default template for
	String[] defaultTemplateProvider() default {};
	
	//This is a way to group templates together for the purpose of assigning them properly when a jira ticket is created for it
	//For example, the same ticket should be created for a PDF Extraction ticket for a provider even if it comes from different templates
	//that's because the template represents the navigation, but the extraction may be the same for multiple templates
	String extractionAssignmentKey() default "";
	
}
