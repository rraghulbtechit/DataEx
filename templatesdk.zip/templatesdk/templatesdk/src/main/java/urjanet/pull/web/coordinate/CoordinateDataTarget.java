package urjanet.pull.web.coordinate;

import java.util.List;

import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;

public class CoordinateDataTarget extends DataTarget {
	
	private CoordinateTargetDefinition coordinateTargetDefinition;
	
	private int pageNumber = 0;
	

	public CoordinateDataTarget() {
	}
	
	public CoordinateDataTarget(String name){
		super(name);
	}

	public CoordinateDataTarget(CoordinateTargetDefinition coordinateTargetDefinition, String name){
		super(name);
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}

	public CoordinateDataTarget(CoordinateTargetDefinition coordinateTargetDefinition, GroupPolicy groupPolicy, String name) {
		super(groupPolicy, name);
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}

	/**
	 *
	 * Create a new XmlDataTarget without any sub-targets
	 *
	 * @param name the name (or key) of this target value
	 * @param xPath the xpath to this target value
	 * @param operator a list of ExtractOperators, applied to the target value
	 */
	public CoordinateDataTarget(CoordinateTargetDefinition coordinateTargetDefinition, String name, ExtractOperator operator) {
		super(name, operator);
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}


	public CoordinateDataTarget(CoordinateTargetDefinition coordinateTargetDefinition, List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}


	public CoordinateDataTarget(CoordinateTargetDefinition coordinateTargetDefinition, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}
	
	public CoordinateDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
	}
	
	public CoordinateDataTarget(List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
	}

	public CoordinateTargetDefinition getCoordinateTargetDefinition() {
		return coordinateTargetDefinition;
	}

	public void setCoordinateTargetDefinition(
			CoordinateTargetDefinition coordinateTargetDefinition) {
		this.coordinateTargetDefinition = coordinateTargetDefinition;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	
	@Override
	public CoordinateDataTarget setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

	@Override
	public CoordinateDataTarget setFormatHint(String formatHint) {
		this.formatHint = formatHint;
		return this;
	}

	@Override
	public CoordinateDataTarget setQualifier(DataTargetQualifier qualifier) {
		this.qualifier = qualifier;
		return this;
	}

	@Override
	public CoordinateDataTarget setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
		return this;
	}

	@Override
	public CoordinateDataTarget setGroupingTarget(boolean groupingTarget) {
		this.groupingTarget = groupingTarget;
		return this;
	}

	@Override
	public CoordinateDataTarget setVariable(String variableName) {
		this.variableName = variableName;
		return this;
	}

	@Override
	public CoordinateDataTarget setDefaultValue(String... defaultValue) {
		String tempValue = defaultValue[0];
		
		for(int i = 1; i < defaultValue.length; i++)
			tempValue += "||" + defaultValue[i];
		
		return this;
	}

}
