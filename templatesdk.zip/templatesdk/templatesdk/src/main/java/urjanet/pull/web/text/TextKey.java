package urjanet.pull.web.text;

public class TextKey {
	
	private int lineNumber;
	private int wordNumber;
	
	//This constructor will be called in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private TextKey() {
		
	}
	
	public TextKey(int lineNum, int wordNum) {
		this.lineNumber = lineNum;
		this.wordNumber = wordNum;
	}
	
	public int getLineNumber() {
		return this.lineNumber;
	}

	/**
	 * @param lineNumber the lineNumber to set
	 */
	public TextKey setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
		return this;
	}
	
	public int getWordNumber() {
		return this.wordNumber;
	}

	/**
	 * @param wordNumber the wordNumber to set
	 */
	public TextKey setWordNumber(int wordNumber) {
		this.wordNumber = wordNumber;
		return this;
	}

}
