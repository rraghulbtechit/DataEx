package urjanet.pull.web;

public enum AjaxProcessing {

	ASYNCHRONOUS,					// all Ajax calls are to be executed asynchronously
									// navigation may continue before all calls ajax calls have been made
	
	SYNCHRONOUS,					// synchronize all ajax calls to main executing thread
									// navigation waits until these ajax calls are completed before continuing
	
	USER_ACTION_SYNCHRONOUS			// DEFAULT. synchronize ajax calls created from main execution thread (direct result of user input)
									// navigation waits until these specific ajax calls are completed before continuing
}
