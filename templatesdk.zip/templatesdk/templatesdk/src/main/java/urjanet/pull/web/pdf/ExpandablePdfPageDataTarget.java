package urjanet.pull.web.pdf;

import java.util.List;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;

public class ExpandablePdfPageDataTarget extends PdfPageDataTarget {
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private ExpandablePdfPageDataTarget() {
		
	}
	
	public ExpandablePdfPageDataTarget(int startPage, int endPage, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(startPage, endPage, groupPolicy, relativeDataTargets);
	}
	
	public ExpandablePdfPageDataTarget(int startPage, int endPage, List<? extends DataTarget> relativeDataTargets) {
		super(startPage, endPage, relativeDataTargets);
	}
	
	public ExpandablePdfPageDataTarget(int pageNumber, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(pageNumber, 0, groupPolicy, relativeDataTargets);
	}
	
	public ExpandablePdfPageDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		super(groupPolicy, relativeDataTargets);
	}
	
	public ExpandablePdfPageDataTarget(int pageNumber, List<? extends DataTarget> relativeDataTargets) {
		super(pageNumber, 0, relativeDataTargets);
	}

	public ExpandablePdfPageDataTarget(List<? extends DataTarget> relativeDataTargets) {
		super(relativeDataTargets);
	}

}
