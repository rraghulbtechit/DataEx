package urjanet.pull.enrollment.util.keys;

public enum Directory {
	/**
	 * Common base directory for dumping bills
	 */
	BASE_DIRECTORY("/opt/enrollment/"),
	
	/**
	 * Holds the files to be processed.
	 */
	OUTPUT_DIRECTORY("output-files");
	
	private final String type;	

	private Directory (String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
}
