package urjanet.pull.web;

/**
 * 
 * @author xavierd
 *
 */
public enum WebClientInstance {
	
	SINGLE, MULTIPLE;
}
