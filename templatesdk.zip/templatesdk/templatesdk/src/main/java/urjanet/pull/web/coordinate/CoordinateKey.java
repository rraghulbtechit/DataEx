package urjanet.pull.web.coordinate;


public class CoordinateKey {
	
	/**
	 * Should have a field that says whether this key is mandatory
	 * if it is, then if not found, will throw an error
	 * if not, then if not found, just set the index to 0 or if an end key to the end of the wordlist
	 * @author tim
	 *
	 */
	public static enum KeyStructure {PROXIMITY, IN_ORDER, INDEXED};
	
	public static enum KeyIncludePattern {INCLUDE_KEY, EXCLUDE_KEY, INCLUDE_LINE, EXCLUDE_LINE};
	
	/**
	 * TODO add a number of contexts to look behind
	 * @author tim
	 *
	 */
	public static enum KeySearchPattern {OUTSIDE_CONTEXT_AFTER, OUTSIDE_CONTEXT_BEFORE, LAST_CONTEXT_BEFORE, INSIDE_CONTEXT};
	
	public static enum KeySeperationPattern {WORD, PHRASE, LINE};
	
	private String key;
	private KeyStructure keyStructure;
	private KeyIncludePattern includePattern;
	private KeySearchPattern searchPattern;
	private KeySeperationPattern seperationPattern;
	
	private int lineNumber, wordNumber;
	
	public CoordinateKey(String key, KeyStructure keyStructure, KeyIncludePattern includePattern, KeySearchPattern searchPattern) {
		super();
		this.key = key;
		this.keyStructure = keyStructure;
		this.includePattern = includePattern;
		this.searchPattern = searchPattern;
		this.seperationPattern = KeySeperationPattern.WORD;
	}
	
	public CoordinateKey(String key, KeyStructure keyStructure, KeySearchPattern searchPattern) {
		super();
		this.key = key;
		this.keyStructure = keyStructure;
		this.includePattern = KeyIncludePattern.EXCLUDE_KEY;
		this.searchPattern = searchPattern;
		this.seperationPattern = KeySeperationPattern.WORD;
		}
	
	public CoordinateKey(String key, KeyStructure keyStructure, KeyIncludePattern includePattern) {
		super();
		this.key = key;
		this.keyStructure = keyStructure;
		this.includePattern = includePattern;
		this.searchPattern = KeySearchPattern.INSIDE_CONTEXT;
		this.seperationPattern = KeySeperationPattern.WORD;
	}
	
	public CoordinateKey(String key, KeyIncludePattern includePattern) {
		this(key, KeyStructure.IN_ORDER, includePattern, KeySearchPattern.INSIDE_CONTEXT);
	}
	public CoordinateKey(String key, KeyIncludePattern includePattern, KeySearchPattern keySearchPattern) {
		this(key, KeyStructure.IN_ORDER, includePattern, keySearchPattern);
	}
	
	public CoordinateKey(String key, KeySearchPattern keySearchPattern) {
		this(key, KeyStructure.IN_ORDER, KeyIncludePattern.EXCLUDE_KEY, keySearchPattern);
	}
	
	public CoordinateKey(String key, KeyStructure keyStructure) {
		super();
		this.key = key;
		this.keyStructure = keyStructure;
		this.includePattern = KeyIncludePattern.EXCLUDE_KEY;
		this.searchPattern = KeySearchPattern.INSIDE_CONTEXT;
		this.seperationPattern = KeySeperationPattern.WORD;
	}
	
	public CoordinateKey(String key) {
		this.key = key;
		this.keyStructure = KeyStructure.IN_ORDER;
		this.includePattern = KeyIncludePattern.EXCLUDE_KEY;
		this.searchPattern = KeySearchPattern.INSIDE_CONTEXT;
		this.seperationPattern = KeySeperationPattern.WORD;
	}
	
	public CoordinateKey(int lineNumber, int wordNumber) {
		this.lineNumber = lineNumber;
		this.wordNumber = wordNumber;
		this.keyStructure = KeyStructure.INDEXED;
		this.seperationPattern = KeySeperationPattern.WORD;
	}
	
	public CoordinateKey(int lineNumber, int wordNumber, KeySeperationPattern seperationPattern) {
		this.lineNumber = lineNumber;
		this.wordNumber = wordNumber;
		this.keyStructure = KeyStructure.INDEXED;
		this.seperationPattern = seperationPattern;
	}

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private CoordinateKey() {
		
	}
	
	public String getKey() {
		return key;
	}

	public CoordinateKey setKey(String key) {
		this.key = key;
		return this;
	}

	public KeyStructure getKeyStructure() {
		return keyStructure;
	}

	public CoordinateKey setKeyStructure(KeyStructure keyStructure) {
		this.keyStructure = keyStructure;
		return this;
	}

	public KeyIncludePattern getIncludePattern() {
		return includePattern;
	}

	public CoordinateKey setIncludePattern(KeyIncludePattern includePattern) {
		this.includePattern = includePattern;
		return this;
	}

	public KeySearchPattern getSearchPattern() {
		return searchPattern;
	}

	public CoordinateKey setSearchPattern(KeySearchPattern searchPattern) {
		this.searchPattern = searchPattern;
		return this;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public CoordinateKey setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
		return this;
	}

	public int getWordNumber() {
		return wordNumber;
	}

	public CoordinateKey setWordNumber(int wordNumber) {
		this.wordNumber = wordNumber;
		return this;
	}

	public KeySeperationPattern getSeperationPattern() {
		return seperationPattern;
	}

	public CoordinateKey setSeperationPattern(KeySeperationPattern seperationPattern) {
		this.seperationPattern = seperationPattern;
		return this;
	}
	
}
