package urjanet.pull.web;

/**
 * 
 * @author wowens
 *
 */
public abstract class BaseDataTargetQualifier implements DataTargetQualifier {

	protected String name;
	
	protected BaseDataTargetQualifier() {
		
	}
	
	public BaseDataTargetQualifier(String qualifierName) {
		this.name = qualifierName;
	}
	
	public String getName() {
		return name;
	}
	
	public BaseDataTargetQualifier setName(String name) {
		this.name = name;
		return this;
	}
}
