package urjanet.pull.bool;

import urjanet.event.TrackingNavigationEventCode;

/**
 * @author xavierd
 *
 */
public class TrackingNavigationEventPageCondition implements PageCondition {

	private PageCondition condition; 
	private TrackingNavigationEventCode eventCode;
	
	//This constructor for Hit usage.
	@SuppressWarnings("unused")
	private TrackingNavigationEventPageCondition() {
		
	}
	
	public TrackingNavigationEventPageCondition(TrackingNavigationEventCode eventCode, PageCondition condition) {
		this.setEventCode(eventCode);
		this.setCondition(condition);
	}

	public PageCondition getCondition() {
		return condition;
	}

	public TrackingNavigationEventPageCondition setCondition(PageCondition condition) {
		this.condition = condition;
		return this;
	}

	public TrackingNavigationEventCode getEventCode() {
		return eventCode;
	}

	public TrackingNavigationEventPageCondition setEventCode(TrackingNavigationEventCode eventCode) {
		this.eventCode = eventCode;
		return this;
	}
	
}
