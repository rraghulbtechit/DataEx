package urjanet.pull.web;

/**
 *
 * @author rburson
 */
public class XmlDataTargetQualifier extends BaseDataTargetQualifier{

	private DataTarget qualifyingTarget;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private XmlDataTargetQualifier() {

	}
	
	public XmlDataTargetQualifier(String qualifierName, DataTarget qualifyingTarget) {
		super(qualifierName);
		this.qualifyingTarget = qualifyingTarget;
	}
	
	public XmlDataTargetQualifier(DataTarget qualifyingTarget) {
		this(null, qualifyingTarget);
	}
	
	public DataTarget getQualifyingTarget() {
		return qualifyingTarget;
	}

	/**
	 * @param qualifyingTarget the qualifyingTarget to set
	 */
	public XmlDataTargetQualifier setQualifyingTarget(DataTarget qualifyingTarget) {
		this.qualifyingTarget = qualifyingTarget;
		return this;
	}

}
