package urjanet.pull.operator;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

import urjanet.regex.RegExHandler;

/**
 *
 * @author rburson
 */
public class RegExOperator implements ExtractOperator{

	private String regEx;
	private int groupCount = -1;

	//This constructor will be used in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private RegExOperator() {
		
	}
	
	public RegExOperator(String regEx) {
		this.regEx = regEx;
	}

	public RegExOperator(String regEx, int groupCount) {
		this.regEx = regEx;
		this.groupCount = groupCount;
	}
	
	public int getGroupCount() {
		return groupCount;
	}
	
	public RegExOperator setGroupCount(int groupCount) {
		this.groupCount = groupCount;
		return this;
	}

	public String getRegEx() {
		return regEx;
	}
	
	public RegExOperator setRegEx(String regEx) {
		this.regEx = regEx;
		return this;
	}
	
	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("RegExOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

		try {
			if (groupCount >= 0) {
				return new ExtractOperand( RegExHandler.extract( text, regEx, groupCount ) );
			}

			return new ExtractOperand( RegExHandler.extract( text, regEx ) );
		} catch (IndexOutOfBoundsException e) {
			throw new OperatorException( "Check the regex group count: " + groupCount + ". Regular expression error: " + regEx, e );
		} catch (Exception e) {
			throw new OperatorException( "Regular expression error: " + regEx, e );
		}
	}

}
