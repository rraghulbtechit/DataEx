package urjanet.pull.web;

import java.util.List;
import java.util.Map;

import urjanet.DataTargetType;
import urjanet.pull.core.BasePullJobTemplate;
import urjanet.pull.core.PageSpec;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.cache.CacheRule;

/**
 *
 * @author rburson
 */
public class WebPullJobTemplate extends BasePullJobTemplate {


	private NavTarget entryPointNavTarget;
	private int threads;
	private long delay;
	private String id;
	static final int CONNECT_TIMEOUT = 45000;
	
	private NavigationOptions defaultNavOptionOverrides = new NavigationOptions();

	private Map<DataTargetType, ExtractOperator> dataTypeOperatorMap;

	//This constructor will be used in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private WebPullJobTemplate() {

	}
	
	public WebPullJobTemplate(String entryPointUrl, PageSpec pageSpec, String id, String author, String revision) {
		this(entryPointUrl, pageSpec, id, 0, 0, author, revision);
	}

	public WebPullJobTemplate(String entryPointUrl, PageSpec pageSpec, String id, int threads, long delay, String author, String revision) {
		super(pageSpec, id, author, revision);
		this.id = id;
		this.entryPointNavTarget = new UrlNavTarget(pageSpec, entryPointUrl);
		this.threads = threads;
		this.delay = delay;
	}

	public WebPullJobTemplate(NavTarget entryPointNavTarget, String id, String author, String revision) {
		this(entryPointNavTarget, id, 0, 0, author, revision);
	}

	public WebPullJobTemplate(NavTarget entryPointNavTarget, String id, int threads, long delay, String author, String revision) {
		super(entryPointNavTarget.getTargetPageSpec(), id, author, revision);
		this.id = id;
		this.entryPointNavTarget = entryPointNavTarget;
		this.threads = threads;
		this.delay = delay;
	}
	
	public NavigationOptions getDefaultNavOptionOverrides() {
		return defaultNavOptionOverrides;
	}
	public void setDefaultNavOptionOverrides(NavigationOptions defaultNavOptionOverrides) {
		this.defaultNavOptionOverrides = defaultNavOptionOverrides;
	}

	public NavTarget getEntryPointNavTarget() {
		return entryPointNavTarget;
	}

	public WebPullJobTemplate setEntryPointNavTarget(NavTarget entryPointNavTarget) {
		this.entryPointNavTarget = entryPointNavTarget;
		return this;
	}

	public long getDelay() {
		return delay;
	}

	public WebPullJobTemplate setDelay(long delay) {
		this.delay = delay;
		return this;
	}

	public int getThreads() {
		return threads;
	}

	public WebPullJobTemplate setThreads(int threads) {
		this.threads = threads;
		return this;
	}

	public WebPullJobTemplate setId(String id) {
		this.id = id;
		return this;
	}

	@Override
	public String getId() {
		return id;
	}

	/**
	 * @param agentVersion the agentVersion to set
	 */
	public WebPullJobTemplate setAgentVersion(AgentVersion agentVersion) {
		defaultNavOptionOverrides.setAgentVersion(agentVersion);
		return this;
	}

	@Override
	public PageSpec getPageSpec(){
		return this.entryPointNavTarget.getTargetPageSpec();
	}

	public WebPullJobTemplate setIgnoreRefreshHeaders(boolean ignoreRefreshHeaders) {
		defaultNavOptionOverrides.setIgnoreSubsequentRefresh(ignoreRefreshHeaders);
		return this;
	}

	public WebPullJobTemplate setInterceptorName(String interceptorName) {
		defaultNavOptionOverrides.setInterceptorName(interceptorName);
		return this;
	}

	public WebPullJobTemplate setRetryOnScriptException(boolean retryOnScriptException) {
		defaultNavOptionOverrides.setRetryOnScriptException(retryOnScriptException);
		return this;
	}

	public WebPullJobTemplate setTimeout(int timeout) {
		defaultNavOptionOverrides.setTimeout(timeout);
		return this;
	}

	public WebPullJobTemplate setCacheRules(List<? extends CacheRule> cacheRules) {
		defaultNavOptionOverrides.setCacheRules(cacheRules);
		return this;
	}

	public WebPullJobTemplate setSslProtocol(String sslProtocol) {
		defaultNavOptionOverrides.setSslProtocol(sslProtocol);
		return this;
	}
	
	public WebPullJobTemplate setUseInsecureSSL(boolean useInsecureSSL) {
		defaultNavOptionOverrides.setUseInsecureSSL(useInsecureSSL);
		return this;
	}

	public WebPullJobTemplate setDisableAjaxController(boolean disableAjaxController) {
		defaultNavOptionOverrides.setDisableAjaxController(disableAjaxController);
		return this;
	}
	
	public WebPullJobTemplate setAjaxProcessing(AjaxProcessing ajaxProcessing) {
		defaultNavOptionOverrides.setAjaxProcessing(ajaxProcessing);
		return this;
	}

	public Map<DataTargetType, ExtractOperator> getDataTypeOperatorMap() {
		return dataTypeOperatorMap;
	}

	public WebPullJobTemplate setDataTargetOperatorMap(Map<DataTargetType, ExtractOperator> dataTargetOperatorMap) {
		this.dataTypeOperatorMap = dataTargetOperatorMap;
		return this;
	}
	
	@Deprecated
	public void setCookieAllowed(boolean cookieAllowed) {
		// TODO: does nothing...
	}

	/**
	 * @param disableExceptionOnScriptError the disableExceptionOnScriptError to set
	 */
	public WebPullJobTemplate setDisableExceptionOnScriptError(boolean disableExceptionOnScriptError) {
		defaultNavOptionOverrides.setDisableExceptionOnScriptError(disableExceptionOnScriptError);
		return this;
	}

	/**
	 * @param webClientInstance the webClientInstance to set
	 */
	public WebPullJobTemplate setWebClientInstance(WebClientInstance webClientInstance) {
		defaultNavOptionOverrides.setWebClientInstance(webClientInstance);
		return this;
	}

	public String getDisableTlsAlgorithm() {
		return defaultNavOptionOverrides.getDisableTlsAlgorithm();
	}

	public WebPullJobTemplate setDisableTlsAlgorithm(TlsAlgorithm ... disableTlsAlgorithm) {
		
		if(disableTlsAlgorithm != null && disableTlsAlgorithm.length > 0) {
			
			String algorithms = disableTlsAlgorithm[0].getName();
			for(int index = 1; index<disableTlsAlgorithm.length; index++) {
				String currentAlgorithm = disableTlsAlgorithm[index].getName();
				if(currentAlgorithm.startsWith("keySize")) {
					algorithms = algorithms + " " + currentAlgorithm;
				} else {
					algorithms = algorithms + ", " + currentAlgorithm;
				}
			}
			defaultNavOptionOverrides.setDisableTlsAlgorithm(algorithms);
		}
		
		return this;
	}	

	public WebPullJobTemplate setUseThreadRefreshHandler(boolean isUseThreadRefreshHandler) {
		defaultNavOptionOverrides.setUseThreadRefreshHandler(isUseThreadRefreshHandler);
		return this;
	}
	
	public WebPullJobTemplate setCssEnabled(boolean isCssEnabled) {
		defaultNavOptionOverrides.setCssEnabled(isCssEnabled);
		return this;
	}
}
