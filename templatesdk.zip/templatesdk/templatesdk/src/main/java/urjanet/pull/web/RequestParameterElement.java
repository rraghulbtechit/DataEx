package urjanet.pull.web;

public class RequestParameterElement extends VariableInputElement {
	
	private String paramName;
	
	//This constructor will be called from Hit to create an instance through Reflection.
	@SuppressWarnings("unused")
	private RequestParameterElement() {
		
	}
	
	public RequestParameterElement(String paramName, String inputName) {
		super(null, inputName);
		this.paramName = paramName;
	}

	public String getParamName() {
		return paramName;
	}

	public RequestParameterElement setParamName(String paramName) {
		this.paramName = paramName;
		return this;
	}
}
