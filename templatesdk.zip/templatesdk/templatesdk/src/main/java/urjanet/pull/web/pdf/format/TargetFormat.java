package urjanet.pull.web.pdf.format;


public abstract class TargetFormat {

	//public abstract boolean endOfTarget(T left, T right);
}
