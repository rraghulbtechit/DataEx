package urjanet.pull.web.pdf.context;


public class TargetContext {
	
	public static enum TargetContextDirection {

        /**
         *
         * <pre>
         * |____|
         * |    |
         * | #3 | <-- #stack_top/#here
         * |____|
         * |    |
         * | #2 | <-- 1. picks a context in stack based on relative #stack_top - {@link #depth} ( 3 - 1 )
         * |____|     2. get the words after/below the match context
         * |    |
         * | #1 |
         * |____|
         *
         *  __________________________________________________
         * |#1                                                |
         * |                  _________________               |
         * |                 |#2               |              |
         * |                 |                 |              |
         * |                 | ______________  |              |
         * |                 ||#3            | |              |
         * |                 ||#here         | |              |
         * |                 ||#stack_top    | |              |
         * |                 ||______________| |              |
         * |                 |.................|              |
         * |                 |.#target_context.|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.................|              |
         * |                 |_________________|              |
         * |                                                  |
         * |__________________________________________________|
         *
         * </pre>
         *
         *
         */
        AFTER_CONTEXT,

        /**
         *
         * <pre>
         * |____|
         * |    |
         * | #3 | <-- #stack_top/#here
         * |____|
         * |    |
         * | #2 | <-- 1. picks a context in stack based on relative #stack_top - {@link #depth} = 3 - 1
         * |____|     2. get the words before/above the match context
         * |    |
         * | #1 |
         * |____|
         *
         *
         *  __________________________________________________
         * |#1                                                |
         * |                  __________________              |
         * |                 |#2                |             |
         * |                 |..................|             |
         * |                 |.#target_context .|             |
         * |                 |.                .|             |
         * |                 |.                .|             |
         * |                 |.                .|             |
         * |                 |................ .|             |
         * |                 | _______________  |             |
         * |                 ||#3             | |             |
         * |                 ||#here          | |             |
         * |                 ||#stack_top     | |             |
         * |                 ||_______________| |             |
         * |                 |                  |             |
         * |                 |                  |             |
         * |                 |                  |             |
         * |                 |                  |             |
         * |                 |                  |             |
         * |                 |                  |             |
         * |                 |__________________|             |
         * |                                                  |
         * |__________________________________________________|
         *
         * </pre>
         */
         BEFORE_CONTEXT,

        /**
         *
         * <pre>
         * |____|
         * |    |
         * | #3 | <-- #stack_top/#here
         * |____|
         * |    |
         * | #2 | <-- picks a context in stack based on relative #stack_top - {@link #depth} = 3 - 1
         * |____|
         * |    |
         * | #1 |
         * |____|
         *
         *  __________________________________________________
         * |#1                                                |
         * |                  _________________               |
         * |                 |#2               |              |
         * |                 |............... .|              |
         * |                 |.#target_context.|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |. ____________  .|              |
         * |                 |.|#3          | .|              |
         * |                 |.|#here       | .|              |
         * |                 |.|#stack_top  | .|              |
         * |                 |.|____________| .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |.               .|              |
         * |                 |............... .|              |
         * |                 |_________________|              |
         * |                                                  |
         * |__________________________________________________|
         *
         * </pre>
         *
         */
        CURRENT_CONTEXT,

        /**
         *
         * <pre>
         * |____|
         * |    |
         * | #3 | <-- #stack_top/#here
         * |____|
         * |    |
         * | #2 |
         * |____|
         * |    |
         * | #1 | <-- picks a context in stack based on absolute {@link #depth} = 1
         * |____|
         *
         *  __________________________________________________ 
         * |#1                                                |
         * |..................................................|
         * |. #target_context ________________               .|
         * |.                |#2              |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |  ____________  |              .|
         * |.                | |#3          | |              .|
         * |.                | |#here       | |              .|
         * |.                | |#stack_top  | |              .|
         * |.                | |____________| |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |                |              .|
         * |.                |________________|              .|
         * |..................................................|                                                 
         * |__________________________________________________|
         *
         * </pre>
         */
         TARGET_CONTEXT_DEPTH,
         
         /**
          * Look up the context based on the label marked in the context.
          */
         TARGET_CONTEXT_LABEL
	};
	
	private int depth;
	private TargetContextDirection targetContext;
	private boolean restrictedContextDelta;
	private String contextLabel;
	
	public TargetContext() {
		this.targetContext = TargetContextDirection.CURRENT_CONTEXT;
		this.depth = 0;
	}
	
	public TargetContext(final String contextLabel) {
		this.contextLabel = contextLabel;
		this.targetContext = TargetContextDirection.TARGET_CONTEXT_LABEL;
	}
	
	public TargetContext(TargetContextDirection behavior, int depth) {
		this.targetContext = behavior;
		this.depth = depth;
	}
	
	public TargetContext(TargetContextDirection behavior, int depth, boolean restrictedContextDelta) {
		this.targetContext = behavior;
		this.depth = depth;
		this.restrictedContextDelta = restrictedContextDelta;
	}

	public int getDepth() {
		return depth;
	}

	public TargetContext setDepth(int depth) {
		this.depth = depth;
		return this;
	}

	public TargetContextDirection getTargetContext() {
		return targetContext;
	}

	public TargetContext setTargetContext(TargetContextDirection targetContext) {
		this.targetContext = targetContext;
		return this;
	}

	public static TargetContext getLastBeforeContext() {
		return new TargetContext(TargetContextDirection.BEFORE_CONTEXT, 1);
	}

	public boolean isRestrictedContextDelta() {
		return restrictedContextDelta;
	}

    /**
     * Used to restrict the context to the delta of words from {@link #depth} + 1 context to {@link #depth}
     */
	public TargetContext setRestrictedContextDelta(boolean restrictedContextDelta) {
		this.restrictedContextDelta = restrictedContextDelta;
		return this;
	}

	public String getContextLabel() {
		return contextLabel;
	}

	public TargetContext setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
		return this;
	}

}
