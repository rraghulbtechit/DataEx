package urjanet.pull.enrollment.util;

import org.apache.commons.lang.StringUtils;

public class StringManupulationUtil {

	public static String addLeadingZeros(String string , int size) {
		return ( string != null ? StringUtils.leftPad(string, size, "0") : null );
	}

	public static String trimToFixedLength(String string , int size) {
		return ( string != null ? string.substring(0, size) : null );
	}

	public static String removeLastDigit(String string) {
		return ( string != null ? string.substring(0,string.length() - 1) : null );
	}
	
	public static String removeLeadingZeros(String string){
		return ( string != null ? string.replaceFirst("^0+(?!$)", "") : null );
	}
}
