package urjanet.pull.web.pdf.key;

public class StringKey extends WordContextKey {
	
	protected String key;
	protected KeyStructure structure;
	private String fontRegEx;
	
	private boolean inverseSearchDirection = false;
	
	//This constructor will be called from Hit to create an instance through reflection.
	protected StringKey() {
		
	}
	
	/**
	 * 
	 * @param key - Whole word(s) to search for. If you are searching on PART of a word, use RegExKey instead
	 * @param structure
	 * @param n - 0-indexed occurrence of key
	 */
	public StringKey(String key, KeyStructure structure, int n) {
		super();
		this.key = key;
		this.structure = structure;
		this.occuranceOfKey = n;
	}
	/**
	 * 
	 * @param key - Whole word(s) to search for. If you are searching on PART of a word, use RegExKey instead
	 * @param structure
	 */
	public StringKey(String key, KeyStructure structure) {
		this(key, structure, 0);
	}
	/**
	 * 
	 * @param key - Whole word(s) to search for. If you are searching on PART of a word, use RegExKey instead
	 * @param n - 0-indexed occurrence of key
	 */
	public StringKey(String key, int n) {
		this(key, KeyStructure.IN_ORDER, n);
	}
	
	/**
	 * 
	 * @param key - Whole word(s) to search for. If you are searching on PART of a word, use RegExKey instead
	 */
	public StringKey(String key) {
		this(key, KeyStructure.IN_ORDER, 0);
	}
	
	public String getKey() {
		return key;
	}

	public StringKey setKey(String key) {
		this.key = key;
		return this;
	}
	
	public String getFontRegEx() {
		return fontRegEx;
	}

	/**
	 *
	 * Search for the key, whose font matches the given fontRegEx.
	 * Supports partial regex match.
	 * <p>
	 * Eg: 'Bold' will match 'ArialBold'
	 *
	 * @param fontRegEx
	 * @return StringKey
	 */
	public StringKey setFontRegEx(String fontRegEx) {
		this.fontRegEx = fontRegEx;
		return this;
	}
	
	public int getOccurrenceOfKey() {
		return occuranceOfKey;
	}
	
	public StringKey setOccuranceOfKey(int occuranceOfKey) {
		this.occuranceOfKey = occuranceOfKey;
		return this;
	}
	
	public KeyStructure getStructure() {
		return structure;
	}
	
	public StringKey setStructure(KeyStructure structure) {
		this.structure = structure;
		return this;
	}
	
	public boolean getInverseSearchDirection() {
		return inverseSearchDirection;
	}

	public StringKey setInverseSearchDirection(boolean inverseSearchDirection) {
		this.inverseSearchDirection = inverseSearchDirection;
		return this;
	}
	
	public boolean isProximity() {
		if(structure == KeyStructure.PROXIMITY) {
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return "StringContextKey: key - " + key + ", KeyStructure - " + structure.name();
	}
	
}
