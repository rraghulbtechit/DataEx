package urjanet.pull.selenium.util;

public enum ReturnStatus {

	SESSION_TIME_OUT(-1),
	SUCCESS(0),
	FAILURE(1);

	private final int returnCode;

	private ReturnStatus(int returnCode) {

		this.returnCode = returnCode;
	}
}
