package urjanet.pull.web.text;

import java.util.List;

import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.GroupPolicy;

public class ExpandableTextDataTarget extends TextDataTarget {
	
	private int index;
	private String endLabel;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private ExpandableTextDataTarget() {
		
	}
	
	public ExpandableTextDataTarget(GroupPolicy groupPolicy, String searchLabel, List<TextDataTarget> relativeDataTargets) {
		super(groupPolicy, null, searchLabel, relativeDataTargets);
		this.setIndex(-1);
	}
	
	public ExpandableTextDataTarget(String searchLabel, List<TextDataTarget> relativeDataTargets) {
		super(searchLabel, relativeDataTargets);
		this.setIndex(-1);
	}

	public ExpandableTextDataTarget(String searchLabel, String endLabel, List<TextDataTarget> relativeDataTargets) {
		super(searchLabel, relativeDataTargets);
		this.setEndLabel(endLabel);
		this.setIndex(-1);
	}
	
	public ExpandableTextDataTarget(GroupPolicy groupPolicy, String searchLabel, int index, List<TextDataTarget> relativeDataTargets) {
		super(groupPolicy, null, searchLabel, relativeDataTargets);
		this.setIndex(index);
	}
	
	public ExpandableTextDataTarget(String searchLabel, int index, List<TextDataTarget> relativeDataTargets) {
		super(searchLabel, relativeDataTargets);
		this.setIndex(index);
	}
	
	public ExpandableTextDataTarget(String searchLabel, int index, String name) {
		super(name, searchLabel);
		this.setIndex(index);
	}

	public ExpandableTextDataTarget(String name, String searchLabel, int index, ExtractOperator operator) {
		super(name, searchLabel, operator);
		this.setIndex(index);
	}

	public int getIndex() {
		return index;
	}
	
	public ExpandableTextDataTarget setIndex(int index) {
		this.index = index;
		return this;
	}

	public ExpandableTextDataTarget setEndLabel(String endLabel) {
		this.endLabel = endLabel;
		return this;
	}

	public String getEndLabel() {
		return endLabel;
	}
	
}
