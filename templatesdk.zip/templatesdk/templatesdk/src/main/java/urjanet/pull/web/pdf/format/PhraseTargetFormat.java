package urjanet.pull.web.pdf.format;

public class PhraseTargetFormat extends WordTargetFormat {

	public static final double DEFAULT_SPACING = 0.60;
	
	private double spacing;
	
	public PhraseTargetFormat(double spacing) {
		this.spacing = spacing;
	}

	public PhraseTargetFormat() {
		this(DEFAULT_SPACING);
	}

	public double getSpacing() {
		return spacing;
	}

	/**
	 * @param spacing the spacing to set
	 */
	public PhraseTargetFormat setSpacing(double spacing) {
		this.spacing = spacing;
		return this;
	}

}
