package urjanet.pull.web;

/**
 *
 * @author rburson
 */
public enum AgentVersion {

	@Deprecated
	FIREFOX_2, 
	
	@Deprecated
	FIREFOX_3, 
	
	@Deprecated
	FIREFOX_3_6,
	
	FIREFOX_38,
	
	/**
	 * This version always holds the latest firefox browser version.
	 * Now the latest version is Firefox_38
	 */
	FIREFOX,
	
	@Deprecated
	INTERNET_EXPLORER_6, 
	
	@Deprecated
	INTERNET_EXPLORER_7, 
	
	@Deprecated
	INTERNET_EXPLORER_8,
	
	@Deprecated
	INTERNET_EXPLORER_11,
	
	/**
	 * This version always holds the latest IE browser version.
	 * Now the latest version is IE11
	 */
	INTERNET_EXPLORER,
	
	@Deprecated
	CHROME_16,
	
	/**
	 * This version always holds the latest Chrome browser version.
	 * Now the latest version is CHROME
	 */
	CHROME,
	
	EDGE

}
