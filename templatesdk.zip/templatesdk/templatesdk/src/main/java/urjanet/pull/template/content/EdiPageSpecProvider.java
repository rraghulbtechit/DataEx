package urjanet.pull.template.content;

import urjanet.pull.core.PageSpec;

public interface EdiPageSpecProvider {
	
	public PageSpec getEdiPageSpec();

}
