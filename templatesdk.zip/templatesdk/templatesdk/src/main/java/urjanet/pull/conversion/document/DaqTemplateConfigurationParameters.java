package urjanet.pull.conversion.document;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * @author xavierd
 *	
 *	The template configuration parameters for DAQ session.
 *
 */
public enum DaqTemplateConfigurationParameters implements ConverterConfigurationParameters {
	
	CUSTOM_DAQ_ACQUISITION_JOB("custom_daq_acquisition_job");

	private String paramName;
	
	private DaqTemplateConfigurationParameters(String paramName) {
		this.paramName = paramName;
	}
	
	/**
	 * 
	 * @see urjanet.pull.conversion.ConverterConfigurationParameters#getParameterName()
	 * @return parameter name
	 */
	@Override
	public String getParameterName() {
		return this.paramName;
	}

}
