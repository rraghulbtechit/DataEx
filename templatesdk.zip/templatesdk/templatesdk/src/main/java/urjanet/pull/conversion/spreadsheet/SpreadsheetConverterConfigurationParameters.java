package urjanet.pull.conversion.spreadsheet;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * Configuration parameters for Spreadsheet/CSV conversion.
 * 
 * @author sriram
 *
 */
public enum SpreadsheetConverterConfigurationParameters implements ConverterConfigurationParameters {
	
	/**
	 * If the heading columns are already provided in the CSV/Spreadsheet.
	 */
	HEADER_PROVIDER("headerProvided"),
	
	/**
	 * CSV specific.  What is the separator character.
	 * Ex: '\t' = tab
	 */
	SEPARATOR("separator"),
	
	/**
	 * If you want to sort by a particular primary column number.
	 */
	PRIMARY_SORT_COLUMN_NUM("primarySortColumn"),
	
	/**
	 * What data type is should the comparison for sort be based on.
	 * Take values from DataTargetType.  For eg. DataTargetType.INTEGER
	 */
	PRIMARY_COLUMN_COMPARATOR("primaryComparator"),
	
	/**
	 * Should the primary column be sorted in ascending order or not.
	 * Default is descending.
	 */
	IS_ASCENDING_PRIMARY("isAscendingPrimary"),
	
	/**
	 * If you want to sort by a particular secondary column number.
	 */
	SECONDARY_SORT_COLUMN_NUM("secondarySortColumn"),
	
	/**
	 * What data type is should the comparison for sort be based on.
	 * Take values from DataTargetType.  For eg. DataTargetType.INTEGER
	 */
	SECONDARY_COLUMN_COMPARATOR("secondaryComparator"),
	
	/**
	 * Should the secondary column be sorted in ascending order or not.
	 * Default is descending.
	 */
	IS_ASCENDING_SECONDARY("isAscendingSecondary"),
	
	/**
	 * If the spreadsheet/CSV contains old data as well, we can specify
	 * a particular date in "mm/dd/yy" as a string to this parameter.
	 * The search would be restricted to dates greater than this date.
	 */
	LAST_END_DATE("lastEndDate"),
	
	/**
	 * Which column contains the end date or the date on which the date search 
	 * is to be done.
	 */
	END_DATE_COLUMN_NUM("endDateColumn"),
	
	/**
	 * Whether duplicate rows are allowed. 
	 */
	DUPLICATES_ALLOWED("duplicatesAllowed"),
	
	/**
	 * Specify the sheet number which you want to extract
	 */
	SHEET_NUM("sheetNumber"),
	
	/**
	 * Specify the sheet name which you want to extract
	 */
	SHEET_NAME("sheetName"),
	
	/**
	 * Whether the page Input is zip file format or not
	 */
	IS_ZIP_FORMAT("isZipFormat"),
	
	/**
	 * It helps to extract the sheet based on the conditional string pattern.
	 * The below are the general formats,
	 * Format1 -> Str1 && Str2 && .... && Strn ? trueSheet : falseSheet
	 * Format2 -> Str1 || Str2 || .... || Strn ? trueSheet : falseSheet
	 * Format3 -> Str1 ? trueSheet : falseSheet
	 */
	CONDITIONAL_SHEET("conditionalSheet"),
	
	
	/**
	 * CSV and other spreadsheets are converted to HTML in order to traverse
	 * To view the intermediate file specify a directory with a filename including the file extension
	 * EX. /opt/urjanet/share/javamail/HTML_Files/AtlantaWater.html
	 */
	SAVE_HTML_FILE("saveHtmlFile"),
	
	
	/**
	 * When the spreadsheets are converted sometimes undesirable characters remain
	 * Specify what characters to remove in an array of char's
	 * EX.      char[] charArray = new char[1];
     *   		charArray[0] = (char)0;
	 */
	REMOVE_CHARACTERS("replaceCharacters"),
	
	/**
	 * When the spreadsheets have multiple sheets/tabs
	 */
	MULTI_TAB("multiTab"),
	
	/**
	 * If we have to use the Excel Format Code to be applied to the cell value, use this option and set its value to true.
	 * Ex. If Format Code "2-00-00-0000" is to be applied to the number 12345, then the result String would be "2-00-01-2345"
	 */
	USE_FORMAT_CODE("useFormatCode"),
	
	
	/**
	 * This is the "null" character - if a value is set to this then it is ignored.
     * I.E. if the quote character is set to null then there is no quote character.
	 */
	ESCAPE_QUOTE_CHARACTER("escapeCharacter"),
	
	/**
	 * An option for a Daq Session to split Xls file into csv based on the given header (ex. cox manheim xls file)
	 */
	COLUMN_NAME_TO_SPLIT("columnNameToSplit");
	
	
	
	/*
	 * Specify directory -> Spit out file
	 * 
	 * Specify find and replace -> characters
	 * 
	 */
	
	private String paramName;

	private SpreadsheetConverterConfigurationParameters(String paramName) {
		this.paramName = paramName;
	}
	
	@Override
	public String getParameterName() {
		return paramName;
	}
	
}


