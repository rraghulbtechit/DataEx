package urjanet.pull.web.intercept;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import urjanet.pull.web.RequestParameterElement;
import urjanet.pull.web.SessionContext;

public class DefaultConnectionInterceptor extends SubstitutionInterceptor {
	
	private SessionContext context;
	
	private List<RequestParameterElement> parameters = new ArrayList<RequestParameterElement>();

	public DefaultConnectionInterceptor(WebConnection webConnection, WebClient webClient, SessionContext context) throws IllegalArgumentException {
		super(webConnection, webClient, context);
		this.context = context;
	}

	@Override
	public void doSubstitutionOnRequest(WebRequest webRequest) {
		
		if (parameters.isEmpty())
			return;
		
		List<NameValuePair> newList = new ArrayList<NameValuePair>();
		
		RequestParameter:
		for (NameValuePair pair : webRequest.getRequestParameters()) {
			
			for (RequestParameterElement element : parameters)
				if (pair.getName().equals(element.getParamName()))
					continue RequestParameter;
			
			newList.add(pair);
		}
		
		for (RequestParameterElement element : parameters) {
			String value = null;
			
			if (context != null) value = (String) context.getContextValue(element.getInputName());
			
			if (value == null) value = element.getValueRegEx();
			
			if (value != null) newList.add(new NameValuePair(element.getParamName(), value));
		}
		
		webRequest.setRequestParameters(newList);
	}

	@Override
	public WebResponse doSubstitutionOnResponse(WebResponse originalResponse, WebRequest webRequestSettings) throws IOException {
		return originalResponse;
	}

	public SessionContext getContext() {
		return context;
	}

	public void setContext(SessionContext context) {
		this.context = context;
	}

	public List<RequestParameterElement> getParameters() {
		return parameters;
	}

	public void addParameter(RequestParameterElement parameter) {
		this.parameters.add(parameter);
	}
	
	@Override
	public void clearTempFiles() {
		clearOnlyPdfs();
	}

}
