package urjanet.pull.enrollment.util.keys;


/**
 * @author sethuramanv
 *
 */
public enum StatusKeys {

	ENROLLED_NOW("enrolled_Now"),
	ALREADY_ENROLLED("already_Enrolled"),
	FAILED("failed"),
	LOGIN_FAILED("login_Failed"),
	LOGIN_SUCCESS("login_Success"),
	NAVIGATION_FAILED("navigation_Failed"),
	EBILL_OPTION_NOT_AVAILABLE("ebill_Option_Not_Available"),
	DEENROLLED_NOW("deEnrolled_Now"),
	ALREADY_DeENROLLED("already_DeEnrolled"),
	REMOVED_NOW("removed_Now"),
	ACCOUNT_NOT_FOUND("account_Not_Found");
	
	
	private final String value;

	private StatusKeys(String value){
		this.value = value;
	}

	public String getValue(){
		return this.value;
	}
	
}
