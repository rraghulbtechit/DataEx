package urjanet.pull.operator;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

public class MathOperator implements ExtractOperator {
	
	public static enum MathOperation {ADD, SUBTRACT, MULTIPLY, DIVIDE, MODULO}
	
	private MathOperation operation;
	private double number;
	
	//This constructor will be used in Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private MathOperator() {
		
	}
	
	public MathOperator(MathOperation operation, double number) {
		this.operation = operation;
		this.number = number;
	}
	
	public MathOperation getOperation() {
		return operation;
	}

	public MathOperator setOperation(MathOperation operation) {
		this.operation = operation;
		return this;
	}

	public double getNumber() {
		return number;
	}
	
	public MathOperator setNumber(double number) {
		this.number = number;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("MathOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

			try {
				if (operation == MathOperation.ADD)
					return new ExtractOperand(Double.parseDouble(text) + number);
				else if (operation == MathOperation.SUBTRACT)
					return new ExtractOperand(Double.parseDouble(text) - number);
				else if (operation == MathOperation.MULTIPLY)
					return new ExtractOperand(Double.parseDouble(text) * number);
				else if (operation == MathOperation.DIVIDE)
					return new ExtractOperand(Double.parseDouble(text) / number);
				else if (operation == MathOperation.MODULO)
					return new ExtractOperand(Double.parseDouble(text) % number);
					throw new OperatorException("Operation Unsupported Exception: " + operation);
			} catch (Exception e) {
				throw new OperatorException("Math Operation error: " + e);
			}
	}
}
