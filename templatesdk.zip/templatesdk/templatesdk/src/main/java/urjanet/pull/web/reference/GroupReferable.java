package urjanet.pull.web.reference;

import java.util.List;

public interface GroupReferable {
	
	public List<ReferenceKey> getReferenceKeys();
	public void addReference(ReferenceKey key);

}
