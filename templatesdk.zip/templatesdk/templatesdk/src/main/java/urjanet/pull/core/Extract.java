package urjanet.pull.core;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.DataTargetType;
import urjanet.pull.PullException;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetOperationType;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.reference.GroupReferable;
import urjanet.pull.web.reference.ReferenceKey;

/**
 * Extract is a container for extracted values and their keys. Keys may point to raw data values or other Extract objects in order to support logical
 * separation of data (i.e. different accounts).
 * <p>
 * Current the expected convention for nested Extract objects is as follows:
 * <p>
 * (Provider-level values) -> (Account-level values) -> (Meter-level values)
 * 
 * @author rburson
 */
public class Extract implements Serializable, GroupReferable {

	private static final long serialVersionUID = -1674917494716235519L;
	
	private static final String indentUnit = "   ";
	private static Pattern nonWhiteSpace = Pattern.compile("\\S");

	/**
	 * This holds the groupName + 'index' = subExtract
	 */
	private Map<String, Extract> subExtractMap = new HashMap<String, Extract>();
	
	/**
	 * This keeps a list of the extracts that have not been joined
	 * but they are waiting to see if in the future the extract may join another
	 * extract that may have been in a parent 
	 */
	private List<Extract> notYetJoined = new ArrayList<Extract>();
	
	/**
	 * This holds the groupName = an index of the next group number for this groupName
	 */
	private Map<String, AtomicInteger> currentGroupIndexMap = new HashMap<String, AtomicInteger>();
	
	/**
	 * these are for all of the values (key-pair) which exist in this extract
	 */
	private Map<String, ExtractValue> extractValuesMap = new ConcurrentHashMap<String, ExtractValue>(16, 0.75f, 1);  // limit to 1 segment to conserve memory
	
	/**
	 * This is used to store values which are specifically used for variables to be accessed for group joining actions
	 */
	private Map<String, ExtractValue> contextVariables = new ConcurrentHashMap<String, ExtractValue>(4, 0.75f, 1);   // limit to 1 segment to conserve memory 

	/**
	 * These are the group references which exist for this extract
	 */
	private List<ReferenceKey> references = new ArrayList<ReferenceKey>();

	/**
	 * these are the source nodes which are for this extract
	 * TODO these are integer ids for now, but should be changed to something for generic
	 */
	private List<String> sourceNodes = new ArrayList<String>();
	private List<Long> checksums = new ArrayList<Long>();
	
	/**
	 * The extracts grouping behavior
	 */
	private GroupPolicy groupPolicy;
	
	/**
	 * Name of the group
	 */
	private String name;
	
	/**
	 * Create a logger
	 */
	private static final Logger log = LoggerFactory.getLogger(Extract.class);
	
	/**
	 * Create a new Extract
	 * 
	 */
	public Extract() {
	}
	
	public void addExtract(Extract e) throws PullException {
		addExtract(e, null);
	}

	public void addExtract(Extract e, GroupPolicy policy) throws PullException {
		
		if (policy == null || policy.getGroupName() == null) {
			addAll(e);
		} else {
			addSubExtract(e, policy);
		}

	}

	public Extract clone() {
		Extract extract = new Extract();
		
		for (ExtractValue extractValue : extractValuesMap.values())
			extract.addValue(extractValue.getName(), extractValue.getValue(), extractValue.getFormatHint(), extractValue.getDataTargetOperationType());
		
		for (Map.Entry<String, Extract> entry : subExtractMap.entrySet())
			extract.subExtractMap.put(entry.getKey(), entry.getValue().clone());
	
		return extract;
	}
	
	/**
	 * 
	 * @param extract
	 * @param policy
	 * @throws PullException
	 */
	protected synchronized void addSubExtract(Extract extract, GroupPolicy policy) throws PullException {
		
		if (policy == null || policy.getGroupName() == null) {
			throw new PullException("GroupPolicy or GroupPolicy's groupName is null");
		}
		
		extract.setGroupPolicy(policy);
		
		AtomicInteger groupNumber = currentGroupIndexMap.get(policy.getGroupName());

		if (groupNumber == null && policy.isCreate()) {

			addNewGroup(extract);

		} else {
			if (policy.getAction().equals(GroupPolicy.GroupAction.JOIN_EXISTING_OR_CREATE)) {
				
				int lastIndex = groupNumber.intValue() - 1;
				subExtractMap.get(policy.getGroupName() + lastIndex).addAll(extract);
				
			} else if (policy.getAction().equals(GroupPolicy.GroupAction.JOIN_EXISTING_OR_CREATE_NOOVERWRITE)) {
				
				int lastIndex = groupNumber.intValue() - 1;
				subExtractMap.get(policy.getGroupName() + lastIndex).mergeValuesAndAddAll(extract);
				
			} else if (policy.onVariable() || policy.onSubgroup()) {
				
				Extract subExtract = null;
				
				if (policy.onSubgroup()) {
					
					//If grouping on subgroup, must find which subgroup which to use
					FindSubGroup:
					for (String currentKey : extract.getSubExtractMap().keySet()) {
						Extract currentSubExtract = extract.getSubExtractMap().get(currentKey);

						//Use the subgroup which defines itself as joining on a variable
						if (currentSubExtract.getGroupPolicy().onVariable()) {
							
							for (String subExtractKey : subExtractMap.keySet()) {
								if (subExtractMap.get(subExtractKey).findSubExtractMatching(currentSubExtract.getContextVariable(), currentSubExtract.getGroupPolicy()) != null) {
									subExtract = subExtractMap.get(subExtractKey);
									break FindSubGroup;
								}
							}
						}
						
					}
				} else {
					subExtract = findSubExtractMatching(extract.getContextVariable(), policy);
				}
					

				if (subExtract != null) {
					
					if (policy.noOverwrite())
						subExtract.mergeValuesAndAddAll(extract);
					else
						subExtract.addAll(extract);
					
				}else if (policy.isCreate()) {

					addNewGroup(extract);
					
				} else {
					
					notYetJoined.add(extract);
					
				}

			} else if (policy.getAction().equals(GroupPolicy.GroupAction.ENUMERATE_NEXT)) {
				addNewGroup(extract);
			}
		}
	}

	protected void mergeValuesAndAddAll(Extract extract) throws PullException {
		
		mergeNoReplace(extract.getExtractValuesMap());
		addAllContainers(extract);
	}

	protected void addAll(Extract extract) throws PullException {
		
		Map<String, ExtractValue> extractMap = extract.extractValuesMap;
		for(Map.Entry<String, ExtractValue> entry : extractMap.entrySet()) {
			ExtractValue currentValue = extractValuesMap.get(entry.getKey());
			ExtractValue extractValue = entry.getValue();
			if (currentValue != null && extractValue.getDataTargetOperationType() != null) {
				BigDecimal mathOperation = null; 
				if(extractValue.getDataTargetOperationType() == DataTargetOperationType.MERGE) {
					String newValue = currentValue.getValue().concat(extractValue.getDataTargetOperationType().getDelimiter()).concat(extractValue.getValue());
					extractValue.setValue(newValue.toString());
					extractValue.setDatTargetOperationType(currentValue.getDataTargetOperationType());
				} else if((mathOperation = doMathOperation(currentValue, extractValue)) != null) {
					try {
						extractValue.setValue(mathOperation.toString());
						extractValue.setDatTargetOperationType(currentValue.getDataTargetOperationType());
					} catch(NumberFormatException nfe) {
						log.error("Unable to format Extract Values" + nfe.getMessage());
					} 
				} 
			}
			extractValuesMap.put(entry.getKey(), extractValue);
		}
		addAllContainers(extract);
	}
	
	private BigDecimal doMathOperation(ExtractValue currentValue, ExtractValue extractValue) {
		
		// In case these values were extracted as dollar amounts, remove the dollar sign
		BigDecimal currentNumber = new BigDecimal(currentValue.getValue().replace("$", ""));
		BigDecimal nextNumber = new BigDecimal(extractValue.getValue().replace("$", ""));

	    if(extractValue.getDataTargetOperationType() == DataTargetOperationType.ADD) {
	        return currentNumber.add(nextNumber);
	    } else if(extractValue.getDataTargetOperationType() == DataTargetOperationType.SUBTRACT) {
	        return currentNumber.subtract(nextNumber);
	    } else if(extractValue.getDataTargetOperationType() == DataTargetOperationType.MULTIPLY) {
	        return currentNumber.multiply(nextNumber);
	    }
	    return null;
	}

	/**
	 * 
	 * @param extract
	 *            the keys and values of which will be added to this Extract object
	 */
	private void addAllContainers(Extract extract) throws PullException {
		
		mergeSourceNodes(extract);
		addScoping(extract);
		
		contextVariables.putAll(extract.getContextVariable());
		
		for (ReferenceKey key : extract.getReferenceKeys())
			this.addReference(key);
		
		addAllSubExtracts(extract);
	}
	
	protected void addNewGroup(Extract extract) throws PullException {
		
		mergeSourceNodes(extract);
		addScoping(extract);
		
		GroupPolicy policy = extract.getGroupPolicy();
		
		AtomicInteger groupNumber = currentGroupIndexMap.get(policy.getGroupName());
		
		if (groupNumber == null) {
			groupNumber = new AtomicInteger(0);
			currentGroupIndexMap.put(policy.getGroupName(), groupNumber);
		}
		
		//Need an intermediate extract so that we can call addExtract and it will call all of the 
		//merging logic
		Extract newExtract = new Extract();
		newExtract.setName(policy.getGroupName() + groupNumber.getAndIncrement());
		newExtract.setGroupPolicy(policy);
		newExtract.addExtract(extract);
		subExtractMap.put(newExtract.getName(), newExtract);
		
		//THIS MIGHT WORK BETTER, BUT WILL WAIT UNTIL SURE IT WON'T BREAK ANYTHING
//		extract.setName(policy.getGroupName() + groupNumber.getAndIncrement());
//		subExtractMap.put(extract.getName(), extract);

	}
	
	private synchronized void addAllSubExtracts(Extract extract) throws PullException {

		for (String groupName : extract.currentGroupIndexMap.keySet()) {
			AtomicInteger count = extract.currentGroupIndexMap.get(groupName);
			
			if (count == null) {
				throw new PullException("Invalid SubExtractContainer: Count is null for groupName " + groupName
						+ " when trying to addAll()");
			}
			for (int i = 0; i < count.intValue(); i++) {
				Extract subExtract = extract.subExtractMap.get(groupName + i);
				
				if (subExtract == null) {
					throw new PullException("InvalidSubExractContainer: Extract for groupName: " + groupName
							+ " is null when trying to addAll()");
				}
				
				addSubExtract(subExtract, subExtract.getGroupPolicy());
			}
		}
		
		for (Extract subExtract : extract.getNotYetJoined()) {
			addSubExtract(subExtract, subExtract.getGroupPolicy());
		}
	}

	private void addScoping(Extract extract) {
		
		if (groupPolicy == null)
			return;
		
		for (ReferenceKey key : extract.getReferenceKeys()) {
			if (key.getScope() != null && key.getScope().getValue().equals(groupPolicy.getGroupName())) {
				key.setScopeId(groupPolicy.getGroupName() + "(" + Integer.toString(this.hashCode()) + ")");
			}
		}
		for (String key : extract.getSubExtractMap().keySet()) {
			addScoping(extract.getSubExtractMap().get(key));
		}
	}

	/**
	 * merges extractMap into extractValueMap without replacing values
	 * 
	 * @param extractMap
	 */
	private void mergeNoReplace(Map<String, ExtractValue> extractMap) {
		Set<String> set = extractMap.keySet();

		for (String key : set) {
			if (extractValuesMap.get(key) == null) {
				extractValuesMap.put(key, extractMap.get(key));
			}
		}
	}

	private void mergeSourceNodes(Extract extract) {
		for (String node : extract.getSourceNodes())
			if (!sourceNodes.contains(node))
				sourceNodes.add(node);
		
		for (Long checksum : extract.getChecksums())
			if (!checksums.contains(checksum))
				checksums.add(checksum);

	}
	
	public void addUniqueSourceNode(String sourceNode) {
		
		if (!sourceNodes.contains(sourceNode))
			sourceNodes.add(sourceNode);
		
		for (Extract possibleJoinLater : notYetJoined)
			possibleJoinLater.addUniqueSourceNode(sourceNode);

		for (String key : this.getSubExtractMap().keySet())
			getSubExtractMap().get(key).addUniqueSourceNode(sourceNode);
	}
	
	public void addUniqueChecksum(Long checksum) {
		if (checksum != null) {
			
			if (!checksums.contains(checksum))
				checksums.add(checksum);
			
			for (String key : this.getSubExtractMap().keySet())
				getSubExtractMap().get(key).addUniqueChecksum(checksum);
		}
	}
	
	/**********************************************************************************************************************************/
	/***************************************************Searching the Extract for values***********************************************/
	/**********************************************************************************************************************************/
	
	public Extract findSubExtractMatching(Map<String, ExtractValue> variables, GroupPolicy policy) {
		
		if (!variables.isEmpty()) {

			SubExtractTraversal:
			for (String subExtractKey : subExtractMap.keySet()) {
				
				//This check is a fix, was not here before
				if (!subExtractKey.startsWith(policy.getGroupName()))
					continue;
				
				Extract subExtract = subExtractMap.get(subExtractKey);

				for (String key : variables.keySet()) {
					if (!subExtract.extractContainsEqualValue(variables.get(key)))
						continue SubExtractTraversal;
				}

				return subExtract;
			}
		}
		
		return null;
	}
	
	public boolean extractContainsEqualValue(ExtractValue value) {
		ExtractValue ev = this.extractValuesMap.get(value.getName());
		if (ev != null && validResultValue(ev.getValue()) && extractValuesAreEqual(ev, value)) {
			return true;
		}
		return false;
	}
	
	private boolean extractValuesAreEqual(ExtractValue v1, ExtractValue v2) {
		if (v1.getTargetType() == DataTargetType.DECIMAL && v2.getTargetType() == DataTargetType.DECIMAL) {
			try {
				boolean areEqual = Double.valueOf(v1.getValue()).equals(Double.valueOf(v2.getValue()));
				return areEqual;
			} catch (Exception ignore) {}
		} else if (v1.getTargetType() == DataTargetType.INTEGER && v2.getTargetType() == DataTargetType.INTEGER) {
			try {
				boolean areEqual = Integer.valueOf(v1.getValue()).equals(Integer.valueOf(v2.getValue()));
				return areEqual;
			} catch (Exception ignore) {}
		}
		
		// TODO: implement rest of DataTargetTypes and set DataTargetType from XmlExtractionHandler (only did PdfExtractionHandler so far...)
		
		return v1.getValue().equals(v2.getValue());
	}

	/**
	 * Check to see if the supplied 'targetName' has a value at any level of the Extract
	 * 
	 * @param targetName
	 *            the value name for which to check for an associated value
	 * @return true if the value is found in the Extract or any of it's subExtracts
	 */
	public boolean valuePresentInHierarchy(String targetName) {

		ExtractValue ev = this.extractValuesMap.get(targetName);
		if (ev != null && validResultValue(ev.getValue())) {
			return true;
		}
		for (Extract e : subExtractMap.values()) {
			if (e.valuePresentInHierarchy(targetName)) {
				return true;
			}
		}
		return false;

	}
	
	/**
	 * Check to see if the supplied 'targetName' has a value in this Extract. Does not check subextracts.
	 * 
	 * @param targetName
	 *            the value name for which to check for an associated value
	 * @return true if the value is found in this Extract's top-level
	 */
	public boolean valuePresentAtThisLevel(String targetName) {

		ExtractValue ev = this.extractValuesMap.get(targetName);
		if (ev != null && validResultValue(ev.getValue())) {
			return true;
		}
		return false;

	}
	
	public boolean hasKeyValuePair(String key, String value) {
		
		String exVal = getValue(key);
		if (exVal != null && exVal.equals(value))
			return true;
		
		return false;
	}
	
	/**
	 * 
	 * @param value
	 * @return true if this value is a valid result value
	 */
	public static boolean validResultValue(Object value) {

		if (value == null) {
			return false;
		}
		if (value instanceof String) {
			if (((String) value).length() < 1) {
				return false;
			}
			Matcher matcher = nonWhiteSpace.matcher((String) value);
			if (!matcher.find()) {
				return false;
			}
		}

		return true;
	}
	
	public double getDoubleValue(String name) {
		ExtractValue value = getExtractValuesMap().get(name);

		if (value == null || value.getValue() == null || value.getValue().equals(""))
			return 0;

		try {
			return Double.valueOf(value.getValue());
		} catch (Exception e) {
			return 0;
		}
	}

	public boolean hasValues() {
		return !extractValuesMap.isEmpty();
	}

	public boolean hasExtracts() {
		return !subExtractMap.isEmpty();
	}
	
	public boolean hasUnjoinedExtracts() {
		return !notYetJoined.isEmpty();
	}
	
	public String getUnEnumeratedGroupName() {

		if (this.getName() == null)
			return null;

		return this.getName().replaceAll("\\d+$", "");

	}
	
	/**
	 * Checks for the presence of a group in the entire extract hierarchy.
	 * This implementation allows for checking for groups with null or empty name.
	 * @param groupName String matching the unenumerated group name to search for
	 * @return
	 */
	public boolean containsGroup(String groupName) {
		boolean hasGroup = StringUtils.equals(groupName, getUnEnumeratedGroupName());
		if (hasGroup)
			return true;
		for (Extract e : getSubExtractMap().values()) {
			if (e.containsGroup(groupName))
				return true;
		}
		return false;
	}
	
	/**********************************************************************************************************************************/
	/***************************************************Getter and Setter Functions****************************************************/
	/**********************************************************************************************************************************/

	public void addValue(DataTarget dataTarget, String targetValue) {
		addValue(dataTarget, targetValue, null);
	}
	
	public void addValue(DataTarget dataTarget, String targetValue, List<ExtractCoordinates> coordinates) {
		
		ExtractValue extractValue = null;
		if(dataTarget.getDataTargetOperationType() != null && dataTarget.getName() != null) {
			extractValue = new ExtractValue(dataTarget.getName(), targetValue, dataTarget.getFormatHint(), dataTarget.getDataTargetOperationType());
		} else {
			extractValue = new ExtractValue(dataTarget.getName(), targetValue, dataTarget.getFormatHint());
		}
		if (dataTarget.getType() != null) {
			extractValue.setTargetType(dataTarget.getType());
		}
		extractValue.setExtractCoordinates(coordinates);
		this.extractValuesMap.put(dataTarget.getName(), extractValue);
	}
	
	/**
	 * 
	 * @param targetName
	 *            the 'key' to map this value to
	 * @param value
	 *            the value to add to the Extract
	 */
	public void addValue(String targetName, String value) {
		this.extractValuesMap.put(targetName, new ExtractValue(targetName, value));
	}

	/**
	 * 
	 * @param targetName
	 *            the 'key' to map this value to
	 * @param value
	 *            the value to add to the Extract
	 * @parma formatHint a hint for the formatter
	 */
	public void addValue(String targetName, String value, String formatHint) {
		this.extractValuesMap.put(targetName, new ExtractValue(targetName, value, formatHint));
	}
	
	public void addValue(String targetName, String value, String formatHint, DataTargetOperationType operationType) {
		this.extractValuesMap.put(targetName, new ExtractValue(targetName, value, formatHint, operationType));
	}
	
	/**
	 * 
	 * @return A map of value names to ExtractValue objects for fast retrieval
	 */
	public Map<String, ExtractValue> getExtractValuesMap() {

		return Collections.unmodifiableMap(this.extractValuesMap);
	}

	public String getValue(String key) {

        ExtractValue ev = extractValuesMap.get(key);
        if (ev != null) {
            return ev.getValue();
        }
        return null;
	}

	public Map<String, Extract> getSubExtractMap() {

		return Collections.unmodifiableMap(subExtractMap);
	}
	
	public ExtractValue getExtractValue(String key) {

        return this.extractValuesMap.get(key);
	}

	/**
	 * 
	 * @return the String representation of this object
	 */
	@Override
	public String toString() {
		return printMePurdy(this, 0, new StringBuilder(300)).toString();
	}
	
	protected GroupPolicy getGroupPolicy() {
		return groupPolicy;
	}
	
	protected void setGroupPolicy(GroupPolicy groupPolicy) {
		this.groupPolicy = groupPolicy;
	}

	public ExtractValue getContextVariable(String key) {
		return contextVariables.get(key);
	}

	public Map<String, ExtractValue> getContextVariable() {
		return contextVariables;
	}

	public void setContextVariable(String key, ExtractValue value) {
		this.contextVariables.put(key, value);
	}
	
	@Override
	public List<ReferenceKey> getReferenceKeys() {
		return Collections.unmodifiableList(references);
	}

	@Override
	public void addReference(ReferenceKey key) {
		if (!references.contains(key))
			references.add(key);
	}

	public List<String> getSourceNodes() {
		return sourceNodes;
	}

	public void setSourceNodes(List<String> sourceNodes) {
		this.sourceNodes = sourceNodes;
	}
	
	public List<Long> getChecksums() {
		return checksums;
	}

	public Long getMasterChecksum(){
		//right now just return the first item in the list
		//ultimately we'll want to create a combined checksum
		if(checksums.isEmpty()) return 0l;
		return checksums.get(0);
	}

	public void setChecksums(List<Long> checksums) {
		this.checksums = checksums;
	}

	public List<Extract> getNotYetJoined() {
		return notYetJoined;
	}

	public void setNotYetJoined(List<Extract> notYetJoined) {
		this.notYetJoined = notYetJoined;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**********************************************************************************************************************************/
	/***************************************************Extract toString() functions***************************************************/
	/**********************************************************************************************************************************/
	
	private static StringBuilder printMePurdy(Extract extract, int depth, StringBuilder sb) {

		StringBuilder indent = new StringBuilder(depth * indentUnit.length());
		for (int i = 0; i < depth; i++) {
			indent.append(indentUnit);
		}
		sb.append(indent);
		String name = extract.getName() != null ? extract.getName() : "woot";
		sb.append("[").append(name).append("] ");

		for (ReferenceKey key : extract.getReferenceKeys()) {
			sb.append(" -> (");
			for (String hashKey : key.getIdentifier().keySet()) {
				ExtractValue value = key.getIdentifier().get(hashKey);
				sb.append(value.toString());
			}
			sb.append(")");
		}

		/*for (String node : extract.getSourceNodes()) {
			sb.append(node + " ");
		}*/
		/*for (Long node : extract.getChecksums()) {
			sb.append((node.longValue() + " ").getBytes());
		}*/

		sb.append("\n");

		StringBuilder keys = new StringBuilder(200);
		for (ExtractValue ev : extract.getExtractValuesMap().values()) {
			sb.append(indent);
			sb.append(indentUnit);
			if (ev.getFormatHint() != null) {
				sb.append(ev.getName() + " = " + ev.getValue() + ", fh = " + ev.getFormatHint() + "\n");
			} else {
				sb.append(ev.getName() + " = " + ev.getValue() + "\n");
			}
		}
		for (Extract e : extract.getSubExtractMap().values()) {
			int newDepth = depth + 1;
			printMePurdy(e, newDepth, keys);
		}

		sb.append(keys);
		sb.append(indent);
		sb.append("[/").append(name).append("]\n");

		return sb;

	}
	public void printMePurdy() {
		try {
		printMePurdy(this, 0, System.out);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void printMePurdy(OutputStream stream) throws IOException { 
		printMePurdy(this, 0, stream);
	}
	private static void printMePurdy(Extract extract, int depth, OutputStream stream) throws IOException {

		StringBuilder indent = new StringBuilder(depth * indentUnit.length());
		for (int i = 0; i < depth; i++) {
			indent.append(indentUnit);
		}
		
		byte[] indentBytes = indent.toString().getBytes();
		byte[] indentUnitBytes = indentUnit.toString().getBytes();
		byte[] open = "[".getBytes();
		byte[] close = "]".getBytes();
		byte[] equals = " = ".getBytes();
		byte[] newline = "\n".getBytes();
		byte[] formatHint = ", fh".getBytes();
		
		stream.write(indentBytes);
		String name = extract.getName() != null ? extract.getName() : "woot";
		
		stream.write(open);
		stream.write(name.getBytes());
		stream.write(close);
		
		byte[] refOpen = " -> (".getBytes();
		byte[] refClose = ")".getBytes();
		for (ReferenceKey key : extract.getReferenceKeys()) {
			stream.write(refOpen);
			
			if (key.getScopeId() != null) {
				stream.write("[scope:".getBytes());
				stream.write(key.getScopeId().getBytes());
				stream.write("]".getBytes());
			}
			for (String hashKey : key.getIdentifier().keySet()) {
				ExtractValue value = key.getIdentifier().get(hashKey);
				stream.write(value.toString().getBytes());
			}
			stream.write(refClose);
		}
		
		
		/*for (String node : extract.getSourceNodes()) {
			stream.write((node + " ").getBytes());
		}*/
		/*for (Long node : extract.getChecksums()) {
			stream.write((node.longValue() + " ").getBytes());
		}*/

		stream.write(newline);
		
		for (ExtractValue ev : extract.getExtractValuesMap().values()) {
			if (ev.getValue() == null)
				continue;
			
			stream.write(indentBytes);
			stream.write(indentUnitBytes);
			stream.write(ev.getName().getBytes());
			stream.write(equals);
			stream.write(ev.getValue().getBytes());
			if (ev.getFormatHint() != null) {
				stream.write(formatHint);
				stream.write(equals);
				stream.write(ev.getFormatHint().getBytes());
			}
			stream.write(newline);
		}
		
		for (Extract e : extract.getSubExtractMap().values()) {
			int newDepth = depth + 1;
			printMePurdy(e, newDepth, stream);
		}

		stream.write(indentBytes);
		stream.write(open);
		stream.write("/".getBytes());
		stream.write(name.getBytes());
		stream.write(close);
		stream.write(newline);

	}

}
