package urjanet.pull.web.pdf.filter;

import urjanet.pull.web.pdf.context.TargetContext.TargetContextDirection;

public class PreviousFilter extends ContextFilter {
	
	private TargetContextDirection targetContextDirection;
	private int depthOfPreviousContexts;
	private String contextLabel;
	
	public PreviousFilter() {
		this(1);
	}
	
	/**
	 * @param depth - Number of context filters to remove
	 */
	public PreviousFilter(int depth) {
		this(depth, TargetContextDirection.CURRENT_CONTEXT);
	}

	public PreviousFilter(String contextLabel) {
		this.contextLabel = contextLabel;
		this.depthOfPreviousContexts = -1;
		this.targetContextDirection = TargetContextDirection.TARGET_CONTEXT_LABEL;
	}
	
	public PreviousFilter(int depth, TargetContextDirection direction) {
		depthOfPreviousContexts = depth;
		targetContextDirection = direction;
	}

	public TargetContextDirection getTargetContextDirection() {
		return targetContextDirection;
	}

	/**
	 * @param targetContextDirection the targetContextDirection to set
	 */
	public PreviousFilter setTargetContextDirection(TargetContextDirection targetContextDirection) {
		this.targetContextDirection = targetContextDirection;
		return this;
	}

	/**
	 * 
	 * @return
	 */
	public String getContextLabel() {
		return contextLabel;
	}

	/**
	 * 
	 * @param contextLabel
	 * @return
	 */
	public PreviousFilter setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
		return this;
	}

	public int getDepthOfPreviousContexts() {
		return depthOfPreviousContexts;
	}

	/**
	 * @param depthOfPreviousContexts the depthOfPreviousContexts to set
	 */
	public PreviousFilter setDepthOfPreviousContexts(int depthOfPreviousContexts) {
		this.depthOfPreviousContexts = depthOfPreviousContexts;
		return this;
	}
	
}
