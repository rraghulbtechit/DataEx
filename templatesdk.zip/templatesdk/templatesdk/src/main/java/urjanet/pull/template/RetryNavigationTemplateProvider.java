package urjanet.pull.template;

import urjanet.pull.core.PageSpec;
import urjanet.pull.web.DataTargetQualifier;

/**
 * @author dennis 
 *
 */
public interface RetryNavigationTemplateProvider {
	
	public PageSpec getRetryNavigation();
	
	public PageSpec getApplyRetryNavigation();
	
	public DataTargetQualifier getRetryNavigationQualifier();
}
