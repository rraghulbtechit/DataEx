package urjanet.pull.web.text;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;

public class TextTargetGroup implements TargetGroup {

	private String searchLabel;
	private GroupPolicy groupPolicy;
	private List<? extends DataTarget> dataTargets;
	private List<? extends NavTarget> navTargets;
	
	public TextTargetGroup() {
	}

	public TextTargetGroup(String searchLabel, GroupPolicy groupPolicy, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this.setSearchLabel(searchLabel);
		this.setGroupPolicy(groupPolicy);
		this.setDataTargets(dataTargets);
		this.setNavTargets(navTargets);
	}


	public TextTargetGroup(String searchLabel, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this(searchLabel, null, dataTargets, navTargets);
	}

	public TextTargetGroup(List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this(null, dataTargets, navTargets);
	}

	public TextTargetGroup(DataTarget ... dataTargets){
		this.setDataTargets(Arrays.asList(dataTargets));
	}

	public TextTargetGroup(NavTarget ... navTargets){
		this.setNavTargets(Arrays.asList(navTargets));
	}

	@SuppressWarnings("unchecked")
	@Override
	public DataTarget asBaseDataTarget() {
		return searchLabel != null ? new TextDataTarget(groupPolicy, null, searchLabel, (List<TextDataTarget>) dataTargets) : null;
	}

	@Override
	public List<? extends DataTarget> getDataTargets() {
		return dataTargets;
	}

	@Override
	public GroupPolicy getGroupPolicy() {
		return groupPolicy;
	}

	@Override
	public List<? extends NavTarget> getNavTargets() {
		return navTargets;
	}

	public void setSearchLabel(String searchLabel) {
		this.searchLabel = searchLabel;
	}

	public String getSearchLabel() {
		return searchLabel;
	}

	public TextTargetGroup setGroupPolicy(GroupPolicy groupPolicy) {
		this.groupPolicy = groupPolicy;
		return this;
	}

	public TextTargetGroup setDataTargets(List<? extends DataTarget> dataTargets) {
		this.dataTargets = dataTargets;
		return this;
	}

	public TextTargetGroup setNavTargets(List<? extends NavTarget> navTargets) {
		this.navTargets = navTargets;
		return this;
	}

}
