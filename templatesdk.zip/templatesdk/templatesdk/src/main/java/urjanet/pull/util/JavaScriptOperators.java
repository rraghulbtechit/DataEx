package urjanet.pull.util;

import urjanet.pull.operator.JavaScriptOperator;

public class JavaScriptOperators {

	public static JavaScriptOperator numberOperator() {
		return new JavaScriptOperator("if (document == null) return; var doc = null; " +
				" if (document.nodeType) doc = document.getData(); else doc = document; " +
				" if (doc == null || doc == \"\") return; if (doc.indexOf(',') != -1) doc = doc.replace(/^,|,+/g,''); " +
				" var val = parseFloat(doc); if (isNaN(val)) return; else return val.valueOf().toString();");
	}

}
