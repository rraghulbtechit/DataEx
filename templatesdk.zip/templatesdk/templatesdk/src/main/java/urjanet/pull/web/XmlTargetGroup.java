package urjanet.pull.web;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.core.TargetGroup;

/**
 *
 * @author rburson
 */
public class XmlTargetGroup implements TargetGroup {

	private String baseXPath;
	private GroupPolicy groupPolicy;
	private List<? extends DataTarget> dataTargets;
	private List<? extends NavTarget> navTargets;

	public XmlTargetGroup() {
	}

	public XmlTargetGroup(String baseXPath, GroupPolicy groupPolicy, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this.baseXPath = baseXPath;
		this.groupPolicy = groupPolicy;
		this.dataTargets = dataTargets;
		this.navTargets = navTargets;
	}


	public XmlTargetGroup(String baseXPath, List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this(baseXPath, null, dataTargets, navTargets);
	}

	public XmlTargetGroup(List<? extends DataTarget> dataTargets, List<? extends NavTarget> navTargets) {
		this(null, dataTargets, navTargets);
	}

	public XmlTargetGroup(DataTarget ... dataTargets){
		this.dataTargets = Arrays.asList(dataTargets);
	}

	public XmlTargetGroup(NavTarget ... navTargets){
		this.navTargets = Arrays.asList(navTargets);
	}
	
	public XmlTargetGroup(List<? extends NavTarget> navTargets){
		this.navTargets = navTargets;
	}

	@Override
	public List<? extends DataTarget> getDataTargets() {
		return dataTargets;
	}

	public XmlTargetGroup setDataTargets(List<? extends DataTarget> dataTargets) {
		this.dataTargets = dataTargets;
		return this;
	}

	@Override
	public List<? extends NavTarget> getNavTargets() {
		return navTargets;
	}

	public XmlTargetGroup setNavTargets(List<? extends NavTarget> navTargets) {
		this.navTargets = navTargets;
		return this;
	}

	public String getBaseXPath() {
		return baseXPath;
	}

	public XmlTargetGroup setBaseXPath(String baseXPath) {
		this.baseXPath = baseXPath;
		return this;
	}

	@Override
	public GroupPolicy getGroupPolicy() {
		return groupPolicy;
	}

	public XmlTargetGroup setGroupPolicy(GroupPolicy groupPolicy) {
		this.groupPolicy = groupPolicy;
		return this;
	}

	@Override
	public DataTarget asBaseDataTarget() {
		return baseXPath != null ? new XmlDataTarget(null, baseXPath) : null;
	}

	public String getGroupQualifiedXpath(String xpath){

		if (this.baseXPath != null && xpath != null) {
			if(this.baseXPath.endsWith("/")){
				return this.baseXPath.concat(xpath);
			}else{
				return this.baseXPath.concat("/").concat(xpath);
			}
		}else{
			return xpath;
		}

	}
}
