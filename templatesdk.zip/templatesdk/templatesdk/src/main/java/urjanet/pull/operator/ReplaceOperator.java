package urjanet.pull.operator;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

public class ReplaceOperator implements ExtractOperator {

	private String regEx;
	private String replaceWith;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private ReplaceOperator() {
		
	}
	
	public ReplaceOperator(String regEx, String replaceWith) {
		this.regEx = regEx;
		this.replaceWith = replaceWith;
	}
	
	public String getRegEx() {
		return regEx;
	}

	public ReplaceOperator setRegEx(String regEx) {
		this.regEx = regEx;
		return this;
	}
	
	public String getReplaceWith() {
		return replaceWith;
	}

	public ReplaceOperator setReplaceWith(String replaceWith) {
		this.replaceWith = replaceWith;
		return this;
	}
	
	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {
				
				
				
				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("RegExOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

			try {
				return new ExtractOperand(text.replaceAll(regEx, replaceWith));

			} catch (Exception e) {
				throw new OperatorException("Regular expression error: " + regEx, e);
			}


	}

}
