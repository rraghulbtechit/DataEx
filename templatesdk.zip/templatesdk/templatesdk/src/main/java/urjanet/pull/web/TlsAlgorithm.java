package urjanet.pull.web;

/**
 * Tls algorithms for disabling it at runtime.
 * 
 * @author xavierd
 *	
 *	<p> 
 *		The key size should be given as part of any one algorithm. It should not be given alone.
 *		Please see java.security file in your JDK (.../java(JDK Path)/jre/lib/security/java.security).
 *	</p>
 *
 */
public enum TlsAlgorithm {
	
	DHE("DHE"),
	
	SSLv3("SSLv3"),
	
	MD5("MD5"), 
	
	DSA("DSA"), 
	
	RSA("RSA"),
	
	KEY_SIZE_LESS_THAN_1024("keySize < 1024"),
	
	KEY_SIZE_LESS_THAN_2048("keySize < 2048");
	
	private String name;
	
	private TlsAlgorithm(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	};
}
