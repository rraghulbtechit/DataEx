package urjanet.pull.conversion;

/**
 * Interface for different document conversion parameters
 * 
 * @author sriram
 *
 */
public interface ConverterConfigurationParameters {
	/**
	 * Get the name of the parameter
	 */
	public String getParameterName();
}


