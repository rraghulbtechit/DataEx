package urjanet.pull.web;

/**
 * 
 * @author xavierd
 *
 */
public enum DataTargetOperationType {
	
	/**
	 * <p> 
	 * The ADD operation will add the two data target's extracted values.
	 * </p>
	 */
	ADD("+"),
	
	/**
	 * <p> 
	 * The SUBTRACT operation will subtract the two data target's extracted values.
	 * </p>
	 */
	SUBTRACT("-"),
	
	/**
	 * <p>
	 * This will merge the values of two data targets. By default it will use the <B>Space</B> as a delimiter.
	 * We can override the delimiter as and when it required in the template by using the <B>setDelimiter</B> property.
	 * <p>
	 */
	MERGE(" "), 
	
	/**
	 * <p> 
	 * The MULTIPLY operation will multiply the two data target's extracted values.
	 * </p>
	 */
	MULTIPLY("*");
	
	private String delimiter;
	
	/**
	 * 
	 * @param delimiter
	 */
	DataTargetOperationType(String delimiter) {
		this.setDelimiter(delimiter);
	}

	/**
	 * @return the delimiter
	 */
	public String getDelimiter() {
		return delimiter;
	}

	/**
	 * @param delimiter the delimiter to set
	 */
	public DataTargetOperationType setDelimiter(String delimiter) {
		this.delimiter = delimiter;
		return this;
	}
}