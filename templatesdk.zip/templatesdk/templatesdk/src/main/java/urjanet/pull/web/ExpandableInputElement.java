package urjanet.pull.web;

/**
 * Important:  An ExpandableInputTarget must be a owned by an ExpandableNavTarget to be subject to expansion!
 * ExpandableNavTarget also provides the id/Collection Subgroup mechansim for grouping
 *
 * An ExpandableInputElement only applies an emblematic distinction to an InputElement.
 * It does not add any behavior. It does however, allow for the selection of multiple input values to
 * be treated as consecutive InputValues (e.g. all items in a drop-down list).  This is useful for navigating over a series of value selections that
 * lead to the same target page page but with different data.  For example, one might want to interate through a list of OPTIONS in a SELECT box that represent
 * different accounts but display the same page with different data for each account.
 * An instance of this class specifies that this ExpandableInputElement will actually be
 * be a set of one or more InputElements once the 'expansionValuesXPath' selector is applied to the targeted input element and the expansionValuesFilter (regEx) is applied subsequently.
 * That is, it can be assumed that the xpath statement will select multiple values (e.e. OPTIONS) which will then each become
 * a single InputElement value.
 *<p>
 * The expansion for ExpandableInputElement is handled by NavTargetHandler
 *<p>
 * This class is similar to ExpandableDataTarget and ExpandableNavTarget
 *
 * @author rburson
 * @see ExpandableNavTarget
 * @see ExpandableDataTarget
 * @see NavTargetHandler
 */
public class ExpandableInputElement extends InputElement{


	private String expansionValuesFilter;
	private String expansionValuesXPath;
	private boolean doNotUseAbsoluteXPath;

	public ExpandableInputElement() {
	}

	/**
	 * Create an ExpandableInputElement
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param expansionValuesFilter a regEx that matches the desired set of values to be submitted (applied after the expansionValuesXPath, null matches all values)
	 * @param expansionValuesXPath an xpath that selects (or narrows) the desired set of values to be submitted (null selects all values)
	 * @param framePath the target framePath, defaults to 0
	 */
	public ExpandableInputElement(String elementXPath, String expansionValuesFilter, String expansionValuesXPath, String framePath) {

		super(elementXPath, null, null, framePath);
		this.expansionValuesFilter = expansionValuesFilter;
		this.expansionValuesXPath = expansionValuesXPath;
	}

	/**
	 *
	 * Create an ExpandableInputElement with the default framePath (0)
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param expansionValuesFilter a regEx that matches the desired set of values to be submitted (applied after the expansionValuesXPath, null matches all values)
	 * @param expansionValuesXPath an xpath that selects (or narrows) the desired set of values to be submitted (null selects all values)
	 */
	public ExpandableInputElement(String elementXPath, String expansionValuesFilter, String expansionValuesXPath) {

		super(elementXPath, null, null);
		this.expansionValuesFilter = expansionValuesFilter;
		this.expansionValuesXPath = expansionValuesXPath;
	}

	/**
	 * Create an ExpandableInputElement with the default framePath (0)

	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param expansionValuesFilter a regEx that matches the desired set of values to be submitted (applied after the expansionValuesXPath, null matches all values)
	 *
	 */
	public ExpandableInputElement(String elementXPath, String expansionValuesFilter) {

		super(elementXPath, null);
		this.expansionValuesFilter = expansionValuesFilter;
	}

	public ExpandableInputElement(String elementXPath, String expansionValuesFilter, boolean deselectAllFirst) {
		
		super(elementXPath, null, deselectAllFirst);
		this.expansionValuesFilter = expansionValuesFilter;
	}

	/**
	 * @return the expansionValuesFilter a regEx that matches the desired set of values to be submitted (applied after the expansionValuesXPath, null matches all values)
	 */
	public String getExpansionValuesFilter() {
		return expansionValuesFilter;
	}

	/**
	 * @param expansionValuesFilter a regEx that matches the desired set of values to be submitted (applied after the expansionValuesXPath, null matches all values)
	 */
	public void setExpansionValuesFilter(String expansionValuesFilter) {
		this.expansionValuesFilter = expansionValuesFilter;
	}

	/**
	 * @return an xpath that selects (or narrows) the desired set of values to be submitted (null selects all values)
	 */
	public String getExpansionValuesXPath() {
		return expansionValuesXPath;
	}

	/**
	 * @param expansionValuesXPath an xpath that selects (or narrows) the desired set of values to be submitted (null selects all values)
	 */
	public void setExpansionValuesXPath(String expansionValuesXPath) {
		this.expansionValuesXPath = expansionValuesXPath;
	}

	/**
	 * 
	 * @return doNotUseAbsoluteXPath
	 */
	public boolean isDoNotUseAbsoluteXPath() {
		return doNotUseAbsoluteXPath;
	}

	/**
	 * 
	 * @param doNotUseAbsoluteXPath
	 * 
	 * Instead of absolute XPath, the relative XPath will be used for identifying the xpath while navigation.
	 */
	public void setDoNotUseAbsoluteXPath(boolean doNotUseAbsoluteXPath) {
		this.doNotUseAbsoluteXPath = doNotUseAbsoluteXPath;
	}
}
