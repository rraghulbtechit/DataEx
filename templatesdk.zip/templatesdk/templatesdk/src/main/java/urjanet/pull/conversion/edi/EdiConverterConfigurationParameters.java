package urjanet.pull.conversion.edi;

import urjanet.pull.conversion.ConverterConfigurationParameters;

/**
 * Edit to HTML conversion configuration options.
 * 
 * @author sriram
 *
 */
public enum EdiConverterConfigurationParameters implements ConverterConfigurationParameters {

	/**
	 * Name of the CUSTOMER/EDI provider.  
	 * Used for searching for right EDI feed/file and also for naming the final result.
	 */
	EDI_PROVIDER("edi_provider"),
	
	/**
	 * Whether to write an EDI receipt to the FTP server or not
	 */
	WRITE_RECEIPT_TO_FTP_SERVER("write_receipt_to_ftp_server"),
	
	
	/**
	 * String prefixed to the 997 receipt file  
	 */
	RECEIPT_FILE_NAME_PREFIX("receipt_file_name_prefix");
	
	private String paramName;
	
	private EdiConverterConfigurationParameters(String paramName) {
		this.paramName = paramName;
	}
	
	/**
	 * Get the parameter name.
	 */
	@Override
	public String getParameterName() {
		return paramName;
	}
}


