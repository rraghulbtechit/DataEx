package urjanet.pull.bool;

import urjanet.pull.web.DataTarget;

/**
 * 
 * @author xavierd
 * 
 * <p>
 * 	The operator will be evaluated against the target1's extracted value and the target2's extracted value.
 *  The operand for the operator is two data target's values.
 *  By default the StringQualifier will take the Equals operation if there is no explicit operators are mentioned.
 * 	NOTE: The type of target1 and target2 should be identical.
 * </p> 
 *
 */
public class StringQualifier extends ComparisonDataTargetQualifier {
	
	private boolean ignoreCase;

	//This constructor will be called from Hit to create an instance through Reflection.
	@SuppressWarnings("unused")
	private StringQualifier() {

	}
	
	public StringQualifier(ComparisonOperator operator, DataTarget target1, DataTarget target2, boolean ignoreCase) {
		super(operator, target1, target2);
		this.ignoreCase = ignoreCase;
	}
	
	public StringQualifier(DataTarget target1, DataTarget target2, boolean ignoreCase) {
		super(ComparisonOperator.EQUAL_TO, target1, target2);
		this.ignoreCase = ignoreCase;
	}
	
	public StringQualifier(DataTarget target1, DataTarget target2) {
		this(ComparisonOperator.EQUAL_TO, target1, target2, false);
	}

	public boolean isIgnoreCase() {
		return ignoreCase;
	}

	public StringQualifier setIgnoreCase(boolean ignoreCase) {
		this.ignoreCase = ignoreCase;
		return this;
	}

	@Override
	public int compareTo(String value1, String value2) {
		
		if(ignoreCase) {
			return value1.compareToIgnoreCase(value2);
		} else {
			return value1.compareTo(value2);
		}
	}
}
