package urjanet.pull.enrollment.util.keys;

public enum Input {
	Enroll(1),
	EbillEnroll(2),
	EbillDeEnroll(3),
	AccountRemove(4);
	
	private final int value;
	
	private Input(int value){
		this.value = value;
	}

	public int getValue(){
		return this.value;
	}
}
