package urjanet.pull.web.pdf.filter;


public class NewspaperLayoutFilter extends ContextFilter {
	
	private VerticalFilter firstColumn;
	
	private OverlapPosition overlapTextPosition;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private NewspaperLayoutFilter() {
		
	}
	
	public NewspaperLayoutFilter(VerticalFilter column1) {
		this.firstColumn = column1;
	}

	public VerticalFilter getFirstColumn() {
		return firstColumn;
	}

	public void setFirstColumn(VerticalFilter firstColumn) {
		this.firstColumn = firstColumn;
	}
	
	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}

	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public NewspaperLayoutFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public NewspaperLayoutFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}

}
