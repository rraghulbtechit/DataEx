package urjanet.pull.operator;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author rburson
 */
public class SimpleOperatorChain implements ExtractOperator{

	private List<? extends ExtractOperator> operators;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private SimpleOperatorChain() {
		
	}
	
	public SimpleOperatorChain(ExtractOperator ... operators){
		this.operators = Arrays.asList(operators);
	}

	public SimpleOperatorChain(List<? extends ExtractOperator> operators) {
		this.operators = operators;
	}

	public List<? extends ExtractOperator> getOperators() {
		return operators;
	}

	public SimpleOperatorChain setOperators(List<ExtractOperator> operators) {
		this.operators = operators;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand input) throws OperatorException{

		ExtractOperand nextOperand = input;
		for(ExtractOperator operator : operators){
			nextOperand = operator.apply(nextOperand);
		}
		return nextOperand;

	}
}
