package urjanet.pull.core;

import java.util.List;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.SessionContext;

/**
 * A PageSpec specifies the 'points of interest' in the content.
 * Primarily specifying which 'NavTargets' to follow on this page and
 * which DataTargets to extract.
 *
 * @author rburson
 */
public interface PageSpec {


	/**
	 *
	 * @return the type of content expected by this PageSpec
	 */
	public ContentType getExpectedContentType();

	/**
	 * 
	 * @param contentType target content type
	 */
	public void setExpectedContentType(ContentType contentType);
	
	/**
	 * 
	 * @return Configuration options for extraction.
	 */
	public ConfigOptions getConfigOptions();
	
	/**
	 * 
	 * @param configOptions config options for content types
	 */
	public void setConfigOptions(ConfigOptions configOptions);
	
	/**
	 * This returns all possible target groups
	 */
	public List<TargetGroup> getAllTargetGroups();
}
