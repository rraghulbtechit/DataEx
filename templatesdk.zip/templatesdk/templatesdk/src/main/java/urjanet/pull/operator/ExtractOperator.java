package urjanet.pull.operator;

/**
 *
 * @author rburson
 */
public interface ExtractOperator {

	public ExtractOperand apply(ExtractOperand operand) throws OperatorException;

}
