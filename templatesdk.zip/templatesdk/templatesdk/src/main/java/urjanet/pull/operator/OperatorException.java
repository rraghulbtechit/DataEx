package urjanet.pull.operator;

import urjanet.pull.PullException;

/**
 *
 * @author rburson
 */
public class OperatorException extends PullException{

	public OperatorException(){
		this("General OperatorException", null);
	}

	public OperatorException(Throwable t){
		this("General OperatorException", t);
	}

	public OperatorException(String message, Throwable t){
		super(message, t);
	}

	public OperatorException(String message){
		this(message, null);
	}
}
