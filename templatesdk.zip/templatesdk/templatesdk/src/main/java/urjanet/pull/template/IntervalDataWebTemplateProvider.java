package urjanet.pull.template;

import urjanet.pull.web.WebPullJobTemplate;

public interface IntervalDataWebTemplateProvider {
	public WebPullJobTemplate getIntervalDataTemplate();
}
