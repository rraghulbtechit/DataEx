package urjanet.pull.core;

/**
 * @author xavierd
 *
 */
public final class ExtractCoordinates {

	private String text;
	private int pageNumber;
	private double llx;
    private double lly;
    private double urx;
    private double ury;
    
    public ExtractCoordinates() {
        
    }
    
    /**
     * 
     * @param text
     * @param llx
     * @param lly
     * @param urx
     * @param ury
     */
    public ExtractCoordinates(final String text, final int pageNumber, 
    		final double llx, final double lly,	final double urx, final double ury) {
    	
    	this.text = text;
    	this.pageNumber = pageNumber;
    	this.llx = llx;
    	this.lly = lly;
    	this.urx = urx;
    	this.ury = ury;
    }

    /**
     * 
     * @return the whole text for the coordinates
     */
	public String getText() {
		return text;
	}

	/**
	 * 
	 * @return the Page Number
	 */
	public int getPageNumber() {
		return pageNumber;
	}
	
	/**
	 * 
	 * @return the llx position
	 */
	public double getLlx() {
		return llx;
	}

	/**
	 * 
	 * @return the lly position
	 */
	public double getLly() {
		return lly;
	}

	/**
	 * 
	 * @return the urx position
	 */
	public double getUrx() {
		return urx;
	}

	/**
	 * 
	 * @return the ury position
	 */
	public double getUry() {
		return ury;
	}
    
    @Override
    public String toString() {
    	
    	StringBuilder sb = new StringBuilder();
    	sb.append("ExtractCoordinates [").append("Text = ").append(text).append(", Page # = ").append(pageNumber);
    	sb.append(", Llx = ").append(llx).append(", Lly = ").append(lly);
    	sb.append(", Urx = ").append(urx).append(", Ury = ").append(ury).append("]");
    	
    	return sb.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
    	
    	if(obj == this) {
    		return true;
    	}
    	
    	if(obj instanceof ExtractCoordinates) {
    		ExtractCoordinates coord = (ExtractCoordinates)obj;
    		if(coord.getText().equals(this.text) && coord.getPageNumber() == this.pageNumber 
    				&& coord.getLlx() == this.llx && coord.getLly() == this.lly 
    				&& coord.getUrx() == this.urx && coord.getUry() == this.ury) {
    			return true;
    		}
    	}
    	
    	return false;
    }

}
