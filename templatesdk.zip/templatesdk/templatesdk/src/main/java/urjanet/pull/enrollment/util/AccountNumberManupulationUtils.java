package urjanet.pull.enrollment.util;

public class AccountNumberManupulationUtils {
	
	private int accountNumberLength;
	private int addZeroAccountNumberLength;
	
	public AccountNumberManupulationUtils () {
		
	}
	
	public AccountNumberManupulationUtils (int accountNumberLength ) {
		this.accountNumberLength = accountNumberLength;
	}
	
	public AccountNumberManupulationUtils (int trimAccountNumberLength , int addZeroAccountNumberLength ) {
		this.accountNumberLength = trimAccountNumberLength;
		this.addZeroAccountNumberLength = addZeroAccountNumberLength;
	}
	
	public String addLeadingZeros(String string ) {
		
		if ( this.accountNumberLength == 0 ) {
			throw new RuntimeException("Account Number Length is Zero , please set account Number length to add Zeros");
		}
		
		return StringManupulationUtil.addLeadingZeros(string, this.accountNumberLength);
	}

	public String trimToFixedLength(String string ) {
		
		if ( this.accountNumberLength == 0 ) {
			throw new RuntimeException("Account Number Length is Zero , please set account Number length to trim");
		}
		
		return StringManupulationUtil.trimToFixedLength(string, this.accountNumberLength);
	}
	
	public String removeLastDigit(String string) {
		return StringManupulationUtil.removeLastDigit(string);
	}
	
	public String addZerosAndTrimToFixedLength(String string) {
	
		if ( this.addZeroAccountNumberLength == 0 ) {
			throw new RuntimeException("Account Number Length is Zero , please set account Number length to add Zeros");
		}
	
		if ( this.accountNumberLength == 0 ) {
			throw new RuntimeException("Account Number Length is Zero , please set account Number length to trim");
		}
		
		string = StringManupulationUtil.addLeadingZeros(string, this.addZeroAccountNumberLength);
		return StringManupulationUtil.trimToFixedLength(string, this.accountNumberLength);
	}
	
	public String addZerosAndRemoveLastDigit(String string) {
		
		if ( this.accountNumberLength == 0 ) {
			throw new RuntimeException("Account Number Length is Zero , please set account Number length to add Zeros");
		}
		
		string = StringManupulationUtil.addLeadingZeros(string, this.accountNumberLength);
		return StringManupulationUtil.removeLastDigit(string);
	}

}