package urjanet.pull.web.pdf;

import java.util.List;

import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.pdf.key.ContextKey;

/**
 * This is PdfPageDataTarget
 *
 * Every template that is using PdfDataTargets must start with a PdfPageDataTarget before starting to use ContextFilters and ContextKeys
 *
 *  to tell subsequent DataTargets what page is on
 *
 * PdfPageDataTargets can be used at any level
 *
 * @author tim
 *
 */
public class PdfPageDataTarget extends DataTarget {

	private boolean inversePages;
	protected int startPage;
	protected int endPage;

	protected ContextKey startQualifier;
	protected ContextKey endQualifier;
	private String contextLabel;

	protected PdfPageDataTarget() {
		
	}

	private PdfPageDataTarget(int startPage, int endPage,
			GroupPolicy groupPolicy, String name, List<? extends DataTarget> relativeDataTargets) {

		this.startPage = startPage;
		this.endPage = endPage;
		this.startQualifier = null;
		this.endQualifier = null;

		if (groupPolicy != null)
			setGroupPolicy(groupPolicy);

		if (name != null)
			setName(name);

		if (relativeDataTargets != null)
			setRelativeDataTargets(relativeDataTargets);

	}

	public PdfPageDataTarget(int startPage, int endPage, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(startPage, endPage, groupPolicy, null, relativeDataTargets);
	}

	public PdfPageDataTarget(int startPage, int endPage, List<? extends DataTarget> relativeDataTargets) {
		this(startPage, endPage, null, relativeDataTargets);
	}

	public PdfPageDataTarget(int pageNumber, GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(pageNumber, pageNumber, groupPolicy, null, relativeDataTargets);
	}

	public PdfPageDataTarget(GroupPolicy groupPolicy, List<? extends DataTarget> relativeDataTargets) {
		this(0, 0, groupPolicy, null, relativeDataTargets);
	}

	public PdfPageDataTarget(int pageNumber, List<? extends DataTarget> relativeDataTargets) {
		this(pageNumber, pageNumber, null, relativeDataTargets);
	}

	public PdfPageDataTarget(List<? extends DataTarget> relativeDataTargets) {
		this(0, relativeDataTargets);
	}

	public int getStartPage() {
		return startPage;
	}

	public PdfPageDataTarget setStartPage(int startPage) {
		this.startPage = startPage;
		return this;
	}

	public int getEndPage() {
		return endPage;
	}

	public PdfPageDataTarget setEndPage(int endPage) {
		this.endPage = endPage;
		return this;
	}

	public ContextKey getStartQualifier() {
		return startQualifier;
	}

	public PdfPageDataTarget setStartQualifier(ContextKey startQualifier) {
		this.startQualifier = startQualifier;
		return this;
	}

	public ContextKey getEndQualifier() {
		return endQualifier;
	}

	public PdfPageDataTarget setEndQualifier(ContextKey endQualifier) {
		this.endQualifier = endQualifier;
		return this;
	}

	@Override
	public PdfPageDataTarget setOperator(ExtractOperator operator) {
		this.operator = operator;
		return this;
	}

	@Override
	public PdfPageDataTarget setFormatHint(String formatHint) {
		this.formatHint = formatHint;
		return this;
	}

	@Override
	public PdfPageDataTarget setQualifier(DataTargetQualifier qualifier) {
		this.qualifier = qualifier;
		return this;
	}

	@Override
	public PdfPageDataTarget setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
		return this;
	}


	@Override
	public PdfPageDataTarget setGroupingTarget(boolean groupingTarget) {
		this.groupingTarget = groupingTarget;
		return this;
	}

	@Override
	public PdfPageDataTarget setVariable(String variableName) {
		this.variableName = variableName;
		return this;
	}

	@Override
	public PdfPageDataTarget setDefaultValue(String... defaultValue) {
		String tempValue = defaultValue[0];

		for(int i = 1; i < defaultValue.length; i++)
			tempValue += "||" + defaultValue[i];

		return this;
	}

	/**
	 * @return the inversePages
	 */
	public boolean isInversePages() {
		return inversePages;
	}

	/**
	 * @param inversePages the inversePages to set
	 */
	public PdfPageDataTarget setInversePages(boolean inversePages) {
		this.inversePages = inversePages;
		return this;
	}

	/**
	 * 
	 * @return
	 */
	public String getContextLabel() {
		return contextLabel;
	}

	/**
	 * 
	 * @param contextLabel
	 * @return
	 */
	public PdfPageDataTarget setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
		return this;
	}

}
