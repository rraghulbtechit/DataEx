package urjanet.pull.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import urjanet.pull.bool.SwitchPageCondition;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.TargetGroup;

/**
 * 
 * This class allows for the Switch selection of all the underlying PageSpec objects.
 * The selection is based on SwitchPageCondition object which defines a PageCondition condition and Corresponding PageSpec.
 * This allows for a single PageSpec to handle several different configurations (PageSpecs) for single page, based
 * on the data available on the page.
 * 
 * 
 * @author venkadeshaperumal
 *
 */
public class SwitchConditionalPageSpec implements PageSpec{

	private List<SwitchPageCondition> switchPageCondition;
	private PageSpec defaultTargetSpec;
	
	public SwitchConditionalPageSpec() {
	}

	/**
	 * Create a new SwitchConditionalPageSpec
	 *
	 * @param List of SwitchPageCondition Object
	 */
	public SwitchConditionalPageSpec(PageSpec defaultTargetSpec, List<SwitchPageCondition> switchPageCondition) {
		this.defaultTargetSpec = defaultTargetSpec;
		this.switchPageCondition = switchPageCondition;
	}
	
	public SwitchConditionalPageSpec(PageSpec defaultTargetSpec, SwitchPageCondition... switchPageCondition) {
		this.defaultTargetSpec = defaultTargetSpec;
		this.switchPageCondition = Arrays.asList(switchPageCondition);
	}

	@Override
	public ContentType getExpectedContentType() {
		if (defaultTargetSpec != null)
			return this.defaultTargetSpec.getExpectedContentType();
		
		return null;
	}

	public List<SwitchPageCondition> getPageCondition() {
		return switchPageCondition;
	}
	
	public void setTargetSpec(PageSpec targetSpec) {
		this.defaultTargetSpec = targetSpec;
	}

	public PageSpec getTargetSpec() {
		return defaultTargetSpec;
	}
	
	@Override
	public void setExpectedContentType(ContentType expectedContentType) {
		this.defaultTargetSpec.setExpectedContentType(expectedContentType);
	}

	@Override
	public ConfigOptions getConfigOptions() {
		if (defaultTargetSpec != null)
			return this.defaultTargetSpec.getConfigOptions();
		
		return null;
	}

	@Override
	public void setConfigOptions(ConfigOptions configOptions) {
		this.defaultTargetSpec.setConfigOptions(configOptions);
	}

    public List<PageSpec> getAllPageSpecs() {
    	
    	List<PageSpec> allSpecs = new ArrayList<PageSpec>();
    	
    	for(SwitchPageCondition eachPageCondition : switchPageCondition) {
    		allSpecs.add(eachPageCondition.getTargetPageSpec());
    	}
    	
        return allSpecs;
    }

	@Override
	public List<TargetGroup> getAllTargetGroups() {
		List<TargetGroup> allGroups = new ArrayList<TargetGroup>();
		
		for(SwitchPageCondition eachPageCondition : switchPageCondition) {
			allGroups.addAll(eachPageCondition.getTargetPageSpec().getAllTargetGroups());
    	}
		
		return allGroups;
	}
	
	public SwitchConditionalPageSpec setPageCondition(List<SwitchPageCondition> pageCondition) {
		this.switchPageCondition = pageCondition;
		return this;
	}
	
}
