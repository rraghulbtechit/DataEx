package urjanet.pull.web;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.HtmlPage;


public class CustomRequestNavTarget extends ExpandableNavTarget {
	
	private static Logger log = LoggerFactory.getLogger(CustomRequestNavTarget.class);
	
	public static enum RequestType {GET, POST, OPTIONS, PUT};
	
	private RequestType requestType;
	private String url;
	private boolean closeAllWindows;
	
	private Map<String, String> additionalHeaders = new HashMap<String, String>();
	private String body;
	private boolean isLoginTarget;
	
	private boolean escapeVariables = false;
	
	/**
	 * NOTE - currently only honored by BifrostEngine
	 * wbo 4/13/16
	 */
	private Map<String, String> jsDataTargets;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private CustomRequestNavTarget() {
		
	}
	
	public CustomRequestNavTarget(String url, RequestType requestType, 
			Map<String, String> jsDataTargets) {
		this.requestType = requestType;
		this.url = url;
		this.jsDataTargets = jsDataTargets;
	}
	
	public CustomRequestNavTarget(String url, RequestType requestType) {
		this.requestType = requestType;
		this.url = url;
	}
	
	public CustomRequestNavTarget(String url, RequestType requestType, DataTarget variables) {
		this.requestType = requestType;
		this.url = url;
		this.metaDataTargets = variables;
	}
	
	public CustomRequestNavTarget(String url, DataTarget variables) {
		this(url, RequestType.GET, variables);
	}
	
	@Override
	public boolean isDynamicTarget() {
		return metaDataTargets != null;
	}
	
	public Map<String, String> getJsDataTargets() {
		return jsDataTargets;
	}
	
	public WebRequest getRequest(Page page) throws MalformedURLException {
		
		String requestUrl = url;
		final URL url;
		if (page instanceof HtmlPage) {
			url = ((HtmlPage)page).getFullyQualifiedUrl(requestUrl);
		} else {
			url = new URL(requestUrl);
		}
		log.trace("<Fully Qualified URL> " + url);
		final WebRequest wrs = new WebRequest(url);
		
		if (requestType == RequestType.POST)
			wrs.setHttpMethod(HttpMethod.POST);
		else if (requestType == RequestType.PUT)
			wrs.setHttpMethod(HttpMethod.PUT);
		else if (requestType == RequestType.OPTIONS)
			wrs.setHttpMethod(HttpMethod.OPTIONS);
		else
			wrs.setHttpMethod(HttpMethod.GET);
		
		if (body != null)
			wrs.setRequestBody(body);
		
		for (String key : additionalHeaders.keySet())
			wrs.setAdditionalHeader(key, additionalHeaders.get(key));
		
		if (additionalHeaders.get("Referer") == null && page != null) {
			wrs.setAdditionalHeader("Referer", page.getWebResponse().getWebRequest().getUrl().toExternalForm());
		}
		
		return wrs;
	}

	public RequestType getRequestType() {
		return requestType;
	}
	
	public CustomRequestNavTarget setRequestType(RequestType requestType) {
		this.requestType = requestType;
		return this;
	}

	public String getUrl() {
		return url;
	}

	public Map<String, String> getAdditionalHeaders() {
		return additionalHeaders;
	}

	public CustomRequestNavTarget setUrl(String url) {
		this.url = url;
		return this;
	}

	public CustomRequestNavTarget setVariables(XmlDataTarget variables) {
		this.metaDataTargets = variables;
		return this;
	}

	public CustomRequestNavTarget setAdditionalHeaders(Map<String, String> additionalHeaders) {
		this.additionalHeaders = additionalHeaders;
		return this;
	}

	public CustomRequestNavTarget addAdditionalHeader(String key, String value) {
		this.additionalHeaders.put(key, value);
		return this;
	}

	public String getBody() {
		return body;
	}

	public CustomRequestNavTarget setBody(String body) {
		this.body = body;
		return this;
	}

	/**
	 * @return the closeAllWindows
	 */
	public boolean isCloseAllWindows() {
		return closeAllWindows;
	}

	/**
	 * @param closeAllWindows the closeAllWindows to set
	 */
	public CustomRequestNavTarget setCloseAllWindows(boolean closeAllWindows) {
		this.closeAllWindows = closeAllWindows;
		return this;
	}

	public boolean isEscapeVariables() {
		return escapeVariables;
	}

	public CustomRequestNavTarget setEscapeVariables(boolean escapeVariables) {
		this.escapeVariables = escapeVariables;
		return this;
	}

	public boolean isLoginTarget() {
		return isLoginTarget;
	}

	public CustomRequestNavTarget setLoginTarget(boolean isLoginTarget) {
		this.isLoginTarget = isLoginTarget;
		return this;
	}

}
