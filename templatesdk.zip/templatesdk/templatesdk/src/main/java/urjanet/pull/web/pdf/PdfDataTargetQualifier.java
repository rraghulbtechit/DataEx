package urjanet.pull.web.pdf;

import java.util.Arrays;
import java.util.List;

import urjanet.keys.MetaKeys;
import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.key.StringKey;

public class PdfDataTargetQualifier extends BaseDataTargetQualifier {
	
	private DataTarget qualifyingTarget;

	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private PdfDataTargetQualifier() {
		
	}
	
	public PdfDataTargetQualifier(String qualifierName, DataTarget qualifyingTarget) {
		super(qualifierName);
		this.qualifyingTarget = qualifyingTarget;
	}
	
	public PdfDataTargetQualifier(DataTarget qualifyingTarget) {
		this(null, qualifyingTarget);
	}
	
	public PdfDataTargetQualifier(String qualifierName, String stringKey) {
		this(qualifierName, new PdfDataTarget(new StringKey(stringKey), MetaKeys.CONDITIONAL_KEY.getValue()));
	}
	
	public PdfDataTargetQualifier(String stringKey) {
		this(null, stringKey);
	}
	
	public PdfDataTargetQualifier(List<? extends ContextFilter> filters) {
		this(new PdfDataTarget(filters, MetaKeys.CONDITIONAL_KEY.getValue()));
	}
	
	public PdfDataTargetQualifier(String qualifierName, ContextFilter ... filters) {
		this(qualifierName, new PdfDataTarget(Arrays.asList(filters), MetaKeys.CONDITIONAL_KEY.getValue()));
	}
	
	public PdfDataTargetQualifier(ContextFilter ... filters) {
		this(null, new PdfDataTarget(Arrays.asList(filters), MetaKeys.CONDITIONAL_KEY.getValue()));
	}
	
	public DataTarget getQualifyingTarget() {
		return qualifyingTarget;
	}
	
	public PdfDataTargetQualifier setQualifyingTarget(DataTarget qualifyingTarget) {
		this.qualifyingTarget = qualifyingTarget;
		return this;
	}
	
}