package urjanet.pull.template.content;

import urjanet.pull.core.PageSpec;

public interface CsvPageSpecProvider {

	public PageSpec getCsvPageSpec();

}
