package urjanet.pull.bool;

import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.DataTarget;

/**
 * 
 * @author xavierd
 * 
 * This acts as a base class for all comparison qualifiers.
 *
 */
public abstract class ComparisonDataTargetQualifier extends BaseDataTargetQualifier {
	
	private ComparisonOperator comparisonOperator;
	private DataTarget qualifyingTarget1;
	private DataTarget qualifyingTarget2;
	
	public static enum ComparisonOperator { EQUAL_TO, LESS_THAN, GREATER_THAN, LESS_THAN_OR_EQUAL_TO, GREATER_THAN_OR_EQUAL_TO };
	
	public abstract int compareTo(String value1, String value2);

	protected ComparisonDataTargetQualifier() {
		
	}
	
	public ComparisonDataTargetQualifier(String qualifierName, ComparisonOperator operator, DataTarget target1, DataTarget target2) {
		super(qualifierName);
		this.comparisonOperator = operator;
		this.qualifyingTarget1 = target1;
		this.qualifyingTarget2 = target2;
	}
	public ComparisonDataTargetQualifier(ComparisonOperator operator, DataTarget target1, DataTarget target2) {
		this(null, operator, target1, target2);
	}

	public ComparisonOperator getComparisonOperator() {
		return comparisonOperator;
	}

	public ComparisonDataTargetQualifier setComparisonOperator(ComparisonOperator comparisonOperator) {
		this.comparisonOperator = comparisonOperator;
		return this;
	}

	public DataTarget getQualifyingTarget1() {
		return qualifyingTarget1;
	}
	
	public ComparisonDataTargetQualifier setQualifyingTarget1(DataTarget qualifyingTarget1) {
		this.qualifyingTarget1 = qualifyingTarget1;
		return this;
	}

	public DataTarget getQualifyingTarget2() {
		return qualifyingTarget2;
	}
	
	public ComparisonDataTargetQualifier setQualifyingTarget2(DataTarget qualifyingTarget2) {
		this.qualifyingTarget2 = qualifyingTarget2;
		return this;
	}
	
}
