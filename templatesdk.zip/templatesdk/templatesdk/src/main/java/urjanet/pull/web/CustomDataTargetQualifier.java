package urjanet.pull.web;

import urjanet.pull.core.Content;

public abstract class CustomDataTargetQualifier implements DataTargetQualifier {

	public abstract boolean targetIsValid(Content content, SessionContext context);
	
}
