package urjanet.pull.web.pdf.filter;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.web.pdf.key.ContextKey;
import urjanet.pull.web.pdf.key.StringKey;

public class RangeFilter extends ContextFilter {

	private ContextKey startKey;
	private ContextKey endKey;
	private OverlapPosition overlapTextPosition;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private RangeFilter() {
		
	}
	
	public RangeFilter(ContextKey startKey, ContextKey endKey) {
		this.startKey = startKey;
		this.endKey = endKey;
	}
	
	public RangeFilter(ContextKey startKey) {
		this(startKey, null);
	}
	
	public RangeFilter(String startKey) {
		this(new StringKey(startKey), null);
	}
	
	public RangeFilter(String startKey, String endKey) {
		this(new StringKey(startKey), new StringKey(endKey));
	}
	
	/**
	 * Use this method if your endKey might occur before the startKey
	 * as the current implementation might find the endKey before the startKey and
	 * then your context will be nothing
	 * @param startKey
	 * @param endKey
	 */
	public static List<RangeFilter> getRangeForceEndAfterStart(ContextKey startKey, ContextKey endKey) {
		return Arrays.asList(new RangeFilter(startKey, null), new RangeFilter(null, endKey));
	}
	
	public ContextKey getStartKey() {
		return startKey;
	}
	
	/**
	 * @param startKey the startKey to set
	 */
	public RangeFilter setStartKey(ContextKey startKey) {
		this.startKey = startKey;
		return this;
	}

	public ContextKey getEndKey() {
		return endKey;
	}
	
	/**
	 * @param endKey the endKey to set
	 */
	public RangeFilter setEndKey(ContextKey endKey) {
		this.endKey = endKey;
		return this;
	}

	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}
	
	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public RangeFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public RangeFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}

	public String toString() {
		String startQualifierString = (startKey==null)?"":startKey.toString();
		String endQualifierString = (endKey==null)?"":endKey.toString();
		
		return "RangeContextFilter: " + " start - " + startQualifierString+", end - "+endQualifierString;
	}
}
