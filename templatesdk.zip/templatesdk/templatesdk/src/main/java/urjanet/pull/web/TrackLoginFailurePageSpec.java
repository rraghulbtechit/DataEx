package urjanet.pull.web;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.bool.PageCondition;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.TargetGroup;

public class TrackLoginFailurePageSpec implements PageSpec {
	
	private final Logger log = LoggerFactory.getLogger(TrackLoginFailurePageSpec.class);
	
	private PageSpec postLoginSuccessPageSpec;
	private PageCondition loginFailureCondition;
	private Boolean loginFailure;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private TrackLoginFailurePageSpec() {
		
	}
	
	public TrackLoginFailurePageSpec(PageSpec postLoginSuccessPageSpec, PageCondition loginFailureCondition) {
		this.postLoginSuccessPageSpec = postLoginSuccessPageSpec;
		this.loginFailureCondition = loginFailureCondition;
	}

	public PageSpec getPageSpec() {
		return postLoginSuccessPageSpec;
	}

	/**
	 * @param postLoginSuccessPageSpec the pageSpec to set
	 */
	public TrackLoginFailurePageSpec setPageSpec(PageSpec postLoginSuccessPageSpec) {
		this.postLoginSuccessPageSpec = postLoginSuccessPageSpec;
		return this;
	}
	
	public PageCondition getPageCondition() {
		return loginFailureCondition;
	}
	
	/**
	 * @param pageCondition the pageCondition to set
	 */
	public TrackLoginFailurePageSpec setPageCondition(PageCondition pageCondition) {
		this.loginFailureCondition = pageCondition;
		return this;
	}

	public Boolean getLoginFailure() {
		return loginFailure;
	}
	
	/**
	 * @param loginFailure the loginFailure to set
	 */
	public TrackLoginFailurePageSpec setLoginFailure(Boolean loginFailure) {
		this.loginFailure = loginFailure;
		return this;
	}
	

	public Logger getLog() {
		return log;
	}
	

	@Override
	public ContentType getExpectedContentType() {
		return postLoginSuccessPageSpec.getExpectedContentType();
	}

	@Override
	public void setExpectedContentType(ContentType contentType) {
		postLoginSuccessPageSpec.setExpectedContentType(contentType);
	}

	@Override
	public ConfigOptions getConfigOptions() {
		return postLoginSuccessPageSpec.getConfigOptions();
	}

	@Override
	public void setConfigOptions(ConfigOptions configOptions) {
		postLoginSuccessPageSpec.setConfigOptions(configOptions);
	}

	@Override
	public List<TargetGroup> getAllTargetGroups() {
		return postLoginSuccessPageSpec.getAllTargetGroups();
	}
	
	
	public PageSpec getTargetPageSpec() {
		return postLoginSuccessPageSpec;
	}

}
