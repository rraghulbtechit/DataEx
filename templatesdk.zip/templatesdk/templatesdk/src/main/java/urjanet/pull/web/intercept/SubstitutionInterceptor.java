package urjanet.pull.web.intercept;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebConnection;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebResponseData;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import urjanet.pull.web.SessionContext;

/**
 * This class is provided as a base class to allow for substituting (or removing) parts of the reponse's body text received from the server.
 * A WebConnenctionWrapper is a wrapper for htmlunit's 'WebConnection that allows us to add custom response processing
 *
 * @author rburson
 */
public abstract class SubstitutionInterceptor extends Interceptor{

	public SubstitutionInterceptor(WebConnection webConnection, WebClient webClient, SessionContext context) throws IllegalArgumentException {
		super(webConnection, webClient, context);
	}

	@Override
	public WebResponse getResponse(final WebRequest webRequest) throws IOException {		

		doSubstitutionOnRequest(webRequest);
		WebResponse response = super.getResponse(webRequest);
		return doSubstitutionOnResponse(response, webRequest);

	}

	/**
	 * This method should be subclassed to do in-place substitution on the WebRequestSettings
	 *
	 * @param webRequestSettings
	 */
	public abstract void doSubstitutionOnRequest(final WebRequest webRequest);

	/**
	 * This method should be subclassed to do substitution on the WebReponse (body or headers, etc) that is returned from the server
	 *
	 * @param orginalResponse
	 * @param webRequestSettings
	 * @return the new webresponse
	 * @throws IOException
	 */
	public abstract WebResponse doSubstitutionOnResponse(final WebResponse originalResponse, final WebRequest webRequest) throws IOException;

	/**
	 * Check to see if a particular 'pattern' is in the response.
	 * 
	 * @param pattern the pattern to find
	 * @param response the web response to apply the pattern to
	 * @return whether or not the pattern is matched in the input
	 */
	protected boolean responseContainsPattern(final Pattern pattern, final WebResponse response){

		return pattern.matcher(response.getContentAsString()).find();

	}

	/**
	 * Replace all occurances of 'pattern' with the supplied string
	 *
	 * @param pattern the pattern to used to match the substrings to be replaced
	 * @param replacementText the text to replace the matched substrings
	 * @param inputString the input to which to apply the substitution
	 * @return the new string with the substitutions applied
	 */
	protected String replaceAllMatchesWithString(final Pattern pattern, final String replacementText, final String inputString){

		if(pattern != null && replacementText != null && inputString != null)
			return pattern.matcher(inputString).replaceAll(replacementText);

		return inputString;

	}

	/**
	 *
	 * @param original the original response
	 * @param newBody the new body text
	 * @param webRequestSettings the orignal webrequestsettings
	 * @return a new WebResponse with the supplied body text
	 */
	protected WebResponse createNewResponseBody(final WebResponse original, final String newBody, final WebRequest webRequestSettings) throws IOException {

		return new WebResponse(new WebResponseData(newBody.getBytes(), original.getStatusCode(), original.getStatusMessage(), original.getResponseHeaders()),
			webRequestSettings, original.getLoadTime());

	}
	
	/**
	 * 
	 * @param wr
	 * @param content
	 * @param contentType
	 * @param responseCode
	 * @param responseMessage
	 * @return a new web response
	 * @throws IOException
	 */
	protected WebResponse createWebResponse(final WebRequest wr, final String content, final String contentType, final int responseCode, final String responseMessage) throws IOException {
		
        final List<NameValuePair> headers = new ArrayList<NameValuePair>();
        final String encoding = "UTF-8";
        headers.add(new NameValuePair("content-type", contentType + "; charset=" + encoding));
        final byte[] body = content.getBytes(encoding);
        final WebResponseData wrd = new WebResponseData(body, responseCode, responseMessage, headers);
        
        return new WebResponse(wrd, wr.getUrl(), wr.getHttpMethod(), 0);
    }

}
