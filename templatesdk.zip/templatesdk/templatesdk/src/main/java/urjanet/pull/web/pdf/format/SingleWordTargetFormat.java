package urjanet.pull.web.pdf.format;

public class SingleWordTargetFormat extends WordTargetFormat {

}
