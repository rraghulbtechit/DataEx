package urjanet.pull.web.pdf.filter;

import urjanet.pull.web.pdf.key.ContextKey;

/**
 * Use PdfPageDataTarget or ExpandablePdfPageDataTarget
 * 
 * @author tim
 *
 */
@Deprecated
public class PageFilter extends ContextFilter {
	
	private int startPage;
	private int endPage;
	private ContextKey startQualifier;
	private ContextKey endQualifier;
	

	public PageFilter(int pageNumber) {
		this.startPage = pageNumber;
		this.endPage = pageNumber;
		this.startQualifier = null;
		this.endQualifier = null;
	}

	public PageFilter(int startPage, int endPage) {
		this.startPage = startPage;
		this.endPage = endPage;
		this.startQualifier = null;
		this.endQualifier = null;
	}
	
	public PageFilter() {
		this.startPage = 0;
		this.endPage = 0;
		this.startQualifier = null;
		this.endQualifier = null;
	}

	public int getStartPage() {
		return startPage;
	}
	
	/**
	 * @param startPage the startPage to set
	 */
	public PageFilter setStartPage(int startPage) {
		this.startPage = startPage;
		return this;
	}

	public int getEndPage() {
		return endPage;
	}
	
	/**
	 * @param endPage the endPage to set
	 */
	public PageFilter setEndPage(int endPage) {
		this.endPage = endPage;
		return this;
	}
	
	public ContextKey getStartQualifier() {
		return startQualifier;
	}
	
	/**
	 * @param startQualifier the startQualifier to set
	 */
	public PageFilter setStartQualifier(ContextKey startQualifier) {
		this.startQualifier = startQualifier;
		return this;
	}

	public ContextKey getEndQualifier() {
		return endQualifier;
	}
	
	/**
	 * @param endQualifier the endQualifier to set
	 */
	public PageFilter setEndQualifier(ContextKey endQualifier) {
		this.endQualifier = endQualifier;
		return this;
	}
	
	public String toString() {
		String startQualifierString = (startQualifier==null)?"":startQualifier.toString();
		String endQualifierString = (endQualifier==null)?"":endQualifier.toString();
		
		return "PageContextFilter: " + " page " + startPage + " to " + endPage + " , start - " + startQualifierString+", end - "+endQualifierString;
	}
}
