package urjanet.pull.web.pdf.filter;

import urjanet.pull.web.pdf.key.ContextKey;

public class HorizontalFilter extends ContextFilter {

	private ContextKey startKey;
	private double topBuffer, bottomBuffer, offset;
	private boolean forward;
	private double maxDistance;
	private OverlapPosition overlapTextPosition;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private HorizontalFilter() {
		
	}
	
	public HorizontalFilter(ContextKey startKey, double topBuffer, double bottomBuffer, double offset, boolean forward) {
		super();
		this.startKey = startKey;
		this.topBuffer = topBuffer;
		this.bottomBuffer = bottomBuffer;
		this.forward = forward;
		this.offset = offset;
	}
	
	public HorizontalFilter(ContextKey startKey, double topBuffer, double bottomBuffer, double offset) {
		super();
		this.startKey = startKey;
		this.topBuffer = topBuffer;
		this.bottomBuffer = bottomBuffer;
		this.forward = true;
		this.offset = offset;
	}
	
	public HorizontalFilter(ContextKey startKey, double topBuffer, double bottomBuffer, boolean forward) {
		super();
		this.startKey = startKey;
		this.topBuffer = topBuffer;
		this.bottomBuffer = bottomBuffer;
		this.forward = forward;
	}
	
	public HorizontalFilter(ContextKey startKey, double topBuffer, double bottomBuffer) {
		this(startKey, topBuffer, bottomBuffer, 0, true);
	}
	
	public HorizontalFilter(ContextKey startKey, double bottomBuffer) {
		this(startKey, 0.0, bottomBuffer, 0, true);
	}
	
	public HorizontalFilter(ContextKey startKey) {
		this(startKey, 0.0, 0.0, 0, true);
	}

	public double getMaxDistance() {
		return maxDistance;
	}

	public HorizontalFilter setMaxDistance(double maxDistance) {
		this.maxDistance = maxDistance;
		return this;
	}
	
	public ContextKey getStartKey() {
		return startKey;
	}

	/**
	 * @param startKey the startKey to set
	 */
	public HorizontalFilter setStartKey(ContextKey startKey) {
		this.startKey = startKey;
		return this;
	}

	public double getTopBuffer() {
		return topBuffer;
	}
	
	/**
	 * @param topBuffer the topBuffer to set
	 */
	public HorizontalFilter setTopBuffer(double topBuffer) {
		this.topBuffer = topBuffer;
		return this;
	}
	
	public double getBottomBuffer() {
		return bottomBuffer;
	}

	/**
	 * @param bottomBuffer the bottomBuffer to set
	 */
	public HorizontalFilter setBottomBuffer(double bottomBuffer) {
		this.bottomBuffer = bottomBuffer;
		return this;
	}

	public double getOffset() {
		return offset;
	}
	
	/**
	 * @param offset the offset to set
	 */
	public HorizontalFilter setOffset(double offset) {
		this.offset = offset;
		return this;
	}
	
	public boolean isForward() {
		return forward;
	}
	
	/**
	 * @param forward the forward to set
	 */
	public HorizontalFilter setForward(boolean forward) {
		this.forward = forward;
		return this;
	}
	
	public OverlapPosition getOverlapTextPosition() {
		return overlapTextPosition;
	}
	
	/**
	 * @param overlapTextPosition the overlapTextPosition to set
	 */
	public HorizontalFilter setOverlapTextPosition(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	/**
	 * 
	 * @param overlapTextPosition
	 * @return
	 */
	public HorizontalFilter removeOverlappingWords(OverlapPosition overlapTextPosition) {
		this.overlapTextPosition = overlapTextPosition;
		return this;
	}
	
	public String toString() {
		return "HorizontalContextFilter: " + ((startKey==null)?"":startKey.toString()) 
		+ ", top - " + topBuffer + ", bottom - " + bottomBuffer + ", forward - " + forward + ", maxDistance - " + maxDistance;
	}
	
}