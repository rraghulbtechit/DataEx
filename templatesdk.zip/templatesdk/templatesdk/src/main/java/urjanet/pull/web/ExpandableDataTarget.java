package urjanet.pull.web;

import java.util.List;

/**
 * An ExpandableDataTarget only applies an emblematic distinction to an XmlDataTarget.
 * It does not add any behavior. It does however, allow for the selection of multiple nodes to
 * be treated as XmlDataTargets.  This is useful for applying a sort of 'templating' mechansim to a single
 * Xml(Html) page, in which 'sections' or 'blocks' of the page could be generalized for use of the same set of sub-targets.
 * An instance of this class specifies that this XmlDataTarget will actually be
 * be a set of one or more XmlDataTargets once the 'xpath' selector is applied to the page.
 * That is, it can be assumed that the xpath statement will select multiple nodes which will then each become
 * a single XmlDataTarget.
 *<p>
 * The expansion for ExpandableDataTarget is handled by DataTargetHandler
 *<p>
 * This class is similar to ExpandableNavTarget and ExpandableInputElement
 *
 * @author rburson
 * @see ExpandableNavTarget
 * @see ExpandableInputElement
 * @see DataTargetHandler
 */
public class ExpandableDataTarget extends XmlDataTarget{

	public ExpandableDataTarget() {
	}
	
	/**
	 * Create a new XmlDataTarget to hold relative sub-targets and assign it an id that puts it in a
	 * Collection Subgroup.
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param xPath the xpath to a set of relative nodes
	 * @param relativeDataTargets the sub-targets that relative to this node
	 * @param id the subgroup to put this target and all of it's sub-targets in
	 */
	public ExpandableDataTarget(GroupPolicy groupPolicy, String xPath, List<XmlDataTarget> relativeDataTargets) {
		super(groupPolicy, xPath, relativeDataTargets);
	}


		/**
	 * Create a new XmlDataTarget to hold relative sub-targets
	 * There is no need to name this target as it is simply a reference point for sub-nodes
	 *
	 * @param xPath the xpath to a set of relative nodes
	 * @param relativeDataTargets the sub-targets that relative to this node
	 */
	public ExpandableDataTarget(String xPath, List<XmlDataTarget> relativeDataTargets) {
		super(xPath, relativeDataTargets);
	}

}
