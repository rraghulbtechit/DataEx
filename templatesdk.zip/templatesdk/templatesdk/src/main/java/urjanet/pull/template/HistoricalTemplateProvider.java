package urjanet.pull.template;

import urjanet.pull.core.PullJobTemplate;

import java.util.List;


public interface HistoricalTemplateProvider extends TemplateProvider {
    public List<PullJobTemplate> getHistoricalTemplate();
}
