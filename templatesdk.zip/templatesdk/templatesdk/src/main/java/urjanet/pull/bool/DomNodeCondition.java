package urjanet.pull.bool;

import com.gargoylesoftware.htmlunit.html.DomNode;

/**
 *
 * @author rburson
 */
public interface DomNodeCondition {

	public boolean isTrue(DomNode node);
}
