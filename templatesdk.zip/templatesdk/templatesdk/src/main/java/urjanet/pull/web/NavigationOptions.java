package urjanet.pull.web;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.pull.web.cache.CacheRule;

public class NavigationOptions {
	
	private static final Logger log = LoggerFactory.getLogger(NavigationOptions.class);
	
	private List<? extends CacheRule> cacheRules;
	private String sslProtocol;
	private Boolean useInsecureSSL;
	private Integer handleRefreshesUnderSeconds;
	
//	private String cookieName;	// TODO: what?   (see below... should have methods to add cookies....)
//	private boolean clearcookie;
//	// Need to find a generic way to do this. Currently this is specific to JEA alone.
//	if(initialConfig.getCookieName()!=null){
//		topWebClient.getCookieManager().addCookie(new Cookie(".jea.com", "jeaDevice_" + initialConfig.getCookieName(), initialConfig.getCookieName(), "/", new Date(2099,1,1) , false));
//		topWebClient.getCookieManager().addCookie(new Cookie("LogCOOKPl95FnjAT", initialConfig.getCookieName(), initialConfig.getCookieName(), "/", new Date(2099,1,1) , false));
//	}

	private Boolean concurrentAccessOk;				// used to mark nav requests as asynchronous
	private Boolean ignoreSubsequentRefresh;
	private String interceptorName;
	private Boolean retryOnScriptException;
	private Boolean disableJavaScript;
	private AgentVersion agentVersion;
	private Integer timeout;						// TODO isn't actually being set on webclient right now...
	private Boolean clearCache;
	private Long waitForJavascript;
	/**
	 * TODO - we should impose a max timeout on this type of wait
	 * and force the js executor thread to end so we never wait forever
	 */
	private Long waitForJavascriptBefore;
	private Boolean tryHandleException;
	private Boolean forceJavaScriptProcessing;
	private Boolean waitForJavascriptOnOriginalPage;
	private Boolean disableExceptionOnScriptError;
	private Boolean clearCookies;
	private Boolean doNotCloseAllWindows;
	private List<Integer> allowedStatusCodes;
	private WebClientInstance webClientInstance;
	private List<String> handleJavascriptAlerts;
	private Boolean doNotApplyPageHistory;
	private Boolean clearHtmlUnitTemporaryFiles;
	
	private AjaxProcessing ajaxProcessing;
	
	private Integer numberOfRetries = 3;
	private Boolean refreshResponseFromServer;
	private Boolean rerenderAjax;
	/*
 	* This addresses some bugs in HtmlUnit
 	* It should be used to address the following situation(s):
 	* 1) An iframe is inserted by Javascript dynamically
 	* This should be re-evaluated when upgrading HtmlUnit
 	*/
	private Boolean needsReinitialization;
	
	/**
	 * These should be legacy options to use basic auth
	 * during navigation
	 */
	private Boolean useBasicAuth;
	private String username;	
	private String password;
	
	private Boolean doNotReloadOriginalPage;
	private String disableTlsAlgorithm;
	private boolean isUseThreadRefreshHandler;
	private Boolean isCssEnabled;

	public static NavigationOptions getDefaultOptions() {
		NavigationOptions defaultOptions = new NavigationOptions();

		defaultOptions.setConcurrentAccessOk(false);
		defaultOptions.setIgnoreSubsequentRefresh(false);
		defaultOptions.setRetryOnScriptException(false);
		defaultOptions.setDisableJavaScript(false);
		defaultOptions.setAgentVersion(AgentVersion.CHROME);
		defaultOptions.setTimeout(WebPullJobTemplate.CONNECT_TIMEOUT);
		defaultOptions.setClearCache(false);
		defaultOptions.setWaitForJavascript(0l);
		defaultOptions.setWaitForJavascriptBefore(0l);
		defaultOptions.setTryHandleException(false);
		defaultOptions.setForceJavaScriptProcessing(false);
		defaultOptions.setDisableAjaxController(false);
		defaultOptions.setWaitForJavascriptOnOriginalPage(false);
		defaultOptions.setDisableExceptionOnScriptError(false);
		defaultOptions.setClearCookies(false);
		defaultOptions.setDoNotCloseAllWindows(false);
		defaultOptions.setWebClientInstance(WebClientInstance.MULTIPLE);
		defaultOptions.setDoNotApplyPageHistory(false);
		defaultOptions.setClearHtmlUnitTemporaryFiles(false);

		defaultOptions.setNumberOfRetries(3);
		defaultOptions.setRefreshResponseFromServer(false);
		defaultOptions.setRerenderAjax(false);
		defaultOptions.setNeedsReinitialization(false);
		defaultOptions.setUseBasicAuth(false);
		
		defaultOptions.setHandleRefreshesUnderSeconds(-1);
		
		defaultOptions.setDoNotReloadOriginalPage(false);
		defaultOptions.setUseThreadRefreshHandler(false);
		defaultOptions.setCssEnabled(true);

		return defaultOptions;
	}
	
	/**
	 * Overrides this option set with overrides set in optionOverrides (non-null options)
	 * Use this option when you have a base option set that you want to override with specific options set in optionOverrides
	 */
	public void overrideWith(NavigationOptions optionOverrides) {
		if (optionOverrides == null)
			return;
		for (Field f : FieldUtils.getAllFields(this.getClass())) {
			if (Modifier.isStatic(f.getModifiers()))
				continue;
			Object override = null;
			try {
				override = f.get(optionOverrides);
			} catch (Exception e) {
				log.warn("Exception getting navigationOption override for {} - {}", f.getName(), e.getMessage());
				continue;
			}
			if (override != null) {
				try {
					f.set(this, override);
//					log.trace("Overriding {} with {}", f.getName(), override.toString());
				} catch (Exception e) {
					log.warn("Exception setting navigationOption override for {} - {}", f.getName(), e.getMessage());
				}
			}
		}
	}
	
	
	/**
	 * Sets options from baseOptions when option is null in the current option set
	 * Use this function when you have set a few specific options and want to set default options for the rest
	 * (Generally you need to merge in a default option set to ensure all (wrapped)primitive options are set ie. bools to avoid npe's)
	 */
	public void merge(NavigationOptions baseOptions) {
		if (baseOptions == null) {
			log.warn("Attempting to merge NavigationOptions with null... merging with default options instead");
			mergeWithDefaultOptions();
			return;
		}
		for (Field f : FieldUtils.getAllFields(this.getClass())) {
			if (Modifier.isStatic(f.getModifiers()))
				continue;
			Object thisField;
			try {
				thisField = f.get(this);
			} catch (Exception e) {
				log.warn("Exception getting NavigationOption for {} - {}", f.getName(), e.getMessage());
				continue;
			}
			if (thisField == null) {	// can merge in the value from baseOptions
				Object baseOptionValue;
				try {
					baseOptionValue = f.get(baseOptions);
				} catch (Exception e) {
					log.warn("Exception getting base NavigationOptions option value for {} - {}", f.getName(), e.getMessage());
					continue;
				}
				if (baseOptionValue != null) {
					try {
						f.set(this, baseOptionValue);
//						log.trace("Merging {} with {}", f.getName(), baseOptionValue.toString());
					} catch (Exception e) {
						log.warn("Exception setting base NavigationOption override for {} - {}", f.getName(), e.getMessage());
					}
				}
			}
		}
	}
	
	public void mergeWithDefaultOptions() {
		merge(getDefaultOptions());
	}
	
	
	public Boolean getConcurrentAccessOk() {
		return concurrentAccessOk;
	}
	public void setConcurrentAccessOk(Boolean concurrentAccessOk) {
		this.concurrentAccessOk = concurrentAccessOk;
	}
	public Boolean getIgnoreSubsequentRefresh() {
		return ignoreSubsequentRefresh;
	}
	public void setIgnoreSubsequentRefresh(Boolean ignoreSubsequentRefresh) {
		this.ignoreSubsequentRefresh = ignoreSubsequentRefresh;
	}
	public String getInterceptorName() {
		return interceptorName;
	}
	public void setInterceptorName(String interceptorName) {
		this.interceptorName = interceptorName;
	}
	public Boolean getRetryOnScriptException() {
		return retryOnScriptException;
	}
	public void setRetryOnScriptException(Boolean retryOnScriptException) {
		this.retryOnScriptException = retryOnScriptException;
	}
	public Boolean getDisableJavaScript() {
		return disableJavaScript;
	}
	public void setDisableJavaScript(Boolean disableJavaScript) {
		this.disableJavaScript = disableJavaScript;
	}
	public AgentVersion getAgentVersion() {
		return agentVersion;
	}
	public void setAgentVersion(AgentVersion agentVersion) {
		this.agentVersion = agentVersion;
	}
	public Integer getTimeout() {
		return timeout;
	}
	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}
	public Boolean getClearCache() {
		return clearCache;
	}
	public void setClearCache(Boolean clearCache) {
		this.clearCache = clearCache;
	}
	public Long getWaitForJavascript() {
		return waitForJavascript;
	}
	public void setWaitForJavascript(Long waitForJavascript) {
		this.waitForJavascript = waitForJavascript;
	}
	public Long getWaitForJavascriptBefore() {
		return waitForJavascriptBefore;
	}
	public void setWaitForJavascriptBefore(Long waitForJavascriptBefore) {
		this.waitForJavascriptBefore = waitForJavascriptBefore;
	}
	public Boolean getTryHandleException() {
		return tryHandleException;
	}
	public void setTryHandleException(Boolean tryHandleException) {
		this.tryHandleException = tryHandleException;
	}
	public Boolean getForceJavaScriptProcessing() {
		return forceJavaScriptProcessing;
	}
	public void setForceJavaScriptProcessing(Boolean forceJavaScriptProcessing) {
		this.forceJavaScriptProcessing = forceJavaScriptProcessing;
	}
	public Boolean getDisableAjaxController() {
		return ajaxProcessing == AjaxProcessing.ASYNCHRONOUS;
	}
	/**
	 * TODO - this doesn't do what the name implies...
	 * It seems (perhaps only with GWT sites) that certain "postponed" js
	 * does not executed when using USER_ACTION_SYNCHRONOUS ajax processing...
	 *   ie) "Processing PostponedAction PostponedAction(Execution of script 
	 *        HtmlScript[<script src="https://ozarksecc.smarthub.coop/deferredjs/A10EF36B4C8A4F8AFAFFB7FF7F8CDF45/8.cache.js">])"
	 *   Where the above 8.cache.js is an asyc call that gets executed when needed (ie. not on initial page load)
	 *   See: http://www.gwtproject.org/doc/latest/DevGuideCodeSplitting.html
	 * NOTE - If you set this to true, you may have to add additional
	 *        waits to your code to know when all required ajax has finished
	 *        processing as they will be processed asynchronously. 
	 * @param disableAjaxController
	 */
	public void setDisableAjaxController(Boolean disableAjaxController) {
		if (disableAjaxController)
			ajaxProcessing = AjaxProcessing.ASYNCHRONOUS;
		else
			ajaxProcessing = AjaxProcessing.USER_ACTION_SYNCHRONOUS;
	}
	public AjaxProcessing getAjaxProcessing() {
		return ajaxProcessing;
	}
	public void setAjaxProcessing(AjaxProcessing ajaxProcessing) {
		this.ajaxProcessing = ajaxProcessing;
	}
	public Boolean getWaitForJavascriptOnOriginalPage() {
		return waitForJavascriptOnOriginalPage;
	}
	public void setWaitForJavascriptOnOriginalPage(Boolean waitForJavascriptOnOriginalPage) {
		this.waitForJavascriptOnOriginalPage = waitForJavascriptOnOriginalPage;
	}
	public Boolean getDisableExceptionOnScriptError() {
		return disableExceptionOnScriptError;
	}
	public void setDisableExceptionOnScriptError(Boolean disableExceptionOnScriptError) {
		this.disableExceptionOnScriptError = disableExceptionOnScriptError;
	}
	public Boolean getClearCookies() {
		return clearCookies;
	}
	public void setClearCookies(Boolean clearCookies) {
		this.clearCookies = clearCookies;
	}
	public Boolean getDoNotCloseAllWindows() {
		return doNotCloseAllWindows;
	}
	public void setDoNotCloseAllWindows(Boolean doNotCloseAllWindows) {
		this.doNotCloseAllWindows = doNotCloseAllWindows;
	}
	public List<Integer> getAllowedStatusCodes() {
		return allowedStatusCodes;
	}
	public void setAllowedStatusCodes(List<Integer> allowedStatusCodes) {
		this.allowedStatusCodes = allowedStatusCodes;
	}
	public WebClientInstance getWebClientInstance() {
		return webClientInstance;
	}
	public void setWebClientInstance(WebClientInstance webClientInstance) {
		this.webClientInstance = webClientInstance;
	}
	public List<String> getHandleJavascriptAlerts() {
		return handleJavascriptAlerts;
	}
	public void setHandleJavascriptAlerts(List<String> handleJavascriptAlerts) {
		this.handleJavascriptAlerts = handleJavascriptAlerts;
	}
	public Boolean getDoNotApplyPageHistory() {
		return doNotApplyPageHistory;
	}
	public void setDoNotApplyPageHistory(Boolean doNotApplyPageHistory) {
		this.doNotApplyPageHistory = doNotApplyPageHistory;
	}
	public Boolean getClearHtmlUnitTemporaryFiles() {
		return clearHtmlUnitTemporaryFiles;
	}
	public void setClearHtmlUnitTemporaryFiles(Boolean clearHtmlUnitTemporaryFiles) {
		this.clearHtmlUnitTemporaryFiles = clearHtmlUnitTemporaryFiles;
	}

	public Integer getNumberOfRetries() {
		return numberOfRetries;
	}

	public void setNumberOfRetries(Integer numberOfRetries) {
		this.numberOfRetries = numberOfRetries;
	}

	public Boolean getRefreshResponseFromServer() {
		return refreshResponseFromServer;
	}

	public void setRefreshResponseFromServer(Boolean refreshResponseFromServer) {
		this.refreshResponseFromServer = refreshResponseFromServer;
	}

	public Boolean getRerenderAjax() {
		return rerenderAjax;
	}

	public void setRerenderAjax(Boolean rerenderAjax) {
		this.rerenderAjax = rerenderAjax;
	}

	public Boolean getNeedsReinitialization() {
		return needsReinitialization;
	}

	public void setNeedsReinitialization(Boolean needsReinitialization) {
		this.needsReinitialization = needsReinitialization;
	}

	public Boolean getUseBasicAuth() {
		return useBasicAuth;
	}

	public void setUseBasicAuth(Boolean useBasicAuth) {
		this.useBasicAuth = useBasicAuth;
	}

	public List<? extends CacheRule> getCacheRules() {
		return cacheRules;
	}

	public void setCacheRules(List<? extends CacheRule> cacheRules) {
		this.cacheRules = cacheRules;
	}

	public String getSslProtocol() {
		return sslProtocol;
	}

	public void setSslProtocol(String sslProtocol) {
		this.sslProtocol = sslProtocol;
	}

	public Boolean getUseInsecureSSL() {
		return useInsecureSSL;
	}

	public void setUseInsecureSSL(Boolean useInsecureSSL) {
		this.useInsecureSSL = useInsecureSSL;
	}

	public Integer getHandleRefreshesUnderSeconds() {
		return handleRefreshesUnderSeconds;
	}

	public void setHandleRefreshesUnderSeconds(Integer handleRefreshesUnderSeconds) {
		this.handleRefreshesUnderSeconds = handleRefreshesUnderSeconds;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	@Override
	public String toString() {
		StringBuilder out = new StringBuilder("[NavOpts]");
		for (Field f : FieldUtils.getAllFields(this.getClass())) {
			if (Modifier.isStatic(f.getModifiers()))
				continue;
			try {
				Object thisField = f.get(this);
				if (thisField != null) {
					out.append(f.getName());
					out.append('=');
					if (obsfucateField(f)) {
						out.append("*****");
					} else {
						out.append(thisField.toString());
					}
					out.append(',');
				}
			} catch (Exception e) {}
		}
		out.append("[/NavOpts]");
		return out.toString();
	}
	
	private boolean obsfucateField(Field f) {
		if (f.getName().equals("password"))
			return true;
		return false;
	}

	public Boolean getDoNotReloadOriginalPage() {
		return doNotReloadOriginalPage;
	}

	public void setDoNotReloadOriginalPage(Boolean doNotReloadOriginalPage) {
		this.doNotReloadOriginalPage = doNotReloadOriginalPage;
	}

	public String getDisableTlsAlgorithm() {
		return disableTlsAlgorithm;
	}

	public void setDisableTlsAlgorithm(String disableTlsAlgorithm) {
		this.disableTlsAlgorithm = disableTlsAlgorithm;
	}

	public boolean isUseThreadRefreshHandler() {
		return isUseThreadRefreshHandler;
	}

	public void setUseThreadRefreshHandler(boolean isUseThreadRefreshHandler) {
		this.isUseThreadRefreshHandler = isUseThreadRefreshHandler;
	}
	
	public Boolean isCssEnabled() {
		return isCssEnabled;
	}

	public void setCssEnabled(Boolean isCssEnabled) {
		this.isCssEnabled = isCssEnabled;
	}
	
}
