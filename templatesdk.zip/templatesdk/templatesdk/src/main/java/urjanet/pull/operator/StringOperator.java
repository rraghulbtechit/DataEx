package urjanet.pull.operator;

import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;

public class StringOperator implements ExtractOperator {
	
	public static enum StringOperation {TO_UPPERCASE, TO_LOWERCASE, APPEND, PREPEND, TRIM};
	
	private StringOperation operation;
	private String value;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private StringOperator() {
		
	}
	
	public StringOperator(StringOperation operation) {
		this(operation, null);
	}
	
	public StringOperator(StringOperation operation, String value) {
		this.operation = operation;
		this.value = value;
	}

	/**
	 * @return the operation
	 */
	public StringOperation getOperation() {
		return operation;
	}

	/**
	 * @param operation the operation to set
	 */
	public StringOperator setOperation(StringOperation operation) {
		this.operation = operation;
		return this;
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	
	/**
	 * @param value the value to set
	 */
	public StringOperator setValue(String value) {
		this.value = value;
		return this;
	}

	@Override
	public ExtractOperand apply(ExtractOperand operand) throws OperatorException {

		try{
			String text = null;
			DomNode result = null;
			if ((result = operand.getResult()) != null) {

				if (result instanceof DomText) {
					text = ((DomText)result).getData().trim();
				} else if (result instanceof DomAttr) {
					text = ((DomAttr)result).getValue().trim();
				} else {
					if (result.getFirstChild() instanceof DomText)
						text = ((DomText)result.getFirstChild()).getData().trim();
					else if (result.getFirstChild() instanceof DomAttr)
						text = ((DomAttr)result.getFirstChild()).getValue().trim();
				}
			} else {
				text = operand.getStringResult();
			}
			return apply(text);
		}catch(ClassCastException cce){
			throw new OperatorException("RegExOperator can only be applied to a DomText node or a DomAttr node or a String", cce);
		}
	}

	private ExtractOperand apply(String text) throws OperatorException {

			try {
				if (operation == StringOperation.TO_UPPERCASE)
					return new ExtractOperand(text.toUpperCase());
				else if (operation == StringOperation.TO_LOWERCASE)
					return new ExtractOperand(text.toLowerCase());
				else if (operation == StringOperation.APPEND)
					return new ExtractOperand(text + value);
				else if (operation == StringOperation.PREPEND)
					return new ExtractOperand(value +text);
				else if (operation == StringOperation.TRIM)
					return new ExtractOperand(text.trim());
				else
					throw new OperatorException("Operation Unsupported Exception: " + operation);
			} catch (Exception e) {
				throw new OperatorException("Regular expression error: " + e);
			}
	}
}
