package urjanet.pull.template;

import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.ftp.FtpPullJobTemplate;

public class VariableTemplateProvider implements TemplateProvider {

    @Override
    public PullJobTemplate getTemplate() {
       return new FtpPullJobTemplate(null, "VariableTemplate", "$LastChangedBy: styner $", "$LastChangedRevision: 35279 $");
    }

}
