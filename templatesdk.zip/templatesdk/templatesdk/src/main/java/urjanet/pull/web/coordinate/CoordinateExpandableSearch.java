package urjanet.pull.web.coordinate;

public class CoordinateExpandableSearch extends CoordinateTargetDefinition {

	
	private CoordinateKey searchKey;
	private String regExQualifier;
	
	private CoordinateKey startKey;
	private CoordinateKey endKey;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private CoordinateExpandableSearch() {
		
	}
	
	public CoordinateExpandableSearch(CoordinateKey searchKey,
			CoordinateKey startKey, CoordinateKey endKey) {
		super();
		this.searchKey = searchKey;
		this.startKey = startKey;
		this.endKey = endKey;
	}
	
	public CoordinateExpandableSearch(CoordinateKey searchKey) {
		super();
		this.searchKey = searchKey;
		this.startKey = null;
		this.endKey = null;
	}


	public CoordinateKey getSearchKey() {
		return searchKey;
	}


	public CoordinateExpandableSearch setSearchKey(CoordinateKey searchKey) {
		this.searchKey = searchKey;
		return this;
	}


	public String getRegExQualifier() {
		return regExQualifier;
	}


	public CoordinateExpandableSearch setRegExQualifier(String regExQualifier) {
		this.regExQualifier = regExQualifier;
		return this;
	}


	public CoordinateKey getStartKey() {
		return startKey;
	}


	public CoordinateExpandableSearch setStartKey(CoordinateKey startKey) {
		this.startKey = startKey;
		return this;
	}


	public CoordinateKey getEndKey() {
		return endKey;
	}


	public CoordinateExpandableSearch setEndKey(CoordinateKey endKey) {
		this.endKey = endKey;
		return this;
	}
	

}
