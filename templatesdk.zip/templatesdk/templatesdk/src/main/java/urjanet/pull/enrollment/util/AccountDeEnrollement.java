package urjanet.pull.enrollment.util;

public interface AccountDeEnrollement extends EbillDeEnroller {

	public boolean accountRemove ( EnrollmentInputs enrollmentInput );
	
}
