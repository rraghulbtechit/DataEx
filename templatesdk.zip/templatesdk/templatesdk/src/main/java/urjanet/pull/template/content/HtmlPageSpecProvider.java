package urjanet.pull.template.content;

import urjanet.pull.core.PageSpec;

public interface HtmlPageSpecProvider {

	public PageSpec getHtmlPageSpec();

}
