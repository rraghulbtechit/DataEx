package urjanet.pull.web;

import urjanet.pull.core.PageSpec;

public class JavaScriptNavTarget extends ClickableNavTarget {
	
	private String script;
	
	public JavaScriptNavTarget() {
		
	}
	
	public JavaScriptNavTarget(PageSpec spec, String script) {
		super(spec, null);
		this.script = script;
	}

	public String getScript() {
		return script;
	}

	public JavaScriptNavTarget setScript(String script) {
		this.script = script;
		return this;
	}
	
	

}
