package urjanet.pull.enrollment.util;

import urjanet.pull.enrollment.util.keys.StatusKeys;

/**
 * 
 * @author sethuramanv
 *
 */
public class EnrollmentAccountMetaData {

	private StatusKeys ebillStatus;
	private Boolean isFirstAttempt;
	
	public EnrollmentAccountMetaData() {
		
	}

	public StatusKeys getEbillStatus() {
		return ebillStatus;
	}

	public void setEbillStatus(StatusKeys ebillStatus) {
		this.ebillStatus = ebillStatus;
	}

	public Boolean getIsFirstAttempt() {
		return isFirstAttempt;
	}

	public void setIsFirstAttempt(Boolean isFirstAttempt) {
		this.isFirstAttempt = isFirstAttempt;
	}
	
}
