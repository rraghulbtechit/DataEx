package urjanet.pull.web.text;

import urjanet.pull.web.BaseDataTargetQualifier;

public class TextDataTargetQualifier extends BaseDataTargetQualifier {

	private TextDataTarget qualifyingTarget;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private TextDataTargetQualifier() {
		
	}
	
	public TextDataTargetQualifier(String qualifierName, TextDataTarget qualifyingTarget) {
		super(qualifierName);
		this.qualifyingTarget = qualifyingTarget;
	}
	
	public TextDataTargetQualifier(TextDataTarget qualifyingTarget) {
		this(null, qualifyingTarget);
	}
	
	public TextDataTarget getQualifyingTarget() {
		return qualifyingTarget;
	}

	/**
	 * @param qualifyingTarget the qualifyingTarget to set
	 */
	public TextDataTargetQualifier setQualifyingTarget(TextDataTarget qualifyingTarget) {
		this.qualifyingTarget = qualifyingTarget;
		return this;
	}

}
