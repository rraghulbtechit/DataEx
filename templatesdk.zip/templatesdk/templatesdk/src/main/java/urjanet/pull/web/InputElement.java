package urjanet.pull.web;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Represents an input value that is required for the navigation or extraction process.
 *
 * @author rburson
 */
public class InputElement {

	private static final Logger log = LoggerFactory.getLogger(InputElement.class);

	private String elementXPath;
	private String valueRegEx;
	private String valueXPath;
	private long waitForAsyncLoad;
	private String framePath;
	private boolean textTypingEnabled;
	private boolean focusAndRenderElement;
	private boolean deselectAllFirst;
	private boolean variableSubstitution;
	private XmlDataTarget metaDataTargets;

	public InputElement() {
	}

	/**
	 * Create an InputElement
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param valueRegEx a regEx that specifies one or more values as input
	 * @param framePath the target framePath, defaults to 0
	 */
	public InputElement(String elementXPath, String valueRegEx, String framePath) {
		this.elementXPath = elementXPath;
		this.valueRegEx = valueRegEx;
		this.framePath = framePath;
	}
	public InputElement(String elementXPath, String valueRegEx, String framePath, boolean deselectAllFirst) {
		this(elementXPath, valueRegEx, framePath);
		this.deselectAllFirst = deselectAllFirst;
	}

	/**
	 * Create an InputElement with the default value for framePath (0)
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param valueRegEx a regEx that specifies one or more values as input
	 */
	public InputElement(String elementXPath, String valueRegEx) {
		this.elementXPath = elementXPath;
		this.valueRegEx = valueRegEx;
	}
	
	public InputElement(String elementXPath) {
		this(elementXPath, null);
	}

	/**
	 * Create an InputElement also specifying a relative xpath to select the value or value range, before applying the valueRegEx
	 * (i.e. a SELECT with the selection of a particular OPTION child or a subset of the OPTION elements)
	 * This is useful for 'narrowing' the available values, selecting a range of values, or selecting values in a relative manner
	 * (i.e. choose the 'first' and 'last' option, regardless of value
	 *
	 *
	 * @param elementXPath the xpath to the element on the 'page' that requires input
	 * @param valueRegEx a regEx that specifies one or more values as input
	 * @param valueXPath an xpath relative to the elementXPath, used to select an available value or a range of available values
	 * @param framePath the target framePath, defaults to 0
	 */
	public InputElement(String elementXPath, String valueRegEx, String valueXPath, String framePath) {
		this.elementXPath = elementXPath;
		this.valueRegEx = valueRegEx;
		this.valueXPath = valueXPath;
		this.framePath = framePath;
	}

	public InputElement(String elementXPath, String valueRegEx,	boolean deselectAllFirst) {
		this(elementXPath, valueRegEx);
		this.deselectAllFirst = deselectAllFirst;
	}

	/**
	 * @return the xpath to the element on the 'page' that requires input
	 */
	public String getElementXPath() {
		return elementXPath;
	}

	/**
	 * @param elementXPath sets the xpath specifying the element on the 'page' that requires input
	 */
	public InputElement setElementXPath(String elementXPath) {
		this.elementXPath = elementXPath;
		return this;
	}

	/**
	 *
	 * @return a regEx that specifies one or more values as input
	 */
	public String getValueRegEx() {
		return valueRegEx;
	}

	/**
	 *
	 * @param valueRegEx a regEx that specifies one or more values as input
	 */
	public InputElement setValueRegEx(String valueRegEx) {
		this.valueRegEx = valueRegEx;
		return this;
	}

	/**
	 *
	 * @return a value that instructs the engine to wait this
	 * long in millis after changing a form value and before getting the page
	 */
	public long getWaitForAsyncLoad() {
		return waitForAsyncLoad;
	}

	/**
	 * @param waitForAsyncLoad sets a value that instructs the engine to wait this
	 * long in millis after changing a form value and before getting the page
	 *
	 */
	public InputElement setWaitForAsyncLoad(long waitForAsyncLoad) {
		this.waitForAsyncLoad = waitForAsyncLoad;
		return this;
	}

	/**
	 *
	 * @return the target framePath, 0 by default
	 */
	public String getFramePath() {
		return framePath;
	}

	/**
	 *
	 * @param framePath
	 */
	public InputElement setFramePath(String framePath) {
		this.framePath = framePath;
		return this;
	}

	/**
	 *
	 * @return an xpath relative to the elementXPath, used to select an available value or a range of available values
	 */
	public String getValueXPath() {
		return valueXPath;
	}

	/**
	 *
	 * @param valueXPath an xpath relative to the elementXPath, used to select an available value or a range of available values
	 */
	public InputElement setValueXPath(String valueXPath) {
		this.valueXPath = valueXPath;
		return this;
	}

	/**
	 * @return textTypingEnabled 
	 * true - to simulates typing the specified text in the HtmlElement
	 * false - to set the specified text at "value" attribute in the HtmlElement
	 */
	public boolean isForceTextTypingEnabled() {
		return textTypingEnabled;
	}

	/**
	 * @param textTypingEnabled the textTypingEnabled to set
	 * true - to simulates typing the specified text in the HtmlElement
	 * false - to set the specified text at "value" attribute in the HtmlElement
	 */
	public InputElement setForceTextTypingEnabled(boolean textTypingEnabled) {
		this.textTypingEnabled = textTypingEnabled;
		return this;
	}

	/**
	 * Returns true if element (HtmlSelect) requires deselecting all options before setting value
	 * @return
	 */
	public boolean isDeselectAllFirst() {
		return deselectAllFirst;
	}

	/**
	 * @return the focusAndRenderNewElement
	 * true - this will make the HtmlElement get focussed and render the same element
	 */
	public boolean isFocusAndRenderElement() {
		return focusAndRenderElement;
	}

	/**
	 * @param focusAndRenderNewElement the focusAndRenderNewElement to set
	 */
	public InputElement setFocusAndRenderElement(boolean focusAndRenderNewElement) {
		this.focusAndRenderElement = focusAndRenderNewElement;
		return this;
	}
	
	public boolean isVariableSubstitution() {
		return variableSubstitution;
	}
	
	public InputElement setVariableSubstitution() {
		return setVariableSubstitution(true);
	}
	
	public InputElement setVariableSubstitution(boolean variableSubstitution) {
		this.variableSubstitution = variableSubstitution;
		return this;
	}
	
	public static void doVariableSubstitution(InputElement input, SessionContext rc) {
		String newVal;
		if ((newVal = doSubstitution(input.getElementXPath(), rc)) != null)  input.setElementXPath(newVal);
		if ((newVal = doSubstitution(input.getValueRegEx(), rc)) != null) 	 input.setValueRegEx(newVal);
		if ((newVal = doSubstitution(input.getValueXPath(), rc)) != null) 	 input.setValueXPath(newVal);
	}
	public static String doSubstitution(String str, SessionContext context) {
		
		String[] parts = StringUtils.substringsBetween(str, "%", "%");
		Set<String> variables = new HashSet<String>();
		String contextValue;
		if (parts != null && parts.length > 0) {
			variables = new HashSet<String>(Arrays.asList(parts));
			for (String variable : variables) {
				contextValue = (String) context.getContextValue(variable);
				if (contextValue != null) {
					str = StringUtils.replace(str, "%"+variable+"%", contextValue);
					
					System.out.println("[INFO] Replaced meter var with: " + contextValue);
					
					return str;
				} else {
					log.error("Error substituting variables for variable : " + variable + " in xpath " + str);
				}
			}
		}
		return str;
	}

	public XmlDataTarget getMetaDataTargets() {
		return metaDataTargets;
	}

	public InputElement setMetaDataTargets(XmlDataTarget metaDataTargets) {
		this.metaDataTargets = metaDataTargets;
		return this;
	}

}
