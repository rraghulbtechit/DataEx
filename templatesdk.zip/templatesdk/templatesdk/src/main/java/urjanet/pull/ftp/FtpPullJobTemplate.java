package urjanet.pull.ftp;

import urjanet.pull.core.BasePullJobTemplate;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.PullJobTemplate;

public class FtpPullJobTemplate extends BasePullJobTemplate {

	private ConfigOptions ftpConfiguration;
	
	public FtpPullJobTemplate(PageSpec pageSpec, String id, ConfigOptions ftpConfiguration, String author, String revision) {
		super(pageSpec, id, author, revision);
		this.ftpConfiguration = ftpConfiguration;
	}
	
	public FtpPullJobTemplate(PageSpec pageSpec, String id, String author, String revision) {
		super(pageSpec, id, author, revision);
	}

	public ConfigOptions getFtpConfiguration() {
		return ftpConfiguration;
	}
}
