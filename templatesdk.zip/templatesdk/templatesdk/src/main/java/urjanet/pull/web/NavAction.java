package urjanet.pull.web;

/**
 *
 * @author rburson
 */
public enum NavAction {

	//NONE - don't actually navigate - same page is returned
	MOUSE_CLICK, MOUSE_OVER, NONE;

}
