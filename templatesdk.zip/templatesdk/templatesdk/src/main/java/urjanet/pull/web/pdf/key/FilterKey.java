package urjanet.pull.web.pdf.key;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.web.pdf.filter.ContextFilter;

public class FilterKey extends WordContextKey {

	private List<? extends ContextFilter> filters;
	
	//This constructor will be called from Hit to create an instance through reflection.
	@SuppressWarnings("unused")
	private FilterKey() {
		
	}
	
	public FilterKey(ContextFilter ... filters) {
		this.filters = Arrays.asList(filters);
	}

	public List<? extends ContextFilter> getFilters() {
		return filters;
	}

	/**
	 * @param filters the filters to set
	 */
	public FilterKey setFilters(List<? extends ContextFilter> filters) {
		this.filters = filters;
		return this;
	}
	
}
