package urjanet.pull.web.cache;

import java.util.regex.Pattern;

import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;

/**
 *
 * @author rburson
 */
public abstract class CacheRule {

	private Pattern urlMatch;

	public CacheRule(Pattern urlMatch) {
		this.urlMatch = urlMatch;
	}

	public Pattern getUrlMatch() {
		return urlMatch;
	}

	public void setUrlMatch(Pattern urlMatch) {
		this.urlMatch = urlMatch;
	}


	public abstract WebResponse tryToCache(WebRequest settings, WebResponse response, MagicCache.CacheDrawer cacheDrawer);

	public abstract WebResponse tryToGet(WebRequest settings, MagicCache.CacheDrawer cacheDrawer);

}
