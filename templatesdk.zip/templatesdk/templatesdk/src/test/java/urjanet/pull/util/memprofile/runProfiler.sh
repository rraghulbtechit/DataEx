#!/bin/bash

source ${URJANET_HOME}/sh/envsetup

javac -d bin -cp $CLASSPATH:"${URJANET_HOME}/lib/*":"${URJANET_HOME}/lib/thirdparty/*" TemplateMemoryProfiler.java

if [ $# -ge 1 ]
then
    templateType=$1
else
    templateType="tp"
fi

if [ "$templateType" == "tp" ]
then
    inputFile="TemplateProviders"
    outputFile="TemplateProvidersResults"
else
    inputFile="HistoricalTemplateProviders"
    outputFile="HistoricalTemplateProvidersResults"
fi

> $outputFile

lines=$(cat $inputFile | wc -l)
currLine=0

while read line           
do
    classRunner.sh urjanet.pull.util.memprofile.TemplateMemoryProfiler "$line $templateType" | sed -n '/^[0-9]* .*: [0-9]*.*/p' >> $outputFile
    ((currLine++))
    printf "Profiling: %d%%\r" $((100 * $currLine / lines))
done < $inputFile

sort -g -r $outputFile -o $outputFile
