#!/bin/bash

source ${URJANET_HOME}/sh/envsetup

if [ ! -d bin ]
then
  mkdir bin
fi

javac -d bin -cp ${CLASSPATH} TemplateFinder.java

templatePath="${URJA_REPO_PATH}/templates/templates/build/classes/main/urjanet/pull/template"
regex="/^urjanet[.]pull[.]template[.]/p"

classRunner.sh urjanet.pull.util.memprofile.TemplateFinder "$templatePath tp" | sed -n $regex > TemplateProviders
classRunner.sh urjanet.pull.util.memprofile.TemplateFinder "$templatePath htp" | sed -n $regex > HistoricalTemplateProviders
