package urjanet.pull.util.memprofile;

import java.io.File;

/**
 * 
 * @author taylor.hearns
 *
 */

public class TemplateFinder
{
    public static void main(String[] args) throws Exception
    {
        String templatesPath = args[0];
        
        String templateType = "tp";
        if(args != null && args.length >= 2) {
            templateType = args[1];
            if(!templateType.equals("tp") && !templateType.equals("htp")) {
                throw new IllegalArgumentException(
                    "Second Argument should be \"tp\" for TemplateProvider and \"htp\" for HistoricalTemplateProvider");
            }
        }
        
        File directory = new File(templatesPath);
        File[] contents = directory.listFiles();
        Class<?> templateProviderInterface = null;
        if(templateType.equals("tp")) {
            templateProviderInterface = Class.forName("urjanet.pull.template.TemplateProvider");
        } else {
            templateProviderInterface = Class.forName("urjanet.pull.template.HistoricalTemplateProvider");
        }
        
        for(File item : contents) {
            if(item.isFile() && item.getName().endsWith(".class")) {
                String templateName = extractClassName(item.getName());
                try {
                    Class<?> templateClass = Class.forName(templateName);
                    
                    // Check whether templateClass implements TemplateProvider
                    if(templateProviderInterface.isAssignableFrom(templateClass)) {
                        System.out.println(templateName);
                    }
                } catch (Throwable t) {
                    System.err.println("Error processing template: " + templateName + " -- " + t.toString());
                }
            }
        }
    }
    
    // assumes file is a .class file
    private static String extractClassName(String fileName)
    {
        String trimmedName = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length()).replace(".class", "");
        return "urjanet.pull.template." + trimmedName;
    }
}
