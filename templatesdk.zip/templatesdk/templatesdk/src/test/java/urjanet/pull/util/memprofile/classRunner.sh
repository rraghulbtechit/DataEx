#!/bin/bash

. ${URJANET_HOME}/sh/envsetup

java -d64 -version > /dev/null 2>&1
if [ "$?" -ne 0 ];
then
   PDFLIB_PATH=/opt/urjanet_infra/deployment/pdflib/
else
   PDFLIB_PATH=/opt/urjanet_infra/deployment/pdflib/64-bit
fi

URJANET_PROPERTIES_OVERRIDE_PREFIX="-Dcom.urjanet.propertyFilePath="
URJANET_PROPERTIES_OVERRIDE=

if [[ $1 == $URJANET_PROPERTIES_OVERRIDE_PREFIX* ]];
then 
   URJANET_PROPERTIES_OVERRIDE=$1
fi

eval java -cp $CLASSPATH:./bin -Xmx2000m $URJANET_PROPERTIES_OVERRIDE -Djava.library.path=$PDFLIB_PATH $*

retval=$?
