package urjanet.pull.util.memprofile;

import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;

import urjanet.pull.template.TemplateProvider;
import urjanet.pull.template.HistoricalTemplateProvider;
import urjanet.pull.core.PullJobTemplate;

/** 
 * 
 * @author taylor.hearns
 * 
 */

public class TemplateMemoryProfiler 
{
    public static void main(String[] args) throws Exception
    {
        String templateName = args[0];
        
        String templateType = "tp";
        if(args != null && args.length >= 2) {
            templateType = args[1];
            if(!templateType.equals("tp") && !templateType.equals("htp")) {
                throw new IllegalArgumentException(
                    "Second Argument should be \"tp\" for TemplateProvider and \"htp\" for HistoricalTemplateProvider");
            }
        }
        
        long initialHeapUsage = getCurrentHeapUsage();
 
        Class<?> templateClass = Class.forName(templateName);
        Object templateProviderObj;
        try {
            templateProviderObj = templateClass.newInstance();
        } catch(IllegalAccessException e) {
            // IllegalAccessException means that this constructor is private
            return;
        }
        Object templateObj = null;
        
        try {
            if(templateType.equals("tp")) {
                //templateObj = ((TemplateProvider) templateProviderObj).getTemplate();
                Method getTemplate = templateClass.getDeclaredMethod("getTemplate");
                //getTemplate.setAccessible(true);
                getTemplate.invoke((TemplateProvider) templateProviderObj);
            } else {
                //templateObj = ((HistoricalTemplateProvider) templateProviderObj).getHistoricalTemplate();
                Method getTemplate = templateClass.getDeclaredMethod("getHistoricalTemplate");
                //getTemplate.setAccessible(true);
                getTemplate.invoke((HistoricalTemplateProvider) templateProviderObj);
            }      
        } catch(NoSuchMethodException | IllegalAccessException e) {
            // NoSuchMethodException means that this method must be inherited, so no need to profile it as we will profile the superclass
            // IllegalAccessException means that this method is private
            return;
        }
        
        long finalHeapUsage = getCurrentHeapUsage();
 
        templateName = templateName.replace("urjanet.pull.template.", "");
        long usedBytes = finalHeapUsage - initialHeapUsage;
        System.out.println(usedBytes + " " + templateName + ": " + humanFriendlyBytes(usedBytes));
    }
    
    // returns the current memory usage of the JVM in bytes
    private static long getCurrentHeapUsage()
    {
        return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
    
        //Runtime runtime = Runtime.getRuntime();
        //return (runtime.totalMemory() - runtime.freeMemory());
    }
    
    private static String humanFriendlyBytes(long bytes)
    {
        double amount = (double) bytes;
        String units = "";
        
        if(bytes < 1024) {
            units = "bytes";
        } else if(bytes < 1024*1024) {
            amount = amount / 1024;
            units = "kB";
        } else if(bytes < 1024*1024*1024) {
            amount = amount / 1024 / 1024;
            units = "MB";
        } else {
            amount = amount / 1024 / 1024 / 1024;
            units = "GB";
        }
        
        NumberFormat formatter = new DecimalFormat("#0.00");
        if(bytes < 1024) {
            formatter = new DecimalFormat("#0");
        }  
        return formatter.format(amount) + " " + units;
    }
 }
