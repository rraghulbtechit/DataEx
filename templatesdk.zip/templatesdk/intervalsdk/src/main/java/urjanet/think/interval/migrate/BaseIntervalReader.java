package urjanet.think.interval.migrate;

import urjanet.pull.core.SmartMeterExtract;

public class BaseIntervalReader {
	
	protected SmartMeterExtract smartMeter;
	private String sheetName;
	
	public BaseIntervalReader(SmartMeterExtract smartMeter) {
		this.smartMeter = smartMeter;
	}
	
	protected boolean contains(String[] row, String key) {
		return indexOf(row, key) < 0 ? false : true; 
	}

	protected int indexOf(String[] row, String key) {
		for (int i = 0; i < row.length; i++) {
			String s = row[i];
			if (s.equalsIgnoreCase(key))
				return i;
		}
		return -1;
	}
	
	public void setSheetName(String name){
		
		this.sheetName = name;
	}
	
	public String getSheetName(){
		
		return sheetName;
	}
}
