package urjanet.think.interval.migrate;

import java.util.List;

import urjanet.think.interval.domain.Interval;

public interface SpreadsheetIntervalReader {
	
	public List<Interval> readRow(List<String> row);

	public List<Interval> flushIntervals();
	
	public void setSheetName(String name);
	
	public String getSheetName();

}
