package urjanet.think.interval.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import urjanet.clean.format.FormatterFactory;
import urjanet.keys.DataValues;
import urjanet.pull.core.SmartMeterExtract;
import urjanet.think.interval.domain.date.UrjanetDateFormatService;

public class Interval implements Cloneable {
	
	private String customerAlias, providerAlias, extractionChannelId, accountNumber, meterNumber, unit, timezone;
	private String serviceType;
	private Date start, end;
	private Double value;
	private String pam, key, month;
	private String serviceAddress, meterUID1, meterUID2, meterUID3;
	private List<String> requiredKeys;
	
	public static void main(String[] args) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		format.setTimeZone(TimeZone.getTimeZone(DataValues.US_MOUNTAIN.getValue()));
		Date date = format.parse("01/01/2013");
		System.out.println(date);
		Calendar c = Calendar.getInstance();
		System.out.println(c.get(Calendar.ZONE_OFFSET));
		c.setTimeZone(TimeZone.getTimeZone(DataValues.US_PACIFIC.getValue()));
		
		System.out.println(c.getTimeZone());
		c.set(Calendar.ZONE_OFFSET, TimeZone.getTimeZone(DataValues.US_PACIFIC.getValue()).getRawOffset());
		System.out.println(c.get(Calendar.ZONE_OFFSET));
		System.out.println(TimeZone.getTimeZone(DataValues.US_EASTERN.getValue()).getRawOffset());
		c.setTime(date);
		System.out.println(c.get(Calendar.MONTH));
		System.out.println(c.getTimeZone());
	}
	
	/*public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, String time, String timeFormat, long durationMillis) throws ParseException {
		start = UrjanetDateFormatService.get().parse(date, dateFormat, time, timeFormat, smartMeter.getTimezone());
		end = new Date(start.getTime() + durationMillis);
		addSmartMeterMetaData(smartMeter);
	}*/
	
	public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, String time, String timeFormat, long durationMillis, String timezone) throws ParseException {
		this(smartMeter, date, dateFormat, time, timeFormat, true, durationMillis, timezone);
	}
	
	public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, String time, String timeFormat, boolean isStartDate, long durationMillis, String timezone) throws ParseException {
		if (isStartDate) {
			this.start = UrjanetDateFormatService.get().parse(date, dateFormat, time, timeFormat, timezone);
			this.end = new Date(start.getTime() + durationMillis);
		} else {
			this.end = UrjanetDateFormatService.get().parse(date, dateFormat, time, timeFormat, timezone);
			this.start = new Date(end.getTime() - durationMillis);
		}
		this.timezone = timezone;
		addSmartMeterMetaData(smartMeter);
	}
	
//	public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, long durationMillis) throws ParseException {
//		start = UrjanetDateFormatService.get().parse(date, dateFormat, smartMeter.getTimezone());
//		end = new Date(start.getTime() + durationMillis);
//		addSmartMeterMetaData(smartMeter);
//	}
	
	public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, long durationMillis, String timezone) throws ParseException {
		this(smartMeter, date, dateFormat, true, durationMillis, timezone);
	}
	
	public Interval(SmartMeterExtract smartMeter, String date, String dateFormat, boolean isStartDate, long durationMillis, String timezone) throws ParseException {
		
		if (isStartDate) {
			this.start = UrjanetDateFormatService.get().parse(date, dateFormat, timezone);
			this.end = new Date(start.getTime() + durationMillis);
		} else {
			this.end = UrjanetDateFormatService.get().parse(date, dateFormat, timezone);
			this.start = new Date(end.getTime() - durationMillis);
		}
		this.timezone = timezone;
		addSmartMeterMetaData(smartMeter);
	}
	
	public Interval(SmartMeterExtract smartMeter, long utc, long duration, String timezone) {
		this(smartMeter, utc, true, duration, timezone);
	}
	public Interval(SmartMeterExtract smartMeter, long utc, boolean isStartDate, long duration, String timezone) {
		
		if (isStartDate) {
			this.start = new Date(utc);
			this.end = new Date(utc + duration);
		} else {
			this.end = new Date(utc);
			this.start = new Date(utc - duration);
		}
		this.timezone = timezone;
		addSmartMeterMetaData(smartMeter);
	}
	
	private Interval(Date start, Date end, String timezone) {
		this.start = start;
		this.end = end;
		this.timezone = timezone;
	}
	
	private void addSmartMeterMetaData(SmartMeterExtract smartMeter) {
		
		String value;
		
		if ((value = smartMeter.getProviderAlias()) != null) providerAlias = value;
		if ((value = smartMeter.getCustomer()) != null) customerAlias = value;
		if ((value = smartMeter.getExtractionChannelId()) != null) extractionChannelId = value;
		setAccountNumber(smartMeter.getAccountNumber());
		setMeterNumber(smartMeter.getMeterNumber());
		setServiceAddress(smartMeter.getServiceAddress());
		setServiceType(smartMeter.getServiceType());
		if ((value = smartMeter.getTimezone()) != null) timezone = value;
	}
	
	public static String getString(String[] array) {
		String string = "";
		for (String s : array)
			string += s + ", ";
		return string;
	}
	
	public Interval getCopy() {
		Interval interval = new Interval(start, end, timezone);
		interval.setCustomerAlias(customerAlias);
		interval.setProviderAlias(providerAlias);
		interval.setExtractionChannelId(extractionChannelId);
		interval.setAccountNumber(accountNumber);
		interval.setMeterNumber(meterNumber);
		interval.setUnit(unit);
		interval.setValue(value);
		interval.setServiceType(serviceType);
		interval.setTimezone(timezone);
		interval.setServiceAddress(serviceAddress);
		interval.setMeterUID1(meterUID1);
		return interval;
	}
	
	/**
	 * Make sure not to set meterNumber directly for dynamic reconciliation to work (will be set on PAM)
	 * @return
	 */
	public boolean isDynamicReconciliation() {
		return meterNumber == null;
	}
	
	public String getPAM() {
		
		if (pam != null)
			return pam;
		
		//TODO need to make sure accountNumber and meterNumber is normalized
		pam = providerAlias + IntervalConstants.pamDelimiter + accountNumber;

		if (meterNumber != null && !meterNumber.isEmpty())
			pam += IntervalConstants.pamDelimiter + meterNumber;
		else {
			if (serviceType != null && serviceType.equals(DataValues.GAS.getValue())) {
				pam += IntervalConstants.pamDelimiter + "g1";
			} else {
				pam += IntervalConstants.pamDelimiter + "e1";
			}
		}
		
		return pam;
	}
	
	public void setPAM(String pam) {
		this.pam = pam;
	}
	
	public String getKey() {
		
		if (key != null)
			return key;
		
		key = getPAM() + IntervalConstants.rowKeyDelimiter + getMonth();
		key = key.replaceAll(" ", "");
		return key;
	}
	
	public String getMonth() {
		
		if (month == null)
			month = new SimpleDateFormat("yyyy" + IntervalConstants.dateDelimiter + "MM").format(start);
		
		return month;
		
	}
	
	public String getCustomerAlias() {
		return customerAlias;
	}
	public void setCustomerAlias(String customerAlias) {
		this.customerAlias = customerAlias;
	}
	public String getProviderAlias() {
		return providerAlias;
	}
	public void setProviderAlias(String providerAlias) {
		this.providerAlias = providerAlias;
	}
	public String getExtractionChannelId() {
		return extractionChannelId;
	}
	public void setExtractionChannelId(String extractionChannelId) {
		this.extractionChannelId = extractionChannelId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = formatText(accountNumber);
	}
	public String getMeterNumber() {
		return meterNumber;
	}
	public void setMeterNumber(String meterNumber) {
		this.meterNumber = formatText(meterNumber);;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = formatText(unit);
	}
	public Date getStart() {
		return start;
	}
	public Date getEnd() {
		return end;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getTimezone() {
		return timezone;
	}
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getServiceAddress() {
		return serviceAddress;
	}

	public void setServiceAddress(String serviceAddress) {
		this.serviceAddress = formatText(serviceAddress);
	}
	
	public String formatText(String s) {
		if (s == null)
			return null;
		return FormatterFactory.getFormatter().formatText(s);
	}

	public boolean sameMeter(Interval interval) {
		if (!this.getProviderAlias().equals(interval.getProviderAlias()))
			return false;
		if (!this.getAccountNumber().equals(interval.getAccountNumber()))
			return false;
		
		String candServiceAddress = interval.getServiceAddress();
		String serviceAddress = this.getServiceAddress();
		if ( (serviceAddress == null && candServiceAddress != null)
				|| (serviceAddress != null && !serviceAddress.equals(candServiceAddress)) )
			return false;
		
		String candMeterUID = interval.getMeterUID1();
		String meterUID = this.getMeterUID1();
		if ( (meterUID == null && candMeterUID != null)
				|| (meterUID != null && !meterUID.equals(candMeterUID)) )
			return false;

		String candMeterUID2 = interval.getMeterUID2();
		String meterUID2 = this.getMeterUID2();
		if ( (meterUID2 == null && candMeterUID2 != null)
				|| (meterUID2 != null && !meterUID2.equals(candMeterUID2)) )
			return false;

		String candMeterUID3 = interval.getMeterUID3();
		String meterUID3 = this.getMeterUID3();
		if ( (meterUID3 == null && candMeterUID3 != null)
				|| (meterUID3 != null && !meterUID3.equals(candMeterUID3)) )
			return false;
		
		return true;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		
		Interval interval = (Interval) super.clone();
		List<String> requireKeys = getRequiredKeys();
		if(requireKeys != null) {
			interval.requiredKeys = (List<String>) ((ArrayList<String>) getRequiredKeys()).clone();
		}
		
		return interval;
	}

	public String getMeterUID1() {
		return meterUID1;
	}

	public void setMeterUID1(String meterUID1) {
		this.meterUID1 = formatText(meterUID1);
	}

	public String getMeterUID2() {
		return meterUID2;
	}

	public void setMeterUID2(String meterUID2) {
		this.meterUID2 = formatText(meterUID2);
	}

	public String getMeterUID3() {
		return meterUID3;
	}

	public void setMeterUID3(String meterUID3) {
		this.meterUID3 = formatText(meterUID3);
	}

	public List<String> getRequiredKeys() {
		return requiredKeys;
	}

	public void setRequiredKeys(List<String> requiredKeys) {
		this.requiredKeys = requiredKeys;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result
				+ ((customerAlias == null) ? 0 : customerAlias.hashCode());
		result = prime * result + ((end == null) ? 0 : end.hashCode());
		result = prime
				* result
				+ ((extractionChannelId == null) ? 0 : extractionChannelId
						.hashCode());
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result
				+ ((meterNumber == null) ? 0 : meterNumber.hashCode());
		result = prime * result
				+ ((meterUID1 == null) ? 0 : meterUID1.hashCode());
		result = prime * result
				+ ((meterUID2 == null) ? 0 : meterUID2.hashCode());
		result = prime * result
				+ ((meterUID3 == null) ? 0 : meterUID3.hashCode());
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + ((pam == null) ? 0 : pam.hashCode());
		result = prime * result
				+ ((providerAlias == null) ? 0 : providerAlias.hashCode());
		result = prime * result
				+ ((requiredKeys == null) ? 0 : requiredKeys.hashCode());
		result = prime * result
				+ ((serviceAddress == null) ? 0 : serviceAddress.hashCode());
		result = prime * result
				+ ((serviceType == null) ? 0 : serviceType.hashCode());
		result = prime * result + ((start == null) ? 0 : start.hashCode());
		result = prime * result
				+ ((timezone == null) ? 0 : timezone.hashCode());
		result = prime * result + ((unit == null) ? 0 : unit.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interval other = (Interval) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (customerAlias == null) {
			if (other.customerAlias != null)
				return false;
		} else if (!customerAlias.equals(other.customerAlias))
			return false;
		if (end == null) {
			if (other.end != null)
				return false;
		} else if (!end.equals(other.end))
			return false;
		if (extractionChannelId == null) {
			if (other.extractionChannelId != null)
				return false;
		} else if (!extractionChannelId.equals(other.extractionChannelId))
			return false;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (meterNumber == null) {
			if (other.meterNumber != null)
				return false;
		} else if (!meterNumber.equals(other.meterNumber))
			return false;
		if (meterUID1 == null) {
			if (other.meterUID1 != null)
				return false;
		} else if (!meterUID1.equals(other.meterUID1))
			return false;
		if (meterUID2 == null) {
			if (other.meterUID2 != null)
				return false;
		} else if (!meterUID2.equals(other.meterUID2))
			return false;
		if (meterUID3 == null) {
			if (other.meterUID3 != null)
				return false;
		} else if (!meterUID3.equals(other.meterUID3))
			return false;
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (pam == null) {
			if (other.pam != null)
				return false;
		} else if (!pam.equals(other.pam))
			return false;
		if (providerAlias == null) {
			if (other.providerAlias != null)
				return false;
		} else if (!providerAlias.equals(other.providerAlias))
			return false;
		if (requiredKeys == null) {
			if (other.requiredKeys != null)
				return false;
		} else if (!requiredKeys.equals(other.requiredKeys))
			return false;
		if (serviceAddress == null) {
			if (other.serviceAddress != null)
				return false;
		} else if (!serviceAddress.equals(other.serviceAddress))
			return false;
		if (serviceType == null) {
			if (other.serviceType != null)
				return false;
		} else if (!serviceType.equals(other.serviceType))
			return false;
		if (start == null) {
			if (other.start != null)
				return false;
		} else if (!start.equals(other.start))
			return false;
		if (timezone == null) {
			if (other.timezone != null)
				return false;
		} else if (!timezone.equals(other.timezone))
			return false;
		if (unit == null) {
			if (other.unit != null)
				return false;
		} else if (!unit.equals(other.unit))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}
}
