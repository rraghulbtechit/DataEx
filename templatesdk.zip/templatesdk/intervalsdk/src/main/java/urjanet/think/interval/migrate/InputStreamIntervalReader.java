package urjanet.think.interval.migrate;

import java.io.InputStream;
import java.util.List;

import urjanet.think.interval.domain.Interval;

public interface InputStreamIntervalReader {

	public List<Interval> readStream(InputStream stream);
	
}
