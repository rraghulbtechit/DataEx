package urjanet.pull.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import urjanet.pull.core.Extract;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import au.com.bytecode.opencsv.CSVReader;
import urjanet.aws.s3.AmazonS3Manager;
import urjanet.clean.format.FormatterFactory;
import urjanet.keys.SmartMeterKeys;
import urjanet.regex.RegExHandler;
import urjanet.relate.RelateUtils;

public class SmartMeterExtract {
	
	public static final String BUCKET_NAME = "urjaintervaldata";
//	protected static final SimpleDateFormat defaultFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
//	protected static final SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
//	protected static final SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
	
//	static {
//		//Must format in gmt for time if we are going to add it to the date
//		timeFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
//	}
	
	private static Map<String, Method> metaFieldSetters;
	private static Map<String, Method> metaFieldGetters;
	
	private String customer;
	private String providerAlias;
	private String accountNumber;
	private String meterNumber;
	private String serviceType;
	private String meterUID1, meterUID2, meterUID3;
	private String delimiter, charsetName;
	
	private String startDate;
	private String endDate;
	
	//This is the raw service address
	private String serviceAddress;
	private String tariff;
	
	//These are the individual parsed serviceAddress
	private String city;
	private String state;
	private String zip;
	
	private String timezone;
	
	private String sourceFormat;
	private String sourceType;
	
	//backed by either a navigationNodeId or a filePath
	private String navigationNodeId;
	
	private String extractionChannelId;
	
	//transient
	private String filePath;

	private String template;
	
	private String energyUnit;
	
	private String intervalReader;
	
	public boolean standalone;
	
	public List<String> filesInTempDirectory = new ArrayList<String>();
	
	
	//Need raw source paths for sinegle source interval data that needs meta data along
	//private String rawSourcePath;
	
	public SmartMeterExtract() {
		
	}
	
	public SmartMeterExtract(Extract smartMeterExtract) {
		setMetaData(smartMeterExtract);
	}
	
	//bash /opt/urjanet_infra/deliveries/scripts/UPS-SXML.sh
	//bash /opt/urjanet_infra/bin/deliveryrunner -c UPS -created ">=07/01/2013 00:00"
	
	//TODO need to figure out what this is taking in 
	public SmartMeterExtract(AmazonS3Manager manager, String s3Key) throws IOException {
		//Download then call add data from file
//		File fout = new File(System.getProperty("java.io.tmpdir") + File.separatorChar + s3Key);
		final String processedIntervalDirectory = "/opt/data/processedinterval";
		File directory = new File(processedIntervalDirectory);
		if (!directory.exists())
			directory.mkdirs();
		File fout = new File(processedIntervalDirectory + File.separatorChar + s3Key);
		IOUtils.copy(manager.getSourceAsStream(s3Key), new FileOutputStream(fout));
		
		String appendedKey = RegExHandler.extract(s3Key, "\\d+\\.\\w+$");
		String extractionIdProvider = s3Key.substring(0, s3Key.indexOf(appendedKey));
		extractionChannelId = RegExHandler.extract(extractionIdProvider, ".*(?=_[A-Za-z]+$)");
		providerAlias = RegExHandler.extract(extractionIdProvider, "(?<=_)[A-Za-z]+$");
		customer = RegExHandler.extract(extractionIdProvider, "^.*(?=_\\d+-)");
		
		if (s3Key.endsWith("zip")) {
			loadDataFromArchive(fout);
			//don't delete, store in processed interval
			//FileUtils.deleteQuietly(fout);
		} else {
			filePath = fout.getAbsolutePath();
		}
		
	}
	

	public SmartMeterExtract(String filename) throws IOException {
		
		File file = new File(filename);
		filename = filename.substring(filename.lastIndexOf('/')+1, filename.length());
		
		String appendedKey = RegExHandler.extract(filename, "\\d+\\.\\w+$");
		String extractionIdProvider = filename.substring(0, filename.indexOf(appendedKey));
		extractionChannelId = RegExHandler.extract(extractionIdProvider, ".*(?=_[A-Za-z]+$)");
		providerAlias = RegExHandler.extract(extractionIdProvider, "(?<=_)[A-Za-z]+$");
		customer = RegExHandler.extract(extractionIdProvider, "^.*(?=_\\d+-)");
		
		loadDataFromArchive( file );
		
	}
	
	
	public SmartMeterExtract(File file) throws FileNotFoundException, IOException {
		String filename = file.getName();
		String appendedKey = RegExHandler.extract(filename, "\\d+\\.\\w+$");
		String extractionIdProvider = filename.substring(0, filename.indexOf(appendedKey));
		extractionChannelId = RegExHandler.extract(extractionIdProvider, ".*(?=_[A-Za-z]+$)");
		providerAlias = RegExHandler.extract(extractionIdProvider, "(?<=_)[A-Za-z]+$");
		customer = RegExHandler.extract(extractionIdProvider, "^.*(?=_\\d+-)");
		
		if (filename.endsWith("zip")) {
			loadDataFromArchive(file);
		} else {
			filePath = file.getAbsolutePath();
		}
	}

	private void loadDataFromArchive(File fout) throws FileNotFoundException, IOException {
		ZipInputStream zis = new ZipInputStream(new FileInputStream(fout));
		byte[] buffer = new byte[4096];
		ZipEntry ze;
		String intervalDataFile = null;
		while ((ze = zis.getNextEntry()) != null) {
			//System.out.println("Extracting: "+ze);
			try {
				int extensionIndex = ze.getName().indexOf('.');
				File unzippedFile = File.createTempFile(ze.getName().substring(0, extensionIndex - 1), ze.getName().substring(extensionIndex), 
						new File(System.getProperty("java.io.tmpdir")));
//				unzippedFile.deleteOnExit();
				FileOutputStream fos = new FileOutputStream(unzippedFile);
				int numBytes;
				while ((numBytes = zis.read(buffer, 0, buffer.length)) != -1)
					fos.write(buffer, 0, numBytes);
				fos.close();
				if (ze.getName().endsWith("meta")) {
					setMetaDataFromFile(unzippedFile);
				} else {
					intervalDataFile = unzippedFile.getAbsolutePath(); 
				}
				
				filesInTempDirectory.add(unzippedFile.getAbsolutePath());
			} catch (Exception e) {
				e.printStackTrace();
			}
			zis.closeEntry();
		}
		
		zis.close();
		
		if (intervalDataFile != null)
			filePath = intervalDataFile;
		else {
			throw new RuntimeException("Data File not extracted!");
		}
	}
	
	public void clearTempFiles() {
		for (String tempFile : filesInTempDirectory) {
			FileUtils.deleteQuietly(new File(tempFile));
		}
	}
	
	public boolean isStandalone() {
		return standalone;
	}
	
	public Extract getMetaData() {
		Extract extract = new Extract();
		
		String value;
		
		if ((value = providerAlias) != null) extract.addValue(SmartMeterKeys.PROVIDER_ID.getValue(), value);
		if ((value = accountNumber) != null) extract.addValue(SmartMeterKeys.ACCOUNT_NUMBER.getValue(), value);
		if ((value = meterNumber) != null) extract.addValue(SmartMeterKeys.METER_NUMBER.getValue(), value);
		if ((value = serviceType) != null) extract.addValue(SmartMeterKeys.SERVICE_TYPE_ID.getValue(), value);
		if ((value = serviceAddress) != null) extract.addValue(SmartMeterKeys.SERVICE_ADDRESS.getValue(), value);
		if ((value = tariff) != null) extract.addValue(SmartMeterKeys.TARIFF.getValue(), value);
		if ((value = city) != null) extract.addValue(SmartMeterKeys.CITY.getValue(), value);
		if ((value = state) != null) extract.addValue(SmartMeterKeys.STATE_PROVINCE.getValue(), value);
		if ((value = zip) != null) extract.addValue(SmartMeterKeys.POSTAL_CODE.getValue(), value);
		if ((value = timezone) != null) extract.addValue(SmartMeterKeys.TIMEZONE.getValue(), value);
		if ((value = meterUID1) != null) extract.addValue(SmartMeterKeys.METER_UID_1.getValue(), value);
		if ((value = meterUID2) != null) extract.addValue(SmartMeterKeys.METER_UID_2.getValue(), value);
		if ((value = meterUID3) != null) extract.addValue(SmartMeterKeys.METER_UID_3.getValue(), value);
		
		if ((value = startDate) != null) extract.addValue(SmartMeterKeys.START_DATE.getValue(), value);
		if ((value = endDate) != null) extract.addValue(SmartMeterKeys.END_DATE.getValue(), value);
		
		if ((value = delimiter) != null) extract.addValue(SmartMeterKeys.DELIMITER.getValue(), value);
		if ((value = charsetName) != null) extract.addValue(SmartMeterKeys.CHARSET_NAME.getValue(), value);
		
		if ((value = sourceFormat) != null) extract.addValue(SmartMeterKeys.SOURCE_FORMAT.getValue(), value);
		if ((value = sourceType) != null) extract.addValue(SmartMeterKeys.SOURCE_TYPE.getValue(), value);
		if ((value = navigationNodeId) != null) extract.addValue(SmartMeterKeys.NAVIGATION_TARGET_NODE_ID.getValue(), value);
		if ((value = extractionChannelId) != null) extract.addValue(SmartMeterKeys.EXTRACTION_CHANNEL_ID.getValue(), value);
		if ((value = intervalReader) != null) extract.addValue(SmartMeterKeys.INTERVAL_READER.getValue(), value);
		if ((value = energyUnit) != null) extract.addValue(SmartMeterKeys.ENERGY_UNIT.getValue(), value);
		
		return extract;
	}
	
	public void setMetaData(Extract extract) {
		//traverse interval data
		//this may get overridden if there are different meter groups

		this.providerAlias = extract.getValue(SmartMeterKeys.PROVIDER_ID.getValue());
		setAccountNumber(extract.getValue(SmartMeterKeys.ACCOUNT_NUMBER.getValue()));
		setMeterNumber(extract.getValue(SmartMeterKeys.METER_NUMBER.getValue()));
		this.serviceType = extract.getValue(SmartMeterKeys.SERVICE_TYPE_ID.getValue());
		setServiceAddress(extract.getValue(SmartMeterKeys.SERVICE_ADDRESS.getValue()));
		setTariff(extract.getValue(SmartMeterKeys.TARIFF.getValue()));
		setCity(extract.getValue(SmartMeterKeys.CITY.getValue()));
		setState(extract.getValue(SmartMeterKeys.STATE_PROVINCE.getValue()));
		setZip(extract.getValue(SmartMeterKeys.POSTAL_CODE.getValue()));
		this.timezone = extract.getValue(SmartMeterKeys.TIMEZONE.getValue());
		setMeterUID1(extract.getValue(SmartMeterKeys.METER_UID_1.getValue()));
		setMeterUID2(extract.getValue(SmartMeterKeys.METER_UID_2.getValue()));
		setMeterUID3(extract.getValue(SmartMeterKeys.METER_UID_3.getValue()));
		
		this.startDate = extract.getValue(SmartMeterKeys.START_DATE.getValue());
		this.endDate = extract.getValue(SmartMeterKeys.END_DATE.getValue());
		
		this.delimiter = extract.getValue(SmartMeterKeys.DELIMITER.getValue());
		this.charsetName = extract.getValue(SmartMeterKeys.CHARSET_NAME.getValue());
		
		this.sourceFormat = extract.getValue(SmartMeterKeys.SOURCE_FORMAT.getValue());
		this.sourceType = extract.getValue(SmartMeterKeys.SOURCE_TYPE.getValue());
		this.navigationNodeId = extract.getValue(SmartMeterKeys.NAVIGATION_TARGET_NODE_ID.getValue());
		this.extractionChannelId = extract.getValue(SmartMeterKeys.EXTRACTION_CHANNEL_ID.getValue());
		setIntervalReader(extract.getValue(SmartMeterKeys.INTERVAL_READER.getValue()));
		setEnergyUnit(extract.getValue(SmartMeterKeys.ENERGY_UNIT.getValue()));
//		this.requiredKeys = extract.getValue(SmartMeterKeys.REQUIRED_KEYS.getValue());	// TODO:	will implement after testing of other stuff works
		
	}

	public void setMetaData(SmartMeterExtract smartMeter) {
		//traverse interval data
		//this may get overridden if there are different meter groups

		String value;
		
		if ((value = smartMeter.getProviderAlias()) != null) this.providerAlias = value;
		setAccountNumber(smartMeter.getAccountNumber());
		setMeterNumber(smartMeter.getMeterNumber());
		if ((value = smartMeter.getServiceType()) != null) this.serviceType = value;
		setServiceAddress(smartMeter.getServiceAddress());
		setTariff(smartMeter.getTariff());
		setCity(smartMeter.getCity());
		setState(smartMeter.getState());
		setZip(smartMeter.getZip());
		if ((value = smartMeter.getTimezone()) != null) this.timezone = value;
		setMeterUID1(smartMeter.getMeterUID1());
		setMeterUID2(smartMeter.getMeterUID2());
		setMeterUID3(smartMeter.getMeterUID3());
		
		if ((value = smartMeter.getStartDate()) != null) this.startDate = value;
		if ((value = smartMeter.getEndDate()) != null) this.endDate = value;
		
		if ((value = smartMeter.getDelimiter()) != null) this.delimiter = value;
		if ((value = smartMeter.getCharsetName()) != null) this.charsetName = value;
		
		if ((value = smartMeter.getSourceFormat()) != null) this.sourceFormat = value;
		if ((value = smartMeter.getSourceType()) != null) this.sourceType = value;
		if ((value = smartMeter.getNavigationNodeId()) != null) this.navigationNodeId = value;
		if ((value = smartMeter.getExtractionChannelId()) != null) this.extractionChannelId = value;

		setIntervalReader(smartMeter.getIntervalReader());
		setEnergyUnit(smartMeter.getEnergyUnit());
	}
	
	public void setMetaDataFromFile(File file) throws IOException {
		
		CSVReader reader = new CSVReader(new FileReader(file));
		String[] row;
		
		while ((row = reader.readNext()) != null) {
			
			if (row[0] != null && !row[0].trim().isEmpty() && row[1] != null && !row[1].trim().isEmpty()) {
				setMetaData(row[0], row[1]);
			}
			
		}
		
		reader.close();
	}
	
	
	public void addFile(ZipOutputStream zip, File file) throws IOException {
		byte[] buf = new byte[1024];
		FileInputStream metaStream = new FileInputStream(file);
		zip.putNextEntry(new ZipEntry(file.getName()));
		int len;
		while ((len = metaStream.read(buf)) > 0)
			zip.write(buf, 0, len);
		zip.closeEntry();
		metaStream.close();
	}
	

	protected void setMetaData(String key, String value) {
		for (Map.Entry<String, Method> metaData : getMetaDataSetters().entrySet()) {
			if (key.toLowerCase().replace(" ", "").startsWith(metaData.getKey().toLowerCase())) {
				try {
					metaData.getValue().invoke(this, value);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}
		}
	}
	
	protected Map<String, Method> getMetaDataSetters() {
		if (metaFieldSetters == null) {
			metaFieldSetters = new HashMap<String, Method>();
			for (Field field : RelateUtils.getInstance().getAllFields(SmartMeterExtract.class, true)) {
				if (field.getType().isAssignableFrom(String.class)) {
					Method setter = RelateUtils.getInstance().findSetter(this, field.getName(), String.class);
					metaFieldSetters.put(field.getName(), setter);
				}
			}
		}
		
		return metaFieldSetters;
	}
	
	public Map<String, Method> getMetaDataGetters() {
		if (metaFieldGetters == null) {
			metaFieldGetters = new HashMap<String, Method>();
			for (Field field : RelateUtils.getInstance().getAllFields(SmartMeterExtract.class, false)) {
				if (field.getType().isAssignableFrom(String.class)) {
					Method getter = RelateUtils.getInstance().findGetter(this, field.getName());
					if (getter != null)
						metaFieldGetters.put(field.getName(), getter);
				}
			}
		}
		
		return metaFieldGetters;
	}
	

	public String getCustomer() {
		return customer;
	}

	public String getProviderAlias() {
		return providerAlias;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getMeterNumber() {
		return meterNumber;
	}

	public String getServiceType() {
		return serviceType;
	}

	public String getServiceAddress() {
		return serviceAddress;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZip() {
		return zip;
	}

	public String getSourceFormat() {
		return sourceFormat;
	}

	public void setSourceFormat(String sourceFormat) {
		this.sourceFormat = sourceFormat;
	}

	public String getNavigationNodeId() {
		return navigationNodeId;
	}

	public String getSourceType() {
		return sourceType;
	}

	public String getFilePath() {
		return filePath;
	}

	public String getExtractionChannelId() {
		return extractionChannelId;
	}

	public void setExtractionChannelId(String extractionChannelId) {
		this.extractionChannelId = extractionChannelId;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public void setProviderAlias(String providerAlias) {
		this.providerAlias = providerAlias;
	}

	public void setAccountNumber(String accountNumber) {
		if (accountNumber != null)
			this.accountNumber = FormatterFactory.getFormatter().formatText(accountNumber);
	}

	public void setMeterNumber(String meterNumber) {
		if (meterNumber != null)
			this.meterNumber = FormatterFactory.getFormatter().formatText(meterNumber);
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public void setServiceAddress(String serviceAddress) {
		if (serviceAddress != null)
			this.serviceAddress = FormatterFactory.getFormatter().formatText(serviceAddress);
	}

	public void setCity(String city) {
		if (city != null)
			this.city = FormatterFactory.getFormatter().formatText(city);
	}

	public void setState(String state) {
		if (state != null)
			this.state = FormatterFactory.getFormatter().formatText(state);
	}

	public void setZip(String zip) {
		if (zip != null)
			this.zip = FormatterFactory.getFormatter().formatText(zip);
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public void setNavigationNodeId(String navigationNodeId) {
		this.navigationNodeId = navigationNodeId;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public void setStandalone(boolean standalone) {
		this.standalone = standalone;
	}
	
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public void setCharsetName(String charsetName) {
		this.charsetName = charsetName;
	}
	
	public String getDelimiter() {
		return delimiter;
	}

	public String getCharsetName() {
		return charsetName;
	}

	public String getTariff() {
		return tariff;
	}

	public void setTariff(String tariff) {
		if (tariff != null)
			this.tariff = FormatterFactory.getFormatter().formatText(tariff);
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}
	
	public String getStartDate() {
		return startDate;
	}
	
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	public String getEndDate() {
		return endDate;
	}
	
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMeterUID1() {
		return meterUID1;
	}

	public void setMeterUID1(String meterUID1) {
		if (meterUID1 != null)
			this.meterUID1 = FormatterFactory.getFormatter().formatText(meterUID1);
	}

	public String getMeterUID2() {
		return meterUID2;
	}

	public void setMeterUID2(String meterUID2) {
		if (meterUID2 != null)
			this.meterUID2 = FormatterFactory.getFormatter().formatText(meterUID2);
	}

	public String getMeterUID3() {
		return meterUID3;
	}

	public void setMeterUID3(String meterUID3) {
		if (meterUID3 != null)
			this.meterUID3 = FormatterFactory.getFormatter().formatText(meterUID3);
	}

	public String getIntervalReader() {
		return intervalReader;
	}

	public void setIntervalReader(String intervalReader) {
		this.intervalReader = intervalReader;
	}

	public String getEnergyUnit() {
		return energyUnit;
	}

	public void setEnergyUnit(String energyUnit) {
		this.energyUnit = energyUnit;
	}

}
