var gulp = require('gulp'),
    jshint = require('gulp-jshint'),
    concat = require('gulp-concat'),
    uglify = require('gulp-uglify'),
    useref = require('gulp-useref'),
    minifyCss = require('gulp-cssnano'),
    minifyHTML = require('gulp-htmlmin'),
    gulpif = require('gulp-if'),
    sourcemaps = require('gulp-sourcemaps'),
    templates = require('gulp-angular-templatecache'),
    watch = require('gulp-watch'),
    webserver = require('gulp-webserver'),
    merge = require('gulp-merge'),
    del = require('del'),
    lazypipe = require('lazypipe');


// --------------------------------------------------------
// Project variables
// --------------------------------------------------------

var clientBase = './src/client';
var appBase = clientBase + '/app';
var allTemplates = appBase + '/**/*.html';
var allJs = [appBase + '/**/*.module.js', appBase + '/**/*.js'];
var allCss = [clientBase + '/styles/**/*.css', appBase + '/**/*.css'];
var allWired = allJs.concat(allCss);
var allImages = clientBase + '/images/**/*';
var indexFile = clientBase + '/index.html';
var buildDir = './build';
var tempDir = './.tmp';


// --------------------------------------------------------
// Clean task deletes the build directory
// --------------------------------------------------------

gulp.task('clean', function() {
    del([
        buildDir,
        tempDir
    ]);
});


// --------------------------------------------------------
// Run JSHint to check our JavaScript
// --------------------------------------------------------

gulp.task('jshint', function() {
    gulp.src(allJs)
        .pipe(jshint())
        .pipe(jshint.reporter('jshint-stylish'))
        .pipe(jshint.reporter('fail'));
});


// --------------------------------------------------------
// Minify and templateCache your Angular Templates
// --------------------------------------------------------

gulp.task('templates', function () {
    return gulp.src(allTemplates)
        .pipe(minifyHTML({
            removeAttributeQuotes: true,
            collapseWhitespace: true
        }))
        .pipe(templates('templates.js', {
            module: 'app.templates',
            root: 'app/',
            standalone: true
        }))
        .pipe(gulp.dest(buildDir));
});


// --------------------------------------------------------
// Optimize All JavaScript/CSS and wire up index.html
// --------------------------------------------------------

gulp.task('optimize-and-wire', function() {
    return gulp.src(indexFile)
        .pipe(useref({}, lazypipe().pipe(sourcemaps.init, { loadMaps: true })))
        .pipe(gulpif('*.js', uglify({ mangle: false })))
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(sourcemaps.write('sourcemaps'))
        .pipe(gulp.dest(buildDir));
});


// --------------------------------------------------------
// Copy other assets to the 'build' directory.
// --------------------------------------------------------

gulp.task('copy-assets', function() {
    var imgs = gulp.src(allImages)
        .pipe(gulp.dest(buildDir + '/images'));
    var fonts = gulp.src('node_modules/font-awesome/fonts/**')
        .pipe(gulp.dest(buildDir + '/fonts'));
    return merge(imgs, fonts);
});


// --------------------------------------------------------
// Default task fully builds the application in the
// 'build' directory.
// --------------------------------------------------------

gulp.task('default', ['templates', 'optimize-and-wire', 'copy-assets'], function() {
});


// --------------------------------------------------------
// Watch for changes and rebuild
// --------------------------------------------------------

gulp.task('watch', ['default'], function() {
    // Start the local webserver
    gulp.start('webserver');

    // Watch for app changes
    watch(allTemplates, function() {
        console.log('Templates changed');
        gulp.start('templates');
    });

    watch(allImages, function() {
        console.log('Images changed');
        gulp.start('copy-assets');
    });

    watch(allWired, function() {
        console.log('Rewiring changes');
        gulp.start('optimize-and-wire');
    });
});


// --------------------------------------------------------
// Launch a local webserver
// --------------------------------------------------------

gulp.task('webserver', function() {
    gulp.src(buildDir)
        .pipe(webserver({
            host: '0.0.0.0',
            port: 8010,
            livereload: true,
            directoryListing: false,
            open: true,
            fallback: 'index.html'
        }));
});

