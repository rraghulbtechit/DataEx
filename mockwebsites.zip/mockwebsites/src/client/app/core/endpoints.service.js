/**
 * A service that provides the addresses of external services with which we need to communicate.
 *
 * This service MUST provide an address for the authServer as it is needed by the blocks.auth helper.
 * You can define other addresses as needed by your application
 */
(function() {

    'use strict';

    angular
        .module('app.core')
        .service('endpoints', endpoints);

    endpoints.$inject =
        ['$location', 'logger'];

    function endpoints($location, logger) {
        // All addresses
        var e = {
            // Address of the SSO server.
            // THESE ARE REQUIRED
            ssoServer: 'http://localhost:8083/uaa',
            ssoClientId: 'acme',
            ssoScope: 'openid',
            ssoRedirectUriPath: '/loggedin',

            // Other addresses can be specified for your app's own use
            otherServer: 'http://localhost:9000',

            // Functions
            getLoginUri: getLoginUri
        };

        var host = $location.host();
        var proto = $location.protocol();

        //
        // Define server addresses
        //
        // NOTE: You can do address discovery in whatever way you want.
        // This is an example of using our current host name to determine the other server addresses,
        // but you could also connect to an external registration server, use DNS or any other method.
        //
        if (_.startsWith(host, '0.0.0.0')) {
            e.ssoServer = 'https://sso-ci.urjanet.net';
            e.ssoClientId = 'urja_test_client';
            e.otherServer = proto + '://otherserver-ci.urjanet.net';

        } else if (_.startsWith(host, 'thisserver-ci.')) {
            e.ssoServer = proto + '://sso-ci.urjanet.net';
            e.ssoClientId = 'urja_client';
            e.otherServer = proto + '://otherserver-ci.urjanet.net';

        } else if (_.startsWith(host, 'thisserver-qa.')) {
            e.ssoServer = proto + '://sso-qa.urjanet.net';
            e.ssoClientId = 'urja_client';
            e.otherServer = proto + '://otherserver-qa.urjanet.net';

        } else if (_.startsWith(host, 'thisserver.')) {
            e.ssoServer = proto + '://sso.urjanet.net';
            e.ssoClientId = 'urja_client';
            e.otherServer = proto + '://otherserver.urjanet.net';

        } else if (_.startsWith(host, '192.168')) {
            // This is for running in Docker containers
            e.ssoServer = proto + '://' + host + ':8083';
            e.ssoClientId = 'acme';
            e.otherServer = proto + '://' + host + ':9000';
        }

        logger.log('endpoints', e);

        /**
         * @name getLoginUri
         * @desc Builds and returns the login URI given the configured SSO parameters.
         * @returns {String}
         */
        function getLoginUri() {
            return e.ssoServer +
                '/oauth/authorize?response_type=token&client_id=' +
                e.ssoClientId +
                '&scope=' +
                e.ssoScope +
                '&redirect_uri=' +
                window.location.origin +
                e.ssoRedirectUriPath;
        }

        return e;
    }

})();
