/**
 * General application configuration.
 */
(function () {
    'use strict';

    var core = angular.module('app.core');

    // app configuration settings used below to configure providers
    var config = {
        // error prefix - used in the exception handler
        appErrorPrefix: '[angular-seed Error] ',

        // application title - used in the router
        appTitle: 'Mock-Website',

        // The local storage name of the JWT - used in auth helper and jwtInterceptor
        tokenStorageName: 'session-token-key',

        // define an authority (i.e. permission) a user must have to access this application - used in auth helper
        authRequiredAuthority: undefined
    };

    core.value('config', config);

    // configure logging, routing and exception handling
    core.config(configure);

    configure.$inject = ['$logProvider', 'routerHelperProvider', 'exceptionHandlerProvider', 'jwtInterceptorProvider', '$httpProvider', 'authHelperProvider'];

    /* @ngInject */
    function configure($logProvider, routerHelperProvider, exceptionHandlerProvider, jwtInterceptorProvider, $httpProvider, authHelperProvider) {
        // Turn on debug logging if enabled
        if ($logProvider.debugEnabled) {
            $logProvider.debugEnabled(true);
        }

        // Configure the authHelper
        authHelperProvider.configure({
            tokenStorageName: config.tokenStorageName,
            requiredAuthority: config.authRequiredAuthority
        });

        // Configure the exception handler
        exceptionHandlerProvider.configure(config.appErrorPrefix);

        // Configure the router
        routerHelperProvider.configure({docTitle: config.appTitle + ': '});

        // Create the jwtInterceptor to get the JWT from storage
        jwtInterceptorProvider.tokenGetter = function(store) {
            return store.get(config.tokenStorageName);
        };

        // Configure the httpProvider to put the JWT in the request Authorization header
        $httpProvider.interceptors.push('jwtInterceptor');

        // Add $http error handling interceptor
        $httpProvider.interceptors.push('httpInterceptor');
    }

    // configure toastr - toastrConfig constant provided by angular-toastr
    core.config(function(toastrConfig) {
        angular.extend(toastrConfig, {
            timeOut: 4000,
            preventOpenDuplicates: true,
            positionClass: 'toast-bottom-right'
        });
    });

})();
