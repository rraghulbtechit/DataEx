(function () {
    'use strict';

    angular
        .module('app.core', [
            'ngAnimate', 'ngSanitize', 'ngMessages',
            'blocks.auth', 'blocks.exception', 'blocks.http', 'blocks.logger', 'blocks.router',
            'ui.router', 'ct.ui.router.extras', 'ui.bootstrap',
            'angularMoment',
            'ngplus'
        ]);
})();
