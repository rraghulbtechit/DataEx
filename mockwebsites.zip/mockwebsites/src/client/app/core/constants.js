/**
 * Constants for use across the application.
 */
(function() {
    'use strict';

    var core =  angular
        .module('app.core');

    /**
     * @desc Constants for role and permission names. These are generally specific to the application.
     */
    var AUTHORITIES = {
        somePermission: "PERM_SOME_PERM",
        someOtherPermission: "PERM_SOME_OTHER_PERM",
    };

    core.constant('AUTHORITIES', AUTHORITIES);

})();
