/**
 * State-based ui.router
 *
 * Each module calls configureStates() to set up its own state changes.
 * In addition, this ensures the user has any authentication/authorization required by a state,
 * handles state change errors and updates the page title on state changes.
 */
(function() {
    'use strict';

    angular
        .module('blocks.router')
        .provider('routerHelper', routerHelperProvider);

    /* @ngInject */
    function routerHelperProvider($locationProvider, $stateProvider, $urlRouterProvider) {
        /* jshint validthis:true */
        var config = {
            docTitle: undefined,
            resolveAlways: {}
        };

        $locationProvider.html5Mode(true);

        this.configure = function(cfg) {
            angular.extend(config, cfg);
        };

        this.$get = RouterHelper;

        /* @ngInject */
        function RouterHelper($location, $rootScope, $state, $uibModalStack, logger, store, authHelper) {
            var handlingStateChangeError = false;
            var hasOtherwise = false;
            var stateCounts = {
                errors: 0,
                changes: 0
            };

            var service = {
                configureStates: configureStates,
                getStates: getStates,
                stateCounts: stateCounts
            };

            init();

            return service;

            ///////////////

            function configureStates(states, otherwisePath) {
                states.forEach(function(state) {
                    state.config.resolve =
                        angular.extend(state.config.resolve || {}, config.resolveAlways);
                    $stateProvider.state(state.state, state.config);
                });
                if (otherwisePath && !hasOtherwise) {
                    hasOtherwise = true;
                    $urlRouterProvider.otherwise(otherwisePath);
                }
            }

            function getStates() { return $state.get(); }

            function init() {
                ensureAuthorization();
                handleRoutingErrors();
                updateDocTitle();
            }

            function ensureAuthorization() {
                    // On state changes we ensure the user is authenticated and authorized, if necessary
                    $rootScope.$on('$stateChangeStart', function(event, toState, params) {

                        // Verify authentication if required
                        if (toState.data && toState.data.requiresLogin) {
                            if (!authHelper.isAuthenticated()) {
                                event.preventDefault();
                                // Store the requested state so we can send the user there once they log in
                                store.set(authHelper.REQUESTED_STATE, { 'state':toState, 'params': params });
                                logger.warning('You must be logged in to perform that action');
                                $state.go('login');
                                return;
                            }
                        }

                        // Verify authorization if required
                        if (toState.data && toState.data.requiresAuthority) {
                            if (!authHelper.hasAnyAuthority(toState.data.requiresAuthority)) {
                                event.preventDefault();
                                logger.warning('You do not have authority to perform that action');
                                $state.go('home');
                                return;
                            }
                        }

                        // Handle state redirection
                        if (toState.redirectTo) {
                            event.preventDefault();
                            $state.go(toState.redirectTo, params);
                        }

                        // Close all open modals
                        $uibModalStack.dismissAll();

                    });
            }

            function handleRoutingErrors() {
                // Route cancellation:
                // On routing error, go to the home page.
                // Provide an exit clause if it tries to do it twice.
                $rootScope.$on('$stateChangeError',
                    function(event, toState, toParams, fromState, fromParams, error) {
                        if (handlingStateChangeError) {
                            return;
                        }
                        stateCounts.errors++;
                        handlingStateChangeError = true;
                        var destination = (toState &&
                            (toState.title || toState.name || toState.loadedTemplateUrl)) ||
                            'unknown target';
                        var msg = 'Error routing to ' + destination + '. ' +
                            (error.data || '') + '. <br/>' + (error.statusText || '') +
                            ': ' + (error.status || '');
                        logger.warning(msg, [toState]);
                        $location.path('/');
                    }
                );
            }

            function updateDocTitle() {
                $rootScope.$on('$stateChangeSuccess',
                    function(event, toState, toParams, fromState, fromParams) {
                        stateCounts.changes++;
                        handlingStateChangeError = false;
                        var title = config.docTitle + ' ' + (toState.title || '');
                        $rootScope.title = title; // data bind to <title>
                    }
                );
            }
        }
    }
})();
