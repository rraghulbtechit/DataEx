/**
 * HTTP interceptor that handles errors received from $http calls.
 */
(function() {
    'use strict';

    angular
        .module('blocks.http')
        .factory('httpInterceptor', httpInterceptor);

    httpInterceptor.$inject = ['$injector', '$q'];

    /* @ngInject */
    function httpInterceptor($injector, $q) {
        return {
            responseError: responseError
        };

        //////////

        /**
         * @name responseError
         * @desc Handles $http errors showing a toast and logging the error
         * @param {Object} rejection
         * @returns {Array|Promise|*}
         */
        function responseError(rejection) {
            var logger = $injector.get('logger');
            var state = $injector.get("$state");

            if (rejection.status < 0) {
                logger.error('Unable to connect to the server');
            } else if (rejection.status == 401) {
                logger.error(_.get(rejection, 'data.message', 'You must be logged in to perform that action'));
                state.go('login');
            } else if (rejection.status == 403) {
                logger.error(_.get(rejection, 'data.message', 'You are not allowed to perform that action'));
            } else if (_.inRange(rejection.status, 400, 499)) {
                logger.log('Request failed. Client error (' + rejection.status + ')', rejection);
            } else {
                logger.log('Request failed. Server error (' + rejection.status + ')', rejection);
            }

            return $q.reject(rejection);
        }
    }

})();