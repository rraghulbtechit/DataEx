(function() {
    'use strict';

    angular
        .module('blocks.http', [
            'blocks.logger'
        ]);

})();