(function() {

    'use strict';

    angular
        .module('blocks.filter', [
        ]);

})();