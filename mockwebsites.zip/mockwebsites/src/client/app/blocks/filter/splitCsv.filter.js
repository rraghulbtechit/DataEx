(function() {
    'use strict';

    angular.module('blocks.filter')
        .filter('splitCsv', splitCsv);

    function splitCsv() {
        return function(input) {
            return input.split(',');
        };
    }

})();