/**
 * Logger that both logs messages to the console and pops up a toast to alert the user.
 */
(function() {
    'use strict';

    angular
        .module('blocks.logger')
        .factory('logger', logger);

    logger.$inject = ['$log', 'toastr'];

    /* @ngInject */
    function logger($log, toastr) {
        var service = {
            showToasts: true,

            error   : error,
            info    : info,
            success : success,
            warning : warning,

            /**
             * Logs the message directly to the console, bypassing toastr
             */
            log : $log.log
        };

        return service;

        /////////////////////

        /**
         * @desc Logs the given message and pops up an error toast
         * @param {String} message
         * @param {Object} data - Optional additional data
         * @param {String} title - Optional title
         */
        function error(message, data, title) {
            toastr.error(formatMessage(message), title, { closeButton: true/*, timeOut: 0, extendedTimeOut: 0*/ });
            $log.error('Error: ' + message, data);
        }

        /**
         * @desc Logs the given message and pops up an info toast
         * @param {String} message
         * @param {Object} data - Optional additional data
         * @param {String} title - Optional title
         */
        function info(message, data, title) {
            toastr.info(formatMessage(message), title);
            $log.info('Info: ' + message, data);
        }

        /**
         * @desc Logs the given message and pops up a success toast
         * @param {String} message
         * @param {Object} data - Optional additional data
         * @param {String} title - Optional title
         */
        function success(message, data, title) {
            toastr.success(formatMessage(message), title);
            $log.info('Success: ' + message, data);
        }

        /**
         * @desc Logs the given message and pops up a warning toast
         * @param {String} message
         * @param {Object} data - Optional additional data
         * @param {String} title - Optional title
         */
        function warning(message, data, title) {
            toastr.warning(formatMessage(message), title);
            $log.warn('Warning: ' + message, data);
        }

        /**
         * @desc Returns the given msg as an HTML UL if it is an array or a simple string if it is not
         * @param {String|Array} msg
         */
        function formatMessage(msg) {
            var result = '';
            if (_.isArray(msg)) {
                if (msg.length > 1) {
                    result += '<ul>';
                    _.forEach(msg, function(m) {
                        result += '<li>' + m + '</li>';
                    });
                    result += '</ul>';
                } else {
                    result = msg[0];
                }
            } else {
                result = msg;
            }
            return result;
        }
    }

}());
