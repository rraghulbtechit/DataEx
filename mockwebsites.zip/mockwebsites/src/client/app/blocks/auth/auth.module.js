(function() {

    'use strict';

    angular
        .module('blocks.auth', [
            'blocks.logger',
            'angular-storage',
            'angular-jwt'
        ]);

})();