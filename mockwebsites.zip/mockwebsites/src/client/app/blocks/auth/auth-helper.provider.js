/**
 * Authorization service that processes logins perfored via the Heimdallr SsoServer.
 */
(function() {
    'use strict';

    angular
        .module('blocks.auth')
        .provider('authHelper', authHelperProvider);

    authHelperProvider.$inject = [];

    /* @ngInject */
    function authHelperProvider() {
        /* jshint validthis:true */
        var config = {
            // Name of the JWT when stored in local storage
            tokenStorageName: 'session-token-key',

            // Name of an authority the user must have to be allowed to log in
            requiredAuthority: undefined
        };

        this.configure = function (cfg) {
            angular.extend(config, cfg);
        };

        this.$get = AuthHelper;

        /* @ngInject */
        function AuthHelper($http, $q, $state, $timeout, logger, store, jwtHelper, endpoints) {
            var service = {
                REQUESTED_STATE: 'angular-seed.lastRequestedState',
                parseAccessToken: parseAccessToken,
                logout: logout,
                getUser: getUser,
                getToken: getToken,
                isAuthenticated: isAuthenticated,
                hasAuthority: hasAuthority,
                hasAnyAuthority: hasAnyAuthority,
                _user: null,
                _token: null,
                _logoutTimeoutPromise: null
            };

            activate();

            return service;

            //////////

            function activate() {
                // Load the token from storage
                var token = store.get(config.tokenStorageName);
                if (token) {
                    if (!jwtHelper.isTokenExpired(token)) {
                        // Pre-authenticate user
                        service._token = token;
                        service._user = jwtHelper.decodeToken(token);

                        // Watch for token expiration
                        _startTokenTimer(token);
                    } else {
                        // If token has already expired, remove it from storage
                        logger.log('Removing expired token');
                        store.remove(config.tokenStorageName);
                    }
                }
            }

            /**
             * @name parseAccessToken
             * @desc Attempts to parse the access token from the URL fragment (hash).
             * @param {Object} urlFragment - string containing the access token or error message
             * @returns {Object}
             */
            function parseAccessToken(urlFragment) {
                return $q(function(resolve, reject) {
                    // parse the url fragment into json
                    var json = _.object(_.compact(_.map(urlFragment.split('&'), function(item) {  if (item) return item.split('='); })));
                    var accessToken = _.get(json, 'access_token');
                    var errorDescription = _.get(json, 'error');

                    if (accessToken !== undefined) {
                        // Get the token and decode the user from it
                        service._token = accessToken;
                        service._user = jwtHelper.decodeToken(service._token);

                        // Validate the requiredAuthority (if specified in the config)
                        if (config.requiredAuthority && !hasAuthority(config.requiredAuthority)) {
                            logout();
                            reject({ data: { message: 'You are not authorized to access this application.' } });
                            return;
                        }

                        // Store the logged in user
                        store.set(config.tokenStorageName, service._token);

                        // Watch for token expiration
                        _startTokenTimer(service._token);

                        resolve({ data: { message: 'Logged in'} });

                    } else if (errorDescription !== undefined) {
                        reject({ data: { message: errorDescription } });

                    } else {
                        reject({ data: { message: 'Invalid access token received' } });

                    }
                });
            }

            /**
             * @name logout
             * @desc Logs the current user out
             */
            function logout() {
                logger.log('Logging out');
                store.remove(config.tokenStorageName);
                $timeout.cancel(service._logoutTimeoutPromise);
                service._token = null;
                service._user = null;
            }

            /**
             * @name getUser
             * @desc Returns the current user
             * @returns {Object}
             */
            function getUser() {
                return service._user;
            }

            /**
             * @name getToken
             * @desc Returns the JWT representing the current user
             * @returns {Object}
             */
            function getToken() {
                return service._token;
            }

            /**
             * @name isAuthenticated
             * @desc Returns whether or not the user is currently logged in
             * @returns {boolean}
             */
            function isAuthenticated() {
                return service._user !== null;
            }

            /**
             * @name hasAuthority
             * @desc Returns whether or not the current user has the given authority
             * @param {String} authority - The name of an authority (i.e.role or permission) to check
             * @returns {boolean}
             */
            function hasAuthority(authority) {
                return service._user && service._user.authorities && service._user.authorities.indexOf(authority) !== -1;
            }

            /**
             * @name hasAnyAuthority
             * @desc Returns whether or not the current use has any of the given authorities
             * @param {Array} auths - The names of one or more authorities (i.e. roles or permissions) to check
             * @returns {boolean}
             */
            function hasAnyAuthority(auths) {
                return service._user && service._user.authorities && _.intersection(auths, service._user.authorities).length > 0;
            }

            function _startTokenTimer(token) {
                var ttl = jwtHelper.getTokenExpirationDate(token).getTime() - Date.now();
                if (ttl > 0) {
                    if (service._logoutTimeoutPromise) {
                        $timeout.cancel(service._logoutTimeoutPromise);
                    }
                    service._logoutTimeoutPromise = $timeout(ttl);
                    service._logoutTimeoutPromise.then(function () {
                        store.set(service.REQUESTED_STATE, { 'state': $state.current, 'params': $state.params });
                        logger.warning('Your login has expired');
                        logout();
                        $state.go('login');
                    });
                } else {
                    logger.warning('Token has already expired');
                }

            }
        }
    }

})();
