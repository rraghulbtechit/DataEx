(function () {
    'use strict';

    angular
        .module('app.home')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['$q', 'logger'];

    /* @ngInject */
    function HomeController($q, logger) {
        var vm = this;
        vm.news = {
            title: 'angular-seed',
            description: 'Angular seed based on HotTowel by John Papa'
        };
        vm.title = 'Home';

        activate();

        //////////

        function activate() {
        }
    }

})();
