(function() {
    'use strict';

    angular
        .module('app.home')
        .run(appRun);

    appRun.$inject = ['routerHelper', 'AUTHORITIES'];

    /* @ngInject */
    function appRun(routerHelper, AUTHORITIES) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [
            {
                state: 'ROOT',
                config: {
                    url: '/',
                    redirectTo: 'login'
                }
            },
            {
                state: 'home',
                config: {
                    url: '/home',
                    templateUrl: 'app/home/home.html',
                    controller: 'HomeController',
                    controllerAs: 'vm',
                    title: 'Home',
                    data: {
                        requiresLogin: true
                    }
                }
            }
        ];
    }

})();
