(function () {
    'use strict';

    angular
        .module('app.login')
        .controller('LoginController', LoginController);

    /* @ngInject */
    function LoginController($state,logger) {
        var vm = this;

        vm.login = login;

        vm.title = 'Login';

        function login() {
            if(vm.username == 'mockwebsite@urjanet.com' && vm.password=='12345') {
                $state.go('page1');
            } else {
                logger.error("Credential Failure");
                $state.go('login');
            }
        }
    }

})();
