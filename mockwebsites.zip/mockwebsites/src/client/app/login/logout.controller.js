(function () {
    'use strict';

    angular
        .module('app.login')
        .controller('LogoutController', LogoutController);

    LogoutController.$inject = ['logger', 'authHelper'];

    /* @ngInject */
    function LogoutController(logger, authHelper) {
        var vm = this;

        vm.title = 'Logout';

        activate();

        //////////

        function activate() {
            authHelper.logout();
            logger.success('You have been logged out');
        }
    }

})();
