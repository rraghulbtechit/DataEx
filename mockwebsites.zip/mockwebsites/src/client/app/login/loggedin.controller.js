(function () {
    'use strict';

    angular
        .module('app.login')
        .controller('LoggedInController', LoggedInController);

    LoggedInController.$inject = ['$state', '$location', 'store', 'logger', 'authHelper'];

    /* @ngInject */
    function LoggedInController($state, $location, store, logger, authHelper) {
        var vm = this;

        vm.title = 'Logged in';

        activate();

        //////////

        function activate() {
            authHelper.parseAccessToken($location.hash())
                .then(
                    function success(response) {
                        logger.success('Welcome back ' + authHelper.getUser().name);

                        // If the user had previous requested a particular state, send them there.
                        // Otherwise send them to the home page
                        var requestedState = store.get(authHelper.REQUESTED_STATE);
                        if (requestedState !== null) {
                            store.remove(authHelper.REQUESTED_STATE);
                            $state.go(requestedState.state.name, requestedState.params);
                        } else {
                            $state.go('home');
                        }
                    },
                    function error(rejection) {
                        logger.error(rejection.data.message);
                        $state.go('login');
                    }
                );
        }
    }

})();
