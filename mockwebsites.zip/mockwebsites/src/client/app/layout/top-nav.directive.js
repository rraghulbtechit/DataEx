(function() {
    'use strict';

    angular
        .module('app.layout')
        .directive('topNav', topNav);

    /* @ngInject */
    function topNav () {
        var directive = {
            bindToController: true,
            controller: TopNavController,
            controllerAs: 'vm',
            restrict: 'EA',
            scope: {
                'navline': '='
            },
            templateUrl: 'app/layout/top-nav.html'
        };

        TopNavController.$inject = ['$state', 'logger', 'authHelper'];

        /* @ngInject */
        function TopNavController($state, logger, authHelper) {
            var vm = this;

            vm.authHelper = authHelper;

            vm.logout = logout;

            //////////

            function logout() {
                authHelper.logout();
                logger.success('You have been logged out.');
                $state.go('login');
            }
        }

        return directive;
    }

})();
