(function () {
    'use strict';

    angular
        .module('app', [
            'app.core',
            'app.login',
            'app.home',
            'app.layout',
            'app.page1',
            // templates module created by gulp-angular-templatecache
            'app.templates'
        ]);

})();
