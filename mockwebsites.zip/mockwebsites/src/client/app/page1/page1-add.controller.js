(function() {
    'use strict';

    angular
        .module('app.page1')
        .controller('Page1AddController', Page1AddController);

    Page1AddController.$inject = ['$state', 'logger'];

    /* @ngInject */
    function Page1AddController($state, logger) {
        var vm = this;
        vm.title = 'Invoice Page';

        vm.download = download;

        activate();

        //////////

         function download() {
            window.open("https://myaccount.centerpointenergy.com/App/Billing/public/billpdf.aspx?sa=000010014186&dd=02&mm=08&yyyy=2017");
            // window.open('https://drive.google.com/open?id=0B0LFOhWjNuFga2dhMVp3NldkNTQ');
            // window.open('file:///opt/mockwebsites/src/client/app/page1/bill_one.pdf', '_self');
        }

        function activate() {
            logger.info('This is ' + vm.title);
        }
    }

})();