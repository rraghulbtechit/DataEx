(function() {
    'use strict';

    angular
        .module('app.page1')
        .controller('Page1PopupController', Page1PopupController);

    Page1PopupController.$inject = ['$state', '$uibModalInstance', 'logger'];

    /* @ngInject */
    function Page1PopupController($state, $uibModalInstance, logger) {
        var vm = this;
        vm.title = 'Module 2 Popup';

        vm.closeDialog = closeDialog;
        vm.dismissDialog = dismissDialog;

        activate();

        //////////

        function activate() {
        }

        function closeDialog() {
            // Close the modal
            $uibModalInstance.close();
            logger.info('You click the OK button');

            // Return to the previous state
            $state.go('^');
        }

        function dismissDialog() {
            // Dismiss the modal
            $uibModalInstance.dismiss();
            logger.warning('You clicked the Cancel button');

            // Return to the previous state
            $state.go('^');
        }
    }

})();