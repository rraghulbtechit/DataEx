(function () {
    'use strict';

    angular
        .module('app.page1')
        .controller('Page1Controller', Page1Controller);

    Page1Controller.$inject = ['$state', 'logger'];

    /* @ngInject */
    function Page1Controller($state, logger) {
        var vm = this;
        vm.title = 'Accounts View';

        vm.accounts = [
            {acct: 'Acct_123', acctName:'Raghul', enrolledDate: 'July 26 2017'}, 
            {acct: 'Acct_1234', acctName:'Sethu', enrolledDate: 'July 26 2017'},
            {acct: 'Acct_12345', acctName:'Tim', enrolledDate: 'July 26 2017'}
        ];

        activate();

        //////////

        function activate() {
            logger.info('This is page1');
        }
    }

})();
