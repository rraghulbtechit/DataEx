(function() {
    'use strict';

    angular
        .module('app.page1', [
            'app.core'
        ]);

})();
