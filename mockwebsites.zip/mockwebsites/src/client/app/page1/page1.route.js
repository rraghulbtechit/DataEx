(function() {
    'use strict';

    angular
        .module('app.page1')
        .run(appRun);

    appRun.$inject = ['routerHelper', 'AUTHORITIES'];

    /* @ngInject */
    function appRun(routerHelper, AUTHORITIES) {
        routerHelper.configureStates(getStates());
    }

    function getStates() {
        return [
            {
                state: 'page1',
                config: {
                    url: '/page1',
                    templateUrl: 'app/page1/page1.html',
                    controller: 'Page1Controller',
                    controllerAs: 'vm',
                    title: 'Page 1',
                    // data: {
                    //     requiresLogin: true//,
                    //     //requiresAuthority: [
                    //     //    AUTHORITIES.accessUserServer
                    //     //]
                    // }
                }
            },

            // Just a regular state (i.e. not nested)
            // Notice no '.' in the state name
            {
                state: 'page1-add',
                config: {
                    url: '/page1/add',
                    templateUrl: 'app/page1/page1-add.html',
                    controller: 'Page1AddController',
                    controllerAs: 'vm',
                    title: 'Page 1 Add',
                    // data: {
                    //     requiresLogin: true
                    // }
                }
            },
            {
                state: 'Acct_123',
                config: {
                    url: '/page1/Acct_123',
                    templateUrl: 'app/page1/Acct_123.html',
                    controller: 'Page1AddController',
                    controllerAs: 'vm',
                    title: 'Acct_123',
                    // data: {
                    //     requiresLogin: true
                    // }
                }
            },
            {
                state: 'Acct_1234',
                config: {
                    url: '/page1/Acct_1234',
                    templateUrl: 'app/page1/Acct_1234.html',
                    controller: 'Page1AddController',
                    controllerAs: 'vm',
                    title: 'Acct_1234',
                    // data: {
                    //     requiresLogin: true
                    // }
                }
            },
            {
                state: 'Acct_12345',
                config: {
                    url: '/page1/Acct_12345',
                    templateUrl: 'app/page1/Acct_12345.html',
                    controller: 'Page1AddController',
                    controllerAs: 'vm',
                    title: 'Acct_12345',
                    // data: {
                    //     requiresLogin: true
                    // }
                }
            },
            {
                state: 'logout',
                config: {
                    url: '/login',
                    templateUrl: 'app/login/login.html',
                    controller: 'LoginController',
                    controllerAs: 'vm',
                    title: 'Logout'
                }
            },
            {
                state: 'back',
                config: {
                    url: '/page1',
                    templateUrl: 'app/page1/page1.html',
                    controller: 'Page1Controller',
                    controllerAs: 'vm',
                    title: 'Page 1'
                }
            },

            // Example of a nested state
            // Notice the '.' in the state name?
            // page1.popup is nested under page1
            // This state pops up a modal dialog instead of displaying page
            {
                state: 'page1.popup',
                config: {
                    url: '/popup',
                    title: 'Create a User',
                    // data: {
                    //     requiresLogin: true
                    // },
                    onEnter: ['$uibModal', function($uibModal) {
                        // modalInstance is passed into the controller
                        var modalInstance = $uibModal
                            .open({
                                templateUrl: 'app/page1/page1-popup.html',
                                controller: 'Page1PopupController',
                                controllerAs: 'vm',
                                keyboard: false,
                                backdrop: 'static'
                            });
                    }]
                }
            }
        ];
    }

})();
