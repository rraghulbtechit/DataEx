# First AngularJS Mock website for Urjanet

_*Revision 2017-06-14*_

# Description

This seed project aims to make it easy to get started building an Angular SPA (single-page application) with
[Heimdallr](https://bitbucket.org/urjanet/heimdallr) authentication. Just copy this source somewhere and start hacking.

**NOTE:** The sample application supports authentication via the Heimdallr SsoServer.
If you are running the app from your computer it expects SsoServer to be accessible at http://localhost:8083.
If you are running the app in Docker it expects SsoServer to be accessible at http://<docker-host>:8083.

There are two ways to build and run this project:

* [Using Node]()
* [Using Gradle]()

You can also build a Docker image to run in a container:

* [Using Docker]()

Finally, you can use this seed as a starting point for your own application:

* [Customizing the Application]().


# Using Node

The underlying toolchain used to build this application is Node (using NPM and Gulp under the covers). If you have node
installed on your computer you can use it directly. This is a better process to use when developing the application
as you don't have to incur the overhead of Gradle.

## Prerequisites

1. node 5.12.0 or greater ([using nvm](https://github.com/creationix/nvm) is the recommended way to install node and npm)
2. npm 3.8.6 or greater

## Building the application

1\. cd into the root of the project directory.

2\. Install all dependencies defined in `package.json`.

```bash
$ npm install
```

3\. Build the application. This creates optimized versions of the html, js and css files and puts them into the `build`
directory.

```bash
$ npm run build
```

## Running locally

Start a local webserver on port 8100 with live reloading. Any changes you make will automatically reload the app in the
browser. This is the best way to work in development as it will automatically optimize your changes and reload them in the
browser.

```bash
$ npm run watch
```

Start a local webserver on port 8100 without live reloading.

```bash
$ npm run webserver
```

**NOTE:** When you run the app in either of these two ways it will automatically load the application in your browser.
By default, it will point at [http://0.0.0.0:8100](http://0.0.0.0:8100). In this mode, the application will point at
the Heimdallr SsoServer in the CI environment. If you prefer to run the SsoServer locally, all you have to do is point
your browser at [http://localhost:8100](http://localhost:8100) instead. 


## Other tasks

#### Delete the build directory (i.e. clean up)

```bash
$ npm run clean
```

#### Check your JavaScript with JSHint

```bash
$ npm run lint
```


# Using Gradle

On top of the node toolchain, we also provide the ability to build with Gradle. This makes it easier to incorporate the
application into our Jenkins build pipelines.

The nice thing about this method is it does not require any tools to be installed on the building computer except for
Java. All other tools (Gradle, Node, NPM, Gulp, etc.) are downloaded automatically into the project directory.

## Prequisites

1. Install Java

## Building the application

This creates optimized versions of the html, js and css files and puts them into the build directory.

```bash
$ ./gradlew build
```

## Other tasks

#### Delete the build directory

```bash
$ ./gradlew clean
```

#### Clean up everything (i.e. delete build and node_modules directories)

```bash
$ ./gradlew cleanAll
```

#### Check your JavaScript with JSHint

```bash
$ ./gradlew lint
```

# Using Docker

This sample is configured with a Gradle Docker plugin, which allows you to generate a Docker image.
This image will use nginx to run the application.

## Build the Docker image

    $ ./gradlew buildDocker

This will create the image and install it in your local Docker registry. You can see it like this:

```bash
$ docker images

REPOSITORY                            TAG                 IMAGE ID            CREATED             SIZE
com.urjanet.samples/ui-angular-seed   1.0                 1450d6bfb20d        5 minutes ago       134.7 MB
nginx                                 1.9.11              574907042fd7        2 weeks ago         134.6 MB
```

## Run the image locally in a Docker container

Now you can run the image in a local Docker container using `docker-compose`.

```bash
$ docker-compose up
```

You can check the status of the running container like this:

```bash
$ docker ps

CONTAINER ID        IMAGE                                     COMMAND                  CREATED             STATUS              PORTS                                     NAMES
01900e28d80d        com.urjanet.samples/ui-angular-seed:1.0   "nginx -g 'daemon off"   55 seconds ago      Up 54 seconds       80/tcp, 443/tcp, 0.0.0.0:8100->8100/tcp   uiangularseed_web_1
```

Now that it is running you can access it by pointing your browser at the address and port of the Docker container.

On a linux machine this will be your local address. On a non-Linux machine, this will likely be a boot2docker virtual
machine. If you are using `docker-machine` you can find the IP address like this:

```bash
$ docker-machine ip [machine name]

192.168.99.100
```

The port on which nginx is listening is shown in the `docker ps` line above, but you can also find it like this:

```bash
$ docker port uiangularseed_web_1

8100/tcp -> 0.0.0.0:8100
```

## Stop and Remove the Docker container

If you started the container with `docker-compose` you can stop it by pressing CTRL-C in the terminal window.

To full remove the container do:

```bash
$ docker-compose down
```

# Customizing the Application

To use this seed application as the starting point for a new application, do at least the following:

1. Fork the original Git repository (or delete the `.git` directory if you cloned it.)
1. Do `./gradlew clean` or `npm run clean` to remove the built application.
1. Update the `group` name in `build.gradle`.
1. Find-and-replace all instances of "angular-seed" with the name of your application.

Some parts of the application are meant to be used as-is:

* **src/client/app/blocks**:
  Contains modules that provide standard functionality, such as authentication, routing, logging and exception handling.
  You should not modify these modules, but you can configure them via **src/client/app/core/config.js** below.

Other parts may need to be tweaked:

* **src**
    * **/client**
        * **/app**
            * **/core**
                * **config.js**: Global application configuration
                * **constants.js**: Global constants
                * **endpoints.service.js**: Defines the addresses of external services
            * **/layout**
                * **top-nav.directive.js**: Top navigation bar code
                * **top-nav.html**: Top navigation bar HTML
        * **app.module.js**: Defines all top-level modules
    * **index.html**: The main HTML template

The rest of the code under **src/client** is fair game.

Happy coding!
