# README #

### What is this repository for? ###

Common urjanet concepts and utilities used by multiple repositories and services

### How do I get set up? ###

To get started, run 'gradle eclipse' to create your eclipse project files, then load the project into your IDE

