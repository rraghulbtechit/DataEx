package urjanet.regex;

import static org.junit.Assert.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

public class ExpressionTests {

    Expressions exp = Expressions.getInstance();
    
    @Test
    public void testREGX_NUM() {
        String[] integerStrings = {
                "0", "1", "100", "1,000", "1,000,000", "-1", "-0", "-100", "-1000",
                "\u22121", "\uFE631", "\uFF0D1", "\u27961"  // Various unicode dashes, followed by a "1"
        };
        Pattern p = Pattern.compile(exp.REGX_NUM);
        for (String str : integerStrings) {
            Matcher m = p.matcher(str);
            assertTrue("'" + str + "' should be considered a valid integer number value", m.matches());
        }
    }
    
    @Test
    public void testREGX_NUM_ANY() {
        String[] numStrings = {
                "0", "1", "100", "1,000", "1,000,000", "-1", "-0", "-100", "-1000",
                "0.0", "1.1", "1,000.999", "-9,999,999.999999999",
                "\u22125.9","\u22121,000,000.9999", "\u22121",
                "\uFE635.9", "\uFE631,000,000.9999", "\uFE631",
                "\uFF0D5.9", "\uFF0D1,000,000.9999", "\uFF0D1",
                "\u27965.9", "\u27961,000,000.9999", "\u27961",
                ".01", "-.01"
        };
        Pattern p = Pattern.compile(exp.REGX_NUM_ANY);
        for (String str : numStrings) {
            Matcher m = p.matcher(str);
            assertTrue("'" + str + "' should be considered a valid decimal number value", m.matches());
        }
    }
    
    @Test
    public void testREGX_CURRENCY() {
        String[] currencyStrings = {
                "$0", "$1", "$100", "$1,000", "$1,000,000", "$-1", "$-0", "$-100", "$-1000",
                "$0.0", "$1.1", "$1,000.999", "$-9,999,999.999999999", 
                "$\u22125.9", "$\u22121,000,000.9999", "$\u22121",
                "$\uFE635.9", "$\uFE631,000,000.9999", "$\uFE631",
                "$\uFF0D5.9", "$\uFF0D1,000,000.9999", "$\uFF0D1",
                "$\u27965.9", "$\u27961,000,000.9999", "$\u27961",
                "-$1.00", "- $ 5.00", "+ $3.50", "$+3.50", "$  +3.50", "$ + 3.50", "$ - 3.50",
                "$.01", "-$.01", "+$.01", "$-.01", "$+.01"
                // It seems that any string which is identified by REGX_NUM_ANY should also be included here ($-sign optional),
                // but that breaks logic in some existing statements - we should consider revisiting that topic (and allowing
                // other currency symbols, both US and abroad)
        };
        Pattern p = Pattern.compile(exp.REGX_CURRENCY);
        for (String str : currencyStrings) {
            Matcher m = p.matcher(str);
            assertTrue("'" + str + "' should be considered a valid currency value", m.matches());
        }
    }
}
