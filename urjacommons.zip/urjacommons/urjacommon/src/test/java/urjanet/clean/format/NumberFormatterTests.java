package urjanet.clean.format;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Test;

public class NumberFormatterTests {

    @Test
    public void testMinusSignVariations() {
        String dashDecimal = "-1.87";
        assertTrue(new BigDecimal("-1.87").compareTo(new BigDecimal(Formatter.clean(dashDecimal, true))) == 0);

        String minusDecimal = "−1.87";
        assertTrue(new BigDecimal("-1.87").compareTo(new BigDecimal(Formatter.clean(minusDecimal, true))) == 0);

        String heavyMinusDecimal = "➖1.87";
        assertTrue(new BigDecimal("-1.87").compareTo(new BigDecimal(Formatter.clean(heavyMinusDecimal, true))) == 0);
    }
    
    @Test
    public void testCurrency() throws FormatException {
        String[] currencyStrings = {
                "$0", "$1", "$100", "$1,000", "$1,000,000", "$-1", "$-0", "$-100", "$-1000", "$−1", "$➖1",
                "$0.0", "$1.1", "$1,000.999", "$-9,999,999.999999999", "$−5.9", "$➖5.9", "$−1,000,000.9999", "$➖1,000,000.9999",
                "-$1.00", "- $ 5.00", "+ $3.50", "$+3.50", "$  +3.50", "$ + 3.50", "$ - 3.50"
        };
        
        DefaultFormatter f = new DefaultFormatter();
        
        for (String str : currencyStrings) {
            assertTrue("'" + str + "' should be a valid currency and extract correctly into a BigDecimal", f.formatCurrency(str, null) != null);
        }
    }
}
