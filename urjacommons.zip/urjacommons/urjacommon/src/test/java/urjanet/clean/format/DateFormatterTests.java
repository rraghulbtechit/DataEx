package urjanet.clean.format;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class DateFormatterTests {
	
    Formatter usFormatter = new DefaultFormatter();
    Formatter euFormatter = new EuropeanFormatter();
    
    private static final int NO_YEAR = 1970;
    
    
    /**
     * Helper method - assumes you expect the date to format as we fail on a FormatException
     * @param dateStr
     * @param formatHint
     * @param expectedMonth 1-indexed month cause it "could be less confusing to some" #GrandmasBoy
     * @param expectedDay
     * @param expectedYear Passing in 1970 or lower will check that the year parsed is 1970 or lower
     * 					we have code which checks if an actual year was parsed which looks for <= 1970
     */
    private void testUS(String dateStr, String formatHint, Integer expectedMonth, Integer expectedDay, Integer expectedYear) {
    	try {
			Date date = usFormatter.formatDate(dateStr, formatHint);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			if (expectedMonth != null) {
				assertEquals(expectedMonth.intValue(), cal.get(Calendar.MONTH)+1);
			}
			if (expectedDay != null) {
				assertEquals(expectedDay.intValue(), cal.get(Calendar.DAY_OF_MONTH));
			}
			if (expectedYear != null) {
				if (expectedYear <= NO_YEAR) {
					// Test for no-year scenarios
					assertTrue(cal.get(Calendar.YEAR) <= NO_YEAR);
				} else {
					assertEquals(expectedYear.intValue(), cal.get(Calendar.YEAR));
				}
			}
		} catch (FormatException e) {
			fail("Failed to format date["+dateStr+"] with formatHint["+formatHint+"]");
		}
    }
    
    
    /*-------------------------------------------------------------------
     * Basic tests
     * -------------------------------------------------------------------
     */
    @Test
    public void test_US_standardFormatHint() {
    	testUS("01/01/2016", "MM/dd/yyyy", 1, 1, 2016);
    }
    @Test
    public void test_US_standardNoFormatHint() {
    	testUS("01/01/2016", null, 1, 1, 2016);
    }
    
    
    /*-------------------------------------------------------------------
     * No day or year tests (just month)
     * -------------------------------------------------------------------
     */
    @Test
    public void test_US_monthWithFormatHint() {
    	testUS("01", "MM", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint() {
    	try {
			usFormatter.formatDate("01", null);
		} catch (FormatException e) {
			return;	// success condition - we are not (yet?) handling this - update when/if we do
		}
    	fail("We should not be able to parse this (yet?) without a format hint... aliens?");
    }
    @Test
    public void test_US_monthWithFormatHint2() {
    	testUS("Jan", "MMM", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint2() {
    	testUS("Jan", null, 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithFormatHint3() {
    	testUS("January", "MMM", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint3() {
    	testUS("January", null, 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithFormatHint4() {
    	testUS("FEB", "MMM", 2, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint4() {
    	testUS("FEB", null, 2, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithFormatHint5() {
    	testUS("DECEMBER", "MMM", 12, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint5() {
    	testUS("DECEMBER", null, 12, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithFormatHint6() {
    	testUS("SEPT", "MMM", 9, 1, NO_YEAR);
    }
    @Test
    public void test_US_monthWithNoFormatHint6() {
    	testUS("SEPT", null, 9, 1, NO_YEAR);
    }
    
    
    /*-------------------------------------------------------------------
     * No year tests
     * -------------------------------------------------------------------
     */
    @Test
    public void test_US_noYearWithFormatHint() {
    	testUS("01/01", "MM/dd", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint() {
    	testUS("01/01", null, 1, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_noYearWithFormatHint2() {
    	testUS("Jan 01", "MMM dd", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint2() {
    	testUS("Jan 01", null, 1, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_noYearWithFormatHint3() {
    	// "Sept" is a non-standard abbreviation so SimpleDateFormat has problems with it
    	// We use another library to parse text based off heuristics which works but will
    	// set the year as the day.. We have code which detects that condition and fixes it
    	testUS("Sept 01", "MMM dd", 9, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint3() {
    	testUS("Sept 01", null, 9, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_noYearWithFormatHint4() {
    	testUS("January 1", "MMM dd", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint4() {
    	testUS("January 1", null, 1, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_noYearWithFormatHint5() {
    	testUS("Jan. 01", "MMM. dd", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint5() {
    	testUS("Jan. 01", null, 1, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_noYearWithFormatHint_incompleteMonth() {
    	testUS("Janu 01", "MMM dd", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_noYearWithNoFormatHint_incompleteMonth() {
    	testUS("Janu 01", null, 1, 1, NO_YEAR);
    }

    @Test
    public void test_US_noYearLeapDayWithFormatHint() {
    	testUS("Feb 29", "MMM dd", 2, 29, NO_YEAR);
    }
    @Test
    public void test_US_noYearLeapDayWithNoFormatHint() {
    	testUS("Feb 29", null, 2, 29, NO_YEAR);
    }

    @Test
    public void test_US_noYearLeapDayWithFormatHint2() {
    	testUS("Feb. 29", "MMM. dd", 2, 29, NO_YEAR);
    }
    @Test
    public void test_US_noYearLeapDayWithNoFormatHint2() {
    	testUS("Feb. 29", null, 2, 29, NO_YEAR);
    }
    
    
    /*-------------------------------------------------------------------
     * Full date tests
     * -------------------------------------------------------------------
     */

    @Test
    public void test_US_WithFormatHint() {
    	// "Sept" is a non-standard abbreviation so SimpleDateFormat has problems with it
    	// We use another library to parse text based off heuristics which works but will
    	// set the year as the day.. We have code which detects that condition and fixes it
    	testUS("Sept 01, 1991", "MMMM dd, yyyy", 9, 1, 1991);
    }
    @Test
    public void test_US_WithNoFormatHint() {
    	testUS("Sept 01, 1991", null, 9, 1, 1991);
    }
    
    @Test
    public void test_US_WithFormatHint2() {
    	testUS("Sept 01, 1991", "MMMM dd, yyyy", 9, 1, 1991);
    }
    @Test
    public void test_US_WithNoFormatHint2() {
    	testUS("Sept 01, 1991", "MMMM dd, yyyy", 9, 1, 1991);
    }
    
    @Test
    public void test_US_WithFormatHint3() {
    	testUS("01.01.01", "MM.dd.yy", 1, 1, 2001);
    }
    @Test
    public void test_US_WithNoFormatHint3() {
    	testUS("01.01.01", null, 1, 1, 2001);
    }
    
    @Test
    public void test_US_WithFormatHint4() {
    	testUS("01 01 01", "MM dd yy", 1, 1, 2001);
    }
    @Test
    public void test_US_WithNoFormatHint4() {
    	testUS("01 01 01", null, 1, 1, 2001);
    }
    
    @Test
    public void test_US_WithFormatHint5() {
    	testUS("Jan 1st 2001", "MMM dd yyyy", 1, 1, 2001);
    }
    @Test
    public void test_US_WithNoFormatHint5() {
    	testUS("Jan 1st 2001", null, 1, 1, 2001);
    }
    
    /***
     * Arguably these two tests should return 2001
     * Keeping these tests to detect change in functionality
     */
    @Test
    public void test_US_WithFormatHint6() {
    	testUS("Jan 1st 01", "MMM dd yyyy", 1, 1, NO_YEAR);
    }
    @Test
    public void test_US_WithNoFormatHint6() {
    	testUS("Jan 1st 01", null, 1, 1, NO_YEAR);
    }
    
    @Test
    public void test_US_LeapDayWithFormatHint() {
    	testUS("Feb 29, 2000", "MMMM dd, yyyy", 2, 29, 2000);
    }
    @Test
    public void test_US_LeapDayWithNoFormatHint() {
    	testUS("Feb 29, 2000", null, 2, 29, 2000);
    }

    
}