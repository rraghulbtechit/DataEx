package urjanet.aws.sqs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import urjanet.environment.UrjanetProperties;

/**
 * 
 * @author xavierd
 *
 */
public class AmazonSqsManagerTest {

	private static AmazonSQSManager sqsManager;
	private static String s3BucketName = "sqs-manager-test-bucket";
	private static String queueName = "SqsManagerTestQueue";
	
	@BeforeClass
	public static void start() throws UrjanetSqsException {
		sqsManager = new AmazonLargeSqsManager(s3BucketName);
		sqsManager.start();
	}
	
	@AfterClass
	public static void stop() throws UrjanetSqsException {
		sqsManager.stop();
	}
	
	@Test
	public void runTest() {
		
		try {
			
			createQueue();
			sendMessage();
			receiveMessage();
			deleteQueue();
			
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false);
		}
	}
	
	private void createQueue() throws UrjanetSqsException {
		sqsManager.createQueue(queueName);
	}
	
	private void sendMessage() throws UrjanetSqsException {
		
		String smallMessage = "Urjanet Energy Solutions Pvt Ltd.,";
		Map<String, String> attributes = new HashMap<String, String>();
		attributes.put("Attribute_1", "Value 1");
		attributes.put("Attribute_2", "Value 2");
		
		sqsManager.sendMessage(queueName, smallMessage, attributes);
		
		String largeMessage = createLargeMessage();
		sqsManager.sendMessage(queueName, largeMessage, attributes);
		
		SampleMessage message1 = new SampleMessage();
		message1.setMessageBody(smallMessage);
		message1.setId(UUID.randomUUID().toString());
		sqsManager.sendMessage(queueName, message1.toJson(), attributes);
		
		SampleMessage message2 = new SampleMessage();
		message2.setMessageBody(largeMessage);
		message2.setId(UUID.randomUUID().toString());
		sqsManager.sendMessage(queueName, message2.toJson(), attributes);
	}
	
	private void receiveMessage() throws UrjanetSqsException {
		
		List<? extends UrjanetSQSMessage> messages = null;
		boolean isMessageReceived = false;
		while((messages = sqsManager.receiveMessages(queueName)) != null && !messages.isEmpty()) {
			for(UrjanetSQSMessage message : messages) {
				sqsManager.confirmMessage(queueName, message);
				isMessageReceived = true;
			}
		}
		Assert.assertTrue(isMessageReceived);
	}
	
	private void deleteQueue() throws UrjanetSqsException {
		sqsManager.deleteQueue(queueName);
	}
	
	private String createLargeMessage() {
		
		StringBuilder messageBody = new StringBuilder();
		messageBody.append("MessageBody [ ");
		for(int i=0; i<262144; i++) {
			messageBody.append(i + " ");
		}
		messageBody.append(" ]");
		
		return messageBody.toString();
	}

	private static class AmazonLargeSqsManager extends AmazonSQSManager {
		
		private static boolean isS3BucketExist = SqsManagerUtils.isS3BucketExist(s3BucketName);
		
		public AmazonLargeSqsManager(String s3BucketName) {
			super(s3BucketName);
		}
		
		@Override
		protected boolean isS3BucketExist() {
			return isS3BucketExist;
		}
		
		@Override
		protected final String getEnvName() {
			return UrjanetProperties.ENV_PRODUCTION;
		}
		
	}
	
	private static class SampleMessage extends UrjanetSQSMessage {
		
		private static final long serialVersionUID = 1L;

		private String messageBody;
		private String id;
		
		public SampleMessage() {}
		
		public void setMessageBody(String messageBody) {
			this.messageBody = messageBody;
		}
		
		public void setId(String id) {
			this.id = id;
		}
		
		@Override
		public String toString() {
			
			return "ID = " + id;
		}

	}
}
