package urjanet.environment;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.cloudformation.AmazonCloudFormationClient;
import com.amazonaws.services.cloudformation.model.DescribeStacksRequest;
import com.amazonaws.services.cloudformation.model.DescribeStacksResult;
import com.amazonaws.services.cloudformation.model.Output;
import com.amazonaws.services.cloudformation.model.Stack;

/**
 * Takes the outputs from a Cloudformation Stack and puts them in a usable
 * hash, instead of a less useful list.
 * @author andy
 *
 */

class StackHelper {

    private static final Logger log = LoggerFactory.getLogger(StackHelper.class);
	
	private String stackName;
	private Map<String, Output> hash = new HashMap<String, Output>();

	public StackHelper(String stackName) {
		this.stackName = stackName;
		refresh();
	}

	public Output getOutput(String key) {
		return hash.get(key);
	}

	public String getStackName() {
		return stackName;
	}
	
	public String getValue(String key) {
		String value = null;
		Output output = getOutput(key);
		if (output != null) {
			value = output.getOutputValue();
		}
		return value;
	}

	// TODO: do we want to support dynamic updates / polling one day?  We'd only worry about it if we
	// wanted to support pushing a new CloudFormation config out that changed config values without
	// restarting the java apps that read them...
	
	private void refresh() {

		log.debug("Reading CloudFormation stackName = " + stackName + "...");
		
		AmazonCloudFormationClient client = new AmazonCloudFormationClient();

		DescribeStacksResult result = client.describeStacks(new DescribeStacksRequest().withStackName(stackName));
		if (result != null && result.getStacks() != null && result.getStacks().size() > 0) {
			Stack stack = result.getStacks().get(0); // there can be only one...
			for (Output output : stack.getOutputs()) {
				hash.put(output.getOutputKey(), output);
			}
		}
		
		log.debug("Successfully retrieved CloudFormation stackName = " + stackName + "...");		
	}
	
}
