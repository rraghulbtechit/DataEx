package urjanet.environment;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.regions.DefaultAwsRegionProviderChain;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.util.EC2MetadataUtils;

import urjanet.UrjanetRuntimeException;

/**
 * Simple java property file wrapper for urjanet configuration settings needed to bootstrap a new app server
 * instance - mostly database connection info at the moment.
 * 
 * Conventions:
 * 
 * platform2 file location is /opt/urjanet_configuration/trunk/urjanet.properties
 * 
 * you can use a symlink here to pick from dev/staging/production configurations - default is a dev configuration
 * with everything running on the local host
 * 
 * naming scheme:
 * 
 *   sql database properties:
 *   
 *   	sqlstore.<store_name>.<prop_name>
 *
 *   mongo database properties:
 *
 *   	mongostore.<store_name>.<prop_name>
 *   
 *   everything else:
 *   
 *   	<category_name>.<prop_name>
 * 
 * the file format is standard java property file syntax, with additional support for token replacement.  All property
 * values can be referenced in other property definitions using "${my.prop.name}" syntax.  The definition order doesn't
 * matter.
 * 
 * sample urjanet.properties content:
 *
 * urja.user=urja
 * urja.pwd=*****
 * sqlstore.core.host=localhost
 * sqlstore.core.port=3306
 * sqlstore.core.db=urja_core
 * sqlstore.core.url=jdbc:mysql://${sqlstore.core.host}:${sqlstore.core.port}/${sqlstore.core.db}?useUnicode\=true&characterEncoding\=UTF-8
 * sqlstore.core.user=${urja.user}
 * sqlstore.core.password=${urja.pwd}
 *
 * properties are grouped together if they share the same dot-notation prefix.  In the example above you could request
 * the only the properties for "sqlstore.core" like this:
 * 
 *    Properties props = UrjanetProperties.get().getGroupedProperties("sqlstore.core");
 *    
 * by convention, all properties that share the "sqlstore.<persistence_unit_name>" prefix will be passed along when the
 * corresponding JPA entity manager factory is initialized, so if you want to inject a hibernate-related property you 
 * would do so like this:
 * 
 * sqlstore.core.hibernate.c3p0.max_size=100
 *    
 * UrjanetProperties is assumed to be a jvm-wide singleton and is initialized lazily on first access.   
 *
 * @author trose
 *
 */

public class UrjanetProperties extends Properties
{
    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(UrjanetProperties.class);
    private static volatile UrjanetProperties s_theInstance = null;
    
    private String          m_deploymentEnv;    
    private Pattern         m_tokenReplacePattern;
    private StackHelper     m_stackHelper;
    private static boolean  s_useConfigService;
    
    // TODO: move default urjanet.properties location to /opt/urjanet_platform/conf
    
    public static final String URJANET_REPOSITORY_PATH = System.getenv("URJA_REPO_PATH");
    
    public static final String URJANET_INSTANCE_CONFIG_DIR = "/opt/urjanet_configuration/trunk";
    public static final String URJANET_INSTANCE_CONFIG_FILE_PATH = "/opt/urjanet_configuration/trunk/urjanet.properties";
    public static final String URJANET_INSTANCE_FALLBACK_CONFIG_FILE_PATH = "/opt/urjanet_configuration/trunk/urjanet.properties.dev";

    // historical synonyms for the env variable
    public static final String DEPLOYMENT_NAME								= "deploymentName";
    public static final String DEPLOYMENT_ENV                               = "env";
    public static final String ENVIRONMENT_NAME                             = "environment.name";
    
    // "legacy" environment names
    public static final String ENV_DEV                                      = "dev";
    public static final String ENV_QATEST                                   = "qatest";
    public static final String ENV_QA                                       = "qa";
    public static final String ENV_INTEGRATION                              = "integration";
    public static final String ENV_STAGING                                  = "staging";
    public static final String ENV_PRODUCTION                               = "prod";
    
    // "new" environment names
    public static final String ENV_LOCAL                                    = "local";
    public static final String ENV_DEV_VPC                                  = "dev";
    public static final String ENV_INT_VPC                                  = "int";
    public static final String ENV_UAT_VPC                                  = "uat";
    public static final String ENV_PRD_VPC                                  = "prd";
    
    
    // toplevel persistence strategies
    public static final String SQLSTORE                                     = "sqlstore";
    public static final String MONGOSTORE                                   = "mongostore";
    
    // jpa persistence unit names
    public static final String STORENAME_CORE                              = "core";
    public static final String STORENAME_EXTRACTION                        = "extraction";
    public static final String STORENAME_DELIVERY                          = "delivery";
    public static final String STORENAME_SOURCES                           = "sources";
    public static final String STORENAME_REPORTING                         = "reporting";
    public static final String STORENAME_DAQ							   = "daq";
    public static final String STORENAME_GIS							   = "gis";
    public static final String STORENAME_PORTAL						       = "portal";
    
    // jpa/hibernate connection and configuration properties (plus our own custom sharding properties)
    public static final String HOST                                        = "host";
    public static final String PORT                                        = "port";
    public static final String URL                                         = "hibernate.connection.url";
    public static final String USER                                        = "hibernate.connection.username";
    public static final String PASSWORD                                    = "hibernate.connection.password";
    public static final String DB										   = "db";
    public static final String SHARDGROUP								   = "shardgroup";
    public static final String SHARDRANGEMIN							   = "rangemin";
    public static final String SHARDRANGEMAX							   = "rangemax";
    public static final String SHARDSCHEMAVERSION						   = "schemaversion";
    public static final String ACTIVESHARD								   = "active";
    public static final String SHARDTEMPLATE							   = "shardTemplate";
    public static final String SHARDID									   = "shardId";
    public static final String NAME										   = "name";
    public static final String REPLICAGROUP								   = "replicagroup";
    public static final String REPLICA								       = "replica";
    public static final String PERSISTENCE_UNIT_OVERRIDE                   = "persistenceUnitOverride";

    // url properties for fixed internal web services
    public static final String SKYLIGHT_BASEURL_INTERNAL				    = "skylight.baseurl.internal";
    public static final String EXTRACTIONCONTROLLER_BASEURL_INTERNAL	    = "extractioncontroller.baseurl.internal";
    public static final String ADMINCONTROLLER_BASEURL_INTERNAL			    = "admincontroller.baseurl.internal";

    // aws cloudformation stackname (behind this container lives lots of SQS, SNS, S3, etc, names and settings)
    // * this is "special" in that the value assigned to this property is used to load a cloudformation stack from aws
    // * we are currently assuming that all-things-Urjanet can sit behind a single cloudformation stack 
    public static final String CLOUDFORMATION_STACKNAME						= "cloudformation.stackname";
    
    // midgard-storage bucket name
    public static final String MIDGARD_STORAGE_BUCKETNAME                   = "midgard.storage.bucket";
    
    public static final String KINESIS_STREAM                               = "kinesis.stream";
    
    public static final String ALLOW_RENDER_ORPHANS                         = "allow.render.orphans";
    
    public static final String TEMPLATE_CLASSLOADER                         = "urjanet.template.classloader";


    // common cloudformation stack properties
    // 
    // *** these are directly tied to the CloudFormation resources that live
    // *** in urjanet_platform/devops/infra/files/cloudformation-template.json
    // *** we need to keep these resources in-sync
    
    public static enum UrjanetCloudFormationProps {

    	// SNS Topic Arn's
        LOGIN_FAILURE_TOPIC_ARN("LoginFailureTopicArn"),
        FILTER_CHANGE_TOPIC_ARN("FilterChangeTopicArn"),
        MIXIN_CHANGE_TOPIC_ARN("MixinChangeTopicArn"),
        ACCOUNT_NOMINATED_TOPIC_ARN("AccountNominatedTopicArn"),
        ACCOUNT_LINKAGE_TOPIC_ARN("AccountLinkageTopicArn"),
        FORM_SUBMISSION_TOPIC_ARN("FormSubmissionTopicArn"),
        FORM_UPDATE_TOPIC_ARN("FormUpdateTopicArn"),
        INPUT_MAP_CHANGE_TOPIC_ARN("CredentialInputMapChangeTopicArn"),
        URJANET_ALERTS_TOPIC_ARN("UrjanetAlertsTopicArn"),
        METER_MIXIN_CHANGE_TOPIC_ARN("MeterMixinChangeTopicArn"),
        METER_LINKAGE_TOPIC_ARN("MeterLinkageTopicArn"),
        ENROLLMENT_STATUS_CHANGE_TOPIC_ARN("EnrollmentStatusChangeTopicArn"),
        CREDENTIAL_STATE_CHANGE_TOPIC_ARN("CredentialStateChangeTopicArn"),
        CREDENTIAL_NAME_CHANGE_TOPIC_ARN("CredentialNameChangeTopicArn"),
        CREDENTIAL_DELETION_TOPIC_ARN("CredentialDeletionTopicArn"),
        MONITORING_STATUS_CHANGE_TOPIC_ARN("MonitoringStatusChangeTopicArn"),
        ACCOUNT_DELIVER_CHANGE_TOPIC_ARN("AccountDeliverChangeTopicArn"),
        ACCOUNT_SUBSCRIBE_CHANGE_TOPIC_ARN("AccountSubscribeChangeTopicArn"),
        SUMMARY_ACCOUNT_DELETION_TOPIC_ARN("SummaryAccountDeletionTopicArn"),
        ACCOUNT_DELETION_TOPIC_ARN("AccountDeletionTopicArn"),
        EBILL_UPDATE_TOPIC_ARN("EbillUpdateTopicArn"),
        
        // SQS Queue Url's
        MASTER_EVENT_LOGGER_QUEUE_URL("MasterEventLoggerQueueUrl"),
        MASTER_EVENT_DEAD_LETTER_QUEUE_URL("MasterEventDeadLetterQueueUrl"),
        ZENDESK_EVENT_QUEUE("ZendeskEventQueueUrl"),
        ZENDESK_DEAD_LETTER_QUEUE_URL("ZendeskDeadLetterQueueUrl"),
        CORE_TO_PORTAL_ETL_QUEUE_URL("CoreToPortalETLQueueUrl"),
        CORE_TO_PORTAL_ETL_DEAD_LETTER_QUEUE_URL("CoreToPortalETLDeadLetterQueueUrl"),
        PORTAL_REPORT_QUEUE_URL("PortalReportQueueUrl"),
        PORTAL_REPORT_DEAD_LETTER_QUEUE_URL("PortalReportDeadLetterQueueUrl"),
        PORTAL_TO_CORE_ETL_QUEUE_URL("PortalToCoreETLQueueUrl"),  // currently unused
        PORTAL_TO_CORE_ETL_DEAD_LETTER_QUEUE_URL("PortalToCoreETLDeadLetterQueueUrl"), // currently unused
      
        // S3 Bucket names
        DAQ_MAILBOX_BUCKET_NAME("DAQMailboxBucketName"),
        PORTAL_ETL_MESSAGE_BUCKET_NAME("PortalETLMessageBucketName"),
        PORTAL_ACTIVATION_FORM_BUCKET_NAME("PortalActivationFormBucketName"),
        PORTAL_REPORT_BUCKET_NAME("PortalReportBucketName");

    	private String keyName; 
    	
    	private UrjanetCloudFormationProps(String keyName) {
    		this.keyName = keyName;
    	}
    	
    	public String getKeyName() {
    		return keyName;
    	}    
    	
    	public UrjanetCloudFormationProps getByName(String eventName) {
    	    for (UrjanetCloudFormationProps prop : UrjanetCloudFormationProps.values()) {
    	        String cleanName = prop.getKeyName().replace("Url", "");
    	        if (StringUtils.equals(eventName, cleanName)) {
    	            return prop;
    	        }
    	    }
    	    
    	    return null;
    	}
    };    
    
    // property value defaults (if no explicit value is set)    
    private static final String DEFAULT_SQL_HOST                            = "localhost";
    private static final String DEFAULT_GIS_HOST                            = "localhost";
    private static final String DEFAULT_SQL_PORT            				= "3306";
    private static final String DEFAULT_GIS_PORT							= "5432";
    private static final String DEFAULT_SQL_USER                            = "urja";
    private static final String DEFAULT_SQL_PASSWORD                        = "r3n3w@bl3";
    
    private static final String DEFAULT_MONGO_HOST							= "localhost";
    private static final String DEFAULT_MONGO_PORT							= "27017";
    private static final String DEFAULT_MONGO_DB							= "core";
    
    private static final String DEFAULT_SKYLIGHT_BASEURL_INTERNAL				= "http://localhost:9002";
    private static final String DEFAULT_EXTRACTIONCONTROLLER_BASEURL_INTERNAL	= "http://localhost:8080";
    private static final String DEFAULT_ADMINCONTROLLER_BASEURL_INTERNAL		= "http://localhost:8081";
    
    
    public static UrjanetProperties get() {
        
        UrjanetProperties props = ensureInitialized(null);
        return props;
    }
    
    public static UrjanetProperties get(String env) {
        
        UrjanetProperties props = ensureInitialized(env);
        return props;        
    }

    private static UrjanetProperties ensureInitialized(String requestedEnv) {
    
        if (s_theInstance == null) {
            
            synchronized (UrjanetProperties.class) {
                
                if (s_theInstance == null) {
                    
                    if (s_useConfigService) {
                        
                        s_theInstance = initFromConfigService();
                        
                    } else {
                        
                        s_theInstance = initFromFilesystem(requestedEnv);
                    }
                }
            }
        }
        
        return s_theInstance;
    }
    
    private static UrjanetProperties initFromFilesystem(String requestedEnv) {
        
        if (StringUtils.isBlank(requestedEnv)) {
            requestedEnv = ENV_DEV;
        }
        return new UrjanetProperties(requestedEnv);        
    }
    
    private static UrjanetProperties initFromConfigService() {
        
        String env = getEnvironmentFromEC2();
        if (StringUtils.isBlank(env)) {
            // not running in ec2?
            env = ENV_LOCAL;
        }
        return new UrjanetProperties(env);
    }
    
    private UrjanetProperties(String env) {
        
        m_deploymentEnv = env;
        m_tokenReplacePattern = Pattern.compile(".*?(\\$[\\{](?:\\w|[-. :])+[\\}])");
        setDefaults();
        load();
    }

    public static void setUseConfigService(boolean useConfigService) {
        
        s_useConfigService = useConfigService;
    }
    
    private void setDefaults() {
        
        super.defaults = new Properties();

        super.defaults.setProperty("deploymentName", ENV_LOCAL);
        
        super.defaults.setProperty("sqlstore.core.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.core.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.core.db", "urja_core");
        super.defaults.setProperty("sqlstore.core.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.core.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.core.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.extraction.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.extraction.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.extraction.db", "urja_extraction");
        super.defaults.setProperty("sqlstore.extraction.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.extraction.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.extraction.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.delivery.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.delivery.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.delivery.db", "urja_delivery");
        super.defaults.setProperty("sqlstore.delivery.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.delivery.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.delivery.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.sources.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.sources.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.sources.db", "urja_sources");
        super.defaults.setProperty("sqlstore.sources.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.sources.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.sources.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.reporting.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.reporting.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.reporting.db", "urja_reporting");
        super.defaults.setProperty("sqlstore.reporting.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.reporting.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.reporting.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.daq.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.daq.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.daq.db", "urja_daq");
        super.defaults.setProperty("sqlstore.daq.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.daq.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.daq.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.gis.host", DEFAULT_GIS_HOST);
        super.defaults.setProperty("sqlstore.gis.port", DEFAULT_GIS_PORT);
        super.defaults.setProperty("sqlstore.gis.db", "biggulp");
        super.defaults.setProperty("sqlstore.gis.hibernate.connection.url", "jdbc:postgresql://${host}:${port}/${db}");
        super.defaults.setProperty("sqlstore.gis.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.gis.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("sqlstore.portal.host", DEFAULT_SQL_HOST);
        super.defaults.setProperty("sqlstore.portal.port", DEFAULT_SQL_PORT);
        super.defaults.setProperty("sqlstore.portal.db", "urja_portal");
        super.defaults.setProperty("sqlstore.portal.hibernate.connection.url", "jdbc:mysql://${host}:${port}/${db}?useUnicode=true&characterEncoding=UTF-8");
        super.defaults.setProperty("sqlstore.portal.hibernate.connection.username", DEFAULT_SQL_USER);
        super.defaults.setProperty("sqlstore.portal.hibernate.connection.password", DEFAULT_SQL_PASSWORD);

        super.defaults.setProperty("mongostore.core.host", DEFAULT_MONGO_HOST);
        super.defaults.setProperty("mongostore.core.port", DEFAULT_MONGO_PORT);
        super.defaults.setProperty("mongostore.core.db", DEFAULT_MONGO_DB);
        
        super.defaults.setProperty("skylight.baseurl.internal", DEFAULT_SKYLIGHT_BASEURL_INTERNAL);
        super.defaults.setProperty("extractioncontroller.baseurl.internal", DEFAULT_EXTRACTIONCONTROLLER_BASEURL_INTERNAL);
        super.defaults.setProperty("admincontroller.baseurl.internal", DEFAULT_ADMINCONTROLLER_BASEURL_INTERNAL);
        
        /*
        super.defaults.setProperty(C3P0_ACQUIRE_INCREMENT, "2");
        super.defaults.setProperty(C3P0_IDLE_TEST_PERIOD, "600");
        super.defaults.setProperty(C3P0_TIMEOUT, "1200");
        super.defaults.setProperty(C3P0_MIN_SIZE, "2");
        super.defaults.setProperty(C3P0_MAX_SIZE, "10");
        super.defaults.setProperty(C3P0_MAX_STATEMENTS, "0");
        super.defaults.setProperty(C3P0_PREFERRED_TEST_QUERY, "select 1;");
        */        
    }

    private void load() 
    {
        // newer apps want to read their config from a centralized configuration server
        // ...
        // we'll make this an either/or proposition, it doesn't make sense to check one and
        // fall back to the other, except when not running in ec2
        
        logger.info("Loading UrjanetProperties - requestedEnv = " + m_deploymentEnv + ", useConfigService = " + s_useConfigService);

        if (s_useConfigService && !ENV_LOCAL.equals(m_deploymentEnv)) {
            
            loadFromConfigService();
            
        } else if (!loadFromPropertyFile()) {
                        
            // consider throwing an exception here if it's not local dev env
            logger.warn("Reverting to default hardcoded properties");
            loadFromDefaults();
        }
        
        resolveProperties(0);
            
        String preloadDeploymentEnv = m_deploymentEnv;
        String postloadDeploymentEnv = determineDeploymentEnvFromProps();

        if (StringUtils.isBlank(postloadDeploymentEnv)) {
            postloadDeploymentEnv = ENV_LOCAL;            
        }
        
        // extra sanity check ... might need to remove this if it causes more trouble than it's worth
        if (!StringUtils.isBlank(preloadDeploymentEnv) && 
            !ENV_LOCAL.equals(preloadDeploymentEnv) &&
            !ENV_DEV.equals(preloadDeploymentEnv) &&
            !preloadDeploymentEnv.equals(postloadDeploymentEnv)) {
            
            throw new UrjanetRuntimeException("Environment mismatch: expected to load config for '" + preloadDeploymentEnv + "' but found '" + postloadDeploymentEnv + "' inside properties");
        }
                        
        m_deploymentEnv = postloadDeploymentEnv;
    
        logger.info("deploymentEnv = " + m_deploymentEnv);
        
        //dumpProperties(this);
    }

    private String determineDeploymentEnvFromProps() {
        
        String env = null;

        env = getProperty(DEPLOYMENT_ENV);
        logger.info(DEPLOYMENT_ENV + " = " + env);
        if (StringUtils.isBlank(env)) {        
            env = getProperty(ENVIRONMENT_NAME);
            logger.info(ENVIRONMENT_NAME + " = " + env);
            if (StringUtils.isBlank(env)) {
                env = getProperty(DEPLOYMENT_NAME);
                logger.info(DEPLOYMENT_NAME + " = " + env);
            }
        }
    
        return env;
    }
    
    public static void dumpProperties(Properties props) {
        
        for (Map.Entry<Object, Object> entry : props.entrySet()) {
            
        	String prop = (String)entry.getKey();
        	String value = (String)entry.getValue();
        	if (prop.contains(PASSWORD))
        		value = "**********";
        	if (prop.startsWith(SQLSTORE) && prop.contains(URL)) {
        		logger.debug("Property " + prop + " = " + value);
        	}
        	else {
        		logger.trace("Property " + prop + " = " + value);
        	}
        }
    }
    
    @Override 
    public String getProperty(String propName) {
        
        String retVal = super.getProperty(propName);
        if (retVal == null) {
            retVal = super.defaults.getProperty(propName);
            if (retVal != null)
                logger.trace("Property " + propName + " using default value of " + retVal);
        }
        return retVal;
    }
    
    @Override
    public String getProperty(String propName, String defaultValue) {
        
        String retVal = super.getProperty(propName);
        if (retVal == null) {
            retVal = defaultValue;
            logger.trace("Property " + propName + " using default value of " + retVal);
        }
        return retVal;
    }
    
    public Integer getIntegerProperty(String propName) {
        
        return Integer.valueOf(getProperty(propName));
    }
    
    public Integer getIntegerProperty(String propName, Integer defaultValue) {
        
        return Integer.valueOf(getProperty(propName, "" + defaultValue));        
    }
        
    public String getCloudFormationProperty(UrjanetCloudFormationProps prop) {

    	return getCloudFormationProperty(prop.getKeyName());
    }
    
    // TODO: could make private b/c it seems like it might be better to enforce compile-time checks
    
    private String getCloudFormationProperty(String prop) {

    	String value = null;
    	
    	ensureStackHelper();
    	
    	if (m_stackHelper != null) {
    		value = m_stackHelper.getValue(prop);    		
    	}
    	
    	return value;    	
    }
    
    private void ensureStackHelper() {
    	
    	if (m_stackHelper == null) {
    		
    		synchronized (UrjanetProperties.class) {
    			
    			if (m_stackHelper == null) {
    				
    				String stackName = getProperty(CLOUDFORMATION_STACKNAME);
    				if (stackName != null) {
    					m_stackHelper = new StackHelper(stackName);
    				}
    			}
    		}
    	}
    }
    
    public static Properties getGroupedProperties(String groupName, Properties props) {
        
    	Properties retProps = new Properties();
    	groupName = groupName.toLowerCase();
    	for (Map.Entry<Object, Object> entry : props.entrySet()) {
    		String propName = ((String)entry.getKey()).toLowerCase();
    		String prefix = groupName + ".";
    		if (propName.startsWith(prefix)) {
    			String fullPropName = (String)entry.getKey();
    			String value = (String)entry.getValue();
    			retProps.setProperty(fullPropName, value);
    			String shortPropName = fullPropName.substring(groupName.length()+1);
    			retProps.setProperty(shortPropName, value);
    		}
    	}
    	return retProps;    
    }
       
    public static void applyOverrides(Properties targetProps, Properties overrides) {
    
    	for (Map.Entry<Object, Object> entry : overrides.entrySet()) {
    		targetProps.setProperty((String)entry.getKey(), (String)entry.getValue());
    	}
    }
    
    public static Set<String> getTopLevelGroupNames(Properties props) {
    
    	HashSet<String> ret = new HashSet<String>();
    	for (Map.Entry<Object, Object> entry : props.entrySet()) {
    		String key = (String)entry.getKey();
    		String groupName;
    		int ix = key.indexOf('.');
    		if (ix != -1) 
    			groupName = key.substring(0, ix);
    		else
    			groupName = key;
    		ret.add(groupName);
    	}
    	
    	return ret;
    }
    
    public static Set<String> getSecondLevelGroupNames(Properties props) {
   
     	HashSet<String> ret = new HashSet<String>();
    	for (Map.Entry<Object, Object> entry : props.entrySet()) {
    		String key = (String)entry.getKey();
    		String groupName;
    		int ix = key.indexOf('.');
    		if (ix != -1) { 
    			groupName = key.substring(ix + 1);
    			ix = groupName.indexOf('.');
    			if (ix != -1) {
    				groupName = groupName.substring(0, ix);
    			} 
    			ret.add(groupName);
    		}
    	}
    	
    	return ret;
    }
    
    public static Properties copy(Properties props) {
    	
    	Properties ret = new Properties();
    	ret.putAll(props);
    	return ret;
    }
    
    public Properties getPersistenceUnitProperties(String persistenceUnitName) {
        
    	Properties jpaProps = getGroupedProperties(SQLSTORE + "." + persistenceUnitName, this);
    	jpaProps.setProperty(NAME, persistenceUnitName);
    	dumpProperties(jpaProps);
    	return jpaProps;
    }
    
    public List<Properties> getAllPersistenceUnitProperties() {
        
    	ArrayList<Properties> ret = new ArrayList<Properties>();
    	HashSet<String> visitedPersistenceUnits = new HashSet<String>();
    	String prefix = SQLSTORE + ".";
    	for (Map.Entry<Object, Object> entry : this.entrySet()) {
    		String propName = ((String)entry.getKey()).toLowerCase();
    		if (propName.startsWith(prefix)) {
    			String puName = propName.substring(prefix.length());
    			puName = puName.substring(0, puName.indexOf('.'));
    			if (!visitedPersistenceUnits.contains(puName)) {
	    			Properties jpaProps = getGroupedProperties(prefix + puName, this);
	    			jpaProps.setProperty(NAME, puName);
	    			ret.add(jpaProps);
	    			visitedPersistenceUnits.add(puName);
    			}
    		}
    	}
    	return ret;
    }
    
    public String getDeploymentName() {
        
        return m_deploymentEnv;
    }
        
    private boolean loadFromPropertyFile() {
        
    	boolean bRet = false;
        String propFilePath = System.getProperty("com.urjanet.propertyFilePath");
        if (propFilePath == null)
        	propFilePath = URJANET_INSTANCE_CONFIG_FILE_PATH;
        
        // try symlinked "urjanet.properties", then "urjanet.properties.envName", finally, "urjanet.properties.dev"
        logger.info("Loading properties from " + propFilePath);
        if (!(bRet = loadFromPropertyFile(propFilePath))) {
        	propFilePath = URJANET_INSTANCE_CONFIG_FILE_PATH + "." + m_deploymentEnv;
        	logger.info("Loading properties from " + propFilePath);
        	if (!(bRet = loadFromPropertyFile(propFilePath))) {
        		propFilePath = URJANET_INSTANCE_FALLBACK_CONFIG_FILE_PATH;
        		logger.info("Loading properties from " + propFilePath);
        		bRet = loadFromPropertyFile(propFilePath);
        	}
        }
        	
        return bRet;
    }
    
    private boolean loadFromPropertyFile(String propFilePath) {
        
        boolean bLoaded = false;
        
        File f = new File(propFilePath);
        if (!f.exists()) {
            logger.error("Property file " + f.getAbsolutePath() + " does not exist");
            return false;
        }

        FileInputStream fis = null;
        
        try {
            
            fis = new FileInputStream(propFilePath);
            Properties propertiesFromFile = new Properties();
            propertiesFromFile.load(fis);
                        
            for (Map.Entry<Object, Object> entry : propertiesFromFile.entrySet()) {
                
                String propName = ((String)entry.getKey()).trim();
                String propValue = ((String)entry.getValue()).trim();

                // fix broken prop files that used wrong db user key
                if (propName.endsWith("hibernate.connection.user")) {
                	propName = propName + "name";
                } 

                super.setProperty(propName, propValue);
                
                logger.trace("added property " + propName + " = " + propValue);
            }
                         
            logger.trace("Loaded properties from '" + propFilePath + "'");
            bLoaded = true;
            
        } catch (Exception e) {
            
            throw new UrjanetRuntimeException("Error loading properties from '" + propFilePath + "'", e);
            
        } finally {
            
            try { fis.close(); } catch (IOException ignore) {}            
        }
        
        return bLoaded;
    }
    
    private void loadFromConfigService() {
        
        int numRetries = 12;
        boolean bLoaded = false;
        
        if (!ENV_DEV_VPC.equals(m_deploymentEnv) && !ENV_INT_VPC.equals(m_deploymentEnv) && !ENV_UAT_VPC.equals(m_deploymentEnv) && !ENV_PRD_VPC.equals(m_deploymentEnv) ) {
            
            throw new UrjanetRuntimeException("Deployment environment must be set and must be one of dev/int/uat/prd");
        }
        
        String urlStr = String.format("https://configserver-%s.urjanetprivate.net/platform/%s/master/urjanet.properties", m_deploymentEnv, m_deploymentEnv);
        logger.info("Config service url: " + urlStr);
        
        // try the config server once every ten seconds, up to 2 minutes, before giving up
        //
        // an error here is fatal, and the application should log an error and fail to start
        
        while (numRetries-- > 0) {
            
            InputStream configStream = null;
            URLConnection configConn = null;
            
            try {
                
                URL url = new URL(urlStr);
                configConn = url.openConnection();
                configStream = configConn.getInputStream();
                byte[] configBytes = IOUtils.toByteArray(configStream);
                
                Properties propertiesFromConfigService = new Properties();
                propertiesFromConfigService.load(new ByteArrayInputStream(configBytes));
                
                for (Map.Entry<Object, Object> entry : propertiesFromConfigService.entrySet())
                {
                    String propName = ((String)entry.getKey()).trim();
                    String propValue = ((String)entry.getValue()).trim();

                    // fix broken prop files that used wrong db user key
                    if (propName.endsWith("hibernate.connection.user")) {
                        propName = propName + "name";
                    } 

                    super.setProperty(propName, propValue);
                    
                    logger.info("added property " + propName + " = " + propValue);
                }
                             
                logger.info("Loaded properties from '" + urlStr + "'");
                bLoaded = true;
                
                break;
                
            } catch (Exception e) {
                
                logger.error("Error loading from configuration service - " + urlStr, e);
                try { Thread.sleep(10000); } catch (Exception ignore) { }
                
            } finally {
                
                IOUtils.closeQuietly(configStream);
                try { 
                    if ((configConn != null) && (configConn instanceof HttpURLConnection)) {
                        ((HttpURLConnection)configConn).disconnect();
                    }
                } catch (Exception ignore) {}
            }
            
            if (!bLoaded) {
                
                throw new UrjanetRuntimeException("Error loading from configuration service - " + urlStr);
            }
        }
    }
    
    private void loadFromDefaults() {
        
        for (Map.Entry<Object, Object> entry : super.defaults.entrySet()) {
            String propName = (String)entry.getKey();
            String propValue = (String)entry.getValue();
            super.setProperty(propName, propValue);
        }
    }
    
    private void resolveProperties(int depth) {
        
        List<String> propsWithMacros = new ArrayList<String>(10);
        int resolvedCount = 0;
        
        for (Map.Entry<Object, Object> entry : this.entrySet()) {
            String propName = (String)entry.getKey();
            String propValue = (String)entry.getValue();

            if (propValue.contains("${"))
            	propsWithMacros.add(propName);
        }
        
		if (depth > 10) {
			StringBuilder sb = new StringBuilder(200);
			for (String propWithMacro : propsWithMacros)
				sb.append(" " + propWithMacro);
			throw new UrjanetRuntimeException("Probable cycle encountered while resolving properties" + sb.toString());
		}
        
        for (String propToResolve : propsWithMacros) {
        	String unresolvedValue = super.getProperty(propToResolve);
        	if (unresolvedValue == null)
        		throw new UrjanetRuntimeException("Unresolved property " + propToResolve);
        	
        	String resolvedValue = resolvePropertyValue(propToResolve, unresolvedValue);
        	super.setProperty(propToResolve, resolvedValue);	
        	if (!resolvedValue.contains("${")) {
        		resolvedCount++;
            	//logger.trace("Resolved " + propToResolve + " to " + resolvedValue);
        	}        	
        }
        
        if (resolvedCount < propsWithMacros.size())
        	resolveProperties(++depth);
    }
                    
	private String resolvePropertyValue(String propToResolve, String unresolvedValue) {
	    
        String retVal = unresolvedValue;
        Matcher matcher = m_tokenReplacePattern.matcher(unresolvedValue);
        boolean bFound = matcher.find();
        if (!bFound)
            return retVal;
        
        do {
            String token = matcher.group(1);
            String name = token.substring(2, token.length()-1);
            
            String operator = null;
            
            String[] operators = name.split(":");
            if (operators.length > 1) {
            	operator = operators[operators.length-1];
            	name = operators[0];
            }
            
            String replacement = super.getProperty(name);

            if (replacement != null) {
                
                if (operator != null && operator.equalsIgnoreCase("uc"))
                	replacement = replacement.toUpperCase();
                else if (operator != null && operator.equalsIgnoreCase("lc"))
                	replacement = replacement.toLowerCase();
            	
                retVal = retVal.replace(token, replacement);
                
            } else {
                
            	throw new UrjanetRuntimeException("Failed to resolve property " + propToResolve + "=" + unresolvedValue);
            }
        }
        while (matcher.find());
        
        return retVal;    			
	}

    /* Returns the environment that this ec2 instance is running in, based on the "environment" instance tag
     * It will return null if not running in AWS
     */
	
	private static String getEnvironmentFromEC2() {
		        
        String env = null;
                
        AmazonEC2 ec2 = null;
        
        try {
                        
            // Populating the value of environment by using tags on the ec2 instance. Is this hacky?
            String instanceId = EC2MetadataUtils.getInstanceId();
            if (instanceId != null) {            
                
                // TODO: use the new builder interface
                
                DefaultAwsRegionProviderChain regionProvider = new DefaultAwsRegionProviderChain();
                String regionName = regionProvider.getRegion();
                logger.debug("ec2Client region: " + regionName);

                ec2 = new AmazonEC2Client();
                ec2.setRegion(Region.getRegion(Regions.fromName(regionName)));

                DescribeInstancesRequest describeInstancesRequest = new DescribeInstancesRequest();
                describeInstancesRequest.setInstanceIds(Arrays.asList(instanceId));
                DescribeInstancesResult result = ec2.describeInstances(describeInstancesRequest);
                for (Reservation reservation: result.getReservations()) {
                    for (Instance i : reservation.getInstances()) {
                        if (i.getInstanceId().equals(instanceId)) {
                            for (Tag tag: i.getTags()) {
                                if (tag.getKey().equalsIgnoreCase("environment")) {
                                    env = tag.getValue();
                                    break;
                                }
                            }
                        }
                    }
               }
                
            } else {
                logger.warn("not running in ec2");
            }
            
        } catch (Exception e) {
            
            logger.error("error describing instance, not running in ec2?", e);
            
        } finally {
            
            if (ec2 != null)
                ec2.shutdown();
        }
        
        logger.debug("ec2 environment tag = " + env);
        
        return env;
	}
	
    public static void main(String[] args) {
        
    	UrjanetProperties urjaProps = UrjanetProperties.get();
    	
    	Properties sqlProps = getGroupedProperties(UrjanetProperties.SQLSTORE, urjaProps);
    	System.out.println("sqlstore property dump...");
    	UrjanetProperties.dumpProperties(sqlProps);
    	
    	Properties mongoProps = getGroupedProperties(UrjanetProperties.MONGOSTORE, urjaProps);
    	System.out.println("mongostore property dump...");
    	UrjanetProperties.dumpProperties(mongoProps);
    	
    	List<Properties> allSqlProps = urjaProps.getAllPersistenceUnitProperties();
    	System.out.println("all persistence units...");
    	for (Properties props : allSqlProps) {
        	System.out.println(".........");
    		UrjanetProperties.dumpProperties(props);
    	}
    }
}
