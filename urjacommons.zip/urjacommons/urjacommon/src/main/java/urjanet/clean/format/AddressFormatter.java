package urjanet.clean.format;

public interface AddressFormatter {

	/**
	 * 
	 * @param value the raw address input string
	 * @return
	 * @throws FormatException
	 */
	public FormatterAddress formatAddress(String value) throws FormatException;
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	public String cleanText(String value);
	
}
