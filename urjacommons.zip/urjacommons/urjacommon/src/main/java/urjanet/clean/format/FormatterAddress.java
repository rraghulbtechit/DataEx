package urjanet.clean.format;

/**
 *
 * @author rburson
 *
 * name, num predir street type postdir, line2, city, state, zip
 */
public class FormatterAddress {

	// Full Address
	private String fullAddress;

	// Address Components
	private String street1;
	private String street2;
	private String street3;
	private String street4;
	private String city;
	private String state;
	private String postal;

	private String country;
	private String province;
	private String region;
	private String locality;
	private String county;

	// Raw Address Lines
	private String addressRaw1;
	private String addressRaw2;
	private String addressRaw3;
	private String addressRaw4;
	private String addressRaw5;
	private String addressRaw6;

	private String addressRecipient1;
	private String addressRecipient2;
	private String addressRecipient3;

	private AddressFormatter formatter;
	
	@Deprecated
	public FormatterAddress() {
	    this(new DefaultFormatter());
	}

	public FormatterAddress(AddressFormatter formatter) {
	    if (formatter == null)
	        formatter = new DefaultFormatter();
	    this.formatter = formatter;
	}
	
	@Deprecated
	public FormatterAddress(String street1, String street2, String street3,
		String street4, String city, String state, String postal) {
	    this.formatter = new DefaultFormatter();
		this.street1 = (street1 != null) ? formatter.cleanText(street1) : null;
		this.street2 = (street2 != null) ? formatter.cleanText(street2) : null;
		this.street3 = (street3 != null) ? formatter.cleanText(street3) : null;
		this.street4 = (street4 != null) ? formatter.cleanText(street4) : null;
		this.city = (city != null) ? formatter.cleanText(city) : null;
		this.state = (state != null) ? formatter.cleanText(state) : null;
		this.postal = (postal != null) ? formatter.cleanText(postal) : null;
	}

    @Deprecated
	public FormatterAddress(String addressRaw1, String addressRaw2, String addressRaw3,
			String addressRaw4, String addressRaw5, String addressRaw6) {
        this.formatter = new DefaultFormatter();
		this.addressRaw1 = (addressRaw1 != null) ? formatter.cleanText(addressRaw1) : null;
		this.addressRaw2 = (addressRaw2 != null) ? formatter.cleanText(addressRaw2) : null;
		this.addressRaw3 = (addressRaw3 != null) ? formatter.cleanText(addressRaw3) : null;
		this.addressRaw4 = (addressRaw4 != null) ? formatter.cleanText(addressRaw4) : null;
		this.addressRaw5 = (addressRaw5 != null) ? formatter.cleanText(addressRaw5) : null;
		this.addressRaw6 = (addressRaw6 != null) ? formatter.cleanText(addressRaw6) : null;
	}

	//
	
	public String getFullAddress() {
		return fullAddress;
	}

	public void setFullAddress(String fullAddress) {
		this.fullAddress = (fullAddress != null) ? formatter.cleanText(fullAddress) : null;
	}

	//
	
	public String getStreet1() {
		return street1;
	}

	public FormatterAddress setStreet1(String street1) {
		this.street1 = (street1 != null) ? formatter.cleanText(street1) : null;
		return this;
	}

	//
	
	public String getStreet2() {
		return street2;
	}

	public FormatterAddress setStreet2(String street2) {
		this.street2 = (street2 != null) ? formatter.cleanText(street2) : null;
		return this;
	}

	//
	
	public String getStreet3() {
		return street3;
	}

	public FormatterAddress setStreet3(String street3) {
		this.street3 = (street3 != null) ? formatter.cleanText(street3) : null;
		return this;
	}

	//
	
	public String getStreet4() {
		return street4;
	}

	public FormatterAddress setStreet4(String street4) {
		this.street4 = (street4 != null) ? formatter.cleanText(street4) : null;
		return this;
	}

	//
	
	public String getCity() {
		return city;
	}

	public FormatterAddress setCity(String city) {
		this.city = (city != null) ? formatter.cleanText(city) : null;
		return this;
	}

	//
	
	public String getState() {
		return state;
	}

	public FormatterAddress setState(String state) {
		this.state = (state != null) ? formatter.cleanText(state) : null;
		return this;
	}

	//
	
	public String getPostal() {
		return postal;
	}

	public FormatterAddress setPostal(String postal) {
		this.postal = (postal != null) ? formatter.cleanText(postal) : null;
		return this;
	}

	//
	
	public String getAddressRaw1() {
		return addressRaw1;
	}

	public FormatterAddress setAddressRaw1(String addressRaw1) {
		this.addressRaw1 = (addressRaw1 != null) ? formatter.cleanText(addressRaw1) : null;
		return this;
	}

	//
	
	public String getAddressRaw2() {
		return addressRaw2;
	}

	public FormatterAddress setAddressRaw2(String addressRaw2) {
		this.addressRaw2 = (addressRaw2 != null) ? formatter.cleanText(addressRaw2) : null;
		return this;
	}

	//
	
	public String getAddressRaw3() {
		return addressRaw3;
	}

	public FormatterAddress setAddressRaw3(String addressRaw3) {
		this.addressRaw3 = (addressRaw3 != null) ? formatter.cleanText(addressRaw3) : null;
		return this;
	}

	//
	
	public String getAddressRaw4() {
		return addressRaw4;
	}

	public FormatterAddress setAddressRaw4(String addressRaw4) {
		this.addressRaw4 = (addressRaw4 != null) ? formatter.cleanText(addressRaw4) : null;
		return this;
	}

	//
	
	public String getAddressRaw5() {
		return addressRaw5;
	}

	public FormatterAddress setAddressRaw5(String addressRaw5) {
		this.addressRaw5 = (addressRaw5 != null) ? formatter.cleanText(addressRaw5) : null;
		return this;
	}

	//
	
	public String getAddressRaw6() {
		return addressRaw6;
	}

	public FormatterAddress setAddressRaw6(String addressRaw6) {
		this.addressRaw6 = (addressRaw6 != null) ? formatter.cleanText(addressRaw6) : null;
		return this;
	}

	//
	
	public String getAddressRecipient1() {
		return addressRecipient1;
	}

	public FormatterAddress setAddressRecipient1(String addressRecipient1) {
		this.addressRecipient1 = (addressRecipient1 != null) ? formatter.cleanText(addressRecipient1) : null;
		return this;
	}

	//
	
	public String getAddressRecipient2() {
		return addressRecipient2;
	}

	public FormatterAddress setAddressRecipient2(String addressRecipient2) {
		this.addressRecipient2 = (addressRecipient2 != null) ? formatter.cleanText(addressRecipient2) : null;
		return this;
	}

	//
	
	public String getAddressRecipient3() {
		return addressRecipient3;
	}

	public FormatterAddress setAddressRecipient3(String addressRecipient3) {
		this.addressRecipient3 = (addressRecipient3 != null) ? formatter.cleanText(addressRecipient3) : null;
		return this;
	}

	//
	
	public String getCountry() {
		return country;
	}

	public FormatterAddress setCountry(String country) {
		this.country = (country != null) ? formatter.cleanText(country) : null;
		return this;
	}

	//
	
	public String getLocality() {
		return locality;
	}

	public FormatterAddress setLocality(String locality) {
		this.locality = (locality != null) ? formatter.cleanText(locality) : null;
		return this;
	}

	//
	
	public String getProvince() {
		return province;
	}

	public FormatterAddress setProvince(String province) {
		this.province = (province != null) ? formatter.cleanText(province) : null;
		return this;
	}

	//
	
	public String getRegion() {
		return region;
	}

	public FormatterAddress setRegion(String region) {
		this.region = (region != null) ? formatter.cleanText(region) : null;
		return this;
	}

	//
	
	public String getCounty() {
		return county;
	}

	public FormatterAddress setCounty(String county) {
		this.county = (county != null) ? formatter.cleanText(county) : null;
		return this;
	}

	//
	
	public void mergeExcludeRaw(FormatterAddress address) {
		mergeRecipient(address.getAddressRecipient1());
		mergeRecipient(address.getAddressRecipient2());
		mergeRecipient(address.getAddressRecipient3());
		mergeStreet(address.getStreet1());
		mergeStreet(address.getStreet2());
		mergeStreet(address.getStreet3());
		mergeStreet(address.getStreet4());

		if (this.getCity() == null || this.getCity().equals("")) this.setCity(address.getCity());
		if (this.getState() == null || this.getState().equals("")) this.setState(address.getState());
		if (this.getPostal() == null || this.getPostal().equals("")) this.setPostal(address.getPostal());

		//TODO AddressKeys do not exist for these yet
		/*if (this.getCountry() == null || this.getCountry().equals("")) this.setCountry(address.getCountry());
		if (this.getProvince() == null || this.getProvince().equals("")) this.setProvince(address.getProvince());
		if (this.getRegion() == null || this.getRegion().equals("")) this.setRegion(address.getRegion());
		if (this.getLocality() == null || this.getLocality().equals("")) this.setLocality(address.getLocality());
		if (this.getCounty() == null || this.getCounty().equals("")) this.setCounty(address.getCounty());*/

		if (this.getFullAddress() == null || this.getFullAddress().equals("")) this.setFullAddress(address.getFullAddress());

	}

	public void merge(FormatterAddress address) {
		mergeExcludeRaw(address);
		mergeRaw(address.getAddressRaw1());
		mergeRaw(address.getAddressRaw2());
		mergeRaw(address.getAddressRaw3());
		mergeRaw(address.getAddressRaw4());
		mergeRaw(address.getAddressRaw5());
		mergeRaw(address.getAddressRaw6());
	}

	public void mergeRaws(FormatterAddress address) {
		mergeRaw(address.getAddressRaw1());
		mergeRaw(address.getAddressRaw2());
		mergeRaw(address.getAddressRaw3());
		mergeRaw(address.getAddressRaw4());
		mergeRaw(address.getAddressRaw5());
		mergeRaw(address.getAddressRaw6());
	}

	public void mergeRecipient(String recipient) {
		if (recipient == null || recipient.equals(""))
			return;

		if (this.getAddressRecipient1() == null) {
			this.setAddressRecipient1(recipient);
		} else if (this.getAddressRecipient2() == null) {
			this.setAddressRecipient2(recipient);
		} else if (this.getAddressRecipient3() == null) {
			this.setAddressRecipient3(recipient);
		}
	}

	public void mergeStreet(String street) {

		if (street == null || street.equals(""))
			return;

		if (this.getStreet1() == null) {
			this.setStreet1(street);
		} else if (this.getStreet2() == null) {
			this.setStreet2(street);
		} else if (this.getStreet3() == null) {
			this.setStreet3(street);
		} else if (this.getStreet4() == null) {
			this.setStreet4(street);
		}
	}

	public void mergeRaw(String raw) {

		if (raw == null || raw.equals(""))
			return;

		if (this.getAddressRaw1() == null) {
			this.setAddressRaw1(raw);
		} else if (this.getAddressRaw2() == null) {
			this.setAddressRaw2(raw);
		} else if (this.getAddressRaw3() == null) {
			this.setAddressRaw3(raw);
		} else if (this.getAddressRaw4() == null) {
			this.setAddressRaw4(raw);
		} else if (this.getAddressRaw5() == null) {
			this.setAddressRaw5(raw);
		} else if (this.getAddressRaw6() == null) {
			this.setAddressRaw6(raw);
		}
	}

	public String getUnformattedComponents() {
		StringBuilder sb = new StringBuilder(64);
		if(getStreet1() != null) sb.append(getStreet1().replaceAll(",", ""));
		if(getStreet2() != null) sb.append(", ").append(getStreet2().replaceAll(",", ""));
		if(getStreet3() != null) sb.append(", ").append(getStreet3().replaceAll(",", ""));
		if(getStreet4() != null) sb.append(", ").append(getStreet4().replaceAll(",", ""));
		if(getCity() != null) sb.append(", ").append(getCity().replaceAll(",", ""));
		if(getState() != null) sb.append(", ").append(getState().replaceAll(",", ""));
		if(getPostal() != null) sb.append(", ").append(getPostal().replaceAll(",", ""));

		return sb.toString();
	}

	public String getUnformattedRawLines() {
		StringBuilder sb = new StringBuilder(64);
		if(getAddressRaw1() != null) sb.append(getAddressRaw1());
		if(getAddressRaw2() != null) sb.append("|").append(getAddressRaw2());
		if(getAddressRaw3() != null) sb.append("|").append(getAddressRaw3());
		if(getAddressRaw4() != null) sb.append("|").append(getAddressRaw4());
		if(getAddressRaw5() != null) sb.append("|").append(getAddressRaw5());
		if(getAddressRaw6() != null) sb.append("|").append(getAddressRaw6());

		return sb.toString();
	}

	@Override
	public String toString() {
		return showComponents("\n");
	}

	public String showComponents(String delimiter) {
		StringBuilder sb = new StringBuilder(64);

		if(getFullAddress() != null) sb.append("Full Address: " + getFullAddress() + delimiter);

		if(getAddressRecipient1() != null) sb.append("Recipient 1: " + getAddressRecipient1() + delimiter);
		if(getAddressRecipient2() != null) sb.append("Recipient 2: " + getAddressRecipient2() + delimiter);
		if(getAddressRecipient3() != null) sb.append("Recipient 3: " + getAddressRecipient3() + delimiter);

		if(getStreet1() != null) sb.append("Street 1: " + getStreet1() + delimiter);
		if(getStreet2() != null) sb.append("Street 2: " + getStreet2() + delimiter);
		if(getStreet3() != null) sb.append("Street 3: " + getStreet3() + delimiter);
		if(getStreet4() != null) sb.append("Street 4: " + getStreet4() + delimiter);

		if(getCity() != null) sb.append("City: " + getCity() + delimiter);
		if(getState() != null) sb.append("State: " + getState() + delimiter);
		if(getPostal() != null) sb.append("Zip: " + getPostal() + delimiter);

		return sb.toString().replaceFirst(delimiter + "$", "");
	}

	public String buildFullAddress() {
		StringBuilder sb = new StringBuilder(64);

		if(getAddressRecipient1() != null) sb.append(getAddressRecipient1() + ", ");
		if(getAddressRecipient2() != null) sb.append(getAddressRecipient2() + ", ");
		if(getAddressRecipient3() != null) sb.append(getAddressRecipient3() + ", ");

		if(getFullAddress() != null) sb.append(getFullAddress() + ", ");

		if(getStreet1() != null) sb.append(getStreet1() + ", ");
		if(getStreet2() != null) sb.append(getStreet2() + ", ");
		if(getStreet3() != null) sb.append(getStreet3() + ", ");
		if(getStreet4() != null) sb.append(getStreet4() + ", ");

		if(getAddressRaw1() != null) sb.append(getAddressRaw1() + ", ");
		if(getAddressRaw2() != null) sb.append(getAddressRaw2() + ", ");
		if(getAddressRaw3() != null) sb.append(getAddressRaw3() + ", ");
		if(getAddressRaw4() != null) sb.append(getAddressRaw4() + ", ");
		if(getAddressRaw5() != null) sb.append(getAddressRaw5() + ", ");
		if(getAddressRaw6() != null) sb.append(getAddressRaw6() + ", ");

		if(getCity() != null) sb.append(getCity() + ", ");
		if(getState() != null) sb.append(getState() + ", ");
		if(getPostal() != null) sb.append(getPostal() + ", ");

		return sb.toString().replaceFirst(",\\s+$", "").trim();
	}

}
