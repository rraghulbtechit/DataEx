package urjanet.clean.format;

public interface StringFormatter {

	/**
	 * 
	 * @param value the input string to format.
	 * @return
	 */
	public String formatText(String value);
	
}
