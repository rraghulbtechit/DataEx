package urjanet.clean.format;

import java.math.BigDecimal;
import java.nio.charset.Charset;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;

public abstract class BaseNumberFormatter extends BaseFormatter implements NumberFormatter {

	protected BaseNumberFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String formatPhoneNumber(String value) throws FormatException {
		
		return clean(value);
	}
	
	@Override
	public BigDecimal formatCurrency(String value, String formatHint) throws FormatException {
		
		value = clean(value);
		
		boolean isCredit = false;

		// Add negative sign in front for credit values
		if (value.indexOf("CR") != -1 || value.indexOf("cr") != -1 || value.indexOf("-") != -1 || value.indexOf("−") != -1
			|| (value.startsWith("(") && value.endsWith(")"))) {
			value = value.replace(')', ' ');
			value = value.replace('(', ' ');
			isCredit = true;
		}

		// if all the characters are non-numeric
		value = value.replaceAll("[^(,\\.0-9)]", "");
		if (value.isEmpty()) {
			throw new FormatException("Unable to format currency: " + value);
		}

		/**
		 * Following 4 lines of code are made for CLECO Template.
		 * Incase the chargeAmount is a Credit value and hence negative, and the ChargeRate is positive, The error occurs
		 * [SystemEvent: WARNING]----------------------------------------------
		   AuditEventCode.AuditEventCode{auditName=chrg.chargeComponent}
		   EntityId: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   EntityType: urjanet.ChargeItem
		   Qualifier: [ChargeItem]
		   chargeAmount: -441.60
		   averageUnitCost: null
		   chargeActualName: CONSTRUCTION FINANCING CREDIT
		   numberOfDaysInPeriod: null
		   chargeUnitsUsed: 44160
		   chargeRate: 0.01
		   chargeRateBase: null
		   chargeRateAdder: null
		   unitsPerRate: null
		   additionalRateMultiplier: null
		   tariffCharge: [TariffCharge id='cc512bd9-de01-11e0-82fb-0019d1a73d13'/]
		   measurementPeriod: [TimeInterval id='cc63c8f1-de01-11e0-82fb-0019d1a73d13'/]
		   usageUnit: [UsageUnit id='cc5152ef-de01-11e0-82fb-0019d1a73d13' name='kWh'
		   measurementType: [MeasurementType id='cc512bda-de01-11e0-82fb-0019d1a73d13' name='general_consumption'/]
		   chargeAmountCurrency: [Currency id='cc501a58-de01-11e0-82fb-0019d1a73d13' name='currency_dollars'/]
		   chargeRateCurrency: [Currency id='cc501a58-de01-11e0-82fb-0019d1a73d13' name='currency_dollars'/]
		   statementComponents: [ArrayList size=1/]
		   usageItems: [ArrayList size=0/]
		   childChargeItems: [ArrayList size=0/]
		   parentChargeItem: null
		   name: null
		   id: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   uuid: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   naturalId: null
		   version: null
		   created: Tue Sep 13 17:43:32 IST 2011
		   customFieldValueSet: null
		   sourceNodes: [ArrayList size=0/]
		   [/ChargeItem]
		 * If we set formatting hint as "CR" or "cr" for the charge rate.  It will add up a minus sign preceding
		 * to the chargeRate by setting isCredit property as true.
		*/
		if(formatHint != null){
			if(formatHint.indexOf("CR") != -1 || formatHint.indexOf("cr") != -1)
				isCredit = true;
		}

		if (formatHint != null) {
			try {
				value = applyFormatHintToNumber(value, formatHint);
			} catch (NumberFormatException ex) {
				throw new FormatException("Unable to format currency: " + value);
			}
		}

		if (isCredit) {
			value = "-" + value;
		}

		return formatDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_DOLLAR_P, ""));
	}
	
	/**
	 * 
	 * @param value
	 * @param formatHint
	 * @return
	 */
	protected String applyFormatHintToNumber(String value, String formatHint) {

		if (value.indexOf(Expressions.getInstance().PERIOD) != -1) {
			// there's already a decimal place in the value
			return value;
		}

		String result = "";
		char[] matcher = formatHint.toCharArray();
		char[] values = value.toCharArray();
		int i = matcher.length - 1, j = value.length() - 1;
		for (; j >= 0;) {
			if (i >= 0) {
				switch (matcher[i]) {
					case 'n':
						if ((values[j] + "").matches("\\d")) {
							result = values[j] + result;
							j--;
						}
						i--;
						break;
					case '.':
						result = '.' + result;
						if (values[j] == matcher[i] || values[j] == ' ') {
							j--;
						}
						i--;
						break;
					case ',':
						result = ',' + result;
						if (values[j] == matcher[i] || values[j] == ' ') {
							j--;
						}
						i--;
						break;
					default:
						if (matcher[i] != values[j]) {
							result = values[j] + result;
							j--;
						}
						i--;
						break;
				}
			} else {
				result = values[j] + result;
				j--;
			}
		}

		if (i == 0) {
			result = matcher[i] + result;
		}

		return result;
	}
	
}
