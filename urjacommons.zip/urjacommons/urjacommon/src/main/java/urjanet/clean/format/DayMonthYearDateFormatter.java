package urjanet.clean.format;

import java.nio.charset.Charset;
import java.util.Date;

import org.pojava.datetime.DateTime;
import org.pojava.datetime.DateTimeConfig;

public class DayMonthYearDateFormatter extends BaseDateFormatter {

	public DayMonthYearDateFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String getDefaultDateFormatHint() {
		return "dd/MM/yyyy";
	}

	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {

		DateTime dt = new DateTime();
		try {
			DateTimeConfig.SUPPORTED_LANGUAGES.clear();
			DateTimeConfig.SUPPORTED_LANGUAGES.add("ES");
			DateTimeConfig.SUPPORTED_LANGUAGES.add("FR");
			DateTimeConfig.SUPPORTED_LANGUAGES.add("DE");
			DateTimeConfig.globalEuropeanDateFormat();
			dt = new DateTime(value);

		} catch (Exception ee) {
			throw new FormatException("Couldn't format date: " + value + " " + " with formatHint: " + formatHint, ee);
		}

		return dt.toDate();
	}

}
