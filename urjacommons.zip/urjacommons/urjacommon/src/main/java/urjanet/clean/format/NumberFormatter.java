package urjanet.clean.format;

import java.math.BigDecimal;

public interface NumberFormatter {

	/**
	 * 
	 * @param value the input string
	 * @return
	 * @throws FormatException
	 */
	public BigDecimal formatDecimal(String value) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @param formatHint the format hint to format the input string
	 * @return
	 * @throws FormatException
	 */
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @param precision the decimal precision value to format the input string
	 * @return
	 * @throws FormatException
	 */
	public BigDecimal formatDecimal(String value, int precision) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @return
	 * @throws FormatException
	 */
	public int formatInteger(String value) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @return
	 * @throws FormatException
	 */
	public String formatPhoneNumber(String value) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @param formatHint the format hint to format the input string
	 * @return
	 * @throws FormatException
	 */
	public BigDecimal formatCurrency(String value, String formatHint) throws FormatException;
	
}
