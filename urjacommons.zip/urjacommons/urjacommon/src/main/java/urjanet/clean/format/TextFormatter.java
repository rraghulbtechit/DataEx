package urjanet.clean.format;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rburson
 */
public class TextFormatter {

	public static String emptyStringIfNull(String target){
		return (target == null) ? "" : target;
	}

	public static String addTrailingSpaceIfNotNull(String target){
		return (target == null) ? "" : target.concat(" ");
	}

	public static String wordCharsOnly(String inputString){

		if(inputString == null) return null;
		return inputString.replaceAll("\\W", "");

	}
	/**
	 * Input - List of String
	 * Method to normalize the strings contained in the list
	 * @param inputString
	 * @return
	 */
	public static List<String> wordCharsOnlyInList(List<String> inputString){

		if(inputString == null) return null;
		List<String> normalizedStringList = new ArrayList<String>();
		for(String s : inputString) {
			normalizedStringList.add(s.replaceAll("\\W", ""));
		}
		
		return normalizedStringList;

	}
}
