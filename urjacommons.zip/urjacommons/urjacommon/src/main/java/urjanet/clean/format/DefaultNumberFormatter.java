package urjanet.clean.format;

import java.math.BigDecimal;
import java.math.MathContext;
import java.nio.charset.Charset;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;

public final class DefaultNumberFormatter extends BaseNumberFormatter {

	public DefaultNumberFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public BigDecimal formatDecimal(String value) throws FormatException {
		
		value = FormatterUtils.formatCreditValue(clean(value));
		try {

			return new BigDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, ""), new MathContext(FormatterUtils.DECIMAL_PRECISION, FormatterUtils.DECIMAL_ROUNDING_MODE)).setScale(FormatterUtils.DECIMAL_SCALE, FormatterUtils.DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}
	}
	
	@Override
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException {
		
		value = FormatterUtils.formatCreditValue(clean(value));
		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, "");
			if (formatHint != null) {
				cleanValue = applyFormatHintToNumber(cleanValue, formatHint);
			}
			return new BigDecimal(cleanValue, new MathContext(FormatterUtils.DECIMAL_PRECISION, FormatterUtils.DECIMAL_ROUNDING_MODE)).setScale(FormatterUtils.DECIMAL_SCALE, FormatterUtils.DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}
	}
	
	@Override
	public BigDecimal formatDecimal(String value, int precision) throws FormatException {
	
		value = FormatterUtils.formatCreditValue(clean(value));
		try {
			return new BigDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, ""), new MathContext(precision));
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}
	}
	
	@Override
	public int formatInteger(String value) throws FormatException {
		
		value = clean(value);
		try {
			return new Double(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, "")).intValue();
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as integer", e);
		}
	}

}
