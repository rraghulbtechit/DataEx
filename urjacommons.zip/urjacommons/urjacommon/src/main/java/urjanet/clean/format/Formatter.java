package urjanet.clean.format;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

/**
 * Extraction data-value formatting interface
 */

public abstract class Formatter implements DateFormatter, NumberFormatter, AddressFormatter, StringFormatter {
	
	/*
	 * These correspond to our database's scale and precision values (and behavior) for decimals
	 */
	protected static final int DECIMAL_SCALE = 10;
	protected static final int DECIMAL_PRECISION = 29;
	protected static final RoundingMode DECIMAL_ROUNDING_MODE = RoundingMode.HALF_UP;
	
	protected boolean stripNonLatin1 = true;
	
	public Date formatDate(String value, String formatHint) throws FormatException {
		
		value = cleanDate(value);
		return formatDateImpl(value, formatHint);
	}
	
	public FormatterAddress formatAddress(String value) throws FormatException {
	
		value = cleanAddress(value);
		return formatAddressImpl(value);
	}
	
	public BigDecimal formatDecimal(String value) throws FormatException {
		
		value = formatCreditValue(cleanDecimal(value));
		return formatDecimalImpl(value);
	}
	
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException {
		
		value = formatCreditValue(cleanDecimal(value));
		return formatDecimalImpl(value, formatHint);
	}
	
	public BigDecimal formatDecimal(String value, int precision) throws FormatException {
	
		value = formatCreditValue(cleanDecimal(value));
		return formatDecimalImpl(value, precision);
	}
	
	public int formatInteger(String value) throws FormatException {
		
		value = cleanInteger(value);
		return formatIntegerImpl(value);
	}
	
	public String formatPhoneNumber(String value) throws FormatException {
		
		value = cleanPhoneNumber(value);
		return formatPhoneNumberImpl(value);
	}
	
	public BigDecimal formatCurrency(String value, String formatHint) throws FormatException {
		
		value = cleanCurrency(value);
		return formatCurrencyImpl(value, formatHint);
	}
	
	public String formatText(String value) {
		
		value = cleanText(value);
		return formatTextImpl(value);
	}
	
	public FormatterMeasurementPeriod formatMeasurementPeriod(String value, String formatHint) throws FormatException {
		
		value = cleanMeasurementPeriod(value);
		return formatMeasurementPeriodImpl(value, formatHint);
	}
	
	// implementations provided by subclass
	protected abstract Date formatDateImpl(String value, String formatHint) throws FormatException;
	protected abstract FormatterAddress formatAddressImpl(String value) throws FormatException;
	protected abstract BigDecimal formatDecimalImpl(String value) throws FormatException;
	protected abstract BigDecimal formatDecimalImpl(String value, String formatHint) throws FormatException;
	protected abstract BigDecimal formatDecimalImpl(String value, int precision) throws FormatException;
	protected abstract int formatIntegerImpl(String value) throws FormatException;
	protected abstract String formatPhoneNumberImpl(String value) throws FormatException;
	protected abstract BigDecimal formatCurrencyImpl(String value, String formatHint) throws FormatException;
	protected abstract String formatTextImpl(String value);
	protected abstract FormatterMeasurementPeriod formatMeasurementPeriodImpl(String value, String formatHint) throws FormatException;
	
	/*protected abstract String getDefaultDateFormatHint();
	protected abstract String getShortMonthAbbreviation(String month);
	protected abstract String getShortDayAbbreviation(String day);*/
	
	// default utility methods - override if necessary
	protected String cleanDate(String value) {
		
		return clean(value, stripNonLatin1);
	}
			
	protected String cleanAddress(String value) {
		
		return clean(value, stripNonLatin1);
	}
	
	protected String cleanDecimal(String value) {
	    
		return clean(value, stripNonLatin1);
	}
	
	protected String cleanInteger(String value) {
		
		return clean(value, stripNonLatin1);
	}
	
	protected String cleanPhoneNumber(String value) {
		
		return clean(value, stripNonLatin1);
	}
	
	protected String cleanCurrency(String value) {
		
		return clean(value, stripNonLatin1);
	}
	
	public String cleanText(String value) {
		
		return clean(value, stripNonLatin1);
	}
	
	protected String cleanMeasurementPeriod(String value) {
		
		return clean(value, stripNonLatin1);
	}
			
	@Deprecated
	public static String clean(String value) {
	    
	    return clean(value, true);
	}
	
	public static String clean(String value, boolean stripNonLatin1) {
		return FormatterUtils.clean(value, stripNonLatin1);
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	protected String formatCreditValue(String value) {
		return FormatterUtils.formatCreditValue(value);
	}
	
	public static String removeNonprintableLatin1(String value) {
		return FormatterUtils.removeNonprintableLatin1(value);
	}
	
	// java regex "\s" doesn't correctly deal with unicode whitespace
	public static String normalizeWhitespace(String value) {
		return FormatterUtils.normalizeWhitespace(value);
	}

	public static String normalizeMinus(String value) {
		return FormatterUtils.normalizeMinus(value);
	}
	
	public static String normalizeSeparators(String value) {
		return FormatterUtils.normalizeSeparators(value);
	}
		
}
