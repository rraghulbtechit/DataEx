package urjanet.clean.format;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.pojava.datetime.DateTime;
import org.pojava.datetime.DateTimeConfig;

/*
 * This is the "Indian" format conventions for IND English extractions which follows European format in Date and US format in currency.
 * So re-used already existing European Formatter here for parsing Date.It will be aligned and corrected properly while Code Refactoring in future.
 * Note : Formatter added only for Date as of now.
 * 
 */
public class IndianFormatter extends DefaultFormatter {	
	
	IndianFormatter() {
	}
	
	@Override
	public Date formatDate(String value, String formatHint) throws FormatException {
		
		if (value == null || value.isEmpty()) {
			throw new FormatException("Couldn't format date: " + value + " " + " with formatHint: " + formatHint);
		}

		value = cleanText(value);

		if (formatHint != null) {
			try {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat(formatHint);
					sdf.setLenient(false);
					return sdf.parse(value);
				} catch (ParseException pe) {
					// Attempt to format the date as a leap year, to handle "02/29"
					// date. Final date created will be "02/29/1968", which is the
					// last leap year prior to 1970.
					SimpleDateFormat sdf = new SimpleDateFormat(formatHint + " yyyy");
					sdf.setLenient(false);
					// set to first leap year prior to 1970 (which is considered an empty year)
					return sdf.parse(value + " 1968");
				}

			} catch (Exception e) {

				/*
				 *  Try the date formatting without a format hint.
				 *  If this fails then only raise exception.
				 */
				DateTime dt = new DateTime();
				try {
					DateTimeConfig.SUPPORTED_LANGUAGES.clear();
					DateTimeConfig.SUPPORTED_LANGUAGES.add("EN");					
					DateTimeConfig.globalEuropeanDateFormat();
					dt = new DateTime(value);

				} catch (Exception ee) {
					throw new FormatException("Couldn't format date: " + value + " " + " with formatHint: " + formatHint, ee);
				}

				return dt.toDate();
			}

		} else {

			DateTime dt = new DateTime();
			try {
				//Configure this for the IND only, for now, for efficiency's sake
				DateTimeConfig.SUPPORTED_LANGUAGES.clear();				
				DateTimeConfig.SUPPORTED_LANGUAGES.add("EN");
				DateTimeConfig.globalEuropeanDateFormat();
				dt = new DateTime(value);

			} catch (IllegalArgumentException e) {
				throw new FormatException("Couldn't format date: " + value, e);
			}

			return dt.toDate();
		}
	}	

}


