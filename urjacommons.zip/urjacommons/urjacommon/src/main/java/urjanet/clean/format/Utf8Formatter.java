package urjanet.clean.format;

public class Utf8Formatter extends DefaultFormatter {
    
    public Utf8Formatter() {
        
        stripNonLatin1 = false;
    }

}
