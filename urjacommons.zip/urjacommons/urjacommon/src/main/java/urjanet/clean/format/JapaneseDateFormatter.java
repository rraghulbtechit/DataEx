package urjanet.clean.format;

import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class JapaneseDateFormatter extends BaseDateFormatter {
	
	private final Locale locale = new Locale("ja", "JP", "JP");

	protected JapaneseDateFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String getDefaultDateFormatHint() {
		return "yyyy/MM/dd";
	}

	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {
		
		try {
			DateFormat df = DateFormat.getDateInstance(DateFormat.FULL, locale);
			return df.parse(value);
		} catch(ParseException p1) {

			//This is a format that we've seen in certain bills that we'd like to add for japanese
			//noted by Wikipedia as the most common format:
			//https://en.wikipedia.org/wiki/Date_and_time_notation_in_Japan
			//The most commonly used date format in Japan is "year month day (weekday)", 
			//with the Japanese characters meaning "year", "month" and "day" inserted after the numerals. Example: 2008年12月31日
			SimpleDateFormat jpYearMonthDay = new SimpleDateFormat("yyyy年MM月dd日");
			jpYearMonthDay.setLenient(false);
			
			try {
				return jpYearMonthDay.parse(value);
			} catch (ParseException p2) {
				SimpleDateFormat sf = new SimpleDateFormat(getDefaultDateFormatHint());
				sf.setLenient(false);
				try {
					return sf.parse(value);
				} catch (ParseException p3) {
					throw new FormatException("Couldn't format date: " + value + " with formatHint: " + formatHint);
				}
			}
		}
	}

	public static void main(String[] args) throws FormatException, ParseException {
		
		String val = "平成29年 5月31日";
		DateFormatter format = new JapaneseDateFormatter(Charset.forName("UTF-8"), new FormatterLocale(Language.JAPANESE, Country.JAPAN));
		Date d = format.formatDate(val, null);
		System.out.println(d.toString());

		System.out.println(format.formatDate("2013年11月24日", null));
		
		
		System.out.println(format.formatDate("05/23/2017", null));
	}
}
