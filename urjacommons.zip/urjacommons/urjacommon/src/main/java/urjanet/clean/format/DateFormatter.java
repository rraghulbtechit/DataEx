package urjanet.clean.format;

import java.util.Date;

public interface DateFormatter {

	/**
	 * 
	 * @param value the input string
	 * @param formatHint the format hint to format the input string.
	 * @return
	 * @throws FormatException
	 */
	public Date formatDate(String value, String formatHint) throws FormatException;
	
	/**
	 * 
	 * @param value the input string
	 * @param formatHint the format hint to format the input string.
	 * @return
	 * @throws FormatException
	 */
	public FormatterMeasurementPeriod formatMeasurementPeriod(String value, String formatHint) throws FormatException;
	
	/**
	 * 
	 * @return the default date format
	 */
	public String getDefaultDateFormatHint();
	
	/**
	 * 
	 * @param month
	 * @return
	 */
	public String getShortMonthAbbreviation(String month);
	
	/**
	 * 
	 * @param day
	 * @return
	 */
	public String getShortDayAbbreviation(String day);
	
}
