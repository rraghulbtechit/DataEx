package urjanet.clean.format;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import net.sourceforge.jgeocoder.AddressComponent;
import net.sourceforge.jgeocoder.us.AddressParser;
import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;
import urjanet.util.ObjectUtils;

public final class UnitedStatesAddressFormatter extends BaseFormatter implements AddressFormatter {

	private static final Map<String, String> STATE_CODE_MAP = new HashMap<String, String>();
	static {
		STATE_CODE_MAP.put("ALABAMA", "AL");
		STATE_CODE_MAP.put("ALASKA", "AK");
		STATE_CODE_MAP.put("AMERICAN SAMOA", "AS");
		STATE_CODE_MAP.put("ARIZONA", "AZ");
		STATE_CODE_MAP.put("ARKANSAS", "AR");
		STATE_CODE_MAP.put("CALIFORNIA", "CA");
		STATE_CODE_MAP.put("COLORADO", "CO");
		STATE_CODE_MAP.put("CONNECTICUT", "CT");
		STATE_CODE_MAP.put("DELAWARE", "DE");
		STATE_CODE_MAP.put("DISTRICT OF COLUMBIA", "DC");
		STATE_CODE_MAP.put("FEDERATED STATES OF MICRONESIA", "FM");
		STATE_CODE_MAP.put("FLORIDA", "FL");
		STATE_CODE_MAP.put("GEORGIA", "GA");
		STATE_CODE_MAP.put("GUAM", "GU");
		STATE_CODE_MAP.put("HAWAII", "HI");
		STATE_CODE_MAP.put("IDAHO", "ID");
		STATE_CODE_MAP.put("ILLINOIS", "IL");
		STATE_CODE_MAP.put("INDIANA", "IN");
		STATE_CODE_MAP.put("IOWA", "IA");
		STATE_CODE_MAP.put("KANSAS", "KS");
		STATE_CODE_MAP.put("KENTUCKY", "KY");
		STATE_CODE_MAP.put("LOUISIANA", "LA");
		STATE_CODE_MAP.put("MAINE", "ME");
		STATE_CODE_MAP.put("MARSHALL IS", "MH");
		STATE_CODE_MAP.put("MARSHALL ISLANDS", "MH");
		STATE_CODE_MAP.put("MARYLAND", "MD");
		STATE_CODE_MAP.put("MASSACHUSETTS", "MA");
		STATE_CODE_MAP.put("MICHIGAN", "MI");
		STATE_CODE_MAP.put("MINNESOTA", "MN");
		STATE_CODE_MAP.put("MISSISSIPPI", "MS");
		STATE_CODE_MAP.put("MISSOURI", "MO");
		STATE_CODE_MAP.put("MONTANA", "MT");
		STATE_CODE_MAP.put("NEBRASKA", "NE");
		STATE_CODE_MAP.put("NEVADA", "NV");
		STATE_CODE_MAP.put("NEW HAMPSHIRE", "NH");
		STATE_CODE_MAP.put("NEW JERSEY", "NJ");
		STATE_CODE_MAP.put("NEW MEXICO", "NM");
		STATE_CODE_MAP.put("NEW YORK", "NY");
		STATE_CODE_MAP.put("NEWJERSEY", "NJ");
		STATE_CODE_MAP.put("NEWMEXICO", "NM");
		STATE_CODE_MAP.put("NEWYORK", "NY");
		STATE_CODE_MAP.put("NORTHERN MARIANA ISLANDS", "MP");
		STATE_CODE_MAP.put("NORTH CAROLINA", "NC");
		STATE_CODE_MAP.put("NORTH DAKOTA", "ND");
		STATE_CODE_MAP.put("N CAROLINA", "NC");
		STATE_CODE_MAP.put("N DAKOTA", "ND");
		STATE_CODE_MAP.put("OHIO", "OH");
		STATE_CODE_MAP.put("OKLAHOMA", "OK");
		STATE_CODE_MAP.put("OREGON", "OR");
		STATE_CODE_MAP.put("PALAU", "PW");
		STATE_CODE_MAP.put("PENNSYLVANIA", "PA");
		STATE_CODE_MAP.put("PUERTO RICO", "PR");
		STATE_CODE_MAP.put("PUERTORICO", "PR");
		STATE_CODE_MAP.put("RHODE ISLAND", "RI");
		STATE_CODE_MAP.put("SOUTH CAROLINA", "SC");
		STATE_CODE_MAP.put("SOUTH DAKOTA", "SD");
		STATE_CODE_MAP.put("S CAROLINA", "SC");
		STATE_CODE_MAP.put("S DAKOTA", "SD");
		STATE_CODE_MAP.put("TENNESSEE", "TN");
		STATE_CODE_MAP.put("TEXAS", "TX");
		STATE_CODE_MAP.put("UTAH", "UT");
		STATE_CODE_MAP.put("VERMONT", "VT");
		STATE_CODE_MAP.put("VIRGIN IS", "VI");
		STATE_CODE_MAP.put("VIRGIN ISLANDS", "VI");
		STATE_CODE_MAP.put("VIRGINIA", "VA");
		STATE_CODE_MAP.put("WASHINGTON", "WA");
		STATE_CODE_MAP.put("WEST VIRGINIA", "WV");
		STATE_CODE_MAP.put("W VIRGINIA", "WV");
		STATE_CODE_MAP.put("WISCONSIN", "WI");
		STATE_CODE_MAP.put("WYOMING", "WY");
	}
	
	private static final String defaultStreet = "123 DEFAULTSUBSTITUTE ST";
	private static final Pattern STATES = Pattern.compile(getStateRegex());
	
	public UnitedStatesAddressFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String cleanText(String value) {
		return clean(value);
	}
	
	@Override
	public FormatterAddress formatAddress(String value) throws FormatException {

		value = clean(value);

		if (value == null || value.length() < 1) {
			throw new FormatException("Couldn't format empty String as address.");
		}

		final FormatterAddress fa = new FormatterAddress(this);

		// basic cleaning
		value = clean(value);

		// fix missing spaces after commas
		value = RegExHandler.replaceAll(value, Expressions.getInstance().COMMA_NOCAP_NO_SPACE_P, ", ");

		if (!value.isEmpty()) {

			// Skip one part at a time until we've reached the end or we get a
			// geo coded address
			String[] values = value.split("\\|");
			String newValue = "";

			LinkedHashMap<Integer, String> recipients = new LinkedHashMap<Integer, String>();
			Stack<String> streets = new Stack<String>();

			// This removes known components which the address parser does not
			// handle (eg. "PO Box 5625")
			// It re-adds them later after the parser is finished
			// These components must exist as separate strings in the array
			// 'values' to be removed
			int embeddedIndex;
			for (int i = 0; i < values.length; i++) {
				String tempValue = values[i];
				if (isRecipient(tempValue)) {
					recipients.put(new Integer(i), tempValue);
				}
				// Searches for street fields unhandled by the address parses
				// that exist within a larger line
				// Splits the line into multiple strings within 'values', and
				// restarts the loop so the components may be handled by the
				// lines above
				else if ((embeddedIndex = getEmbeddedStreetIndex(tempValue)) != -1) {
					values = splitOnIndex(embeddedIndex, values, i);

					i = -1;
					streets.clear();
					recipients.clear();
				} else if (isStreet(tempValue)) {
					streets.add(tempValue);
				}
			}

			// This function removes the recipients and streets which the parser
			// cannot handle
			if (!recipients.isEmpty() || !streets.isEmpty()) {
				String[] newValues = new String[values.length - recipients.size()];

				int newValuesIndex = 0;

				for (int i = 0; i < values.length; i++) {
					if (!recipients.keySet().contains(new Integer(i))) {
						if (streets.contains(values[i]))
							newValues[newValuesIndex++] = defaultStreet;
						else
							newValues[newValuesIndex++] = values[i];
					}
				}
				values = newValues;
			}

			/**
			 * These are the components which need to be parsed correctly from
			 * the begining This is based off of the assumption that the city,
			 * state, zip are the bottom line It is also based off the
			 * observation that once a name has been parsed, most of the other
			 * pieces will have been parsed since we parse from the bottom up
			 */
			AddressComponent[] keyComponents = { AddressComponent.CITY, AddressComponent.STATE, AddressComponent.ZIP,
					AddressComponent.NAME };
			Map<AddressComponent, String> addrGeo = null;
			Map<AddressComponent, String> tempAddress = null;
			int parsedLineIndex = 0;

			/**
			 * This loop parses the address from the bottom line up It takes the
			 * combination of lines which the parser was able to extract the
			 * most information out of
			 */
			ParseAddressLines: for (int i = values.length - 1; i >= 0; i--) {

				if (i == values.length - 1)
					newValue = checkForLongZip(values[i]);
				else
					newValue = values[i] + ", " + newValue;

				try {

					/**
					 * IMPORTANT: This parser requires a State or a Zip Code! IT
					 * WILL NOT WORK JUST ON A STREET
					 */
					tempAddress = AddressParser.parseAddress(newValue, true);

					/**
					 * Now normalize it
					 */
					Map<AddressComponent, String> normalizedAddr = AddressStandardizer
							.normalizeParsedAddress(tempAddress);
					tempAddress = normalizedAddr;

					String city = tempAddress.get(AddressComponent.CITY);
					if (city != null && tempAddress.get(AddressComponent.STATE) == null
							&& STATES.matcher(city.toUpperCase()).matches()) {
						tempAddress.remove(AddressComponent.CITY);
						tempAddress.put(AddressComponent.STATE, city);
					}

				} catch (Exception e) {
					// log.error("Failed to parse address: " + newValue + " with
					// jgeocoder.");
					tempAddress = null;
				}

				if (tempAddress != null) {
					if (addrGeo == null) {
						addrGeo = tempAddress;
						parsedLineIndex = i;
					} else if (size(tempAddress) >= size(addrGeo)) {

						for (AddressComponent key : keyComponents) {

							String component = addrGeo.get(key);
							String newComponent = tempAddress.get(key);

							if (component != null && !component.equals(newComponent)) {
								continue ParseAddressLines;
							}
						}
						addrGeo = tempAddress;
						parsedLineIndex = i;
					}

				}

			}

			/**
			 * This section re-substitues recipients which had been previously
			 * removed but only if it was before the parsedLineIndex, otherwise
			 * we'll add them later
			 */
			List<Entry<Integer, String>> toRemove = new ArrayList<Entry<Integer, String>>();

			// TODO this is not correct, can't really do a comparison of
			// original index
			// to index of paired down list. submitted unit test to fix:
			// testRecipientReplacement
			for (Entry<Integer, String> entry : recipients.entrySet()) {
				if (entry.getKey().intValue() <= parsedLineIndex) {
					fa.mergeRecipient(entry.getValue());
					toRemove.add(entry);
				} else
					break;
			}

			for (Entry<Integer, String> entry : toRemove)
				recipients.remove(entry.getKey());

			if (addrGeo != null && !addrGeo.isEmpty()) {

				try {
					StringBuilder street = new StringBuilder(64);
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.NUMBER)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.PREDIR)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.STREET)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.TYPE)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.POSTDIR)));

					String street1 = street.toString().trim();

					street = new StringBuilder(64);
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.PREDIR2)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.STREET2)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.TYPE2)));
					street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.POSTDIR2)));

					String street2 = street.toString().trim();

					fa.setCity(addrGeo.get(AddressComponent.CITY));
					fa.setState(addrGeo.get(AddressComponent.STATE));
					fa.setPostal(addrGeo.get(AddressComponent.ZIP));

					// This merges back in the lines which the parser did not
					// extract good data out of
					for (int i = 0; i < parsedLineIndex; i++)
						fa.mergeRecipient(values[i]);

					// This merges the name from the parser
					fa.mergeRecipient(addrGeo.get(AddressComponent.NAME));

					// This finally resubstitues the final recipients which were
					// removed at the begining
					for (Entry<Integer, String> entry : recipients.entrySet())
						fa.mergeRecipient(entry.getValue());

					// These merge back the streets and resubstitues streets if
					// the were removed
					if (!street2.equals(""))
						addStreet(fa, street1 + " & " + street2, streets);
					else
						addStreet(fa, street1, streets);

					addStreet(fa, addrGeo.get(AddressComponent.LINE2), streets);

					// Any other streets which were removed and not
					// re-substituted by the two lines above are re-added here
					for (String entry : streets) {
						mergeExtraSubstituteStreets(fa, entry);
						// fa.mergeStreet(entry);
					}

				} catch (Exception e) {
					throw new FormatException("Unable to format address: " + value, e);
				}

			} else {

				// we assume that if this wasn't successful, set the value to
				// the full address
				throw new FormatException("Unable to format address: " + value);
				// fa.setFullAddress(checkForLongZip(value.replace("|", ", ")));
			}

		}

		return fa;

	}
	
	/**
	 * 
	 * @param address
	 * @param street
	 */
	private void mergeExtraSubstituteStreets(FormatterAddress address, String street) {
		
		if (street == null || street.equals(""))
			return;

		// checking if default street was in any of the other fields
		// instead of removing it and adding it as a street
		// we replace it with the street to preserve the order of the fields
		if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient1())) {
			address.setAddressRecipient1(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient2())) {
			address.setAddressRecipient2(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient3())) {
			address.setAddressRecipient3(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet1())) {
			address.setStreet1(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet2())) {
			address.setStreet2(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet3())) {
			address.setStreet3(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet4())) {
			address.setStreet4(street);
		} else {
			address.mergeStreet(street);
		}
	}

	/**
	 * 
	 * @param address
	 * @return
	 */
	private int size(Map<AddressComponent, String> address) {

		int size = 0;
		for (AddressComponent key : address.keySet()) {
			String value = address.get(key);
			if (value != null && !value.equals(""))
				size++;
		}
		return size;
	}

	/**
	 * this checks to see if there is consecutive digits on the line and if it's greater than 5
	 * we add a dash
	 * @param newValue
	 * @return
	 */
	private String checkForLongZip(String newValue) {

		if (RegExHandler.extract(newValue, "\\d{6,9}$") != null) {
			for (int i = newValue.length() - 1; i >= 0; i--) {
				if (newValue.charAt(i) > '9' || newValue.charAt(i) < '0') {
					newValue = new StringBuilder(newValue).insert(i + 6, "-").toString();
					break;
				} else if (i == 0) {
					newValue = new StringBuilder(newValue).insert(i + 5, "-").toString();
				}
			}
		}
		return newValue;
	}

	/**
	 * This function adds the street to the formatter address
	 * It's main job is to resubstitue a street into the formatter
	 * A street might have been substituted out because it is known that the parser cannot handle that street type
	 * eg. PO Box, State Rd...
	 * @param address
	 * @param street
	 * @param substitutedStreets
	 */
	private void addStreet(FormatterAddress address, String street, Stack<String> substitutedStreets) {

		if (street == null)
			return;

		String newStreet = street.trim();

		if (newStreet.contains(defaultStreet)) {
			if (!newStreet.startsWith(defaultStreet)) {
				String prefix = newStreet.substring(0, newStreet.indexOf(defaultStreet));
				address.mergeRecipient(prefix.trim());
				newStreet = newStreet.substring(newStreet.indexOf(defaultStreet));
			}

			address.mergeStreet(substitutedStreets.pop());

			if (!newStreet.endsWith(defaultStreet)) {
				newStreet = newStreet.substring(newStreet.indexOf(defaultStreet) + defaultStreet.length()).trim();
			}

		} else {
			address.mergeStreet(newStreet);
		}
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private int getEmbeddedStreetIndex(String addressLine) {
		
		int index;
		if ((index = getEmbeddedPOBoxIndex(addressLine)) != -1) return index;
		if ((index = getEmbeddedGridSystemIndex(addressLine)) != -1) return index;
		if ((index = getEmbeddedStateRoadIndex(addressLine)) != -1) return index;
		return -1;
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private int getEmbeddedPOBoxIndex(String addressLine) {
		
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(((?<=^|(, ))BOX)|(P[\\. ]*O[\\. ]*)) [^,]*(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}
	
	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private int getEmbeddedGridSystemIndex(String addressLine) {
		
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(?<=^|(, ))([WESN]\\d+[WESN]\\d+) [^,]*(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}
	
	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private int getEmbeddedStateRoadIndex(String addressLine) {
		
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(?<=^|(, ))(\\d+ STATE (RD|ROAD) \\d+)(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}

	/**
	 * 
	 * @param embeddedIndex
	 * @param values
	 * @param curValueIndex
	 * @return
	 */
	private String[] splitOnIndex(int embeddedIndex, String[] values, int curValueIndex) {
		
		String before, extract, rest;

		before = values[curValueIndex].substring(0, embeddedIndex).trim();
		int endIndex = values[curValueIndex].indexOf(",", embeddedIndex);
		if (endIndex == -1) {
			endIndex = values[curValueIndex].length();
			rest = null;
		}
		else
			rest = values[curValueIndex].substring(endIndex, values[curValueIndex].length()).trim();
		extract = values[curValueIndex].substring(embeddedIndex, endIndex);

		String[] tempValues;
		if (rest != null)	// allocate extra room for values
			tempValues = new String[values.length + 2];
		else
			tempValues = new String[values.length + 1];

		// copy unchanged lines before the split
		int j=0;
		for (j = 0; j < curValueIndex; j++) {
			tempValues[j] = values[j];
		}
		// add split lines
		int count = j;
		tempValues[count++] = before;
		tempValues[count++] = extract;
		if (rest != null)
			tempValues[count++] = rest;
		// copy rest of unchanged lines
		for (j = j+1; j < values.length; j++) {
			tempValues[count++] = values[j];
		}

		return tempValues;
	}


	/**
	 * Pre-processing function to determine if the address line is a known street type
	 * @param addressLine
	 * @return
	 */
	private boolean isStreet(String addressLine) {
		return isPOBox(addressLine) || isStateRoad(addressLine) || isGridSystem(addressLine) || isFractionalStreet(addressLine);
	}
	
	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isFractionalStreet(String addressLine) {

		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		if (RegExHandler.extract(addressLine, "^(\\d+)?\\s*\\d+/\\d+") != null) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isGridSystem(String addressLine) {
		
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		if (RegExHandler.extract(addressLine, "^[WwEeSsNn]\\d+[WwEeSsNn]\\d+") != null) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isStateRoad(String addressLine) {
		
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}
		String address = addressLine.toUpperCase().trim();

		if (RegExHandler.stringMatches(address, "\\d+ STATE (RD|ROAD) \\d+"))
			return true;
		return false;
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isPOBox(String addressLine) {
		
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (address.startsWith("PO ")
			|| address.startsWith("P O ")
			|| address.startsWith("P.O. ")
			|| address.startsWith("P. O. ")
			|| (address.startsWith("BOX") && (address.length() > 3) && !Character.isLetter(address.charAt(3)))
			|| address.startsWith("POST OFFICE ")) {
		    
			return true;
		}
		return false;
	}

	/**
	 * Pre-processing function which determines if an address line is a confirmed recipient type
	 * @param addressLine
	 * @return
	 */
	private boolean isRecipient(String addressLine) {
		return isAttention(addressLine) || isCareOf(addressLine);
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isAttention(String addressLine) {
		
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (address.startsWith("ATTN")
			|| address.startsWith("ATTENTION")) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param addressLine
	 * @return
	 */
	private boolean isCareOf(String addressLine) {
		
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (RegExHandler.extract(address, "^CO(:|\\s)") != null
			|| RegExHandler.extract(address, "^C/O(:|\\s)") != null
			|| RegExHandler.extract(address, "^CARE OF(:|\\s)") != null) {
			return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @return
	 */
	private static Map<String, String> getSTATE_CODE_MAP() {
		return STATE_CODE_MAP;
	}
	
	/**
	 * 
	 * @return
	 */
	private static String getStateRegex() {
		return join("|", getSTATE_CODE_MAP().values(), getSTATE_CODE_MAP().keySet());
	}
	
	/**
	 * 
	 * @param separator
	 * @param collections
	 * @return
	 */
	@SafeVarargs
	private static String join(String separator, Collection<String>... collections) {
		
		Set<String> union = new HashSet<String>();
		for (Collection<String> c : collections) {
			union.addAll(c);
		}
		String[] set = new String[union.size()];
		List<String> lst = Arrays.asList(union.toArray(set));
		Collections.sort(lst, new Comparator<String>() {
			public int compare(String o1, String o2) {
				return Integer.valueOf(o2.length()).compareTo(o1.length());
			}
		});
		return org.apache.commons.lang.StringUtils.join(lst, separator);
	}
	
}
