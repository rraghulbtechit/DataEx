package urjanet.clean.format;

import java.nio.charset.Charset;

/**
 * 
 * @author xavierd
 *
 */
public abstract class BaseFormatter {

	private final Charset charSet;
	private final FormatterLocale locale;
	
	protected BaseFormatter(final Charset charSet, final FormatterLocale locale) {
		this.charSet = charSet;
		//To avoid null pointer exception, the dummy locale is added if it's null.
		this.locale = (locale == null)? new FormatterLocale(Language.NONE, Country.NONE) : locale;
	}

	public Charset getCharSet() {
		return charSet;
	}

	public FormatterLocale getLocale() {
		return locale;
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	protected String clean(String value) {
		
		boolean isStripNonLatin1 = true;
		if(charSet != null && charSet.name().equalsIgnoreCase("UTF-8")) {
			isStripNonLatin1 = false;
		}
		return FormatterUtils.clean(value, isStripNonLatin1);
	}
}
