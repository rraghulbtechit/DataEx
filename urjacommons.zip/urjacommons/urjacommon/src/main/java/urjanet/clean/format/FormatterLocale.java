package urjanet.clean.format;

/**
 * 
 * @author xavierd
 *
 */
public final class FormatterLocale {

	private final Language language;
	private final Country country;
	
	public FormatterLocale(final Language language, final Country country) {
		this.language = language;
		this.country = country;
	}
	
	/**
	 * 
	 * @return the language
	 */
	public Language getLanguage() {
		return language;
	}

	/**
	 * 
	 * @return the country
	 */
	public Country getCountry() {
		return country;
	}
	
}
