package urjanet.clean.format;

import java.util.Date;

/**
 *
 * @author rburson
 */
public class FormatterMeasurementPeriod {

	private Date beginDate;
	private Date endDate;

	public FormatterMeasurementPeriod(Date beginDate, Date endDate) {
		this.beginDate = beginDate;
		this.endDate = endDate;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public String toString(){
		return "beginDate:".concat(beginDate.toString()).concat(" endDate:").concat(endDate.toString());
	}
}
