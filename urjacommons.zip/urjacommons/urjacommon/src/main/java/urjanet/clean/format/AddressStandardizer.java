package urjanet.clean.format;

import static net.sourceforge.jgeocoder.AddressComponent.CITY;
import static net.sourceforge.jgeocoder.AddressComponent.POSTDIR;
import static net.sourceforge.jgeocoder.AddressComponent.POSTDIR2;
import static net.sourceforge.jgeocoder.AddressComponent.PREDIR;
import static net.sourceforge.jgeocoder.AddressComponent.PREDIR2;
import static net.sourceforge.jgeocoder.AddressComponent.STATE;
import static net.sourceforge.jgeocoder.AddressComponent.STREET;
import static net.sourceforge.jgeocoder.AddressComponent.STREET2;
import static net.sourceforge.jgeocoder.AddressComponent.TYPE;
import static net.sourceforge.jgeocoder.AddressComponent.TYPE2;
import static net.sourceforge.jgeocoder.AddressComponent.ZIP;
import static urjanet.clean.format.AddressStandardizerDataMaps.getDIRECTIONAL_MAP;
import static urjanet.clean.format.AddressStandardizerDataMaps.getORDINAL_MAP;
import static urjanet.clean.format.AddressStandardizerDataMaps.getSAINT_NAME_MAP;
import static urjanet.clean.format.AddressStandardizerDataMaps.getSTATE_CODE_MAP;
import static urjanet.clean.format.AddressStandardizerDataMaps.getSTREET_TYPE_MAP;

import java.util.EnumMap;
import java.util.Map;

import net.sourceforge.jgeocoder.AddressComponent;

import org.apache.commons.lang.StringUtils;

/*
 *  Borrowed heavily from net.sourceforge.jgeocoder.us.AddressStandardizer - part of the JGeocoder
 *  open source component.
 *
 *  Background - we use net.sourceforge.jgeocoder.us.AddressParser to parse raw addresses
 *  into their various components. However, we also had a need to standardize/normalize the
 *  address components post-parse e.g. map Alabama->AL, Highway->HWY etc.
 *
 *  The AddressStandardizer bundled with JGeocoder appeared on the surface to give us what
 *  we want. However, after testing I found some issues with it. For example:
 *
 *  Original address:   COX COMUNICATIONS INC, 9 J P MURPHY HW, COX CUMMUNICATION, WEST WARWICK   RI 02893
 *  Parsed Address:     {NAME=COX COMUNICATIONS INC, NUMBER=9 J, STREET=P MURPHY HW, LINE2=COX CUMMUNICATION, CITY=WEST WARWICK, STATE=RI, ZIP=02893}
 *  Normalized address: {NAME=COX COMUNICATIONS INC, NUMBER=9-J, STREET=P MURPHY HW, LINE2=COX CUMMUNICATION, CITY=WEST WARWICK, STATE=RI, ZIP=02893}
 *
 *  Notice what it has done to the number component.
 *
 *  This was enough to convince me that we need to have the opportunity to trim and tweak the normalization
 *  of the address. This is why I decided to create this class. It gives us more freedom and control to do
 *  what we need.
 *
 *  Jason
 *
 */
public class AddressStandardizer{

	/**
	 *
	 * Normalize the input parsedAddr map into a standardize format
	 * The effect of Normalization can be summarized as follows:
	 * General
	 * capitalization->CAPITALIZATION
	 *
	 * Directionals
	 *    e.g. NORTH->N, NORTHEAST->NE, N W->NW
	 *
	 * Street types
	 *    e.g. {PKWAY,PKWYS,PKWY}->PKY, {ALLEE, ALLEY, ALLY}->ALY
	 *
	 * States
	 *    e.g. {ALABAMA,Alabama}->AL
	 *
	 * Zips
	 *    e.g. 30338-3109->3308
	 *
	 * Saint abbreviations (expanded)
	 *    e.g. ST MARYS->SAINT MARYS
	 *
	 * @param parsedAddr
	 * @return normalized address in a map
	 */
	public static Map<AddressComponent, String>  normalizeParsedAddress(Map<AddressComponent, String> parsedAddr){
		Map<AddressComponent, String> ret = new EnumMap<AddressComponent, String>(AddressComponent.class);
		//just take the digits from the number component
		for(Map.Entry<AddressComponent, String> e : parsedAddr.entrySet()){
			String v = StringUtils.upperCase(e.getValue());
			switch (e.getKey()) {
			case PREDIR: ret.put(PREDIR, normalizeDir(v)); break;
			case POSTDIR: ret.put(POSTDIR, normalizeDir(v)); break;
			case TYPE: ret.put(TYPE, normalizeStreetType(v)); break;
			case PREDIR2: ret.put(PREDIR2, normalizeDir(v)); break;
			case POSTDIR2: ret.put(POSTDIR2, normalizeDir(v)); break;
			case TYPE2: ret.put(TYPE2, normalizeStreetType(v)); break;
			case STATE: ret.put(STATE, normalizeState(v)); break;
			case ZIP: ret.put(ZIP, normalizeZip(v)); break;
			case CITY: ret.put(CITY, saintAbbrExpansion(v)); break;
			case STREET: ret.put(STREET, normalizeOrdinal(saintAbbrExpansion(v))); break;
			case STREET2: ret.put(STREET2, normalizeOrdinal(saintAbbrExpansion(v))); break;
			default: ret.put(e.getKey(), v); break;
			}
		}
		return ret;
	}

	private static String normalizeDir(String dir){
		if(dir == null) return null;
		dir = dir.replace(" ", "");
		return dir.length() > 2 ? getDIRECTIONAL_MAP().get(dir): dir;
	}

	private static String normalizeStreetType(String type){
		return nvl(getSTREET_TYPE_MAP().get(type), type);
	}

	public static String normalizeState(String state){
		return nvl(getSTATE_CODE_MAP().get(state), state);
	}

	private static String normalizeZip(String zip){
		//TODO: this is stripping off long zips... need a better way to normalize
		return /*StringUtils.length(zip) > 5 ? zip.substring(0, 5) : */zip;
	}

	private static String saintAbbrExpansion(String city){
		String exp = null;
		if((exp = getSAINT_NAME_MAP().get(city))!=null){
			return exp;
		}
		return city;
	}

	private static String normalizeOrdinal(String street){
		String ordinal = null;
		if((ordinal = getORDINAL_MAP().get(street))!=null){
			return ordinal;
		}
		return street;
	}

	public static <T> T nvl(T t, T tt){
		return t == null ? tt : t;
	}

}
