package urjanet.clean.format;

import java.nio.charset.Charset;

public class DefaultStringFormatter extends BaseFormatter implements StringFormatter {

	public DefaultStringFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String formatText(String value) {

		value = clean(value);
		
		// Remove any quotes at the front of the string
		if (value.startsWith("'") || value.startsWith("\"")) {
			value = value.substring(1);
		}

		// Remove any quotes at the back of the string
		if (value.endsWith("'") || value.endsWith("\"")) {
			value = value.substring(0, value.length() - 1);
		}

		return value;
	}

}
