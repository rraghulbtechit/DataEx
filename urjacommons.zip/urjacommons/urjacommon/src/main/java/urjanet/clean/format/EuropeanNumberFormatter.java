package urjanet.clean.format;

import java.math.BigDecimal;
import java.math.MathContext;
import java.nio.charset.Charset;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;

public final class EuropeanNumberFormatter extends BaseNumberFormatter {

	public EuropeanNumberFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			if (formatHint != null) {
				cleanValue = applyFormatHintToNumber(cleanValue, formatHint);
			}
			return new BigDecimal(cleanValue, new MathContext(FormatterUtils.DECIMAL_PRECISION, FormatterUtils.DECIMAL_ROUNDING_MODE)).setScale(FormatterUtils.DECIMAL_SCALE, FormatterUtils.DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public BigDecimal formatDecimal(String value) throws FormatException {

		return formatDecimal(value, null);
	}

	@Override
	public BigDecimal formatDecimal(String value, int precision) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			return new BigDecimal(cleanValue, new MathContext(precision));
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public int formatInteger(String value) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			return new Double(cleanValue).intValue();
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as integer", e);
		}

	}

	

}
