package urjanet.clean.format;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Stack;
import java.util.regex.Pattern;

import net.sourceforge.jgeocoder.AddressComponent;
import net.sourceforge.jgeocoder.us.AddressParser;

import org.apache.commons.lang.StringUtils;
import org.pojava.datetime.DateTime;
import org.pojava.datetime.DateTimeConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;
import urjanet.util.ObjectUtils;

/*
 * This is the "default" format conventions for US English extractions
 * 
 */


public class DefaultFormatter extends Formatter {

	private static final Logger log = LoggerFactory.getLogger(DefaultFormatter.class);
		
	protected static Map<String, String> MONTHS;
	protected static Map<String, String> DAYS;
	
	static {
		MONTHS = new HashMap<String, String>();
		MONTHS.put("january", "jan");
		MONTHS.put("february", "feb");
		MONTHS.put("march", "mar");
		MONTHS.put("april", "apr");
		MONTHS.put("may", "may");
		MONTHS.put("june", "jun");
		MONTHS.put("july", "jul");
		MONTHS.put("august", "aug");
		MONTHS.put("sept", "sep");
		MONTHS.put("september", "sep");
		MONTHS.put("october", "oct");
		MONTHS.put("november",  "nov");
		MONTHS.put("december", "dec");
		
		DAYS = new HashMap<String, String>();
		DAYS.put("monday", "mon");
		DAYS.put("tuesday", "tue");
		DAYS.put("wednesday", "wed");
		DAYS.put("thursday", "thu");
		DAYS.put("friday", "fri");
		DAYS.put("saturday", "sat");
		DAYS.put("sunday", "sun");
	};
	
	protected static final String defaultStreet = "123 DEFAULTSUBSTITUTE ST";
	
	DefaultFormatter() {
		
	}
	
	@Override
	public String getDefaultDateFormatHint() {
		
		return "MM/dd/yyyy";
	}
	
	@Override
	public String getShortMonthAbbreviation(String month) {
	
		String shortMonth = MONTHS.get(month);
		if (shortMonth == null)
			shortMonth = month;
		return shortMonth;
	}
	
	@Override 
	public String getShortDayAbbreviation(String day) {
		
		String shortDay = DAYS.get(day);
		if (shortDay == null)
			shortDay = day;
		return shortDay;
	}
	
	@Override
	public Date formatDateImpl(String value, String formatHint) throws FormatException {
		
		Date date = null;
		
		if (value == null || value.isEmpty()) {
			throw new FormatException("Couldn't format date: '" + value + "' with formatHint: " + formatHint);
		}
		
		if (formatHint != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(formatHint);
				sdf.setLenient(false);
				date = sdf.parse(value);
			} catch (ParseException | IllegalArgumentException pe) {
				if(!isFormatHintHasYear(formatHint)){//This might be 29th Feb leap year Issue.
					try {
						SimpleDateFormat sdf = new SimpleDateFormat(formatHint + " yyyy");
						sdf.setLenient(false);
						// set to first leap year prior to 1970 (which is considered as an empty year)
						return sdf.parse(value + " 1968");
					} catch (ParseException | IllegalArgumentException pe2) {}
				}
				date = formatDateImpl(value);
				if (date != null) {
					log.warn("Date value: " + value + " was parsed but didn't match formatHint: " + formatHint + ", parsed value may be incorrect");
				}
			}
		} else {
			date = formatDateImpl(value);
		}
		
		if (date != null)
			return date;
		else
			throw new FormatException("Couldn't format date: " + value + " with formatHint: " + formatHint);

	}

	private boolean isFormatHintHasYear(String formatHint) {
		if(formatHint == null) return false;
		return formatHint.contains("y") || formatHint.contains("Y");
	}
	
	/**
	 * Use a collection of formatters or heuristics to guess the value's
	 * date format and convert to a Date
	 * @param value
	 * @return
	 */
	private Date formatDateImpl(String value) {
		/*
		 *  Try the date formatting without a format hint.
		 *  If this fails then only raise exception.
		 */
		DateTime dt = null;
		try {

			//Configure this for the US only, for now, for efficiency's sake
			DateTimeConfig.SUPPORTED_LANGUAGES.clear();
			DateTimeConfig.SUPPORTED_LANGUAGES.add("EN");
			DateTimeConfig.globalAmericanDateFormat();
			dt = new DateTime(value);

		} catch (IllegalArgumentException e) {
			
			try {
				// DateTime doesn't support input without years.. Lets try adding a year (leap cause the 29th matters)
				dt = new DateTime(value + " 1968");
			} catch (IllegalArgumentException ee) {}
		}
		
		if (dt != null) {
			Date date = dt.toDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			if (cal.get(Calendar.YEAR) <= 31) {
				// Assume DateTime parsed a day or month as the year (ie. for "Sept 30")
				// Let's try that again but adding in a fake year
				try {
					dt = new DateTime(value + " 1968");
				} catch (IllegalArgumentException ee) {}
			}
		}
		
		if (dt == null)
			return null;

		return dt.toDate();
	}

	@Override
	public BigDecimal formatDecimalImpl(String value, String formatHint) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, "");
			if (formatHint != null) {
				cleanValue = applyFormatHintToNumber(cleanValue, formatHint);
			}
			return new BigDecimal(cleanValue, new MathContext(DECIMAL_PRECISION, DECIMAL_ROUNDING_MODE)).setScale(DECIMAL_SCALE, DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public BigDecimal formatDecimalImpl(String value) throws FormatException {

		try {

			return new BigDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, ""), new MathContext(DECIMAL_PRECISION, DECIMAL_ROUNDING_MODE)).setScale(DECIMAL_SCALE, DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public BigDecimal formatDecimalImpl(String value, int precision) throws FormatException {

		try {
			return new BigDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, ""), new MathContext(precision));
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public int formatIntegerImpl(String value) throws FormatException {

		try {
			return new Double(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_COMMA_P, "")).intValue();
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as integer", e);
		}

	}

	@Override
	/**
	 * This function parses the an address line.
	 * The pieces need to be separated by pipes |
	 *
	 * We use JGeoCoder to parse
	 *
	 * It also has a lot of different logic to make up for the situations which JGeoCoder does not parse right
	 */
	public FormatterAddress formatAddressImpl(String value) throws FormatException {

		if (value == null || value.length() < 1) {
			throw new FormatException("Couldn't format empty String as address.");
		}

		final FormatterAddress fa = new FormatterAddress(this);

		// basic cleaning
		value = cleanText(value);

		//fix missing spaces after commas
		value = RegExHandler.replaceAll(value, Expressions.getInstance().COMMA_NOCAP_NO_SPACE_P, ", ");

		if (!value.isEmpty()) {

			// Skip one part at a time until we've reached the end or we get a geo coded address
			String[] values = value.split("\\|");
			String newValue = "";

			LinkedHashMap<Integer, String> recipients = new LinkedHashMap<Integer, String>();
			Stack<String> streets = new Stack<String>();


			//This removes known components which the address parser does not handle	(eg. "PO Box 5625")
			//It re-adds them later after the parser is finished
			//These components must exist as separate strings in the array 'values' to be removed
			int embeddedIndex;
			for (int i = 0; i < values.length; i++) {
				String tempValue = values[i];
				if (isRecipient(tempValue)) {
					recipients.put(new Integer(i), tempValue);
				}
				// Searches for street fields unhandled by the address parses that exist within a larger line
				// Splits the line into multiple strings within 'values', and restarts the loop so the components may be handled by the lines above
				else if ((embeddedIndex = getEmbeddedStreetIndex(tempValue)) != -1) {
					values = splitOnIndex(embeddedIndex, values, i);

					i = -1;
					streets.clear();
					recipients.clear();
				} else if (isStreet(tempValue)) {
					streets.add(tempValue);
				}
			}

			//This function removes the recipients and streets which the parser cannot handle
			if (!recipients.isEmpty() || !streets.isEmpty()) {
				String[] newValues = new String[values.length - recipients.size()];

				int newValuesIndex = 0;

				for (int i = 0; i < values.length; i++) {
					if (!recipients.keySet().contains(new Integer(i))) {
						if (streets.contains(values[i]))
							newValues[newValuesIndex++] = defaultStreet;
						else
							newValues[newValuesIndex++] = values[i];
					}
				}
				values = newValues;
			}

			/**
			 * These are the components which need to be parsed correctly from the begining
			 * This is based off of the assumption that the city, state, zip are the bottom line
			 * It is also based off the observation that once a name has been parsed,
			 * most of the other pieces will have been parsed since we parse from the bottom up
			 */
			AddressComponent[] keyComponents = {AddressComponent.CITY, AddressComponent.STATE, AddressComponent.ZIP, AddressComponent.NAME};
			Map<AddressComponent, String> addrGeo = null;
			Map<AddressComponent, String> tempAddress = null;
			int parsedLineIndex = 0;

			/**
			 * This loop parses the address from the bottom line up
			 * It takes the combination of lines which the parser was able to extract the most information out of
			 */
			ParseAddressLines:
			for (int i = values.length - 1; i >= 0; i--) {

				if (i == values.length - 1)
					newValue = checkForLongZip(values[i]);
				else
					newValue = values[i] + ", " + newValue;

				try {
					
					/**
					 * IMPORTANT: This parser requires a State or a Zip Code!
					 * IT WILL NOT WORK JUST ON A STREET
					 */
					tempAddress = AddressParser.parseAddress(newValue, true);
					
					/**
					 * Now normalize it
					 */
					Map<AddressComponent, String> normalizedAddr  = AddressStandardizer.normalizeParsedAddress(tempAddress);
					tempAddress = normalizedAddr;

					String city = tempAddress.get(AddressComponent.CITY);
					if (city != null
							&& tempAddress.get(AddressComponent.STATE) == null
							&& STATES.matcher(city.toUpperCase()).matches()) {
						tempAddress.remove(AddressComponent.CITY);
						tempAddress.put(AddressComponent.STATE, city);
					}
					
				} catch (Exception e) {
//					log.error("Failed to parse address: " + newValue + " with jgeocoder.");
					tempAddress = null;
				}

				if (tempAddress != null) {
					if (addrGeo == null) {
						addrGeo = tempAddress;
						parsedLineIndex = i;
					} else if (size(tempAddress) >= size(addrGeo)) {
						
						for (AddressComponent key : keyComponents) {
							
							String component = addrGeo.get(key);
							String newComponent = tempAddress.get(key);
							
							if (component != null && !component.equals(newComponent)) {
								continue ParseAddressLines;
							}
						}
						addrGeo = tempAddress;
						parsedLineIndex = i;
					}
					
				}

			}


			/**
			 * This section re-substitues recipients which had been previously removed
			 * but only if it was before the parsedLineIndex, otherwise we'll add them later
			 */
			List<Entry<Integer, String>> toRemove = new ArrayList<Entry<Integer, String>>();

			//TODO this is not correct, can't really do a comparison of original index
			//to index of paired down list.  submitted unit test to fix: testRecipientReplacement
			for (Entry<Integer, String> entry : recipients.entrySet()) {
				if (entry.getKey().intValue() <= parsedLineIndex) {
					fa.mergeRecipient(entry.getValue());
					toRemove.add(entry);
				} else
					break;
			}

			for (Entry<Integer, String> entry : toRemove)
				recipients.remove(entry.getKey());


			if (addrGeo != null && !addrGeo.isEmpty()) {

				try {
						StringBuilder street = new StringBuilder(64);
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.NUMBER)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.PREDIR)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.STREET)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.TYPE)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.POSTDIR)));

						String street1 = street.toString().trim();

						street = new StringBuilder(64);
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.PREDIR2)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.STREET2)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.TYPE2)));
						street.append(TextFormatter.addTrailingSpaceIfNotNull(addrGeo.get(AddressComponent.POSTDIR2)));

						String street2 = street.toString().trim();

						fa.setCity(addrGeo.get(AddressComponent.CITY));
						fa.setState(addrGeo.get(AddressComponent.STATE));
						fa.setPostal(addrGeo.get(AddressComponent.ZIP));

						//This merges back in the lines which the parser did not extract good data out of
						for (int i = 0; i < parsedLineIndex; i++)
							fa.mergeRecipient(values[i]);

						//This merges the name from the parser
						fa.mergeRecipient(addrGeo.get(AddressComponent.NAME));

						//This finally resubstitues the final recipients which were removed at the begining
						for (Entry<Integer, String> entry : recipients.entrySet())
							fa.mergeRecipient(entry.getValue());

						//These merge back the streets and resubstitues streets if the were removed
						if (!street2.equals(""))
							addStreet(fa, street1 + " & " + street2, streets);
						else
							addStreet(fa, street1, streets);

						addStreet(fa, addrGeo.get(AddressComponent.LINE2), streets);

						//Any other streets which were removed and not re-substituted by the two lines above are re-added here
						for (String entry : streets) {
							mergeExtraSubstituteStreets(fa, entry);
//							fa.mergeStreet(entry);
						}

				} catch (Exception e) {
					throw new FormatException("Unable to format address: " + value, e);
				}

			} else {

				//we assume that if this wasn't successful, set the value to the full address
				throw new FormatException("Unable to format address: " + value);
//				fa.setFullAddress(checkForLongZip(value.replace("|", ", ")));
			}

		}

		return fa;

	}
	
	public void mergeExtraSubstituteStreets(FormatterAddress address, String street) {
		if (street == null || street.equals(""))
			return;

		//checking if default street was in any of the other fields
		//instead of removing it and adding it as a street
		//we replace it with the street to preserve the order of the fields
		if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient1())) {
			address.setAddressRecipient1(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient2())) {
			address.setAddressRecipient2(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getAddressRecipient3())) {
			address.setAddressRecipient3(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet1())) {
			address.setStreet1(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet2())) {
			address.setStreet2(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet3())) {
			address.setStreet3(street);
		} else if (ObjectUtils.equalNeitherNull(defaultStreet, address.getStreet4())) {
			address.setStreet4(street);
		} else {
			address.mergeStreet(street);
		}
	}

	private static int size(Map<AddressComponent, String> address) {
		int size = 0;
		for (AddressComponent key : address.keySet()) {
			String value = address.get(key);
			if (value != null && !value.equals(""))
				size++;
		}
		return size;
	}

	/**
	 * this checks to see if there is consecutive digits on the line and if it's greater than 5
	 * we add a dash
	 * @param newValue
	 * @return
	 */
	public static String checkForLongZip(String newValue) {
		if (RegExHandler.extract(newValue, "\\d{6,9}$") != null) {
			for (int i = newValue.length() - 1; i >= 0; i--) {
				if (newValue.charAt(i) > '9' || newValue.charAt(i) < '0') {
					newValue = new StringBuilder(newValue).insert(i + 6, "-").toString();
					break;
				} else if (i == 0) {
					newValue = new StringBuilder(newValue).insert(i + 5, "-").toString();
				}
			}
		}
		return newValue;
	}

	/**
	 * This function adds the street to the formatter address
	 * It's main job is to resubstitue a street into the formatter
	 * A street might have been substituted out because it is known that the parser cannot handle that street type
	 * eg. PO Box, State Rd...
	 * @param address
	 * @param street
	 * @param substitutedStreets
	 */
	private static void addStreet(FormatterAddress address, String street, Stack<String> substitutedStreets) {

		if (street == null)
			return;

		String newStreet = street.trim();

		if (newStreet.contains(defaultStreet)) {
			if (!newStreet.startsWith(defaultStreet)) {
				String prefix = newStreet.substring(0, newStreet.indexOf(defaultStreet));
				address.mergeRecipient(prefix.trim());
				newStreet = newStreet.substring(newStreet.indexOf(defaultStreet));
			}

			address.mergeStreet(substitutedStreets.pop());

			if (!newStreet.endsWith(defaultStreet)) {
				newStreet = newStreet.substring(newStreet.indexOf(defaultStreet) + defaultStreet.length()).trim();
			}

		} else {
			address.mergeStreet(newStreet);
		}
	}


	private static int getEmbeddedStreetIndex(String addressLine) {
		int index;
		if ((index = getEmbeddedPOBoxIndex(addressLine)) != -1) return index;
		if ((index = getEmbeddedGridSystemIndex(addressLine)) != -1) return index;
		if ((index = getEmbeddedStateRoadIndex(addressLine)) != -1) return index;
		return -1;
	}

	private static int getEmbeddedPOBoxIndex(String addressLine) {
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(((?<=^|(, ))BOX)|(P[\\. ]*O[\\. ]*)) [^,]*(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}
	private static int getEmbeddedGridSystemIndex(String addressLine) {
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(?<=^|(, ))([WESN]\\d+[WESN]\\d+) [^,]*(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}
	private static int getEmbeddedStateRoadIndex(String addressLine) {
		String address = addressLine.toUpperCase();
		String embedded = RegExHandler.extract(address, "(?<=^|(, ))(\\d+ STATE (RD|ROAD) \\d+)(?=,|$)");
		if (embedded == null || embedded.equals(address))
			return -1;
		return address.indexOf(embedded);
	}

	private static String[] splitOnIndex(int embeddedIndex, String[] values, int curValueIndex) {
		String before, extract, rest;

		before = values[curValueIndex].substring(0, embeddedIndex).trim();
		int endIndex = values[curValueIndex].indexOf(",", embeddedIndex);
		if (endIndex == -1) {
			endIndex = values[curValueIndex].length();
			rest = null;
		}
		else
			rest = values[curValueIndex].substring(endIndex, values[curValueIndex].length()).trim();
		extract = values[curValueIndex].substring(embeddedIndex, endIndex);

		String[] tempValues;
		if (rest != null)	// allocate extra room for values
			tempValues = new String[values.length + 2];
		else
			tempValues = new String[values.length + 1];

		// copy unchanged lines before the split
		int j=0;
		for (j = 0; j < curValueIndex; j++) {
			tempValues[j] = values[j];
		}
		// add split lines
		int count = j;
		tempValues[count++] = before;
		tempValues[count++] = extract;
		if (rest != null)
			tempValues[count++] = rest;
		// copy rest of unchanged lines
		for (j = j+1; j < values.length; j++) {
			tempValues[count++] = values[j];
		}

		return tempValues;
	}


	/**
	 * Pre-processing function to determine if the address line is a known street type
	 * @param addressLine
	 * @return
	 */
	private static boolean isStreet(String addressLine) {
		return isPOBox(addressLine) || isStateRoad(addressLine) || isGridSystem(addressLine) || isFractionalStreet(addressLine);
	}
	
	private static boolean isFractionalStreet(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		if (RegExHandler.extract(addressLine, "^(\\d+)?\\s*\\d+/\\d+") != null) {
			return true;
		}
		return false;
	}

	private static boolean isGridSystem(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		if (RegExHandler.extract(addressLine, "^[WwEeSsNn]\\d+[WwEeSsNn]\\d+") != null) {
			return true;
		}
		return false;
	}

	private static boolean isStateRoad(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}
		String address = addressLine.toUpperCase().trim();

		if (RegExHandler.stringMatches(address, "\\d+ STATE (RD|ROAD) \\d+"))
			return true;
		return false;
	}


	private static boolean isPOBox(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (address.startsWith("PO ")
			|| address.startsWith("P O ")
			|| address.startsWith("P.O. ")
			|| address.startsWith("P. O. ")
			|| (address.startsWith("BOX") && (address.length() > 3) && !Character.isLetter(address.charAt(3)))
			|| address.startsWith("POST OFFICE ")) {
		    
			return true;
		}
		return false;
	}

	/**
	 * Pre-processing function which determines if an address line is a confirmed recipient type
	 * @param addressLine
	 * @return
	 */
	private static boolean isRecipient(String addressLine) {
		return isAttention(addressLine) || isCareOf(addressLine);
	}

	private static boolean isAttention(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (address.startsWith("ATTN")
			|| address.startsWith("ATTENTION")) {
			return true;
		}
		return false;
	}

	private static boolean isCareOf(String addressLine) {
		if (addressLine == null || addressLine.equals("")) {
			return false;
		}

		String address = addressLine.toUpperCase().trim();

		if (RegExHandler.extract(address, "^CO(:|\\s)") != null
			|| RegExHandler.extract(address, "^C/O(:|\\s)") != null
			|| RegExHandler.extract(address, "^CARE OF(:|\\s)") != null) {
			return true;
		}
		return false;
	}

	@Override
	public BigDecimal formatCurrencyImpl(String value, String formatHint) throws FormatException {
		
		boolean isCredit = false;

		// Add negative sign in front for credit values
		if (value.indexOf("CR") != -1 || value.indexOf("cr") != -1 || value.indexOf("-") != -1 || value.indexOf("−") != -1
			|| (value.startsWith("(") && value.endsWith(")"))) {
			value = value.replace(')', ' ');
			value = value.replace('(', ' ');
			isCredit = true;
		}

		// if all the characters are non-numeric
		value = value.replaceAll("[^(,\\.0-9)]", "");
		if (value.isEmpty()) {
			throw new FormatException("Unable to format currency: " + value);
		}

		/**
		 * Following 4 lines of code are made for CLECO Template.
		 * Incase the chargeAmount is a Credit value and hence negative, and the ChargeRate is positive, The error occurs
		 * [SystemEvent: WARNING]----------------------------------------------
		   AuditEventCode.AuditEventCode{auditName=chrg.chargeComponent}
		   EntityId: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   EntityType: urjanet.ChargeItem
		   Qualifier: [ChargeItem]
		   chargeAmount: -441.60
		   averageUnitCost: null
		   chargeActualName: CONSTRUCTION FINANCING CREDIT
		   numberOfDaysInPeriod: null
		   chargeUnitsUsed: 44160
		   chargeRate: 0.01
		   chargeRateBase: null
		   chargeRateAdder: null
		   unitsPerRate: null
		   additionalRateMultiplier: null
		   tariffCharge: [TariffCharge id='cc512bd9-de01-11e0-82fb-0019d1a73d13'/]
		   measurementPeriod: [TimeInterval id='cc63c8f1-de01-11e0-82fb-0019d1a73d13'/]
		   usageUnit: [UsageUnit id='cc5152ef-de01-11e0-82fb-0019d1a73d13' name='kWh'
		   measurementType: [MeasurementType id='cc512bda-de01-11e0-82fb-0019d1a73d13' name='general_consumption'/]
		   chargeAmountCurrency: [Currency id='cc501a58-de01-11e0-82fb-0019d1a73d13' name='currency_dollars'/]
		   chargeRateCurrency: [Currency id='cc501a58-de01-11e0-82fb-0019d1a73d13' name='currency_dollars'/]
		   statementComponents: [ArrayList size=1/]
		   usageItems: [ArrayList size=0/]
		   childChargeItems: [ArrayList size=0/]
		   parentChargeItem: null
		   name: null
		   id: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   uuid: cc5104c8-de01-11e0-82fb-0019d1a73d13
		   naturalId: null
		   version: null
		   created: Tue Sep 13 17:43:32 IST 2011
		   customFieldValueSet: null
		   sourceNodes: [ArrayList size=0/]
		   [/ChargeItem]
		 * If we set formatting hint as "CR" or "cr" for the charge rate.  It will add up a minus sign preceding
		 * to the chargeRate by setting isCredit property as true.
		*/
		if(formatHint != null){
			if(formatHint.indexOf("CR") != -1 || formatHint.indexOf("cr") != -1)
				isCredit = true;
		}

		if (formatHint != null) {
			try {
				value = applyFormatHintToNumber(value, formatHint);
			} catch (NumberFormatException ex) {
				throw new FormatException("Unable to format currency: " + value);
			}
		}

		if (isCredit) {
			value = "-" + value;
		}

		return formatDecimal(RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_DOLLAR_P, ""));
	}

	protected String applyFormatHintToNumber(String value, String formatHint) {

		if (value.indexOf(Expressions.getInstance().PERIOD) != -1) {
			// there's already a decimal place in the value
			return value;
		}

		String result = "";
		char[] matcher = formatHint.toCharArray();
		char[] values = value.toCharArray();
		int i = matcher.length - 1, j = value.length() - 1;
		for (; j >= 0;) {
			if (i >= 0) {
				switch (matcher[i]) {
					case 'n':
						if ((values[j] + "").matches("\\d")) {
							result = values[j] + result;
							j--;
						}
						i--;
						break;
					case '.':
						result = '.' + result;
						if (values[j] == matcher[i] || values[j] == ' ') {
							j--;
						}
						i--;
						break;
					case ',':
						result = ',' + result;
						if (values[j] == matcher[i] || values[j] == ' ') {
							j--;
						}
						i--;
						break;
					default:
						if (matcher[i] != values[j]) {
							result = values[j] + result;
							j--;
						}
						i--;
						break;
				}
			} else {
				result = values[j] + result;
				j--;
			}
		}

		if (i == 0) {
			result = matcher[i] + result;
		}

		return result;
	}

	@Override
	public String formatPhoneNumberImpl(String value) {
		return value;
	}

	@Override
	public String formatTextImpl(String value) {

		// Remove any quotes at the front of the string
		if (value.startsWith("'") || value.startsWith("\"")) {
			value = value.substring(1);
		}

		// Remove any quotes at the back of the string
		if (value.endsWith("'") || value.endsWith("\"")) {
			value = value.substring(0, value.length() - 1);
		}

		return value;
	}


	/**
	 * Format a measurement period.  The DataTargetType of this value would be
	 * MEASUREMENT_PERIOD.
	 *
	 * @return Date[] - Array of 2 Date objects representing start and end date
	 */
	@Override
	public FormatterMeasurementPeriod formatMeasurementPeriodImpl(String value, String formatHint) throws FormatException {

		FormatterMeasurementPeriod fmp = null;
		try {
			boolean afterSplit = false;
			String month = null;

			GregorianCalendar cal = new GregorianCalendar();

			// Remove "."'s and ","'s from the value.
			value = value.replaceAll("[.,]", " ");

			if (value.indexOf(" to ") != -1) {
				// Check for "to"
				String[] parts = value.split(" to ");
				String[] formatParts = null;
				if (formatHint != null) {
					formatParts = formatHint.split("to");
				}
				fmp = formatParts(parts, formatParts);
			} else if (value.matches("\\d+\\s*/\\s*\\d+")) {
				Date beginDate = formatDate(value, formatHint);
				cal.setTime(beginDate);
				cal.add(Calendar.MONTH, 1);
				cal.add(Calendar.DATE, -1);
				Date endDate = cal.getTime();
				fmp = new FormatterMeasurementPeriod(beginDate, endDate);
			} else if ((RegExHandler.matches(value, "\\d+-\\w+") || RegExHandler.matches(value, "\\d+-\\d+"))
				&& !RegExHandler.matches(value, "\\w+-\\w+-\\w+")) {
				// Check for "-"
				String[] parts = value.split("-");

				String[] formatParts = null;
				if (formatHint != null) {
					formatParts = formatHint.split("-");
				}

				fmp = formatParts(parts, formatParts);
			} else {
				Date beginDate, endDate;
				afterSplit = false;
				month = containsMonth(value);
				beginDate = formatIt(value, month, afterSplit, formatHint);
				cal.setTime(beginDate);

				if (formatHint != null && !formatHint.equals("")) {
//					try {
//						int daysAdjustment = Integer.parseInt(formatHint);
//						cal.add(Calendar.DATE, daysAdjustment);
//						beginDate = cal.getTime();
//					} catch (NumberFormatException e){log.debug("Format Hint isn't number: " + formatHint);}
					//endDate = beginDate;
					cal.add(Calendar.MONTH, 1);
					cal.add(Calendar.DAY_OF_MONTH, -1);
					endDate = cal.getTime();
				} else {
					// One month ahead
					cal.add(Calendar.MONTH, 1);
					cal.add(Calendar.DATE, -1);
					endDate = cal.getTime();
				}
				fmp = new FormatterMeasurementPeriod(beginDate, endDate);
			}
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as measurement period", e);
		}

		return fmp;
	}

	/**
	 * Format parts of a measurement period separated by a hiphen
	 * or a "to" keyword
	 *
	 * @param parts
	 * @param formatParts
	 * @return
	 * @throws FormatException
	 */
	protected FormatterMeasurementPeriod formatParts(String[] parts, String[] formatParts) throws FormatException {

		Date beginDate;
		Date endDate;
		String month = null;
		boolean afterSplit;

		// If there are more than two parts, then we are not looking at a date value!
		if (parts.length > 2) {
			throw new FormatException("Error formatting value for Measurement Period - " + parts.toString());
		}

		afterSplit = true;

		// First Part
		month = containsMonth(parts[0]);
		if (formatParts != null) {
			beginDate = formatIt(parts[0], month, afterSplit, formatParts[0]);
		} else {
			beginDate = formatIt(parts[0], month, afterSplit, null);
		}

		// Second Part
		if (containsMonth(parts[1]) != null) {
			month = containsMonth(parts[1]);
		} else if (month != null) {
			parts[1] = month + " " + parts[1];
		}

		if (formatParts != null) {
			endDate = formatIt(parts[1], month, afterSplit, formatParts[1]);
		} else {
			endDate = formatIt(parts[1], month, afterSplit, null);
		}

		return new FormatterMeasurementPeriod(beginDate, endDate);
	}

	/**
	 * Main method for getting the Date object from the incoming String.
	 *
	 * @param measPeriod
	 * @param month
	 * @param afterSplit
	 * @param formatParts
	 * @return
	 * @throws FormatException
	 */
	protected Date formatIt(String measPeriod, String month, boolean afterSplit, String formatHint) throws FormatException {
		if (month != null) {
			// Count the number of integers in the value
			int valIdx;
			String values = null;
			if ((valIdx = measPeriod.indexOf(" ", measPeriod.indexOf(month))) != -1) {
				values = measPeriod.substring(valIdx);
			} else {
				values = measPeriod.substring(measPeriod.indexOf(month)+month.length()+1);
				values = values.replace('-', ' ');
			}
			if (values != null) {
				String[] parts = values.split("[\\ ,]");
				int intCount = 0;
				for (String part : parts) {
					if (!part.isEmpty() && StringUtils.isNumeric(part)) {
						intCount++;
						if (intCount == 2) {
							break;
						}
					}
				}

				if (intCount != 2) {

					int intDay = 0;
					int intYear = 0;
					if (intCount == 1) {
						for (String part : parts) {
							if (!part.isEmpty() && StringUtils.isNumeric(part)) {
								int intPart = Integer.parseInt(part);
								if (intPart > 31
										|| (formatHint != null
												&& formatHint.contains("y")
												&& !formatHint.contains("d"))){
									intYear = intPart;
								}else{
									intDay = intPart;
								}
							}
						}
					}

					if (intCount == 0 || (intCount == 1 && intDay != 0)) {
						// find the year
						GregorianCalendar cal = new GregorianCalendar();
						boolean yearFound = false;
						int year = -1;
						while (!yearFound) {
							String currentMonth = new DateFormatSymbols().getShortMonths()[cal.get(Calendar.MONTH)];
							if (currentMonth.toLowerCase().equals(month)) {
								year = cal.get(Calendar.YEAR);
								yearFound = true;
							}
							cal.add(Calendar.MONTH, -1);
						}

						if (year != -1) {
							if (afterSplit) {
								// It contains a date with the month name
								measPeriod += ", " + year;
							} else {
								// It contains a month name and a year
								measPeriod = intDay + " " + month + "-" + year;
							}
						}
					} else if (intCount == 1 && intYear != 0) {
						measPeriod = month + "-" + intYear;
					}
				}
			}
		}

		return formatDate(measPeriod, formatHint);
	}

	/**
	 * Check whether the String value contains a short month name.
	 *
	 * @param value
	 * @return
	 */
	protected String containsMonth(String value) {
		
		for (String month : MONTHS.values()) {
			if (value.toLowerCase().indexOf(month) != -1) {
				return month;
			}
		}

		return null;
	}
	
    private static final Map<String, String> STATE_CODE_MAP = new HashMap<String, String>();
    public static Map<String, String> getSTATE_CODE_MAP() {
        return STATE_CODE_MAP;
      }
    static {
    STATE_CODE_MAP.put("ALABAMA", "AL");
    STATE_CODE_MAP.put("ALASKA", "AK");
    STATE_CODE_MAP.put("AMERICAN SAMOA", "AS");
    STATE_CODE_MAP.put("ARIZONA", "AZ"); 
    STATE_CODE_MAP.put("ARKANSAS", "AR");
    STATE_CODE_MAP.put("CALIFORNIA", "CA");
    STATE_CODE_MAP.put("COLORADO", "CO");
    STATE_CODE_MAP.put("CONNECTICUT", "CT");
    STATE_CODE_MAP.put("DELAWARE", "DE");
    STATE_CODE_MAP.put("DISTRICT OF COLUMBIA", "DC");
    STATE_CODE_MAP.put("FEDERATED STATES OF MICRONESIA", "FM");
    STATE_CODE_MAP.put("FLORIDA", "FL");
    STATE_CODE_MAP.put("GEORGIA", "GA");
    STATE_CODE_MAP.put("GUAM", "GU");
    STATE_CODE_MAP.put("HAWAII", "HI");
    STATE_CODE_MAP.put("IDAHO", "ID");
    STATE_CODE_MAP.put("ILLINOIS", "IL");
    STATE_CODE_MAP.put("INDIANA", "IN");
    STATE_CODE_MAP.put("IOWA", "IA");
    STATE_CODE_MAP.put("KANSAS", "KS");
    STATE_CODE_MAP.put("KENTUCKY", "KY");
    STATE_CODE_MAP.put("LOUISIANA", "LA");
    STATE_CODE_MAP.put("MAINE", "ME");
    STATE_CODE_MAP.put("MARSHALL IS", "MH");
    STATE_CODE_MAP.put("MARSHALL ISLANDS", "MH");
    STATE_CODE_MAP.put("MARYLAND", "MD");
    STATE_CODE_MAP.put("MASSACHUSETTS", "MA");
    STATE_CODE_MAP.put("MICHIGAN", "MI");
    STATE_CODE_MAP.put("MINNESOTA", "MN");
    STATE_CODE_MAP.put("MISSISSIPPI", "MS");
    STATE_CODE_MAP.put("MISSOURI", "MO");
    STATE_CODE_MAP.put("MONTANA", "MT");
    STATE_CODE_MAP.put("NEBRASKA", "NE");
    STATE_CODE_MAP.put("NEVADA", "NV");
    STATE_CODE_MAP.put("NEW HAMPSHIRE", "NH");
    STATE_CODE_MAP.put("NEW JERSEY", "NJ");
    STATE_CODE_MAP.put("NEW MEXICO", "NM");
    STATE_CODE_MAP.put("NEW YORK", "NY");
    STATE_CODE_MAP.put("NEWJERSEY", "NJ");
    STATE_CODE_MAP.put("NEWMEXICO", "NM");
    STATE_CODE_MAP.put("NEWYORK", "NY");
    STATE_CODE_MAP.put("NORTHERN MARIANA ISLANDS", "MP");
    STATE_CODE_MAP.put("NORTH CAROLINA", "NC");
    STATE_CODE_MAP.put("NORTH DAKOTA", "ND");
    STATE_CODE_MAP.put("N CAROLINA", "NC");
    STATE_CODE_MAP.put("N DAKOTA", "ND");
    STATE_CODE_MAP.put("OHIO", "OH");
    STATE_CODE_MAP.put("OKLAHOMA", "OK");
    STATE_CODE_MAP.put("OREGON", "OR");
    STATE_CODE_MAP.put("PALAU", "PW");
    STATE_CODE_MAP.put("PENNSYLVANIA", "PA");
    STATE_CODE_MAP.put("PUERTO RICO", "PR");
    STATE_CODE_MAP.put("PUERTORICO", "PR");
    STATE_CODE_MAP.put("RHODE ISLAND", "RI");
    STATE_CODE_MAP.put("SOUTH CAROLINA", "SC");
    STATE_CODE_MAP.put("SOUTH DAKOTA", "SD");
    STATE_CODE_MAP.put("S CAROLINA", "SC");
    STATE_CODE_MAP.put("S DAKOTA", "SD");
    STATE_CODE_MAP.put("TENNESSEE", "TN");
    STATE_CODE_MAP.put("TEXAS", "TX");
    STATE_CODE_MAP.put("UTAH", "UT");
    STATE_CODE_MAP.put("VERMONT", "VT");
    STATE_CODE_MAP.put("VIRGIN IS", "VI");
    STATE_CODE_MAP.put("VIRGIN ISLANDS", "VI");
    STATE_CODE_MAP.put("VIRGINIA", "VA");
    STATE_CODE_MAP.put("WASHINGTON", "WA");
    STATE_CODE_MAP.put("WEST VIRGINIA", "WV");
    STATE_CODE_MAP.put("W VIRGINIA", "WV");
    STATE_CODE_MAP.put("WISCONSIN", "WI");
    STATE_CODE_MAP.put("WYOMING", "WY");
}
	private static final Pattern STATES = Pattern.compile(getStateRegex());
    public static String getStateRegex(){
        return join("|", getSTATE_CODE_MAP().values(), getSTATE_CODE_MAP().keySet());
      }
    private static String join(String separator, Collection<String>...collections){
        Set<String> union = new HashSet<String>();
        for(Collection<String> c : collections){
          union.addAll(c);      
        }
        String[] set = new String[union.size()];
        List<String> lst = Arrays.asList(union.toArray(set));
        Collections.sort(lst, new Comparator<String>(){
          public int compare(String o1, String o2) {
            return Integer.valueOf(o2.length()).compareTo(o1.length());
          }
        });
        return org.apache.commons.lang.StringUtils.join(lst, separator);
      }
    
}
