package urjanet.clean.format;

import java.math.BigDecimal;
import java.util.Date;

public final class FormatterWrapper extends Formatter {

	private final DateFormatter dateFormatter;
	private final NumberFormatter numberFormatter;
	private final AddressFormatter addressFormatter;
	private final StringFormatter textFormatter;
	
	public FormatterWrapper(DateFormatter dateFormatter, NumberFormatter numberFormatter, AddressFormatter addressFormatter, StringFormatter textFormatter) {
		
		this.dateFormatter = dateFormatter;
		this.numberFormatter = numberFormatter;
		this.addressFormatter = addressFormatter;
		this.textFormatter = textFormatter;
	}
	
	public DateFormatter getDateFormatter() {
		return dateFormatter;
	}

	public NumberFormatter getNumberFormatter() {
		return numberFormatter;
	}

	public AddressFormatter getAddressFormatter() {
		return addressFormatter;
	}

	public StringFormatter getTextFormatter() {
		return textFormatter;
	}
	
	@Override
	public Date formatDate(String value, String formatHint) throws FormatException {
		return this.dateFormatter.formatDate(value, formatHint);
	}
	
	@Override
	public FormatterAddress formatAddress(String value) throws FormatException {
		return this.addressFormatter.formatAddress(value);
	}
	
	@Override
	public BigDecimal formatDecimal(String value) throws FormatException {
		return this.numberFormatter.formatDecimal(value);
	}
	
	@Override
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException {
		return this.numberFormatter.formatDecimal(value, formatHint);
	}
	
	@Override
	public BigDecimal formatDecimal(String value, int precision) throws FormatException {
		return this.numberFormatter.formatDecimal(value, precision);
	}
	
	@Override
	public int formatInteger(String value) throws FormatException {
		return this.numberFormatter.formatInteger(value);
	}
	
	@Override
	public String formatPhoneNumber(String value) throws FormatException {
		return this.numberFormatter.formatPhoneNumber(value);
	}
	
	@Override
	public BigDecimal formatCurrency(String value, String formatHint) throws FormatException {
		return this.numberFormatter.formatCurrency(value, formatHint);
	}
	
	@Override
	public String formatText(String value) {
		return this.textFormatter.formatText(value);
	}
	
	@Override
	public FormatterMeasurementPeriod formatMeasurementPeriod(String value, String formatHint) throws FormatException {
		return this.dateFormatter.formatMeasurementPeriod(value, formatHint);
	}
	
	@Override
	public String cleanText(String value) {
		return this.addressFormatter.cleanText(value);
	}

	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {
		return this.dateFormatter.formatDate(value, formatHint);
	}

	@Override
	protected FormatterAddress formatAddressImpl(String value) throws FormatException {
		return this.addressFormatter.formatAddress(value);
	}

	@Override
	protected BigDecimal formatDecimalImpl(String value) throws FormatException {
		return this.numberFormatter.formatDecimal(value);
	}

	@Override
	protected BigDecimal formatDecimalImpl(String value, String formatHint) throws FormatException {
		return this.numberFormatter.formatDecimal(value, formatHint);
	}

	@Override
	protected BigDecimal formatDecimalImpl(String value, int precision) throws FormatException {
		return this.numberFormatter.formatDecimal(value, precision);
	}

	@Override
	protected int formatIntegerImpl(String value) throws FormatException {
		return this.numberFormatter.formatInteger(value);
	}

	@Override
	protected String formatPhoneNumberImpl(String value) throws FormatException {
		return this.numberFormatter.formatPhoneNumber(value);
	}

	@Override
	protected BigDecimal formatCurrencyImpl(String value, String formatHint) throws FormatException {
		return this.numberFormatter.formatCurrency(value, formatHint);
	}

	@Override
	protected String formatTextImpl(String value) {
		return this.textFormatter.formatText(value);
	}

	@Override
	protected FormatterMeasurementPeriod formatMeasurementPeriodImpl(String value, String formatHint) throws FormatException {
		return this.dateFormatter.formatMeasurementPeriod(value, formatHint);
	}

	@Override
	public String getDefaultDateFormatHint() {
		return this.dateFormatter.getDefaultDateFormatHint();
	}

	@Override
	public String getShortMonthAbbreviation(String month) {
		return this.dateFormatter.getShortMonthAbbreviation(month);
	}

	@Override
	public String getShortDayAbbreviation(String day) {
		return this.dateFormatter.getShortDayAbbreviation(day);
	}
	
}
