package urjanet.clean.format;

import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;

public final class FormatterUtils {
	
	public static final int DECIMAL_SCALE = 10;
	public static final int DECIMAL_PRECISION = 29;
	public static final RoundingMode DECIMAL_ROUNDING_MODE = RoundingMode.HALF_UP;
	public static final String MINUS = "-";
	public static Map<String, String> ENGLISH_MONTHS;
	public static Map<String, String> ENGLISH_DAYS;
	
	static {
		ENGLISH_MONTHS = new HashMap<String, String>(12);
		ENGLISH_MONTHS.put("january", "jan");
		ENGLISH_MONTHS.put("february", "feb");
		ENGLISH_MONTHS.put("march", "mar");
		ENGLISH_MONTHS.put("april", "apr");
		ENGLISH_MONTHS.put("may", "may");
		ENGLISH_MONTHS.put("june", "jun");
		ENGLISH_MONTHS.put("july", "jul");
		ENGLISH_MONTHS.put("august", "aug");
		ENGLISH_MONTHS.put("sept", "sep");
		ENGLISH_MONTHS.put("september", "sep");
		ENGLISH_MONTHS.put("october", "oct");
		ENGLISH_MONTHS.put("november",  "nov");
		ENGLISH_MONTHS.put("december", "dec");
		
		ENGLISH_DAYS = new HashMap<String, String>(7);
		ENGLISH_DAYS.put("monday", "mon");
		ENGLISH_DAYS.put("tuesday", "tue");
		ENGLISH_DAYS.put("wednesday", "wed");
		ENGLISH_DAYS.put("thursday", "thu");
		ENGLISH_DAYS.put("friday", "fri");
		ENGLISH_DAYS.put("saturday", "sat");
		ENGLISH_DAYS.put("sunday", "sun");
	};
	
	//Don't let anybody create an object
	private FormatterUtils() {
		
	}
	
	/**
	 * 
	 * @param month
	 * @return
	 */
	public static String getEnglishShortMonthAbbreviation(String month) {
	
		String shortMonth = ENGLISH_MONTHS.get(month);
		if (shortMonth == null) {
			shortMonth = month;
		}
		return shortMonth;
	}
	
	/**
	 * 
	 * @param day
	 * @return
	 */
	public static String getEnglishShortDayAbbreviation(String day) {
		
		String shortDay = ENGLISH_DAYS.get(day);
		if (shortDay == null) {
			shortDay = day;
		}
		return shortDay;
	}
	
	/**
	 * 
	 * @param value
	 * @param stripNonLatin1
	 * @return
	 */
	public static String clean(String value, boolean stripNonLatin1) {

        if (value == null) {
            return "";
        }

        // order here matters...anything that normalizes unicode chars outside the latin1 range 
        // needs to come before "removeNonprintableLatin1()"
        
        value = normalizeMinus(value);
        
        // system only supports 1atin1 chars at the moment...this turns everything outside
        // the latin1 range into spaces
        if (stripNonLatin1) {
            value = removeNonprintableLatin1(value);
        }
        
        // normalize spaces (condense multiple spaces into a single)
        value = normalizeWhitespace(value);
        
        // normalize separators
        return normalizeSeparators(value);	    
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String formatCreditValue(String value) {
		
		value = value.trim();
		boolean isNegative = (value.endsWith("-")|| StringUtils.indexOfIgnoreCase(value, "CR") != -1 ||
				(value.startsWith("(") && value.endsWith (")")));
		
		if(isNegative) {
			value = MINUS + value.replaceAll("[\\(\\)\\-]|(?i)cr","");
		}
		
		return value;
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String removeNonprintableLatin1(String value) {
	
		return RegExHandler.replaceAll(value, Expressions.getInstance().NONPRINTABLE_LATIN1_P, " ");
	}
	
	/**
	 * java regex "\s" doesn't correctly deal with unicode whitespace
	 * 
	 * @param value
	 * @return
	 */
	public static String normalizeWhitespace(String value) {

		return RegExHandler.replaceAll(value, Expressions.getInstance().ONE_OR_MORE_SPACES_P, " ").replaceAll("\\s?\\|\\s?", "|").trim();
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String normalizeMinus(String value) {
	    
	    return RegExHandler.replaceAll(value, Expressions.getInstance().UNICODE_MINUS_P, "-");
	}
	
	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String normalizeSeparators(String value) {

		// the "soft-hyphen" gives us trouble, replace it with the ascii version
		value = value.replace('\u00AD', '-');
		// the non-breaking space character is not consistent with XML formatting; replacing it with normal space
		value = value.replace('\u00A0', ' ');
		return value;
	}
	
}
