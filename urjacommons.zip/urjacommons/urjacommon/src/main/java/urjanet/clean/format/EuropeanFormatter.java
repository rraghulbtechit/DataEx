package urjanet.clean.format;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.pojava.datetime.DateTime;
import org.pojava.datetime.DateTimeConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.regex.Expressions;
import urjanet.regex.RegExHandler;

public class EuropeanFormatter extends Utf8Formatter {

	
	private static final Logger log = LoggerFactory.getLogger(EuropeanFormatter.class);
		
	/*
	 * These correspond to our database's scale and precision values (and behavior) for decimals
	 */
	private static final int DECIMAL_SCALE = 10;
	private static final int DECIMAL_PRECISION = 29;
	private static final RoundingMode DECIMAL_ROUNDING_MODE = RoundingMode.HALF_UP;

	NumberFormat numberFormat = new DecimalFormat("0.00");
	
	@Override
	public Date formatDate(String value, String formatHint) throws FormatException {
		
		if (value == null || value.isEmpty()) {
			throw new FormatException("Couldn't format date: " + value + " " + " with formatHint: " + formatHint);
		}

		value = cleanText(value);

		if (formatHint != null) {
			try {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat(formatHint);
					sdf.setLenient(false);
					return sdf.parse(value);
				} catch (ParseException pe) {
					// Attempt to format the date as a leap year, to handle "02/29"
					// date. Final date created will be "02/29/1968", which is the
					// last leap year prior to 1970.
					SimpleDateFormat sdf = new SimpleDateFormat(formatHint + " yyyy");
					sdf.setLenient(false);
					// set to first leap year prior to 1970 (which is considered an empty year)
					return sdf.parse(value + " 1968");
				}

			} catch (Exception e) {

				/*
				 *  Try the date formatting without a format hint.
				 *  If this fails then only raise exception.
				 */
				DateTime dt = new DateTime();
				try {
					DateTimeConfig.SUPPORTED_LANGUAGES.clear();
					DateTimeConfig.SUPPORTED_LANGUAGES.add("ES");
					DateTimeConfig.SUPPORTED_LANGUAGES.add("FR");
					DateTimeConfig.SUPPORTED_LANGUAGES.add("DE");
					DateTimeConfig.globalEuropeanDateFormat();
					dt = new DateTime(value);

				} catch (Exception ee) {
					throw new FormatException("Couldn't format date: " + value + " " + " with formatHint: " + formatHint, ee);
				}

				return dt.toDate();
			}

		} else {

			DateTime dt = new DateTime();
			try {
				//Configure this for the US only, for now, for efficiency's sake
				DateTimeConfig.SUPPORTED_LANGUAGES.clear();
				DateTimeConfig.SUPPORTED_LANGUAGES.clear();
				DateTimeConfig.SUPPORTED_LANGUAGES.add("ES");
				DateTimeConfig.SUPPORTED_LANGUAGES.add("FR");
				DateTimeConfig.SUPPORTED_LANGUAGES.add("DE");
				DateTimeConfig.globalEuropeanDateFormat();
				dt = new DateTime(value);

			} catch (IllegalArgumentException e) {
				throw new FormatException("Couldn't format date: " + value, e);
			}

			return dt.toDate();
		}
	}

	@Override
	public BigDecimal formatDecimal(String value, String formatHint) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			if (formatHint != null) {
				cleanValue = applyFormatHintToNumber(cleanValue, formatHint);
			}
			return new BigDecimal(cleanValue, new MathContext(DECIMAL_PRECISION, DECIMAL_ROUNDING_MODE)).setScale(DECIMAL_SCALE, DECIMAL_ROUNDING_MODE);
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public BigDecimal formatDecimal(String value) throws FormatException {

		return formatDecimal(value, null);
	}

	@Override
	public BigDecimal formatDecimal(String value, int precision) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			return new BigDecimal(cleanValue, new MathContext(precision));
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as decimal", e);
		}

	}

	@Override
	public int formatInteger(String value) throws FormatException {

		try {
			String cleanValue = RegExHandler.replaceAll(value, Expressions.getInstance().SINGLE_PERIOD_P, "");
			cleanValue = RegExHandler.replaceAll(cleanValue, Expressions.getInstance().SINGLE_COMMA_P, ".");
			return new Double(cleanValue).intValue();
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as integer", e);
		}

	}

}
