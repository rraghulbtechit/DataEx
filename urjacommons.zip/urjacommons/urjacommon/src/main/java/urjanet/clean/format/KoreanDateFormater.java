package urjanet.clean.format;

import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class KoreanDateFormater extends YearMonthDayDateFormatter {
	
	private Locale locale;

	public KoreanDateFormater(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
		if(locale.getCountry() == Country.NORTH_KOREA) {
			this.locale = new Locale("ko", "KP", "KP");
		} else if(locale.getCountry() == Country.SOUTH_KOREA) {
			this.locale = new Locale("ko", "KR", "KR");
		} else if(locale.getCountry() == Country.CHINA){
			this.locale = new Locale("ko", "CN", "CN");
		}
	}
	
	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {
		
		try {
			DateFormat df = DateFormat.getDateInstance(DateFormat.FULL, locale);
			return df.parse(value);
		} catch(ParseException p1) {

			//For date Refer: https://en.wikipedia.org/wiki/South_Korea
			SimpleDateFormat koreanYearMonthDay = new SimpleDateFormat("yyyy년 MM월 dd일");
			koreanYearMonthDay.setLenient(false);
			
			try {
				return koreanYearMonthDay.parse(value);
			} catch (ParseException p2) {
				SimpleDateFormat sf = new SimpleDateFormat(getDefaultDateFormatHint());
				sf.setLenient(false);
				try {
					return sf.parse(value);
				} catch (ParseException p3) {
					throw new FormatException("Couldn't format date: " + value + " with formatHint: " + formatHint);
				}
			}
		}
	}

	public static void main(String[] args) throws FormatException, ParseException {
		
		String val = "1975년 7월 14일";
		DateFormatter format = new KoreanDateFormater(Charset.forName("UTF-8"), new FormatterLocale(Language.KOREAN, Country.SOUTH_KOREA));
		Date d = format.formatDate(val, null);
		System.out.println(d.toString());
	}
	
}
