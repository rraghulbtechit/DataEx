package urjanet.clean.format;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

public class YearMonthDayDateFormatter extends BaseDateFormatter {

	public YearMonthDayDateFormatter(Charset charSet, FormatterLocale formatterLocale) {
		super(charSet, formatterLocale);
	}

	@Override
	public String getDefaultDateFormatHint() {
		return "yyyy/MM/dd";
	}

	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {

		try {
			SimpleDateFormat sf = new SimpleDateFormat(getDefaultDateFormatHint());
			sf.setLenient(false);
			return sf.parse(value);
		} catch (Exception ee) {
			throw new FormatException("Couldn't format date: " + value + " with formatHint: " + formatHint);
		}
	
	}

}
