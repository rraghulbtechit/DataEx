/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package urjanet.clean.format;

import urjanet.UrjanetException;

public class FormatException extends UrjanetException{

    public FormatException(){
		this("General FormatException", null);
	}

	public FormatException(Throwable t){
		this("General FormatException", t);
	}

	public FormatException(String message, Throwable t){
		super(message, t);
	}

	public FormatException(String message){
		this(message, null);
	}

}
