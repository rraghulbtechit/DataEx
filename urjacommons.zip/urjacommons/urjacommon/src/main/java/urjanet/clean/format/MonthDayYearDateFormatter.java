package urjanet.clean.format;

import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Date;

import org.pojava.datetime.DateTime;
import org.pojava.datetime.DateTimeConfig;

public final class MonthDayYearDateFormatter extends BaseDateFormatter {

	/**
	 * 
	 * @param charSet
	 * @param locale
	 */
	public MonthDayYearDateFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public String getDefaultDateFormatHint() {
		return "MM/dd/yyyy";
	}

	@Override
	protected Date formatDateImpl(String value, String formatHint) throws FormatException {
		
		/*
		 *  Try the date formatting without a format hint.
		 *  If this fails then only raise exception.
		 */
		DateTime dt = null;
		try {

			//Configure this for the US only, for now, for efficiency's sake
			DateTimeConfig.SUPPORTED_LANGUAGES.clear();
			DateTimeConfig.SUPPORTED_LANGUAGES.add("EN");
			DateTimeConfig.globalAmericanDateFormat();
			dt = new DateTime(value);

		} catch (IllegalArgumentException e) {
			
			try {
				// DateTime doesn't support input without years.. Lets try adding a year (leap cause the 29th matters)
				dt = new DateTime(value + " 1968");
			} catch (IllegalArgumentException ee) {}
		}
		
		if (dt != null) {
			Date date = dt.toDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			if (cal.get(Calendar.YEAR) <= 31) {
				// Assume DateTime parsed a day or month as the year (ie. for "Sept 30")
				// Let's try that again but adding in a fake year
				try {
					dt = new DateTime(value + " 1968");
				} catch (IllegalArgumentException ee) {}
			}
		}
		
		if (dt == null)
			return null;

		return dt.toDate();
	}

}
