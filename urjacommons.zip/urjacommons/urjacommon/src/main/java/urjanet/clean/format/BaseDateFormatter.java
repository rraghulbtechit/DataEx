package urjanet.clean.format;

import java.nio.charset.Charset;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;

import urjanet.regex.RegExHandler;

public abstract class BaseDateFormatter extends BaseFormatter implements DateFormatter {

	protected abstract Date formatDateImpl(String value, String formatHint) throws FormatException;
	
	/**
	 * 
	 * @param charSet
	 * @param locale
	 */
	protected BaseDateFormatter(Charset charSet, FormatterLocale locale) {
		super(charSet, locale);
	}

	@Override
	public Date formatDate(String value, String formatHint) throws FormatException {
		
		String cleanText = clean(value);
		
		if (cleanText == null || cleanText.isEmpty()) {
			throw new FormatException("Couldn't format date: '" + value + "' with formatHint: " + formatHint);
		}
		
		Date date = formatSimpleDate(cleanText, formatHint);
		
		if(date != null) {
			return date;
		} else {
			date = formatDateImpl(cleanText, formatHint);
			if(date != null) {
				return date;
			}
		}
		
		throw new FormatException("Couldn't format date: " + cleanText + " with formatHint: " + formatHint);
	}
	
	@Override
	public String getShortMonthAbbreviation(String month) {
		
		if(Language.ENGLISH == getLocale().getLanguage()) {
			return FormatterUtils.getEnglishShortMonthAbbreviation(month);
		}
		
		return null;
	}

	@Override
	public String getShortDayAbbreviation(String day) {
		
		if(Language.ENGLISH == getLocale().getLanguage()) {
			return FormatterUtils.getEnglishShortDayAbbreviation(day);
		}
		
		return null;
	}
	
	/**
	 * Format a measurement period.  The DataTargetType of this value would be
	 * MEASUREMENT_PERIOD.
	 *
	 * @return Date[] - Array of 2 Date objects representing start and end date
	 */
	@Override
	public FormatterMeasurementPeriod formatMeasurementPeriod(String value, String formatHint) throws FormatException {

		value = clean(value);

		FormatterMeasurementPeriod fmp = null;
		try {
			boolean afterSplit = false;
			String month = null;

			GregorianCalendar cal = new GregorianCalendar();

			// Remove "."'s and ","'s from the value.
			value = value.replaceAll("[.,]", " ");

			if (value.indexOf(" to ") != -1) {
				// Check for "to"
				String[] parts = value.split(" to ");
				String[] formatParts = null;
				if (formatHint != null) {
					formatParts = formatHint.split("to");
				}
				fmp = formatParts(parts, formatParts);
			} else if (value.matches("\\d+\\s*/\\s*\\d+")) {
				Date beginDate = formatDate(value, formatHint);
				cal.setTime(beginDate);
				cal.add(Calendar.MONTH, 1);
				cal.add(Calendar.DATE, -1);
				Date endDate = cal.getTime();
				fmp = new FormatterMeasurementPeriod(beginDate, endDate);
			} else if ((RegExHandler.matches(value, "\\d+-\\w+") || RegExHandler.matches(value, "\\d+-\\d+"))
					&& !RegExHandler.matches(value, "\\w+-\\w+-\\w+")) {
				// Check for "-"
				String[] parts = value.split("-");

				String[] formatParts = null;
				if (formatHint != null) {
					formatParts = formatHint.split("-");
				}

				fmp = formatParts(parts, formatParts);
			} else {
				Date beginDate, endDate;
				afterSplit = false;
				month = containsMonth(value);
				beginDate = formatIt(value, month, afterSplit, formatHint);
				cal.setTime(beginDate);

				if (formatHint != null && !formatHint.equals("")) {
					cal.add(Calendar.MONTH, 1);
					cal.add(Calendar.DAY_OF_MONTH, -1);
					endDate = cal.getTime();
				} else {
					// One month ahead
					cal.add(Calendar.MONTH, 1);
					cal.add(Calendar.DATE, -1);
					endDate = cal.getTime();
				}
				fmp = new FormatterMeasurementPeriod(beginDate, endDate);
			}
		} catch (Exception e) {
			throw new FormatException("Failed to format " + value + " as measurement period", e);
		}

		return fmp;
	}
	
	/**
	 * Format parts of a measurement period separated by a hiphen
	 * or a "to" keyword
	 *
	 * @param parts
	 * @param formatParts
	 * @return
	 * @throws FormatException
	 */
	protected FormatterMeasurementPeriod formatParts(String[] parts, String[] formatParts) throws FormatException {

		Date beginDate;
		Date endDate;
		String month = null;
		boolean afterSplit;

		// If there are more than two parts, then we are not looking at a date value!
		if (parts.length > 2) {
			throw new FormatException("Error formatting value for Measurement Period - " + parts.toString());
		}

		afterSplit = true;

		// First Part
		month = containsMonth(parts[0]);
		if (formatParts != null) {
			beginDate = formatIt(parts[0], month, afterSplit, formatParts[0]);
		} else {
			beginDate = formatIt(parts[0], month, afterSplit, null);
		}

		// Second Part
		if (containsMonth(parts[1]) != null) {
			month = containsMonth(parts[1]);
		} else if (month != null) {
			parts[1] = month + " " + parts[1];
		}

		if (formatParts != null) {
			endDate = formatIt(parts[1], month, afterSplit, formatParts[1]);
		} else {
			endDate = formatIt(parts[1], month, afterSplit, null);
		}

		return new FormatterMeasurementPeriod(beginDate, endDate);
	}
	
	/**
	 * Main method for getting the Date object from the incoming String.
	 *
	 * @param measPeriod
	 * @param month
	 * @param afterSplit
	 * @param formatParts
	 * @return
	 * @throws FormatException
	 */
	protected Date formatIt(String measPeriod, String month, boolean afterSplit, String formatHint) throws FormatException {

		if (month != null) {
			// Count the number of integers in the value
			int valIdx;
			String values = null;
			if ((valIdx = measPeriod.indexOf(" ", measPeriod.indexOf(month))) != -1) {
				values = measPeriod.substring(valIdx);
			} else {
				values = measPeriod.substring(measPeriod.indexOf(month) + month.length() + 1);
				values = values.replace('-', ' ');
			}
			if (values != null) {
				String[] parts = values.split("[\\ ,]");
				int intCount = 0;
				for (String part : parts) {
					if (!part.isEmpty() && StringUtils.isNumeric(part)) {
						intCount++;
						if (intCount == 2) {
							break;
						}
					}
				}

				if (intCount != 2) {

					int intDay = 0;
					int intYear = 0;
					if (intCount == 1) {
						for (String part : parts) {
							if (!part.isEmpty() && StringUtils.isNumeric(part)) {
								int intPart = Integer.parseInt(part);
								if (intPart > 31 || (formatHint != null && formatHint.contains("y")
										&& !formatHint.contains("d"))) {
									intYear = intPart;
								} else {
									intDay = intPart;
								}
							}
						}
					}

					if (intCount == 0 || (intCount == 1 && intDay != 0)) {
						// find the year
						GregorianCalendar cal = new GregorianCalendar();
						boolean yearFound = false;
						int year = -1;
						while (!yearFound) {
							String currentMonth = new DateFormatSymbols().getShortMonths()[cal.get(Calendar.MONTH)];
							if (currentMonth.toLowerCase().equals(month)) {
								year = cal.get(Calendar.YEAR);
								yearFound = true;
							}
							cal.add(Calendar.MONTH, -1);
						}

						if (year != -1) {
							if (afterSplit) {
								// It contains a date with the month name
								measPeriod += ", " + year;
							} else {
								// It contains a month name and a year
								measPeriod = intDay + " " + month + "-" + year;
							}
						}
					} else if (intCount == 1 && intYear != 0) {
						measPeriod = month + "-" + intYear;
					}
				}
			}
		}

		return formatDate(measPeriod, formatHint);
	}
	
	/**
	 * Check whether the String value contains a short month name.
	 *
	 * @param value
	 * @return
	 */
	protected String containsMonth(String value) {
		
		for (String month : FormatterUtils.ENGLISH_MONTHS.values()) {
			if (value.toLowerCase().indexOf(month) != -1) {
				return month;
			}
		}

		return null;
	}
	
	/**
	 * 
	 * @param value
	 * @param formatHint
	 * @return
	 */
	protected Date formatSimpleDate(final String value, final String formatHint) {
		
		if (formatHint != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(formatHint);
				sdf.setLenient(false);
				return sdf.parse(value);
			} catch (ParseException | IllegalArgumentException pe) {
				if(!isFormatHintHasYear(formatHint)) {//This might be 29th Feb leap year Issue.
					try {
						SimpleDateFormat sdf = new SimpleDateFormat(formatHint + " yyyy");
						sdf.setLenient(false);
						// set to first leap year prior to 1970 (which is considered as an empty year)
						return sdf.parse(value + " 1968");
					} catch (ParseException | IllegalArgumentException pe2) {}
				}
			}
		}
		
		return null;
	}
	
	/**
	 * 
	 * @param formatHint
	 * @return
	 */
	protected boolean isFormatHintHasYear(String formatHint) {
		
		return (formatHint == null)? false : (formatHint.contains("y") || formatHint.contains("Y"));
	}
	
}
