package urjanet.io;

/**
 *
 * @author rburson
 */
public interface ObjectSerializer {

	public String writeObject(Object o) throws Exception;

}
