package urjanet.io;

import org.codehaus.jackson.map.ObjectMapper;

public class JSONReader<T> {
	
	public JSONReader() {
		
	}

	public T fromJSON(String jsonObject, Class<T> clazz) {

		ObjectMapper mapper = new ObjectMapper();
		T obj = null;
		try {
			obj = mapper.readValue(jsonObject, clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
}
