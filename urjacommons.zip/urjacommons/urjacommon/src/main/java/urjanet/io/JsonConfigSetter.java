package urjanet.io;

import org.codehaus.jackson.map.ObjectMapper;

public interface JsonConfigSetter {
	public void go(ObjectMapper objectMapper);
}
