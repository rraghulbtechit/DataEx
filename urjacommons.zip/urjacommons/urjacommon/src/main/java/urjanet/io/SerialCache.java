package urjanet.io;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import urjanet.UrjanetException;

public class SerialCache {

	protected static final Logger log = LoggerFactory.getLogger(SerialCache.class);
	protected String rootPath;
	protected File location;
	protected int keyIndex = 0;

	/**
	 * Cache is lazily created upon first cache() call.
	 */
	public SerialCache(String rootPath, String cacheDir) {

		this.rootPath = rootPath;
		this.location = new File(rootPath + "/" + cacheDir);

	}

	public String cache(Serializable entry) throws UrjanetException{

		if (keyIndex == 0) {
			init();
		}
		keyIndex++;
		cache(entry, Integer.toString(keyIndex));
		return Integer.toString(keyIndex);
	}

	/**
	 * if (!keyIndex) init() is lazy creation of location in file directory structure
	 */
	public void cache(Serializable entry, String filename) throws UrjanetException {
		//log.debug("entering cache entry ${entry.getUrl()}")
		ObjectOutputStream oos = null;
		try {

			oos = new ObjectOutputStream(new FileOutputStream(new File(location, filename + ".ser")));
			oos.writeObject(entry);

		} catch (Exception e) {
			log.debug("", e);
			throw new UrjanetException("Failed to cache entry", e);
		} finally {
			try {
				oos.flush();
				oos.close();
			} catch (Exception e) {
			}
		}
	}

	public Serializable retrieve(String filename) throws UrjanetException {
		//log.debug("entering retrieve entry $key")
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(new File(location, filename + ".ser")));
			return (Serializable) ois.readObject();
		} catch (Exception e) {
			throw new UrjanetException("Failed to retrieve object from cache", e);
		} finally {
			try {
				ois.close();
			} catch (Exception e) {
			}
		}
	}

	public void deleteFromCache(String key) {
		try {
			new File(location, "${key}.ser").delete();
		} catch (Exception e) {
			log.error("", e);
		}
	}

	/**
	 * Deletes the contents of the cache directory along with the cache directory itself
	 */
	public void deleteCacheDir() {
		if (location != null) {
			deleteRecursive(location, true);
		}
	}

	/**
	 * Deletes the contents of the cache directory, but not the cache directory itself
	 */
	public static void emptyCacheRoot(String rootPath) {
		if (rootPath != null) {
			emptyCacheRoot(new File(rootPath));

		}
	}

	public static void emptyCacheRoot(File root) {
		if (root != null) {
			deleteRecursive(root, false);
		}
	}

	protected synchronized void init() {
		this.location.mkdirs();
	}

	protected static boolean deleteRecursive(File startDir, boolean deleteDir) {

		if (startDir.isDirectory()) {

			FileFilter ff = new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return pathname.isDirectory() || pathname.getName().endsWith(".ser");
				}
			};

			File[] children = startDir.listFiles(ff);
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteRecursive(children[i], true);
				if (!success) {
					return false;
				}
			}
		}
		if (deleteDir) {
			return startDir.delete();
		}

		return true;
	}
}
