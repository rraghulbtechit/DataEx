package urjanet.aws.sqs;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.UUID;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.ChangeMessageVisibilityRequest;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.DeleteQueueRequest;
import com.amazonaws.services.sqs.model.GetQueueAttributesRequest;
import com.amazonaws.services.sqs.model.GetQueueAttributesResult;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;

import urjanet.environment.UrjanetProperties;

/**
 * <p>
 * 
 * 	This SQS manager will handle both small and large messages. 
 * The large messages (which is having more than 262144 bytes in size) are stored in S3 and that will be referred by each message. 
 * The small messages (which is having less than 262144 bytes in size) are stored merely in SQS. Since it's having
 * less than 256Kb of bytes, it can be directly stored in SQS. There won't be any S3 object to refer the small messages.
 * 
 * 	In addition, the S3 object will be live only for 14 days. If the job is not handling that message within 14 days of
 * time interval then that object will be removed from the S3 without any notification. Because the expiration date
 * is 14 days from the time of message creation.
 * 
 * </p>
 *  
 * @author xavierd
 *
 */
public class AmazonSQSManager {
	
	private static Logger log = LoggerFactory.getLogger(AmazonSQSManager.class);
	
	private static final int DEFAULT_MESSAGE_LENGTH = 262144;
	
	private final String s3BucketName;
	
	private AmazonSQS sqs;
	private AmazonS3Client s3Client; 
    private boolean isStarted = false;
    private String queueUrl;
    
    private boolean isS3BucketExist = true;
    
    public AmazonSQSManager() {
    	this.s3BucketName = null;
    }
    
    public AmazonSQSManager(String s3BucketName) {
    	this.s3BucketName = s3BucketName;
    }
    
    /**
     * Starts the SQS service with S3 Client for large messages.
     * 
     * @return
     * @throws UrjanetSqsException
     */
    public synchronized AmazonSQSManager start() throws UrjanetSqsException {
        
    	if (isStarted) {
            return this;
        }
    	try {
    		sqs = new AmazonSQSClient();
            // Set default region as per sample code
            sqs.setRegion(Region.getRegion(Regions.US_EAST_1));   
            
            s3Client = new AmazonS3Client();
            if(!isS3BucketExist() && s3BucketName != null) {
            	s3Client.createBucket(s3BucketName);
            	isS3BucketExist = true;
            }
    	} catch(Exception e) {
    		throw new UrjanetSqsException("Got exception while starting the sqs service..", e);
    	}
        
        isStarted = true;
        
        return this;
    }
    
    /**
     * Stops both S3 and Sqs service.
     * 
     * @return
     * @throws UrjanetSqsException
     */
    public synchronized AmazonSQSManager stop() throws UrjanetSqsException {
     
    	if (!isStarted) {
            return this;
        }
        
    	try {
    		sqs.shutdown();
    		s3Client.shutdown();
    	} catch(Exception e) {
    		throw new UrjanetSqsException("Got exception while shutdown the SQS service..", e);
    	}
        
        isStarted = false;
        
        return this;
    }
    
    /**
     * Sets the queue 
     * 
     * @param queue
     * @return
     * @throws UrjanetSqsException
     */
    public AmazonSQSManager setQueue(String queue) throws UrjanetSqsException {
     
    	if (!isStarted) {
            throw new UrjanetSqsException("Unable to set queue " + queue + ", since the Sqs Manager is not yet started.");
        }
    	try {
    		// Get the queue url from by its name
    		queueUrl = sqs.getQueueUrl(queue).getQueueUrl();
    	} catch(Exception e) {
    		throw new UrjanetSqsException(e);
    	}
        
        return this;
    }
    
    /**
     * Extends the visibility timeout of the message in case processing is taking longer than expected.  Use this to
     * ensure that the message is not delievered to another consumer if your process is still working on it.
     * 
     * @param queue
     * @param message
     * @param timeout Number of seconds (NOT milliseconds) to reset the message visibility timeout to. 
     *         Will default to 30 seconds.
     * @throws UrjanetSqsException
     */
    public void extendMessage(String queue, UrjanetSQSMessage message, Integer timeout) throws UrjanetSqsException {
 
    	if (!isStarted) {
            throw new UrjanetSqsException("The SQS manager is not yet started..");
        }        
    	try {
    		// Get the queue url from by its name
            String queueUrl = sqs.getQueueUrl(queue).getQueueUrl();
            // If a timeout is passed in, use it, otherwise default to 30 seconds.
            Integer visTimeout = timeout != null ? timeout : 30;
            ChangeMessageVisibilityRequest cmvr = new ChangeMessageVisibilityRequest(queueUrl, message.getReceiptHandle(), visTimeout);
            sqs.changeMessageVisibility(cmvr);
    	} catch(Exception e) {
    		throw new UrjanetSqsException("Got exception while extending the message's visibility..", e);
    	}
    }
    
    /**
     * Confirms successful processing of receieved message by removing it from the Amazon SQS queues.  Otherwise
     * the message will be redelieverd when its visibility timeout is over.
     * 
     * @param queue
     * @param message
     * @throws UrjanetSqsException
     */
    public void confirmMessage(String queue, UrjanetSQSMessage message) throws UrjanetSqsException {
     
    	if (!isStarted) {
            throw new UrjanetSqsException("The SQS manager is not yet started..");
        }
    	try {
    		// Get the queue url from by its name
            String queueUrl = sqs.getQueueUrl(queue).getQueueUrl();
            DeleteMessageRequest dmr = new DeleteMessageRequest(queueUrl, message.getReceiptHandle());
            if(message.getS3Id() != null) {
            	s3Client.deleteObject(s3BucketName, message.getS3Id());
            }
            sqs.deleteMessage(dmr);
    	} catch(Exception e) {
    		throw new UrjanetSqsException("Got exception while deleting the message.." + ((message != null)? message.getClass().getSimpleName() : ""), e);
    	}
        
    }
    
    /**
     * Sends the message to SQS queue.
     * 
     * @param queue
     * @param message
     * @param attributes
     * @param messageClazz
     * @return
     * @throws UrjanetSqsException
     */
    public SendMessageResult sendMessage(String queue, String message, Map<String, String> attributes) throws UrjanetSqsException {
    	
        if (!isStarted) {
            throw new UrjanetSqsException("The SQS manager is not yet started..");
        }
        if(message == null) {
        	throw new UrjanetSqsException("The message should not be null..");
        }
        // Need to wrap any message attributes passed in in the Amazon object
        Map<String, MessageAttributeValue> messageAttributes = null;
        if (attributes != null && attributes.size() > 0) {
        	messageAttributes = new HashMap<String, MessageAttributeValue>();
            for(Entry<String, String> entry : attributes.entrySet()) {
            	MessageAttributeValue attributeValue = new MessageAttributeValue().withDataType("String").withStringValue(entry.getValue());
                messageAttributes.put(entry.getKey(), attributeValue);
            }
        }
        try {
        	boolean isLargeMessage = isLargeMessage(message, messageAttributes);
            //Enable this option only for production environment.
            if(isLargeMessage && UrjanetProperties.ENV_PRODUCTION.equals(getEnvName())) {
            	//Put the large message into S3 and generate a small message to send it into SQS.
            	String s3Id = putIntoS3Bucket(message);
            	message = getSmallMessage(message).setS3Id(s3Id).toJson();
            }
            //Get the queue url from by its name
            String queueUrl = sqs.getQueueUrl(queue).getQueueUrl();
            SendMessageRequest smr = new SendMessageRequest(queueUrl, message);
            if(messageAttributes != null) {
            	smr.setMessageAttributes(messageAttributes);
            }
            SendMessageResult result = sqs.sendMessage(smr);
            
            return result;
        } catch(Exception e) {
        	throw new UrjanetSqsException("Got exception while sending the message to queue -> " + queue, e);
        }
    }
    
    /**
     * Puts the message into s3 bucket and return the corresponding s3 id.
     * 
     * @param messageBody
     * @return 
     * @throws UrjanetSqsException
     */
    private String putIntoS3Bucket(final String messageBody) throws UrjanetSqsException {
    	
    	if(s3BucketName == null) {
    		throw new UrjanetSqsException("The S3 Bucket name is null.. You can't send large messages.. The message size exceeds the limit of 256kb..");
    	}
    	if(messageBody == null) {
    		throw new UrjanetSqsException("The message body should not be null..");
    	}
    	
    	try {
        	String s3Id = generateS3Key();
        	ObjectMetadata metaData = new ObjectMetadata();
        	Calendar cal = Calendar.getInstance();
        	cal.add(Calendar.DAY_OF_MONTH, 14);
        	//The message should be deleted from s3 if it's not processed within 14 days of time interval.
        	metaData.setExpirationTime(cal.getTime());
        	s3Client.putObject(s3BucketName, s3Id, new ByteArrayInputStream(messageBody.getBytes(Charset.forName("UTF-8"))), metaData);
        	
        	return s3Id;
        	
    	} catch(Exception e) {
    		throw new UrjanetSqsException("Got exception while putting the message into S3 Bucket -> " + s3BucketName, e);
    	}
    }
    
    
   /**
    * 
    * @param s3Id
    * 
    * @return a Small message and that size should be less than 256kb.
    */
    protected UrjanetSQSMessage getSmallMessage(final String originalMessage) {
    	
    	return new UrjanetSQSMessage();
    }
    
    /**
     * 
     * @return the current environment name
     */
    protected String getEnvName() {
    	return UrjanetProperties.get().getDeploymentName();
    }
    
    /**
     * Receives the message from the specified Queue.
     * 
     * @param queue
     * @param messageClazz
     * @return
     * @throws UrjanetSqsException
     */
	public List<? extends UrjanetSQSMessage> receiveMessages(String queue) throws UrjanetSqsException {
		
		if (!this.isStarted) {
			throw new UrjanetSqsException("The SQS manager is not yet started..");
		}
		try {
			String queueUrl = this.sqs.getQueueUrl(queue).getQueueUrl();

			ReceiveMessageRequest rmr = new ReceiveMessageRequest(queueUrl);
			rmr.setAttributeNames(Arrays.asList(new String[] { "All" }));
			rmr.setMessageAttributeNames(Arrays.asList(new String[] { "All" }));

			ReceiveMessageResult result = this.sqs.receiveMessage(rmr);
			List<UrjanetSQSMessage> messages = new ArrayList<>();
			
			for (Message message : result.getMessages()) {
				
				UrjanetSQSMessage coreUrjaMessage = new UrjanetSQSMessage(message);
				
				UrjanetSQSMessage s3Message = null;
				try {
					s3Message = UrjanetSQSMessage.fromJson(coreUrjaMessage.getBody());
				} catch(Exception e) {}
				
				if(s3Message != null && s3Message.getS3Id() != null) {
					if(s3BucketName == null) {
						throw new UrjanetSqsException("There is a S3 Id [" + s3Message.getS3Id() + "] attached with the message.. But the s3Bucket name is not mentioned..");
					}
					S3Object s3Object = s3Client.getObject(s3BucketName, s3Message.getS3Id());
					InputStream s3Stream = s3Object.getObjectContent();
					String s3MsgBody = "";
					Scanner scan = new Scanner(s3Stream, "UTF-8");
					scan.useDelimiter("\\A");
					while(scan.hasNext()) {
						s3MsgBody = s3MsgBody + scan.next();
					}
					scan.close();
					
					//Set the s3 message to the actual message.
					coreUrjaMessage.setS3Id(s3Message.getS3Id());
					coreUrjaMessage.setBody(s3MsgBody);
					coreUrjaMessage.setMD5OfBody(DigestUtils.md5Hex(s3MsgBody));
					
					//Clear S3Message
					s3Message = null;
				} 
			
				//If possible, convert the message body into UrjanetSQSMessage.
				//If the posted message is an instance of UrjanetSqsMessage(Json format) then, it's convertible
				//to UrjanetSqsMessage. Otherwise, it may be a raw message.. Just leave it as exist.
				try {
					UrjanetSQSMessage urjaSqsMessage = UrjanetSQSMessage.fromJson(coreUrjaMessage.getBody());
					urjaSqsMessage.copyMessageProperties(coreUrjaMessage);
					coreUrjaMessage = urjaSqsMessage;
				} catch(Exception e) { }
				
				messages.add(coreUrjaMessage);
			}

			return messages;
			
		} catch(Exception e) {
			throw new UrjanetSqsException("Got exception while receiving the message from queue -> " + queue, e);
		}
	}
	
	/**
	 * 
	 * @param queueName
	 * @return a Newly created queue.
	 */
	public String createQueue(String queueName) throws UrjanetSqsException {
		
		if (!this.isStarted) {
			throw new UrjanetSqsException("The SQS manager is not yet started..");
		}
		
		try {
			CreateQueueResult result = sqs.createQueue(queueName);

			return result.getQueueUrl();
		} catch(Exception e) {
			throw new UrjanetSqsException("Got exception while creating a queue -> " + queueName, e);
		}
	}
	
	/**
	 * Delete an existing queue.
	 * 
	 * @param queueName
	 * @param messageClazz
	 * @throws UrjanetSqsException
	 */
	public void deleteQueue(String queueName) throws UrjanetSqsException {
		
		if (!this.isStarted) {
			throw new UrjanetSqsException("The SQS manager is not yet started..");
		}
		
		try {
			String queueUrl = this.sqs.getQueueUrl(queueName).getQueueUrl();
			try {
				//Deletes the existing message one by one and then delete the queue.
				//Because there may a message which may refer the S3 bucket for large message.
				List<? extends UrjanetSQSMessage> allMessages = null;
				
				while((allMessages = receiveMessages(queueName)) != null && allMessages.size() > 0) {
					
					for(UrjanetSQSMessage message : allMessages) {
						confirmMessage(queueName, message);
					}
				}
			} catch(Exception e) {
				log.error("Error occurred while clean up the messages one by one.. ", e);
			}
			sqs.deleteQueue(new DeleteQueueRequest(queueUrl));
		} catch(Exception e) {
			throw new UrjanetSqsException("Got exception while deleting the queue -> "+ queueName, e);
		}
	}
	
	/**
	 * 
	 * @param queueUrl
	 * @return All Queue attributes.
	 * @throws UrjanetSqsException 
	 */
	public GetQueueAttributesResult getQueueAttributes(String queueUrl) throws UrjanetSqsException {
		
		if (!this.isStarted) {
			throw new UrjanetSqsException("The SQS manager is not yet started..");
		}
		
		try {
			GetQueueAttributesResult result = sqs.getQueueAttributes(new GetQueueAttributesRequest(queueUrl).withAttributeNames("All"));
			
			return result;
		} catch(Exception e) {
			throw new UrjanetSqsException("Got exception while getting all attributes of a queue.." + queueUrl, e);
		}
		
	}
	
	/**
	 * 
	 * @return a queue url if already set.
	 */
	public String getQueueUrl() {
		return queueUrl;
	}
	
	/**
	 * Check whether the incoming message is large or not.
	 * 
	 * @param messageBody
	 * @param messageAttributes
	 * @return
	 */
	private boolean isLargeMessage(final String messageBody, final Map<String, MessageAttributeValue> messageAttributes) {
		
		long length = getStringSizeInBytes(messageBody);
		length += getMsgAttributesSize(messageAttributes);
		
		//Let's decrease 10Kb from the default size to reduce false positives. 
		int buffer = 10240;
		log.info("The message size is : " + (length / 1024) + "Kb");
		return length >= (DEFAULT_MESSAGE_LENGTH - buffer);
	}
	
	/**
	 * 
	 * @param messageAttributes
	 * @return
	 */
	private int getMsgAttributesSize(Map<String, MessageAttributeValue> messageAttributes) {
		
		int totalMsgAttributesSize = 0;
		if(messageAttributes == null || messageAttributes.size() <=0) {
			return totalMsgAttributesSize;
		}
		for (Entry<String, MessageAttributeValue> entry : messageAttributes.entrySet()) {
			totalMsgAttributesSize += getStringSizeInBytes(entry.getKey());

			MessageAttributeValue entryVal = entry.getValue();
			if (entryVal.getDataType() != null) {
				totalMsgAttributesSize += getStringSizeInBytes(entryVal.getDataType());
			}

			String stringVal = entryVal.getStringValue();
			if (stringVal != null) {
				totalMsgAttributesSize += getStringSizeInBytes(entryVal.getStringValue());
			}

			ByteBuffer binaryVal = entryVal.getBinaryValue();
			if (binaryVal != null) {
				totalMsgAttributesSize += binaryVal.array().length;
			}
		}
		
		return totalMsgAttributesSize;
	}
	    
	/**
	 * 
	 * @param messageBody
	 * @return
	 */
	private long getStringSizeInBytes(final String messageBody) {
		
		if(messageBody == null) {
			return 0l;
		}
//		return messageBody.getBytes(Charset.forName("UTF-8")).length;
		CountingOutputStream countingOutputStream = new CountingOutputStream();
		try {
			Writer writer = new OutputStreamWriter(countingOutputStream, "UTF-8");
			writer.write(messageBody);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			throw new AmazonClientException("Unable to calculate the size of the message..", e);
		}
		return countingOutputStream.getTotalSize();
	}

	/**
	 * 
	 * @return a Random UUID to identify the S3 Key for a particular message.
	 */
	private String generateS3Key() {
		
		UUID uuid = UUID.randomUUID();
		
		return uuid.toString();
	}
	
	protected boolean isS3BucketExist() {
		return isS3BucketExist;
	}

	protected AmazonSQS getSqsClient() {
		return sqs;
	}

	private static class CountingOutputStream extends OutputStream {

		private long totalSize;

		@Override
		public void write(int b) {
			++totalSize;
		}

		@Override
		public void write(byte[] b) {
			totalSize += b.length;
		}

		@Override
		public void write(byte[] b, int offset, int len) {
			totalSize += len;
		}

		public long getTotalSize() {
			return totalSize;
		}
	}

	/**
     * Testing main
     * 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        
    	String queue = "test_queue-urja";
        
        AmazonSQSManager sqsManager = new AmazonSQSManager("daq-sqs-split-job").start();
        sqsManager.createQueue(queue);
        
        System.out.println("Sending message ...");
        
        Map<String, String> attr = new HashMap<String, String>();
        attr.put("Attribute_1", "Value 1");
        attr.put("attribute_2", "Value 2");

        Scanner scan = new Scanner(new File("/home/xavierd/Desktop/text.txt"));
        scan.useDelimiter("\\A");
        String body = "";
        while(scan.hasNext()) {
        	body = body + scan.next();
        }
        scan.close();
//        SampleMessage sqsMessage = new SampleMessage("Urjanet", body);
//        UrjanetSQSMessage sqsMessage = new SampleMessage("Urjanet", "Energy Solutions");

        sqsManager.sendMessage(queue, "Urjanet Energy Solutions Pvt. Ltd.,", /*body, *//*sqsMessage.toJson(),*/ attr);
        System.out.println("Message sent!");
        
        System.out.println("Receiving messages ...");
        List<? extends UrjanetSQSMessage> messages = sqsManager.receiveMessages(queue);
        
        for (UrjanetSQSMessage message : messages) {
        	
//        	SampleMessage sMsg = (SampleMessage)message;
        	
//        	System.out.println("Sample Message.." + sMsg.getName());
        	
            System.out.println("-----Message-----");
            System.out.println("Body : " + message.getBody());
            System.out.println("Body Md5 checksum : " + message.getMD5OfBody());
            System.out.println("Message Id : " + message.getMessageId());
            System.out.println("Message Receipt Handle : " + message.getReceiptHandle());
            System.out.println("Attributes : " + message.getAttributes());
            System.out.println("Message Attributes : " + message.getMessageAttributes());
            System.out.println("Message Attributes MD5 checksum : " + message.getMD5OfMessageAttributes());
            System.out.println("S3 Id -> " + message.getS3Id());
//            System.out.println("S3 ID -> " + sMsg.getS3Id());
            System.out.println("Time stamp : " + new Date(message.getTimestamp()));
            System.out.println("----------\n");
            
            /*if(message instanceof SampleMessage) {
            	System.out.println("Sample Message : " + message.toString());
            }*/
            
            System.out.println("Confirming message ...");
            sqsManager.confirmMessage(queue, message);
            System.out.println("Message confirmed!");
        }        
        System.out.println("All messaged recieved");        
        
        sqsManager.deleteQueue(queue);
        
        sqsManager.stop();
    }
}
