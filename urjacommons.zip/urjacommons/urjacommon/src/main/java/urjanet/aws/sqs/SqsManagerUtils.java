package urjanet.aws.sqs;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;

/**
 * 
 * @author xavierd
 *
 */
public final class SqsManagerUtils {

	private static Logger log = LoggerFactory.getLogger(SqsManagerUtils.class);
	
	//Don't let anyone create an instance from outside.
	private SqsManagerUtils() {
		
	}
	
	/**
	 * Checks whether the mentioned s3 bucket name is exist or not.
	 * 
	 * @param s3BucketName
	 * @param authCredentials
	 * @return
	 * @throws AmazonClientException
	 */
	public static boolean isS3BucketExist(final String s3BucketName) throws AmazonClientException {
		
		try {
    		AmazonS3Client localS3Client = null;
        	try {
        		localS3Client = new AmazonS3Client(); 
        		List<Bucket> allBuckets = localS3Client.listBuckets();
                for(Bucket bucket : allBuckets) {
                	if(s3BucketName.equals(bucket.getName())) {
                		return true;
                	}
                }
        	} catch(Exception e) {
        		log.error("Got exception while listing the existing S3 buckets..", e);
        	} finally {
        		if(localS3Client != null) {
        			localS3Client.shutdown();
        		}
        	}
		} catch(Exception e) {
			throw new AmazonClientException(e.getCause());
		}
		
		return false;
	}
	
}
