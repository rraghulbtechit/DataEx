package urjanet.aws;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.amazonaws.services.ec2.model.GroupIdentifier;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Tag;

public class EC2InstanceDto {

	private String instanceId;
	private String instanceType;
	private String amiId;
	private List<String> securityGroups = new ArrayList<String>();
	private List<String> tags = new ArrayList<String>();
	private Date launchDate;
	private String architecture;
	private String platform;
	private String state;
	private String publicDns;
	
	public EC2InstanceDto() {
		
	}
	
	public EC2InstanceDto(Instance instance) {
		this.instanceId = instance.getInstanceId();
		this.amiId = instance.getImageId();
		this.instanceType = instance.getInstanceType();
		this.architecture = instance.getArchitecture();
		this.platform = instance.getPlatform();
		this.state = instance.getState().getName();
		this.publicDns = instance.getPublicDnsName();
		

		for (Tag tag : instance.getTags()) {
			tags.add(tag.getKey() + "=" + tag.getValue());
		}
		
		for (GroupIdentifier group : instance.getSecurityGroups()) {
			securityGroups.add(group.getGroupName());
		}
		
		this.launchDate = instance.getLaunchTime();
	}
	
}
