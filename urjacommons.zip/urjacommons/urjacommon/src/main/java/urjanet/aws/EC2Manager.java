package urjanet.aws;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.DescribeInstanceStatusRequest;
import com.amazonaws.services.ec2.model.DescribeInstanceStatusResult;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Filter;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceState;
import com.amazonaws.services.ec2.model.InstanceStateName;
import com.amazonaws.services.ec2.model.InstanceStatus;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class EC2Manager {
    private static Logger log = LoggerFactory.getLogger(EC2Manager.class);
    
    private AmazonEC2 ec2;
    
    public void startEC2() {
        // TODO: replace with non-personal credentials
        AWSCredentials creds = new BasicAWSCredentials("AKIAJU2CQPVDLHJLJZSA", "pwgNFrfyTC2+ZL4uvI9sXtMAqVHcSKyt6OayXXqf");
        ec2 = new AmazonEC2Client(creds);
    }
    
    public String getDetails(String instanceId) {
    	Instance instance = getInstance(instanceId);
    	
    	String host = instance.getPublicDnsName();
    	String username = "ubuntu";
    	String keyLocation = "/home/" + System.getProperty("user.name") + "/.ssh/" + instance.getKeyName() + ".pem";

        UrjaSsh sshClient = new UrjaSsh(host, username, keyLocation);
        String output = sshClient.executeCommand("jps -lvm");
        sshClient.stop();
        
        return output;
    }
    
    public String getStackTrace(String instanceId, String pid) {
    	Instance instance = getInstance(instanceId);
    	
    	String host = instance.getPublicDnsName();
    	String username = "ubuntu";
    	String keyLocation = "/home/" + System.getProperty("user.name") + "/.ssh/" + instance.getKeyName() + ".pem";

        UrjaSsh sshClient = new UrjaSsh(host, username, keyLocation);
        String output = sshClient.executeCommand("jstack " + pid);
        sshClient.stop();
        
        return output;
    }
    
    public List<EC2InstanceDto> getInstances() {
    	List<EC2InstanceDto> instances = new ArrayList<EC2InstanceDto>();
        
        DescribeInstancesResult describeInstancesResult = ec2.describeInstances();
        
        List<Reservation> reservations = describeInstancesResult.getReservations();
        for (Reservation reservation : reservations) {
            List<Instance> list = reservation.getInstances();
            
            for (Instance i : list) {
            	instances.add(new EC2InstanceDto(i));
            }
        }
       
        return instances;
    }
    
    public List<Instance> getInstances(List<String> instanceIds) {
        List<Instance> instances = new ArrayList<Instance>();
        
        DescribeInstancesRequest describeInstancesRequest = new DescribeInstancesRequest()
            .withInstanceIds(instanceIds);
        
        DescribeInstancesResult describeInstancesResult = ec2.describeInstances(describeInstancesRequest);
        
        List<Reservation> reservations = describeInstancesResult.getReservations();
        for (Reservation reservation : reservations) {
            List<Instance> currentInstances = reservation.getInstances();
            for (Instance instance : currentInstances) {
                instances.add(instance);
            }
        }        
       
        return instances;
    }
    
    public Instance getInstance(String instanceId) {
        Instance instance = null;
        
        List<Instance> instances = getInstances(Arrays.asList(instanceId));
        if (instances != null && !instances.isEmpty()) {
            instance = instances.get(0);
        }
        
        return instance;
    }
    
    public Instance getInstanceByName(String name) {
        Map<String, String> nameTag = new HashMap<String, String>();
        nameTag.put("Name", name);
        
        List<Instance> instances = getInstancesByTags(nameTag);
        if (instances != null && instances.size() > 0) {
            return instances.get(0);
        } else {
            return null;
        }
    }
    
    public List<Instance> getInstancesByTags(Map<String, String> tags) {
        List<Instance> instances = new ArrayList<Instance>();
        List<Filter> filters = new ArrayList<Filter>();
        
        for (Map.Entry<String, String> entry : tags.entrySet()) {
            Filter tempFilter = new Filter("tag:"+entry.getKey(), Arrays.asList(entry.getValue()));
            filters.add(tempFilter);
        }
        
        DescribeInstancesRequest describeInstanceRequest = new DescribeInstancesRequest().withFilters(filters);
        DescribeInstancesResult instanceResult = ec2.describeInstances(describeInstanceRequest);
        
        for (Reservation reservation : instanceResult.getReservations()) {
            if (reservation.getInstances() != null) {
                instances.addAll(reservation.getInstances());
            }
        }
        
        return instances;
    }
    
    public void terminateInstance(String instanceId) {
        TerminateInstancesRequest terminateRequest = new TerminateInstancesRequest().withInstanceIds(instanceId);

        TerminateInstancesResult terminateResult = ec2.terminateInstances(terminateRequest);
    }
    
    public Instance createInstance(String instanceType, String imageId, String securityGroup, String keyName, String instanceName) {
        RunInstancesRequest runInstanceRequest = new RunInstancesRequest();
        runInstanceRequest.withInstanceType(instanceType)
            .withImageId(imageId)
            .withMinCount(1)
            .withMaxCount(1)
            .withSecurityGroupIds(securityGroup)
            .withKeyName(keyName);
        
        RunInstancesResult runInstancesResult = ec2.runInstances(runInstanceRequest);

        if (runInstancesResult != null && runInstancesResult.getReservation() != null) {
            List<Instance> instances = runInstancesResult.getReservation().getInstances();
            
            if (instances != null && !instances.isEmpty()) {
                Instance instance = instances.get(0);
                String instanceId = instance.getInstanceId();

                // EC2 is crazy sometimes and won't see a newly created instance immediatly after the request so we need to sit here and loop until 
                // Amazon sees the new instance otherwise the createTag request below will throw and exception.
                Instance instanceCreatedCheck = getInstance(instanceId);
                while (instanceCreatedCheck == null) {
                    instanceCreatedCheck = getInstance(instanceId);
                }
                
                CreateTagsRequest tagRequest = new CreateTagsRequest();
                tagRequest.withResources(instanceId).withTags(new Tag("Name", instanceName));
                ec2.createTags(tagRequest);
                
                return instance;
            }

        }
        
        return null;
    }

    public void addTags(Instance instance, Map<String, String> tagValues) {
        Set<Tag> tags = new HashSet<Tag>(tagValues.size());
        
        for (Entry<String, String> entry : tagValues.entrySet()) {
            tags.add(new Tag(entry.getKey(), entry.getValue()));
        }
        
        CreateTagsRequest tagRequest = new CreateTagsRequest();
        tagRequest.withResources(instance.getInstanceId()).withTags(tags);        
        ec2.createTags(tagRequest);
    }
    
    public String getTagValue(Instance instance, String tagKey) {
        for (Tag tag : instance.getTags()) {
            if (StringUtils.equals(tag.getKey(), tagKey)) {
                return tag.getValue();
            }
        }
    
        return null;
    }
    
    public boolean isInstanceReady(String instanceId) {
        DescribeInstanceStatusRequest statusRequest = new DescribeInstanceStatusRequest().withInstanceIds(instanceId);
        DescribeInstanceStatusResult statusResult = ec2.describeInstanceStatus(statusRequest);

        if (statusResult.getInstanceStatuses() != null && statusResult.getInstanceStatuses().size() > 0) {
            InstanceStatus status = statusResult.getInstanceStatuses().get(0);
            if (StringUtils.equals(status.getInstanceState().getName(), InstanceStateName.Running.toString())) {
                if (StringUtils.equals(status.getInstanceStatus().getStatus(), "ok")) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isInstanceShuttingDown(String instanceId) {
        Instance instance = getInstance(instanceId);
        
        if (instance != null) {
            InstanceState state = instance.getState();
            
            return StringUtils.equals(state.getName(), InstanceStateName.ShuttingDown.toString()) ||
            StringUtils.equals(state.getName(), InstanceStateName.Stopped.toString()) ||
            StringUtils.equals(state.getName(), InstanceStateName.Stopping.toString()) ||
            StringUtils.equals(state.getName(), InstanceStateName.Terminated.toString());
        }
        
        return true;
    }
}
