package urjanet.aws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import urjanet.UrjanetException;

public class UrjanetLocalWorker extends UrjanetWorker {
    private Process p;
    private Thread t;
    
    public UrjanetLocalWorker(String name, String workerClassPath) {
        super(name, workerClassPath);
    }

    @Override
    public void startInstance() throws UrjanetException {
    }

    @Override
    public void initializeWorker() {
    }

    @Override
    public void terminateInstance() {
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        while (true) {
            int c = in.read();
            if (c == -1) {
                break;
            }
            out.write((char) c);
        }
    }
    
    @Override
    public void startWorker() {
        try {
            String cleanName = getName().replace(" ", "_");

            ProcessBuilder pb = new ProcessBuilder();

            Map<String, String> env = pb.environment();
            
            List<String> cmds = new ArrayList();
            cmds.add("java");
            cmds.addAll(Arrays.asList(env.get("JVM_OPTS").split(" ")));
            cmds.add("urjanet.pull.async.ExtractWorker");
            
            pb.command(cmds);
            pb.directory(new File("/opt/urjanet_platform/trunk"));
            
            File log = new File("~/" + cleanName + ".log");
            pb.redirectErrorStream(true);
            
            System.out.println("starting process");
            p = pb.start();
            
            t = new Thread(new Runnable() {

                @Override
                public void run() {
                    try {
                        copy(p.getInputStream(), System.out);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                
            });
            
            t.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void stopWorker() {
        try {
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
            bw.write("cmd /c");
            
            p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void runCommand(String command) {
    }
    
    public static void main(String[] args) throws Exception {
        UrjanetLocalWorker localWorker = new UrjanetLocalWorker("test", "urjanet.pull.async.ExtractWorker");
        System.out.println("Starting worker");
        localWorker.startWorker();
        System.out.println("Startup finished, sleepign 5 sec");
        Thread.sleep(5000);
        System.out.println("Stopping worker");
        localWorker.stopWorker();
        
        
    }

}
