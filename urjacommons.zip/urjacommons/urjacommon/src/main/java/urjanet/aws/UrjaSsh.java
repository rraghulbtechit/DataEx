package urjanet.aws;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.environment.UrjanetProperties;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class UrjaSsh {
    public enum SshEnviroment {
        STAGING, PRODUCTION 
    }
    
    private static Logger log = LoggerFactory.getLogger(UrjaSsh.class);
    
    private String host;
    private String username;
    private String keyLocation;
    Session session;
    
    private ChannelExec asyncChannel;
    private Session asyncSession;
    private boolean runningAsync;
    
    public UrjaSsh() {
        super();
    }
    
    public UrjaSsh(SshEnviroment env) {
        super();
        
        String envMod = "";
        
        switch (env) {
        case STAGING: 
            envMod = "staging";
            break;
        case PRODUCTION:
            envMod = "prod";
        }
        
        UrjanetProperties props = UrjanetProperties.get();
        
        this.host = props.getProperty("ssh."+envMod+".url");
        this.username = props.getProperty("ssh."+envMod+".user");
        this.keyLocation = props.getProperty("ssh.keylocation") + props.getProperty("ssh."+envMod+".key");        
    }
    
    public UrjaSsh(String host, String username, String keyLocation) {
        super();
        this.host = host;
        this.username = username;
        this.keyLocation = keyLocation;
    }

    public static void main(String[] args) throws Exception {
//        String host = "ec2-50-16-181-195.compute-1.amazonaws.com";
//        String username = "ubuntu";
//        String keyLocation = "/home/styner/.ssh/rainforeststagingkeypair.pem";
//        String password = "";
        
//        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
//        new UrjaSsh(host, username, keyLocation).executeCommand("ls -lrat", byteArray);
//        System.out.println(byteArray.toString());
        
//        UrjaSsh sshClient = new UrjaSsh(host, username, keyLocation);
//        File logFile = new File("/home/styner/SPENCE_SSH_TEST_FILE.log");
//        FileOutputStream fos = new FileOutputStream(logFile);
//        sshClient.executeAsyncCommand("ls -lrat", fos);
        
//        Thread.sleep(3000);
//        sshClient.closeAsyncConnection();
        
        
        UrjaSsh sshClient = new UrjaSsh("ec2-50-16-181-195.compute-1.amazonaws.com", "ubuntu", "/home/styner/.ssh/rainforeststagingkeypair.pem");
//        File testDownload = new File("/home/styner/TESTSCPFILE2");
//        FileOutputStream fos = new FileOutputStream(testDownload);
//        System.out.println("executing command");
//        sshClient.scp("/opt/data/AcctTrack/UPS/reports/ActTrkUPS2014_05_20.csv", fos);
        
//        sshClient.sftpFrom("/opt/data/AcctTrack/UPS/reports/ActTrkUPS2014_05_20.csv", fos);
//        System.out.println("command done");
//        fos.close();
        
//        String output = sshClient.executeCommand("ll -t /opt/data/AcctTrack/UPS/reports/ | grep ActTrk.*csv");
        String output = sshClient.executeCommand("cd /opt/data/AcctTrack/UPS/reports/; ls -lt --time-style=+%Y-%m-%d::%H:%M | grep ActTrk.*csv");
        System.out.println(output);
        sshClient.stop();
        System.exit(0);
    }
    
    public void closeAsyncConnection() {
        if (runningAsync) {
            runningAsync = false;
            asyncChannel.disconnect();
            asyncSession.disconnect();
        }
    }
    
    public void closeAsyncChannel() {
    	if (runningAsync) {
    		runningAsync = false;
    		asyncChannel.disconnect();
    	}
    }
    
    public ChannelExec getAsyncChannel() {
    	return asyncChannel;
    }
    
    public void executeAsyncCommand(String command, OutputStream output) {
        if (runningAsync) {
            log.error("Already running an asyncronous command with this SSH instance");
            return;
        }
        
        try {
            runningAsync = true;
            asyncSession = getSshSession();

            asyncChannel = (ChannelExec) asyncSession.openChannel("exec");
            asyncChannel.setCommand(command);
            asyncChannel.setInputStream(null);
            asyncChannel.setOutputStream(output);
            
            asyncChannel.connect();
        } catch (JSchException je) {
            log.error("JSch Error", je);
            runningAsync = false;
        } finally {

        } 
    }
    
    /**
     * Sftp file from remote, much simpler and sturdy than scp
     * 
     * @param filePath
     * @param out
     */
    public void sftpFrom(String filePath, OutputStream out) {
        ChannelSftp channel = null;
        
        try {
            Session session = getSshSession();
            
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            
            channel.get(filePath, out);
        } catch (Exception e) {
            log.error("error downloading file!", e);
        } finally {
            if (channel != null) {
                channel.disconnect();
            }
        }
    }
    
    /**
     * Scp file from remote to local.  Fragile, consider sftp instead.
     * 
     * @param filePath
     * @param output
     */
    public void scpFrom(String filePath, OutputStream output) {
        ChannelExec channel = null;
        
        try {
            Session session = getSshSession();

            channel = (ChannelExec) session.openChannel("exec");
            
            String scp = "scp -f " + filePath;
            
            channel.setCommand(scp);
            channel.setInputStream(null);
            channel.setOutputStream(null);
            InputStream commandIn = channel.getInputStream();
            OutputStream commandOut = channel.getOutputStream();

            channel.connect();

            commandOut.write(0);
            commandOut.flush();
            String header = readLine(commandIn);
            int length = Integer.parseInt(header.substring(6, header.indexOf(' ', 6)));
            
            // send '\0'
            commandOut.write(0);
            commandOut.flush();
            
            int bytesRemaining = length;
            byte[] bytes = new byte[2048];
            
            while (true) {
                int readLength = Math.min(bytesRemaining, 2048);
                int bytesRead = commandIn.read(bytes, 0, readLength);
                
                output.write(bytes);
                output.flush();
                
                bytesRemaining -= bytesRead;
                
                if (bytesRemaining == 0) {
                    break;
                }
            }
            
            if (0 != commandIn.read()) {
                log.error("End of stream not detected!");
            } else {
                commandOut.write(0);
                commandOut.flush();
            }
        } catch (JSchException je) {
            log.error("JSch Error", je);
        } catch (IOException ioe) {
            log.error("IO Error", ioe);
        } finally {
            if (channel != null) {
                channel.disconnect();
            }
        }      
    }
    
    private String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        while(true) {
            int c = in.read();
            if (c == '\n') {
                return baos.toString();
            } else if (c == -1) {
                throw new IOException("End of stream");
            } else {
                baos.write(c);
            }
        }
    }
    
    public void executeCommand(String command, OutputStream output) {
        try {
            Session session = getSshSession();

            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);
            channel.setInputStream(null);
            channel.setOutputStream(null);
            InputStream commandOutput = channel.getInputStream();

            channel.connect();

            byte[] bytes = new byte[1024];
            int bytesRead = commandOutput.read(bytes);
            while (bytesRead > 0) {
                output.write(bytes, 0, bytesRead);
                bytesRead = commandOutput.read(bytes);
            }

            channel.disconnect();
        } catch (JSchException je) {
            log.error("JSch Error", je);
        } catch (IOException ioe) {
            log.error("IO Error", ioe);
        } finally {

        }       
    }
    
    public String executeCommand(String command) {
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        executeCommand(command, byteArray);
        return byteArray.toString();
    }
  
    public UrjaSsh stop() {
        if (session != null) {
            session.disconnect();
            session = null;
        }
        return this;
    }
    
    public UrjaSsh start() {
        try {
            getSshSession();
        } catch (JSchException e) {
            log.error("Error starting session", e);
        }
        
        return this;
    }
    
    private Session getSshSession() throws JSchException {
        if (session != null) {
            return session;
        }
        
        JSch jsch = new JSch();
        jsch.addIdentity(keyLocation);

        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        
        session = jsch.getSession(username, host);
        session.setConfig(config);
        session.connect();
       
        return session;
    }
}
