package urjanet.aws;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.UrjanetException;
import urjanet.environment.UrjanetProperties;

import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceType;

public class UrjanetWorker {
    public enum UrjanetWorkerState {
        STOPPING, STOPPED, STARTING, STARTED, INITIALIZING, INITIALIZED, UNINITIALIZED, TERMINATING, TERMINATED;
    }
    
    private static Logger log = LoggerFactory.getLogger(UrjanetWorker.class);
    private static final String START_UP_SCRIPT = "/home/ubuntu/initializeSlave.sh";
    
    private String name;
    private String ec2InstanceId;
    private EC2Manager ec2;
    private UrjaSsh ssh;
    private volatile UrjanetWorkerState state;
    private String workerClassPath;
    
    private String sshKeyLocation;
    private String sshKey;
    private String sshUser;
    private String ec2MachineType;
    private String ec2GroupName;
    private String ec2Key;
    private String ec2Ami;
    private String ec2MasterUrl;
    
    public UrjanetWorker(String name, String workerClassPath) {
        super();
        
        this.name = name;
        this.workerClassPath = workerClassPath;
        
        ec2 = new EC2Manager();
        ec2.startEC2();
        state = UrjanetWorkerState.UNINITIALIZED;
        
        ec2MachineType = UrjanetProperties.get().getProperty("ec2worker.machinetype");
        ec2GroupName = UrjanetProperties.get().getProperty("ec2worker.securitygroup");
        ec2Key = UrjanetProperties.get().getProperty("ec2worker.keyname");
        ec2Ami = UrjanetProperties.get().getProperty("ec2worker.ami");
        ec2MasterUrl = UrjanetProperties.get().getProperty("ec2worker.masterUrl");
        sshKeyLocation = UrjanetProperties.get().getProperty("ec2worker.ssh.keylocation");
        sshKey = UrjanetProperties.get().getProperty("ec2worker.ssh.key");
        sshUser = UrjanetProperties.get().getProperty("ec2worker.ssh.user");
    }

    public UrjanetWorker(String name, String workerClassPath, String ec2InstanceId) {
        this(name, workerClassPath);
        this.ec2InstanceId = ec2InstanceId;
    }
    
    public void fullStart() throws UrjanetException {
        startInstance();
        initializeWorker();
        startWorker();
    }
    
    public void fullStop() throws UrjanetException {
        stopWorker();
        terminateInstance();
    }

    public void startInstance() throws UrjanetException {
        Instance instance = null;
        if (StringUtils.isBlank(ec2InstanceId)) {
            log.info("Starting new EC2 instance");
            instance = ec2.createInstance(ec2MachineType, ec2Ami, ec2GroupName, ec2Key, name);
            ec2InstanceId = instance.getInstanceId();
            
            Map<String, String> tags = new HashMap<String, String>();
            tags.put("UrjanetType", "DynamicWorker");
            tags.put("WorkerType", workerClassPath);
            ec2.addTags(instance, tags);
            log.info("EC2 instance created, instanceId: " + ec2InstanceId);
        } else {
            log.info("Looking up instance for instanceId: " + ec2InstanceId);
            instance = ec2.getInstance(ec2InstanceId);
        }  
        
        if (instance == null) {
            log.error("EC2 instance could not be created or found!");
            throw new UrjanetException("Could not create or find EC2 instance");
        }
    }
    
    public void initializeWorker() {
        state = UrjanetWorkerState.INITIALIZING;
        // Wait for EC2 instance to be started and initialzed on Amazon's end
        boolean instanceReady = ec2.isInstanceReady(ec2InstanceId);
        System.out.println("instanceReady? " +instanceReady);
        try {
            while (!instanceReady) {
                Thread.sleep(5*1000);
                instanceReady = ec2.isInstanceReady(ec2InstanceId);
                System.out.println("instanceReady? " +instanceReady);
            }
            
            Instance instance = ec2.getInstance(ec2InstanceId);
            
            ssh = new UrjaSsh(instance.getPublicDnsName(), sshUser, sshKeyLocation + instance.getKeyName() +".pem");

        } catch (InterruptedException e) {
            log.error("Error waiting on Amazon instance to become ready", e);
        }
        
        // Check to see if the instance has already been initialized
        String startedCheckOutput = ssh.executeCommand("find /home/ubuntu -name worker_started");
        
        if (StringUtils.contains(startedCheckOutput, "worker_started")) {
            log.info("Worker already initilized, skipping sync.");            
        } else {
            // Run environmental startup script
            log.info("Worker not initilized, starting sync");
            String startupCommand = START_UP_SCRIPT + " " + ec2MasterUrl + " " + sshKey;
            startupCommand += "; touch /home/ubuntu/worker_started";
            ssh.executeCommand(startupCommand, System.out);

        }
        
        state = UrjanetWorkerState.INITIALIZED;
    }

    public void terminateInstance() {
        state = UrjanetWorkerState.TERMINATING;
        if (StringUtils.isNotBlank(ec2InstanceId)) {
            if (!ec2.isInstanceShuttingDown(ec2InstanceId)) {
                ec2.terminateInstance(ec2InstanceId);
            }
        }
        state = UrjanetWorkerState.TERMINATED;
    }
    
    public void startWorker() {
        state = UrjanetWorkerState.STARTING;
        // Check to see if the process is already running, exit if running
        String processCheckReturn = ssh.executeCommand("jps -vl | grep " + workerClassPath);
        if (StringUtils.isNotBlank(processCheckReturn)) {
            log.info("Java worker already running");
            return;
        }
        
        log.info("Starting java worker: " + workerClassPath);
        
        String cleanName = name.replace(" ", "_");
        StringBuilder sb = new StringBuilder();
        sb.append("java -cp $CLASSPATH ")
            .append(workerClassPath);
        
        ssh.executeCommand(sb.toString());
        state = UrjanetWorkerState.STARTED;
    }
    
    public void stopWorker() {
        state = UrjanetWorkerState.STOPPING;
        log.info("Stopping java worker");        
        String processCmd = "jps -vl | grep " + workerClassPath;
        String processCheckReturn = ssh.executeCommand(processCmd);
        
        if (StringUtils.isBlank(processCheckReturn)) {
            log.info("Java worker not found");
            return;
        } else {
            String[] processArr = processCheckReturn.split(" ");
            if (processArr.length == 2) {
                String pid = processArr[0];
                log.info("Killing pid " + pid);
                ssh.executeCommand("kill " + pid);

                try {
                    while (StringUtils.isNotBlank(processCheckReturn)) {
                        Thread.sleep(5 * 1000);
                        processCheckReturn = ssh.executeCommand(processCmd);
                    }
                    
                    log.info("Java worker stopped");
                } catch (Exception e) {
                    log.error("Error while shutting down java worker!", e);
                }
            }
        }
        state = UrjanetWorkerState.STOPPED;
    }
    
    public void runCommand(String command) {
        ssh.executeCommand(command, System.out);
    }
    
    public boolean isStarting() {
        return state == UrjanetWorkerState.STARTING ||
                state == UrjanetWorkerState.INITIALIZING ||
                state == UrjanetWorkerState.UNINITIALIZED ||
                state == UrjanetWorkerState.INITIALIZED;
    }
    
    public boolean isRunning() {
        return state == UrjanetWorkerState.STARTED;
    }
    
    public boolean isStopped() {
        return state == UrjanetWorkerState.STOPPING ||
                state == UrjanetWorkerState.STOPPED ||
                state == UrjanetWorkerState.TERMINATING ||
                state == UrjanetWorkerState.TERMINATED;
    }

    public String getName() {
        return name;
    }
}
