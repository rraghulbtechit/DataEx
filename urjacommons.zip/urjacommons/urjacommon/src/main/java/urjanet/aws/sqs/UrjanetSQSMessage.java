package urjanet.aws.sqs;


import java.util.Date;

import com.amazonaws.services.sqs.model.Message;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UrjanetSQSMessage extends Message {

	private static final long serialVersionUID = -8482469739401737947L;
	
	//S3 id for a large message (which exceeds the limit of 262144 bytes).
	protected String s3Id;
	protected final long timestamp;
	
	protected static ObjectMapper jsonMapper = null;
	
	static {
		jsonMapper = new ObjectMapper();
		jsonMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jsonMapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
		jsonMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); 
	}

	public UrjanetSQSMessage() {
		
        super();
        this.timestamp = new Date().getTime();
    }
	
	/**
	 * Copies the AmazonMessage's properties into Urjanet Sqs Message
	 * 
	 * @param message
	 */
	public UrjanetSQSMessage(Message message) {
		this();
        copyMessageProperties(message);
	}
    
    /**
     * Copy constructor to copy and get a new object.
     * 
     * @param message
     */
    public UrjanetSQSMessage(UrjanetSQSMessage message) {
        this();
        this.s3Id = message.getS3Id();
        copyMessageProperties(message);
    }
    
    /**
     * Fill the current message object's properties with the incoming AWS sqs message.
     * 
     * @param sqsMessage
     */
    public UrjanetSQSMessage copyMessageProperties(final Message sqsMessage) {
    	
		setBody(sqsMessage.getBody());
		setMD5OfBody(sqsMessage.getMD5OfBody());
		setAttributes(sqsMessage.getAttributes());
		setMessageAttributes(sqsMessage.getMessageAttributes());
		setMD5OfMessageAttributes(sqsMessage.getMD5OfMessageAttributes());
		setReceiptHandle(sqsMessage.getReceiptHandle());
		setMessageId(sqsMessage.getMessageId());
		
		return this;
    }
    
    /**
     * 
     * @param sqsMessage
     * @return
     */
    public UrjanetSQSMessage copyMessageProperties(final UrjanetSQSMessage sqsMessage) {
    	
    	setS3Id(sqsMessage.getS3Id());
    	copyMessageProperties((Message)sqsMessage);
    	
    	return this;
    }

	/**
	 * 
	 * @return a JSON string
	 */
	public String toJson() {

		try {
			return jsonMapper.writeValueAsString(this);
		} catch (Exception e) {
			throw new RuntimeException("SQS Message serialization error..", e);
		}
	}

	/**
	 * 
	 * @param json
	 * 
	 * @return a specified object type from a JSON String
	 */
	public static UrjanetSQSMessage fromJson(final String json) {

		try {
			return  fromJson(json, UrjanetSQSMessage.class);
		} catch (Exception e) {
			throw new RuntimeException("SQS message deserialization error..", e);
		}
	}
	
	/**
	 * 
	 * @param json
	 * 
	 * @return a specified object type from a JSON String
	 */
	public static <T> T fromJson(final String json, final Class<T> clazz) {

		try {
			return  jsonMapper.readValue(json, clazz);
		} catch (Exception e) {
			throw new RuntimeException("SQS message deserialization error..", e);
		}
	}
	
	/**
	 * 
	 * @return a S3 Id
	 */
	public String getS3Id() {
		return s3Id;
	}

	/**
	 * Sets the S3 Id
	 * 
	 * @param s3Id
	 */
	public UrjanetSQSMessage setS3Id(String s3Id) {
		this.s3Id = s3Id;
		return this;
	}
	
	/**
	 * 
	 * @return a time stamp which the message was created.
	 */
	public long getTimestamp() {
		return timestamp;
	}

}
