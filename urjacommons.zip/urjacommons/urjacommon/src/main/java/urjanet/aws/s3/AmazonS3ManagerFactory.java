package urjanet.aws.s3;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.BasicAWSCredentials;

public class AmazonS3ManagerFactory {
	
	private static final Logger log = LoggerFactory.getLogger(AmazonS3ManagerFactory.class);

	private static AmazonS3ManagerFactory _instance = new AmazonS3ManagerFactory();
	private Map<String, BasicAWSCredentials> bucketCredentials = new HashMap<String, BasicAWSCredentials>();
	private Map<String, AmazonS3Manager> existingManagers = new HashMap<String, AmazonS3Manager>();
	
	public static AmazonS3ManagerFactory getInstance() {
		return _instance;
	}
	
	protected AmazonS3ManagerFactory() {
		
		// TODO: load creds from external source (urjanet.properties?)
		// TODO: configure S3 security so that the buckets that contain source images are locked down better
		// use "null" to indicate that we want to use the default AWS cred search chain (env vars, jvm props, ~/.aws/credentials, instance role)
		
		//bucketCredentials.put("DAQ", null);
		//bucketCredentials.put("urja_sources", null);	
		//bucketCredentials.put("ExtractOnDemand", null);
		//bucketCredentials.put("urjanet-slicendice-db", null);
	}
	
	public AmazonS3Manager createNew(String bucketName) {
		
		AmazonS3Manager s3Mgr = null;
		BasicAWSCredentials creds = bucketCredentials.get(bucketName);
		String accessKey = null;
		String secretKey = null;
		
		if (creds != null) {
			accessKey = creds.getAWSAccessKeyId();
			secretKey = creds.getAWSSecretKey();
		}
		
		s3Mgr = new AmazonS3Manager(accessKey, secretKey, bucketName);

		return s3Mgr;
	}

	public synchronized AmazonS3Manager createOrReuse(String bucketName) {
		
		AmazonS3Manager s3Manager = existingManagers.get(bucketName);
		if (s3Manager == null) {
			s3Manager = createNew(bucketName);
			existingManagers.put(bucketName, s3Manager);
		}
		return s3Manager;		
	}
	
	public synchronized void shutdown(AmazonS3Manager manager) {

		AmazonS3Manager cachedManager = existingManagers.get(manager.getBucketName());
		if (cachedManager != null && cachedManager == manager) {
			existingManagers.remove(manager.getBucketName());
		}
		manager.shutdown();
		
	}
	
}
