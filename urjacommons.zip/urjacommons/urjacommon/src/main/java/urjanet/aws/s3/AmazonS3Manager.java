package urjanet.aws.s3;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.internal.UploadImpl;

import urjanet.util.StringUtils;

/**
 * Wrapper around S3 api.  Behind the scenes there's a thread pool attached to each TransferManager instance.  Graceful shutdown 
 * requires tearing down this thread pool so that the jvn can exit, so the burden is currently on the user of this class to
 * call the "stop" method when you are done with all S3 access.
 * 
 * @author trose
 *
 */
public class AmazonS3Manager {
	
	private static final Logger log = LoggerFactory.getLogger(AmazonS3Manager.class);
	
	protected String accessKey; 
	protected String secretKey; 
	protected String bucketName;
	protected Bucket bucket;
	protected AmazonS3 s3Client;
	protected TransferManager transferManager;
	
	AmazonS3Manager(String accessKey, String secretKey, String bucketName) {
		
		init(accessKey, secretKey, bucketName);
	}
	
	private void init(String accessKey, String secretKey, String bucketName) {
	
		this.accessKey = accessKey;
		this.secretKey = secretKey;
		this.bucketName = bucketName;

		if (!StringUtils.isBlank(accessKey) && !StringUtils.isBlank(secretKey)) {
			this.s3Client = new AmazonS3Client(new BasicAWSCredentials(accessKey,secretKey));
		} else {
			this.s3Client = new AmazonS3Client();
		}
		
		this.transferManager = new TransferManager(s3Client);
		this.bucket = getBucketByName(bucketName);
	}
	
	public String getBucketName() {
		return bucketName;
	}
	
	public synchronized void shutdown(){
		
		if (transferManager != null) {			
			transferManager.shutdownNow();
			s3Client = null;
			transferManager = null;
		}
	}
	
	public boolean isShutdown() {
		return transferManager == null;
	}
	
	public void delete(String bucketName, String filename) {
		s3Client.deleteObject(bucketName, filename);
	}
	
	
	public String putSource(byte[] saveFile) {
		String key = generateKey();
		System.out.println("Generating Key: " + key);
		
		ObjectMetadata metadata = new ObjectMetadata();
		
		return putSource(saveFile, key, metadata);	
	}
	
	public String putSource(byte[] saveFile, String key) {
		ObjectMetadata metadata = new ObjectMetadata();
		return putSource(saveFile, key, metadata);	
	}
	
	public String putSource(byte[] saveFile, String key, boolean overwrite) {
		return putSource(saveFile, key, new ObjectMetadata(), overwrite);	
	}
	
	public String putSource(byte[] saveFile, String key, ObjectMetadata metadata) {
		return putSource(saveFile, key, metadata, false);	
	}
	
	public String putSource(InputStream is) {
		String key = generateKey();
		System.out.println("Generating Key: " + key);
		return putSource(is, key);
	}
	
	public String putSource(InputStream is, String key) {
		return putSource(is, key, new ObjectMetadata(), false);
	}
	
	public String putSource(InputStream is, String key, ObjectMetadata metadata, boolean overwrite) {
		try {
			return doS3Upload(is, key, metadata);
		} catch (Exception e) {
			log.error("putSource(" + key + ")", e);
			return null;
		}
	}

	// This method accepts an input stream, key (unique filename), and metadata
	// Returns the key if successful otherwise returns null
	public String putSource(byte[] saveFile, String key, ObjectMetadata metadata, boolean overwrite) {
		
		if (!overwrite && keyExists(key)) {
			System.out.println("The following key already exists: " + key);
			return null;
		}
		
		try {
			
			final int NUM_RETRIES = 3;
			int retryCount = 0;
			
			while (retryCount <= NUM_RETRIES) {
				
				try {
					return doS3Upload(saveFile, key, metadata);
				
				} catch (AmazonClientException ace) {
					if (retryCount >= NUM_RETRIES) {
						throw ace;
					}
					
					int sleepSeconds = (int) Math.pow(5, retryCount++);
					log.warn("AmazonClientException while uploading file to S3: {}. Retry #{} in {}s...", ace.getMessage(), retryCount, sleepSeconds);
					try {
						Thread.sleep(sleepSeconds * 1000);
					} catch (InterruptedException e) { log.debug("How rude, my sleep was interrupted", e); }
				}
			}
			
			// We shouldn't get to here
        	log.error("putSource(" + key + ") failed");
        	return null;
			
        } catch (Exception e) {
        	log.error("putSource(" + key + ")", e);
        	return null;
        }
		
	}
	
	private String doS3Upload(byte[] saveFile, String key, ObjectMetadata metadata) throws Exception {
		return doS3Upload(saveFile, key, metadata, false);
	}
	private String doS3Upload(byte[] saveFile, String key, ObjectMetadata metadata, boolean overwrite) throws Exception {
		ByteArrayInputStream saveStream = null;
		try {
			saveStream = new ByteArrayInputStream(saveFile);
			return doS3Upload(saveStream, key, metadata);
		} finally {
			IOUtils.closeQuietly(saveStream);
		}
	}
	private String doS3Upload(InputStream saveStream, String key, ObjectMetadata metadata) throws Exception {
		// TODO: add ProgressListener to print out progress/debug info
		Upload myUpload = transferManager.upload(bucketName, key, saveStream, metadata);
		myUpload.waitForCompletion();
		log.debug("putSource(" + key + ") completed - " + myUpload.getProgress().getBytesTransfered() + " bytes");
		return key;
	}
	
	// This method accepts an input stream, key (unique filename), and metadata
	// Returns the key if successful otherwise returns null
	public String put(InputStream saveStream, String key, String bucket) throws AmazonServiceException, AmazonClientException, InterruptedException {
		try {
			// TODO: add ProgressListener to print out progress/debug info
			Upload myUpload = transferManager.upload(bucket, key, saveStream, new ObjectMetadata());
			myUpload.waitForCompletion();
			log.debug("putSource(" + key + ") completed - " + myUpload.getProgress().getBytesTransfered() + " bytes");
			return key;
		} finally {
			IOUtils.closeQuietly(saveStream);
		}
		
	}
	
	public String putSource(File saveFile, String key) {
		return putSource(saveFile, key, false);
	}
	public String putSource(File saveFile, String key, boolean overwrite) {
				
		if (!overwrite && keyExists(key)) {
			
			System.out.println("The following key already exists: " + key);
			return null;
		}
		
		try {

			UploadImpl myUpload = (UploadImpl)transferManager.upload(bucketName, key, saveFile);
			myUpload.waitForCompletion();
			log.debug("putSource(" + saveFile + ", " + key + ") completed - " + myUpload.getProgress().getBytesTransfered() + " bytes");
			return key;
			
        } catch (Exception e) {
        	
        	log.error("putSource(" + saveFile + ", " + key + ")", e);
        	return null;
        }
		
	}
	
	public String putSource(File saveFile) {
		
		return putSource(saveFile, saveFile.getName());		
	}
	
	
// TODO Allow for multiple files to be put	
//	public void putSource(Map<File, String> files){
//		
//		
//	
	
	public byte[] getSource(String key) {
				
		//System.out.println("Getting source for key: " + key);	
		byte[] sourceArray = null;
		S3Object objectComplete = null;
				
		try {
			
			objectComplete = s3Client.getObject(bucketName, key);
			S3ObjectInputStream inputStream = objectComplete.getObjectContent();
			sourceArray = IOUtils.toByteArray(inputStream);
			IOUtils.closeQuietly(inputStream);
			
        } catch (Exception e) {        	
        	log.error("getSource(" + key + ")", e);
        }
		
		return sourceArray;

	}
	
	public byte[] get(String key, String bucket) throws IOException {
		S3Object objectComplete = s3Client.getObject(bucket, key);
		S3ObjectInputStream inputStream = null;
		try {
			inputStream = objectComplete.getObjectContent();
			return IOUtils.toByteArray(inputStream);
		} finally {
			if (inputStream != null)
				IOUtils.closeQuietly(inputStream);
		}
	}
		
	public InputStream getSourceAsStream(String key){
		
//		System.out.println("Getting source stream for key: " + key);
		InputStream stream = null;
		
		try {
			
			S3Object objectComplete = s3Client.getObject(bucketName, key);
			stream = objectComplete.getObjectContent();

        } catch (Exception e) {
        	
        	log.error("getSourceAsStream(" + key + ")", e);
            
        }
	
		return stream;
	}
	
	public int getSourceByteLength(String key){
		
		int byteLength = -1;		
		S3Object objectComplete = null;
		
		try {
			
			objectComplete = s3Client.getObject(bucketName, key);
			byteLength = (int)objectComplete.getObjectMetadata().getContentLength();

        } catch (Exception e) {
        	
        	log.error("getSourceByteLength(" + key +")", e);
        }
		
		return byteLength;
	}
	
	//Check if the key is CONTAINED within any of the keys in the bucket
	private boolean keyExists(String key) {
//		System.out.println("Validation existance of key: " + key);			
		ObjectMetadata metadata = getObjectMetadata(key);	
		return metadata != null;
		
	}
	
	// Retrieve the Metadata of the file object
	public ObjectMetadata getObjectMetadata(String key){
		
		ObjectMetadata objectDetailsOnly = null;
		try {
			
			objectDetailsOnly = s3Client.getObjectMetadata(bucketName, key);
			
		} catch (Exception e) {
			
			log.debug("getObjectMeta(" + key + "): " + e.toString());			
		}
		
		return objectDetailsOnly;		
	}
	
	public List<String> getObjects() {
		List<String> s3Ids = new ArrayList<String>();
		
		ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(bucketName);
		ObjectListing listing;
		do {
			listing = s3Client.listObjects(listObjectsRequest);
			for (S3ObjectSummary summary : listing.getObjectSummaries()) {
				s3Ids.add(summary.getKey());
			}
			listObjectsRequest.setMarker(listing.getNextMarker());
		} while (listing.isTruncated());
		
		return s3Ids;
	}
	
	/*public List<String> getObjects() {
		List<String> s3Ids = new ArrayList<String>();
		ObjectListing listing = s3Client.listObjects(bucketName);
		boolean truncated = true;
		while (truncated) {
			truncated = listing.isTruncated();
			for (S3ObjectSummary summary : listing.getObjectSummaries()) {
				s3Ids.add(summary.getKey());
			}
		}
		
		return s3Ids;
	}*/
			
	private Bucket getBucketByName(String bucketName) {
		
		Bucket returnBucket = null;		
		List<Bucket> buckets = s3Client.listBuckets();	
		
		for(Bucket bucket: buckets){
			if (bucket.getName().equalsIgnoreCase(bucketName)){
				returnBucket = bucket;
			}
		}
		
		System.out.println("Chosen Bucket: " + returnBucket.getName());
		return returnBucket;
	}
	
	private String generateKey() {
		
		UUID idOne = UUID.randomUUID();
		return idOne.toString();
	}	

}




