package urjanet.aws.s3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;

import com.amazonaws.services.s3.model.ObjectMetadata;


public class AmazonS3Tester {
		
	private AmazonS3Manager s3Manager;
	
	public AmazonS3Tester(){
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		AmazonS3Tester test = new AmazonS3Tester(); 
		test.start();
		
		
// 1. This tests ()
//		String test1 = "/home/jmangiameli/Desktop/Camel/Docs/suez.wt";
//		test.testPutFile(test1);     	
       	       	
// 2. This test the method putSource -> byte[]
//		String test2 = "/home/jmangiameli/Desktop/Camel/Docs/KC_AlabamaPower.pdf";
//		test.testPutSourceByteArray(test2);      
		
	
// 3. This test the putSource	 -> InputStream
// 		String test3 = "/home/jmangiameli/Desktop/Camel/Docs/KC_AlabamaPower.pdf";
//		test.testPutSourceInputStream(test3);
	
		
// 4. This test the putSource	 -> InputStream, key
//		String test4 = "/home/jmangiameli/Desktop/Camel/Docs/KC_AlabamaPower.pdf";
//		String key = UUID.randomUUID().toString() + "--" + "Amazon_S3_Test_File";
//		test.testPutSourceInputStream(test4, key);
		
		
		
// 5. This test the getSource	 -> byte[]
//		String test5 = "8612d7ce-1367-4b26-a3d6-c5187fe29a41--Amazon_S3_Test_File";
//		String saveFile1 = "/home/jmangiameli/Desktop/Camel/Docs/byteArrayTest.pdf";
//		test.testGetByteArray(test5, saveFile1);
	
        
// 6. This test the method getSource -> InputStream
//		String test6 = "8612d7ce-1367-4b26-a3d6-c5187fe29a41--Amazon_S3_Test_File";
//		String saveFile2 = "/home/jmangiameli/Desktop/Camel/Docs/inputStreamTest.pdf";
//		test.testGetInputStream(test6, saveFile2);

		
// 7. This test the putSource	 -> byte[]  ->Print to console
//		String test7 = "suez.wt";
//		test.testGetByteArrayPrint(test7);
//		
		
		test.stop();

	}
	
	private void start(){
		s3Manager = AmazonS3ManagerFactory.getInstance().createOrReuse("DAQ");	}
	
	private void stop(){
		s3Manager.shutdown();
	}
	
	private void testPutSourceFile(String filepath){
		File file = new File(filepath);

		System.out.println("Attempting to store the File: " + file.getAbsolutePath());				
		String success = s3Manager.putSource(file);
		System.out.println("Storage successfull: " + success);
		
		
	}
	

	private void testPutSourceByteArray(String filepath){	
		File file = new File(filepath);
		
		System.out.println("File: " + file.getAbsolutePath());
		
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		
		System.out.println("Stream: " + inputStream.toString());
		
		byte[] byteArray = null;
		try {
			byteArray =  IOUtils.toByteArray(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			inputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Length of byte array: " + byteArray.length);
		
		
		ObjectMetadata metadata = new ObjectMetadata();
//		metadata.setContentType("application/pdf");
		
		System.out.println("Attempting to store the InputStream for file: " + file.getAbsolutePath());		
		String success = s3Manager.putSource(byteArray);
		System.out.println("Storage key: " + success);
		
	
	}
	
	
	private void testPutSourceInputStream(String filePath){	
		File file = new File(filePath);
		
		InputStream kc_alabamaPower = null;
		try {
			kc_alabamaPower = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType("application/pdf");
		
		System.out.println("Attempting to store the InputStream for file: " + file.getAbsolutePath());
		
		String success = s3Manager.putSource(kc_alabamaPower);
		
		try {
			kc_alabamaPower.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Successfully stored key: " + success);
		
	
	}
	
	private void testPutSourceInputStream(String filePath, String key){	
		File file = new File(filePath);
		
		InputStream kc_alabamaPower = null;
		try {
			kc_alabamaPower = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType("application/pdf");
		
		System.out.println("Attempting to store the InputStream for file: " + file.getAbsolutePath());
		
		String success = s3Manager.putSource(kc_alabamaPower, key);
		
		try {
			kc_alabamaPower.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Successfully stored key: " + success);
		
	
	}
	
	
	private void testPutSourceFile(){	
		String accessChannel = "KimberlyClark_1-AlabamaPower_1 ";
		File kc_alabamaPower = new File("/home/jmangiameli/Desktop/Camel/Docs/KC_AlabamaPower.pdf");
		
		System.out.println("Attempting to store the file: " + kc_alabamaPower.getAbsolutePath());
		
		String success = s3Manager.putSource(kc_alabamaPower, accessChannel);
		
		System.out.println("Storage successfull: " + success);
		
	
	}

	
	private void testGetByteArray(String s3Key, String saveFile){
	   	byte[] source = s3Manager.getSource(s3Key);	   	
	   	System.out.println("Source byte length: " + source.length);
	   	
	   	File file = new File(saveFile);
	   	saveByteArray(source, file);
	   	
	   	//Print's file contents
//	    for (int i = 0; i < source.length; i++) {
//	        System.out.print((char)source[i]);
//	    }	
	}
	
	private void testGetByteArrayPrint(String s3Key){
	   	byte[] source = s3Manager.getSource(s3Key);	   	
	   	System.out.println("Source byte length: " + source.length);
	   	
	   	//Print's file contents
		System.out.println("----------------- Printing File Contents ------------------");
		System.out.println("------------------------------------------------------------");
	    for (int i = 0; i < source.length; i++) {
	        System.out.print((char)source[i]);
	    }	
	    System.out.println("");
	}
	
	private void testGetInputStream(String key, String saveFile){
    
		InputStream is = s3Manager.getSourceAsStream(key);		
		System.out.println("Here");
		int numberOfBytes = s3Manager.getSourceByteLength(key);
		
		byte[] sourceArray = inputStreamToByteArray(is, numberOfBytes);
		File file = new File(saveFile);
		
		saveByteArray(sourceArray, file);
	}

	
	private static void saveByteArray(byte[] sourceArray, File file){
		System.out.println("Attempting to store file: " + file.getAbsolutePath());
		OutputStream out = null;
		try {
			out = new FileOutputStream(file);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			out.write(sourceArray);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Storage Successfull");
		
	}
	
	
	private static byte[] inputStreamToByteArray(InputStream is, int arrayLength){
		System.out.println("Input stream to byte array");
		
		byte[] buffer = new byte[arrayLength];
		
		int totalBytesRead = 0;
		int bytesRead = -1;

		while (true) {
	        try {
				bytesRead = is.read(  buffer,  totalBytesRead, buffer.length - totalBytesRead);
				System.out.println(bytesRead);
			} catch (IOException e) {
				System.out.println("Error reading bytes from Input Stream");
				e.printStackTrace();
				buffer = null;
				break;
			}
	        if (bytesRead == -1) {
	                break;
	        } else {
	                totalBytesRead += bytesRead;
	        }
		}
		
		try {
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return buffer;
		
	}


}
