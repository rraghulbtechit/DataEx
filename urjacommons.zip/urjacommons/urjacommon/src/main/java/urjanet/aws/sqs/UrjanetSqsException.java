package urjanet.aws.sqs;

import urjanet.UrjanetException;

/**
 * All exceptions which are related to SQS service can use this class.
 * 
 * @author xavierd
 *
 */
public class UrjanetSqsException extends UrjanetException {

	private static final long serialVersionUID = 1L;

	/**
	 * Create a new UrjanetSqsException
	 *
	 * @param message a descriptive message
	 */
	public UrjanetSqsException(String message){
		this(message, null);
	}
	
	/**
	 * Create a new UrjanetSqsException
	 *
	 * @param t a nested exception
	 */
	public UrjanetSqsException(Throwable t){
		this("General UrjanetSqsException", t);
	}

	/**
	 * Create a new UrjanetSqsException
	 *
	 * @param message a descriptive message
	 * @param t a nested exception
	 */
	public UrjanetSqsException(String message, Throwable t){
		super(message, t);
	}

}
