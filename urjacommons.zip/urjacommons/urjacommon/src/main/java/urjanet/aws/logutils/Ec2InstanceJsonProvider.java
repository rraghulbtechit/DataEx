package urjanet.aws.logutils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.util.EC2MetadataUtils;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractFieldJsonProvider;

public class Ec2InstanceJsonProvider extends AbstractFieldJsonProvider<ILoggingEvent> {

	private static String instanceId;
	private static String amiId;
	private static String region;
	private static String instanceType;
	private static String availabilityZone;

	private static Map<String, String> tags = new HashMap<>();
	
	static {
		
		try {
			
			instanceId = EC2MetadataUtils.getInstanceId();
			amiId = EC2MetadataUtils.getAmiId();
			region = EC2MetadataUtils.getEC2InstanceRegion();
			instanceType = EC2MetadataUtils.getInstanceType();
			availabilityZone = EC2MetadataUtils.getAvailabilityZone();
			
			if (instanceId != null) {
				AmazonEC2Client client = new AmazonEC2Client();
				DescribeInstancesRequest req = new DescribeInstancesRequest().withInstanceIds(instanceId);
				DescribeInstancesResult res = client.describeInstances(req);
				Reservation me = res.getReservations().get(0);
				List<Instance> instances = me.getInstances();
				for (Tag tag : instances.get(0).getTags()) {
					if (!tag.getKey().startsWith("aws:")) {
						tags.put(tag.getKey(), tag.getValue());
					}
				}
			}
			
		} catch (Exception e) {
			// not running in ec2?
			e.printStackTrace();
		}
	}

	public Ec2InstanceJsonProvider() {
	}
	
	@Override
	public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {

		generator.writeFieldName("ec2");
		generator.writeStartObject();
		generator.writeStringField("instance", instanceId);
		generator.writeStringField("ami", amiId);
		generator.writeStringField("region", region);
		generator.writeStringField("type",  instanceType);
		generator.writeStringField("az", availabilityZone);
		generator.writeEndObject();
		
		for (Map.Entry<String, String> entry : tags.entrySet()) {
			
			generator.writeStringField(entry.getKey(), entry.getValue());
		}

	}

}
