package urjanet.aws;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateChange;
import com.amazonaws.services.ec2.model.InstanceStateName;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class EC2ManagerTest {
    private static boolean exit = false;
    private static List<String> runningInstances;
    private static AmazonEC2 ec2;
    private static BufferedReader bufferedIn;
    
    public static void main(String[] args) throws Exception {
        UrjanetWorker worker = new UrjanetWorker("testWorker S", "urjanet.pull.async.ExtractWorker", "i-53bc7e21");
        
        /*
        EC2Manager ec2 = new EC2Manager();
        ec2.startEC2();
        boolean ready = ec2.isInstanceReady("i-3349a841");
        
        System.out.println("ready? " + ready);
        
        String stateName = ec2.getInstance("i-f6e2ed85").getState().getName();
        String runningName = InstanceStateName.Running.toString();
        System.out.println(runningName);
        System.out.printf("Statename: %s, RunningName: %s", stateName, runningName);
        */
        
        System.out.println("Starting instance");
        worker.startInstance();
        
        System.out.println("Initialize the worker");
        worker.initializeWorker();
                
        System.out.println("Start the worker");
        worker.startWorker();
        worker.stopWorker();
        
/*        
 *      System.out.println("Terminate worker");
        worker.terminateInstance();
*/        
        System.out.println("complete");
        
        
        
/*        runningInstances = new ArrayList<String>();
        AWSCredentials creds = new BasicAWSCredentials("AKIAJU2CQPVDLHJLJZSA", "pwgNFrfyTC2+ZL4uvI9sXtMAqVHcSKyt6OayXXqf");
        ec2 = new AmazonEC2Client(creds);        
        
        DescribeInstanceStatusRequest statusRequest = new DescribeInstanceStatusRequest().withInstanceIds("i-a2878fc5");
        DescribeInstanceStatusResult statusResult = ec2.describeInstanceStatus(statusRequest);
        
        for (InstanceStatus status : statusResult.getInstanceStatuses()) {
            System.out.println(status.getInstanceStatus().getStatus());
            
            for (InstanceStatusDetails details : status.getInstanceStatus().getDetails()) {
                System.out.printf("Name: %s | Details: %s\n", details.getName(), details.getStatus());
            }
        
        }
*/        
/*        bufferedIn = new BufferedReader(new InputStreamReader(System.in));
        
        
        while (!exit) {
            processCommand(bufferedIn.readLine());
        }
*/        
        
        //createEC2Instance();
    }
    
    public static void processCommand(String cmd) throws Exception {
        if (StringUtils.equals("createInstance", cmd)) {
            System.out.println("----Creating new EC2 instance----");
            createEC2Instance();
        } else if (StringUtils.equals("monitorInstance", cmd)) {
            System.out.println("----Input instanceId to monitor----");
            String instanceId = bufferedIn.readLine();
            if (StringUtils.isNotBlank(instanceId)) {
                monitorState(Arrays.asList(instanceId));
            }
        } else if (StringUtils.equals("endInstance", cmd)) {
            endEC2Instance();
        } else if (StringUtils.equals("describeInstances", cmd)) {
            describeInstances();
        } else if (StringUtils.contains(cmd, "bootstrap")) {
            String[] params = cmd.split(" ");
            if (params.length < 2) {
                System.out.println("----usage: bootstrap <instance id>----");
            } else {
                System.out.printf("----Bootrapping: %s----\n", params[1]);
                bootstrapInstance(params[1]);
            }
        } else if (StringUtils.contains(cmd, "attach")) {
            String[] params = cmd.split(" ");
            if (params.length < 2) {
                System.out.println("----usage: attach <instance id>----");
            } else {
                System.out.printf("----Attaching: %s----\n", params[1]);
                runningInstances.add(params[1]);
            }
        } else if (StringUtils.equals("exit", cmd)) {
            System.out.println("----Exiting----");
            exit = true;
        } else {
            System.out.println("----Unknown Command----");
        }
    }
    
    public static void endEC2Instance() {
        TerminateInstancesRequest terminateRequest = new TerminateInstancesRequest()
            .withInstanceIds(runningInstances);
        
        TerminateInstancesResult terminateResult = ec2.terminateInstances(terminateRequest);
        
        for (InstanceStateChange stateChange : terminateResult.getTerminatingInstances()) {
            System.out.println("CurrentState : " + stateChange.getCurrentState());
        }
    }
    
    public static void monitorState(List<String> instanceIds) throws Exception {
        DescribeInstancesRequest instancesStatusRequest = new DescribeInstancesRequest()
                .withInstanceIds(instanceIds);

        System.out.println("----Monitoring status, press q to stop----");
        boolean stopStatus = false;
        while (!stopStatus) {
            System.out.println("----Making status request----");
            DescribeInstancesResult instancesResult = ec2.describeInstances(instancesStatusRequest);
            System.out.println("----Reqest Result received----");
            for (Reservation reservation : instancesResult.getReservations()) {
                for (Instance instance : reservation.getInstances()) {
                    System.out.println("Instance <" + instance.getInstanceId() + "> state : " + instance.getState());
                }
            }

            System.out.println("----Waiting 1 sec----");
            Thread.sleep(1000);
            
            System.out.println("----Reading input?----");
            if (bufferedIn.ready()) {
                String cmd = bufferedIn.readLine();
                if (StringUtils.equals("q", cmd)) {
                    stopStatus = true;
                }
            }
        }
    }
    
    public static void bootstrapInstance(String instanceId) throws Exception {
        Instance foundInstance = null;
        for (Instance instance : getInstances()) {
            if (StringUtils.equals(instanceId, instance.getInstanceId())) {
                foundInstance = instance;
            }
        }
       
        if (foundInstance != null) {
            System.out.println("found instance, setup connection");
            String host = foundInstance.getPublicDnsName();
            String username = "ubuntu";
            String keyLocation = "/home/styner/.ssh/"+foundInstance.getKeyName()+".pem";
            
            System.out.printf("Connecting with host:%s | username:%s | keyLocation:%s\n", host, username, keyLocation);
            UrjaSsh ssh = new UrjaSsh(host, username, keyLocation);
            ssh.executeCommand("/home/ubuntu/initializeSlave.sh rainbigstaging.ec2.urjanet.net rainforeststagingkeypair.pem", System.out);
            System.out.println("All done bootstrapping");
        }
    }
    
    public static void bootstrapInstances() throws Exception {
        for (Instance instance : getInstances()) {
            String host = instance.getPublicDnsName();
            String username = "ubuntu";
            String keyLocation = "/home/styner/.ssh/"+instance.getKeyName()+".pem";
            
            UrjaSsh ssh = new UrjaSsh(host, username, keyLocation);
            ssh.executeCommand("ls -lrat", System.out);
            System.out.println("All done bootstrapping");
        }
    }
    
    private static List<Instance> getInstances() throws Exception {
        List<Instance> runningInstanceList = new ArrayList<Instance>();
        
        DescribeInstancesRequest describeInstancesRequest = new DescribeInstancesRequest()
        .withInstanceIds(runningInstances);
        
        DescribeInstancesResult describeInstancesResult = ec2.describeInstances(describeInstancesRequest);
        
        List<Reservation> reservations = describeInstancesResult.getReservations();
        for (Reservation reservation : reservations) {
            List<Instance> instances = reservation.getInstances();
            for (Instance instance : instances) {
                runningInstanceList.add(instance);
            }
        }
        
        return runningInstanceList;
    }
    
    public static void describeInstances() throws Exception {
        for (Instance instance : getInstances()) {
            System.out.println("Instance Id : " + instance.getInstanceId());
            System.out.println("Key Name : " + instance.getKeyName());
            System.out.println("Public IP : " + instance.getPublicIpAddress());
            System.out.println("Private DNS : " + instance.getPrivateDnsName());
            System.out.println("Public DNS : " + instance.getPublicDnsName());
            System.out.print("Tags : ");
            for (Tag tag : instance.getTags()) {
                System.out.print(tag.getKey() + "=" + tag.getValue() + ", ");
            }
            System.out.println("----------\n");
        }
    }
    
    public static void createEC2Instance() throws Exception {
        System.out.println("----Creating instance----");
        RunInstancesRequest runInstanceRequest = new RunInstancesRequest();
        runInstanceRequest.withInstanceType("t1.micro")
            .withImageId("ami-5c9f0c35")
            .withMinCount(1)
            .withMaxCount(1)
            .withSecurityGroupIds("Rainforest Staging")
            .withKeyName("rainforeststagingkeypair");
        
        RunInstancesResult runInstances = ec2.runInstances(runInstanceRequest);
        System.out.println("----Request Sent----");
        List<Instance> instances = runInstances.getReservation().getInstances();
        
        for (Instance instance : instances) {
            System.out.println("----Instance id: " + instance.getInstanceId() + "----");
            runningInstances.add(instance.getInstanceId());
            
            CreateTagsRequest tagRequest = new CreateTagsRequest();
            tagRequest.withResources(instance.getInstanceId())
                .withTags(new Tag("Name", "S Instance Test"));
            ec2.createTags(tagRequest);
        }
        
        monitorState(runningInstances);
        
       /*
        DescribeInstancesResult instanceResult = ec2.describeInstances();
        
        List<Reservation> reservations = instanceResult.getReservations();
        
        for (Reservation reservation : reservations) {
            for (Instance instance : reservation.getInstances()) {
                System.out.println("Instance Id : " + instance.getInstanceId());
                System.out.println("Key Name : " + instance.getKeyName());
                System.out.println("Public IP : " + instance.getPublicIpAddress());
                System.out.println("Private DNS : " + instance.getPrivateDnsName());
                System.out.println("Public DNS : " + instance.getPublicDnsName());
                System.out.print("Tags : ");
                for (Tag tag : instance.getTags()) {
                    System.out.print(tag.getKey() + "=" +tag.getValue()+ ", ");
                }
                System.out.println("----------\n");
            }
        }
        */
    }
}
