package urjanet.aws;

//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.UUID;
//
//import org.apache.commons.lang.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import urjanet.UrjanetException;
//import urjanet.messaging.MessageMonitor;
//import urjanet.messaging.UrjanetMessageQueue;
//
//import com.amazonaws.services.ec2.model.Instance;
//import com.amazonaws.services.ec2.model.InstanceStateName;
//import com.amazonaws.services.ec2.model.Tag;
//
//public class MessageWorkerMonitor {
//    private static final Logger log = LoggerFactory.getLogger(MessageWorkerMonitor.class);
//    private static MessageMonitor msgMonitor;
//    private static Map<String, List<UrjanetWorker>> activeWorkers;
//    private static EC2Manager ec2;
//
//    /*
//     * Worker stages represent the break points for number of workers based on number of queue messages.  
//     * Example: {0, 10, 20, 40} represents one worker required at 10 or less messages, 2 workers for 10-20, 3 workers for 20-40, and 4 workers above 40.
//     */ 
//    private static int[] extractionStages = {0, 70};
//    private static int[] domainWorkerStages = {0, 70};
//    
//    public static void main(String[] args) throws Exception {
//        log.info("Starting MessageWorker Monitor Service");
//        
//        ec2 = new EC2Manager();
//        ec2.startEC2();
//
//        Instance staging = ec2.getInstanceByName("Rainforest Big Staging");
//        msgMonitor = new MessageMonitor(staging.getPublicDnsName());
//        
//        activeWorkers = new HashMap<String, List<UrjanetWorker>>();
//        
//        log.info("Looking for orphaned workers");
//        attachExistingWorkers();
//        
//        log.info("Starting queue monitoring");
//        while(true) {
//            log.info("Processing Queues");
//            processQueue(UrjanetMessageQueue.EXTRACTION_JOB_REQUEST, "urjanet.pull.async.ExtractWorker", extractionStages);
//            processQueue(UrjanetMessageQueue.PIPELINE_REQUEST, "urjanet.think.async.DomainObjectWorker", domainWorkerStages);
//            
//            log.info("Finished processing Queues, waiting ...");
//            Thread.sleep(30*1000);
//            //Thread.sleep(5*60*1000);
//        }
//    }
//    
//    public static void processQueue(UrjanetMessageQueue queue, String workerClassPath, int[] workerStages) throws UrjanetException {
//        log.info("Processing Queue: " + queue.getJmsQueueName());
//        long queueSize = msgMonitor.getQueueSize(queue);
//        List<UrjanetWorker> workers = activeWorkers.get(workerClassPath);
//        int workersSize = 0;
//        int requiredWorkers = 0;
//
//        if (workers != null) {
//            workersSize = workers.size();
//        }
//        System.out.println("WOrkers Size: " + workersSize );
//       
//        if (queueSize > 0) {
//            // Determine the number of workers required based on the workerStages array.
//            for (int i = 0; i < workerStages.length; i++) {
//                if (queueSize > workerStages[i]) {
//                    System.out.println("seeting required worksers to " +(i+1));
//                    requiredWorkers = i + 1;
//                }
//            }
//            
//            /*
//             * Determine the difference between the calculated number of required workers and the actual number of running workers
//             * and either create or destroy workers to get the number of actual workers to the number of required ones.
//             */
//            int workersDiff = requiredWorkers - workersSize;
//            if (workersDiff > 0) {
//                System.out.printf("CALCULATED WORKERS: %d, EXISING WORKERS: %d, SPAWN %d NEW WORKERS\n", requiredWorkers, workersSize, workersDiff);
//                spawnWorkers(workerClassPath, workersDiff);
//            } else if (workersDiff < 0) {
//                System.out.printf("CALCULATED WORKERS: %d, EXISING WORKERS: %d, DESTROY %d WORKERS\n", requiredWorkers, workersSize, Math.abs(workersDiff));
//                terminateWorkers(workerClassPath, Math.abs(workersDiff));
//            }
//        } else {
//            if (workersSize > 0) {
//                // Queue size is 0, terminate all remaining workers.
//                System.out.printf("QUEUE EMPTY, DESTORYING %d WORKERS\n", workersSize);
//                terminateWorkers(workerClassPath, workersSize);
//            }
//        }
//    }
//    
//    public static void spawnWorkers(String workerClass, int amount) throws UrjanetException {
//        List<UrjanetWorker> workerList = activeWorkers.get(workerClass);
//        
//        if (workerList == null) {
//            workerList = new ArrayList<UrjanetWorker>();
//            activeWorkers.put(workerClass, workerList);
//        }
//        
//        for (int i = 0; i < amount; i++) {
//            UrjanetWorker worker = new UrjanetWorker("Worker_" + UUID.randomUUID(), workerClass);
//            workerList.add(worker);
//            
//            worker.fullStart();
//        }
//    }
//    
//    public static void terminateWorkers(String workerClass, int amount) throws UrjanetException {
//        List<UrjanetWorker> workerList = activeWorkers.get(workerClass);
//        List<UrjanetWorker> workersToTerminate = new ArrayList<UrjanetWorker>();
//        
//        if (workerList != null) {
//            for (UrjanetWorker worker : workerList) {
//                if (!worker.isStopped()) {
//                    if (workersToTerminate.size() < amount) {
//                        workersToTerminate.add(worker);
//                    }
//                }
//            }
//        }
//        
//        for (UrjanetWorker worker : workersToTerminate) {
//            workerList.remove(worker);
//            worker.fullStop();                    
//        }
//    }
//    
//    /**
//     * This looks up runnig workers on ec2 then checks them against the in memory list of workers.  If it finds instances in ec2 which don't have
//     * in memory objects, it will create them.
//     * 
//     * @throws UrjanetException
//     */
//    public static void attachExistingWorkers() throws UrjanetException {
//        log.info("Looking for orphaned running workers to attach");
//        
//        Map<String, String> tags = new HashMap<String, String>();
//        tags.put("UrjanetType", "DynamicWorker");
//        
//        List<Instance> existingWorkers = ec2.getInstancesByTags(tags);
//        
//        for (Instance existingWorker : existingWorkers) {
//            // Skip the instance if it isn't running or starting up.
//            if (!StringUtils.equals(existingWorker.getState().getName(), InstanceStateName.Pending.toString()) &&
//                    !StringUtils.equals(existingWorker.getState().getName(), InstanceStateName.Running.toString())) {
//                continue;
//            }
//            
//            String workerType = ec2.getTagValue(existingWorker, "WorkerType");
//            String workerName = ec2.getTagValue(existingWorker, "Name");
//            
//            List<UrjanetWorker> workers = activeWorkers.get(workerType);
//            
//            boolean attachNewWorker = true;
//            
//            if (workers == null) {
//                workers = new ArrayList<UrjanetWorker>();
//                activeWorkers.put(workerType, workers);
//            } else {
//                // Check to see if the current ec2 instance already has a UrjanetWorker representation.
//                for (UrjanetWorker worker : workers) {
//                    if (StringUtils.equals(worker.getName(), workerName)) {
//                        attachNewWorker = false;
//                    }
//                }
//            }
//            
//            if (attachNewWorker) {
//                log.info("Attaching orphaned worker: " + workerName +", worker class: " + workerType);
//                UrjanetWorker urjaWorker = new UrjanetWorker(workerName, workerType, existingWorker.getInstanceId());
//                urjaWorker.fullStart();
//
//                workers.add(urjaWorker);
//            }
//        }
//    }
//}
