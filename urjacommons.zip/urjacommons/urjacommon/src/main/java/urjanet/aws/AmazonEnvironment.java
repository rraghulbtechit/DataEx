package urjanet.aws;

/**
 * Represents the configurations for worker instances in the various environments
 */
public enum AmazonEnvironment {
    STAGING("rainforeststagingkeypair.pem", "rainbigstaging.ec2.urjanet.net", "Rainforest Staging", "rainforeststagingkeypair"), 
    PRODUCTION("", "", "", "");
    
    // Ssh key for use with init script
    private String sshKey;
    // Url key to pull from for init script
    private String masterUrl;
    // Amazon security group to use for instance creation
    private String securityGroup;
    // Amazon key name to use for instance creation
    private String ec2KeyName;    

    private AmazonEnvironment(String sshKey, String masterUrl, String securityGroup, String ec2KeyName) {
        this.sshKey = sshKey;
        this.masterUrl = masterUrl;
        this.securityGroup = securityGroup;
        this.ec2KeyName = ec2KeyName;
    }
    
    public String getSshKey() {
        return sshKey;
    }
    
    public void setSshKey(String sshKey) {
        this.sshKey = sshKey;
    }
    
    public String getMasterUrl() {
        return masterUrl;
    }
    
    public void setMasterUrl(String masterUrl) {
        this.masterUrl = masterUrl;
    }

    public String getSecurityGroup() {
        return securityGroup;
    }

    public void setSecurityGroup(String securityGroup) {
        this.securityGroup = securityGroup;
    }

    public String getEc2KeyName() {
        return ec2KeyName;
    }

    public void setEc2KeyName(String ec2KeyName) {
        this.ec2KeyName = ec2KeyName;
    }   
    
}
