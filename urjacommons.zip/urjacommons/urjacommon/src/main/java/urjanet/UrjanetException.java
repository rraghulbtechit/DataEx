package urjanet;

import java.util.Date;

/**
 * Base exception for all subpackages' exceptions
 *
 * @author rburson
 */
public class UrjanetException extends Exception{

	private Date id = new Date();

	/**
	 *  Create a new UrjanetException with no message or nested exception
	 */
	public UrjanetException(){
		this("General UrjanetException", null);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param t a nested exception
	 */
	public UrjanetException(Throwable t){
		this("General UrjanetException", t);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param message a descriptive message
	 * @param t a nested exception
	 */
	public UrjanetException(String message, Throwable t){
		super(message, t);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param message a descriptive message
	 */
	public UrjanetException(String message){
		this(message, null);
	}

	public Date getId() {
		return id;
	}

	public static Throwable getRootException(Throwable t){
		if(t.getCause() != null){
			return getRootException(t.getCause());
		}
		return t;
	}

}
