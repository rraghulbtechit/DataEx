package urjanet.json;

public class JsonUtilsParseException extends JsonUtilsException {

	private static final long serialVersionUID = 1L;

	public JsonUtilsParseException(String msg) {
		super(msg);
	}

	public JsonUtilsParseException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public JsonUtilsParseException(Throwable cause) {
		super(cause);
	}
}
