package urjanet.json;

public class JsonUtilsException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public JsonUtilsException(String msg) {
		super(msg);
	}

	public JsonUtilsException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public JsonUtilsException(Throwable cause) {
		super(cause);
	}
}
