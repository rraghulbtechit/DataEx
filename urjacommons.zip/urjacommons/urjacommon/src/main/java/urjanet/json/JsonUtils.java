package urjanet.json;

import java.io.Reader;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

/**
 * Provides I/O of JSON to/from Java objects
 * 
 * The interface is modeled after Gson so please refer to Gson
 * documentation for API details.
 * 
 * Please use this utility instead of coding to Gson directly - 
 * this is to reduce the amount of direct coupling we have to Gson.
 * 
 * If Gson has something that you need that this utility doesn't have
 * then please consider writing a wrapper method. If you do write a wrapper
 * methods, please do not allow Gson exceptions to ripple up - please
 * catch them and wrap them with a JsonUtilsException
 * 
 * @author jason
 *
 */
public class JsonUtils {
	
	public <T> T fromJson(Reader json, Class<T> classOfT) throws JsonUtilsException {
		try {
			Gson gson = new Gson();
			return gson.fromJson(json, classOfT);
		}
		catch (JsonParseException e) {
			throw new JsonUtilsParseException (e);
		}
		catch (Exception e) {
			throw new JsonUtilsException(e);
		}
	}

	public String toJson(Object src) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		return gson.toJson(src);
	}
	
	public String toPrettyPrintJson(Object src) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		return gson.toJson(src);
	}

}
