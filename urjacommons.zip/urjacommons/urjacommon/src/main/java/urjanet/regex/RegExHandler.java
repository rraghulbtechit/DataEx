package urjanet.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * Reusable regex operations
 *
 * @author rburson
 */
public class RegExHandler {

	/**
	 * Extract the specified expression from the input text.
	 *
	 * @param text the text to extract FROM
	 * @param regEx the regex describing the extraction
	 * @return the extracted String
	 */
	public static String extract(String text, String regEx){

		return extract(text, Pattern.compile(regEx));

	}

	public static String extract(String text, Pattern p){

		Matcher matcher = p.matcher(text);
		return matcher.find() ? matcher.group() : null;

	}

	public static String extract(String text, String regEx, int groupCount) {

		return extract( text, Pattern.compile( regEx ), groupCount );
	}

	/**
	 * 
	 * Returns selected group from the match
	 * @param text 
	 * 			the text to extract FROM
	 * @param pattern 
	 * 			the regex describing the extraction
	 * @param groupCount
	 * 			the match group 
	 * @return the extracted String
	 */
	public static String extract(String text, Pattern pattern, int groupCount) {

		Matcher matcher = pattern.matcher( text );
		if (matcher.find() && matcher.group( groupCount ) != null) {
			return matcher.group( groupCount );
		} else {
			return null;
		}
	}
	
	/**
	 * 
	 * Attempt to match the supplied expression in the supplied text
	 * 
	 * @param text
	 *            the text to match against
	 * @param regEx
	 *            the expression specifying the match
	 * @return whether the expression matched or not
	 */
	public static boolean matches(String text, String regEx){

		return matches(text, Pattern.compile(regEx));

	}
	
	/**
	 * Do an exact match on the given regular expression
	 * 
	 * @param text the text to match against
	 * @param regEx the expression specifying the match
	 * @return whether the expression matched or not
	 */
	public static boolean stringMatches(String text, String regEx) {
		return text.matches(regEx);
	}

	/**
	 * Match text on regEx with multiline and case-insensitive option
	 * 
	 * @param text
	 * @param regEx
	 * @return
	 */
	public static boolean stringMatchesMultilineIgnoreCase(String text, String regEx) {
		return matches(text,  Pattern.compile(regEx, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE));
	}
	
	/**
	 * Attempt to match the supplied expression in the supplied text
	 *
	 * @param text
	 * @param p
	 * @return
	 */
	public static boolean matches(String text, Pattern p){

		Matcher matcher = p.matcher(text);
		return matcher.find();

	}

	/**
	 * Replace the given regular expression matches with the supplied String
	 *
	 * @param text
	 * @param toReplace
	 * @param replaceWith
	 * @return
	 */
	public static String replaceAll(String text, String toReplace, String replaceWith){

		return replaceAll(text, Pattern.compile(toReplace), replaceWith);
	}

	/**
	 * Replace the given regular expression matches with the supplied String
	 *
	 * @param text
	 * @param toReplace
	 * @param replaceWith
	 * @return
	 */
	public static String replaceAll(String text, Pattern toReplace, String replaceWith){

		Matcher matcher = toReplace.matcher(text);
		return matcher.replaceAll(replaceWith);

	}

	/**
	 * Replace the first regular expression match with the supplied String
	 *
	 * @param text
	 * @param toReplace
	 * @param replaceWith
	 * @return
	 */
	public static String replaceFirst(String text, String toReplace, String replaceWith){
		return replaceFirst(text, Pattern.compile(toReplace), replaceWith);
	}

	/**
	 * Replace the first regular expression match with the supplied String
	 *
	 * @param text
	 * @param toReplace
	 * @param replaceWith
	 * @return
	 */
	public static String replaceFirst(String text, Pattern toReplace, String replaceWith){

		Matcher matcher = toReplace.matcher(text);
		return matcher.replaceFirst(replaceWith);

	}

}