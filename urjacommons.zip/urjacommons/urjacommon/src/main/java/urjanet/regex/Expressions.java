package urjanet.regex;

import java.util.regex.Pattern;

/**
 *
 * @author rburson
 */
public class Expressions {

	private static final Expressions expressions = new Expressions();

	public static Expressions getInstance(){
		return expressions;
	}

	private Expressions(){
	}

	/* String expressions here ------------------------------------------------------------------------------*/
	//Please be descriptive when naming these -
	//Specify the capturing portion of the expression and optional non-capturing portions (preced them with NOCAP)

	public final String SPACE = "\\s";
	public final String NON_SPACE = "\\S";
	public final String COMMA = ",";
	public final String PERIOD = "\\.";
	public final String DOLLAR = "\\$";
	public final String WORD_CHAR = "\\w";
	public final String NON_WORD_CHAR = "\\W";

    public final String UNICODE_MINUS_CHARS = "\\u2212\\uFE63\\uFF0D\\u2796";
    public final String UNICODE_MINUS = "[" + UNICODE_MINUS_CHARS + "]";
    public final String MINUS = "[-" + UNICODE_MINUS_CHARS + "]";
	
	public final String ONE_OR_MORE_SPACES = SPACE.concat("+");

	//a word character is [a-zA-Z_0-9]
	public final String ONE_OR_MORE_WORD_CHARS = WORD_CHAR.concat("+");

	public final String ONE_OR_MORE_NON_WORD_CHARS = NON_WORD_CHAR.concat("+");

	public final String COMMA_NO_SPACE = COMMA.concat(NON_SPACE);

	public final String COMMA_NON_CAP_NO_SPACE = COMMA.concat(wrapWithZeroWidthPositiveLookahead(NON_SPACE));

	/**
	 *  Matches a date in MM/DD/YYYY format (with / - or . as the separators) Also, M and D can be 1 or 2 digits and Y can be 2, 3, or 4 digits
	 */
	public final String REGX_DATE = "(([0-9]{1,2})[-/\\.]([0-9]{1,2})[-/\\.]([0-9]{2,4}+))";
		
	public final String REGX_DATE_MONTH_DAY = "(([0-9]{1,2})[-/\\.]([0-9]{1,2}))";
	
	/**
	 *  Matches a date in YYYY/MM/DD format (with / - or . as the separators) Also, M and D can be 1 or 2 digits and Y can be 2, 3, or 4 digits
	 */
	public final String REGX_DATE_YEAR_MONTH_DATE = "(([0-9]{1,4})[-/\\.]([0-9]{1,2})[-/\\.]([0-9]{1,2}+))";

	/**
	 *  Matches an integer with commas or without commas
	 */
	public final String REGX_NUM = MINUS + "{0,1}((\\d{1,3}(,?\\d{3})+)|\\d{1,3})";

	/**
	 *  Matches an integer or decimal (an number of decimal places) with commas or without commas
	 */
	public final String REGX_NUM_ANY = REGX_NUM + "?(\\.\\d+)?";
	
	public final String REGX_POSITIVE_NUM_ANY = "((\\d{1,3}(,?\\d{3})+)|\\d{1,3})?(\\.\\d+)?";

	/**
	 * Currently matches US currency only ($, not cents symbols)
	 * Allowing minus and plus in various places, which could let in multiple... this regex gets really big
	 * if you don't do that though...
	 */
	public final String REGX_CURRENCY = MINUS + "{0,1}\\+{0,1}\\s*\\$\\s*\\+?" + MINUS + "?\\s*" + REGX_NUM_ANY;
	//	"((" + MINUS + "?\\s*\\$?\\s*) | (\\+?\\s*\\$?\\s*) | (\\$\\s*" + MINUS + "?\\s*) | (\\$\\s*\\+?\\s*))" + REGX_POSITIVE_NUM_ANY;
	
	/**
	 *  Matches a valid email address
	 */
	public final String REGX_EMAIL = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";

	/**
	 * Matches a valid access channel. It can be used to get customer and provider name from access channel by group matching 
	 */
	public final String REGX_ACCESS_CHANNEL = "(\\w+)_\\d+-(\\w+)_\\d+";
	
	/*
	 * @TODO
	 * This needs to be an actual ascii range or better yet, unicode ranges that remove invisible characters
	 */
	public final String NONPRINTABLE_ASCII = "[^(A-Za-z0-9\\s\\.,\\?'\"!@#\\$%\\^&\\*\\(\\)-_=\\+;:<>\\/\\\\|\\}\\{\\[\\]`~)]";
	
	// see http://en.wikipedia.org/wiki/ISO_8859-1
	public final String NONPRINTABLE_LATIN1 = "[^(\\s\\u0020-\\u007E\\u00A0-\\u00FF)]";
	
	public final String UNICODE_WHITESPACE = "["
            + "\\u0009" // CHARACTER TABULATION
            + "\\u000A" // LINE FEED (LF)
            + "\\u000B" // LINE TABULATION
            + "\\u000C" // FORM FEED (FF)
            + "\\u000D" // CARRIAGE RETURN (CR)
            + "\\u0020" // SPACE
            + "\\u0085" // NEXT LINE (NEL) 
            + "\\u00A0" // NO-BREAK SPACE
            + "\\u1680" // OGHAM SPACE MARK
            + "\\u180E" // MONGOLIAN VOWEL SEPARATOR
            + "\\u2000" // EN QUAD 
            + "\\u2001" // EM QUAD 
            + "\\u2002" // EN SPACE
            + "\\u2003" // EM SPACE
            + "\\u2004" // THREE-PER-EM SPACE
            + "\\u2005" // FOUR-PER-EM SPACE
            + "\\u2006" // SIX-PER-EM SPACE
            + "\\u2007" // FIGURE SPACE
            + "\\u2008" // PUNCTUATION SPACE
            + "\\u2009" // THIN SPACE
            + "\\u200A" // HAIR SPACE
            + "\\u2028" // LINE SEPARATOR
            + "\\u2029" // PARAGRAPH SEPARATOR
            + "\\u202F" // NARROW NO-BREAK SPACE
            + "\\u205F" // MEDIUM MATHEMATICAL SPACE
            + "\\u3000" // IDEOGRAPHIC SPACE
            + "]";        
	
	public final String ONE_OR_MORE_UNICODE_SPACES = UNICODE_WHITESPACE.concat("+");
		    
	/* Patterns here --------------------------------------------------------------------------------------*/
	//End patterns with _P
	//Specify the capturing portion of the pattern and optional non-capturing portions (preced them with NOCAP)

	public final Pattern ONE_OR_MORE_SPACES_P = Pattern.compile(ONE_OR_MORE_UNICODE_SPACES);
	public final Pattern ONE_OR_MORE_WORD_CHARS_P = Pattern.compile(ONE_OR_MORE_WORD_CHARS);
	public final Pattern ONE_OR_MORE_NON_WORD_CHARS_P = Pattern.compile(ONE_OR_MORE_NON_WORD_CHARS);
	public final Pattern SINGLE_PERIOD_P = Pattern.compile(PERIOD);
	public final Pattern SINGLE_COMMA_P = Pattern.compile(COMMA);
	public final Pattern SINGLE_DOLLAR_P = Pattern.compile(DOLLAR);
	public final Pattern COMMA_NO_SPACE_P = Pattern.compile(COMMA_NO_SPACE);
	//comma followed by a non-captured non-space
	public final Pattern COMMA_NOCAP_NO_SPACE_P = Pattern.compile(COMMA_NON_CAP_NO_SPACE);
	public final Pattern NONPRINTABLE_LATIN1_P = Pattern.compile(NONPRINTABLE_LATIN1);
	public final Pattern UNICODE_MINUS_P = Pattern.compile(UNICODE_MINUS);
	

	/*
	 * Allows this forward reference to be a non-captured group.
	 * This item's presence is considered 'positive' which means that you 'expect' it to be there in order for the
	 * expression to evaluate to true;
	 */
	public String wrapWithZeroWidthPositiveLookahead(String expression){
		return "(?=".concat(expression).concat(")");
	}

	/*
	 * Allows this forward reference to be a non-captured group.
	 * This item's presence is considered 'negative' which means that you DON'T 'expect' it to be there in order for the
	 * expression to evaluate to true;
	 */
	public String wrapWithZeroWidthNegativeLookahead(String expression){
		return "(?!".concat(expression).concat(")");
	}

	/*
	 * Allows this backward reference to be a non-captured group.
	 * This item's presence is considered 'positive' which means that you 'expect' it to be there in order for the
	 * expression to evaluate to true;
	 */
	public String wrapWithZeroWidthPositiveLookbehind(String expression){
		return "(?<=".concat(expression).concat(")");
	}

	/*
	 * Allows this backward reference to be a non-captured group.
	 * This item's presence is considered 'negative' which means that you DON'T 'expect' it to be there in order for the
	 * expression to evaluate to true;
	 */
	public String wrapWithZeroWidthNegativeLookbehind(String expression){
		return "(?<!".concat(expression).concat(")");
	}
	
	public static void main(String[] args) {
	    
		String str1 = new String("général de petite puissance G");
		String result1 = str1.replaceAll(Expressions.getInstance().NONPRINTABLE_LATIN1, "?");
		String result2 = str1.replaceAll(Expressions.getInstance().NONPRINTABLE_ASCII, "?");
		
		System.out.println(str1);
		System.out.println(result1);
		System.out.println(result2);

		str1 = new String("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890`~!@#$%^&*()_+-=[]{};:\\|\'\",.?/>< \u00C0\u00D0\u00E0\u00F0   \u0101");
		result1 = str1.replaceAll(Expressions.getInstance().NONPRINTABLE_LATIN1, "?");
		result2 = str1.replaceAll(Expressions.getInstance().NONPRINTABLE_ASCII, "?");
		
		System.out.println(str1);
		System.out.println(result1);
		System.out.println(result2);
		
	}
}
