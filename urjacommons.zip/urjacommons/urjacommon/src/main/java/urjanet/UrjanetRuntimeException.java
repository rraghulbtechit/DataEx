package urjanet;

/**
 * Base runtime exception for all subpackages'  runtime exceptions
 *
 * @author rburson
 */
public class UrjanetRuntimeException extends RuntimeException{

	/**
	 *  Create a new UrjanetException with no message or nested exception
	 */
	public UrjanetRuntimeException(){
		this("General UrjanetException", null);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param t a nested exception
	 */
	public UrjanetRuntimeException(Throwable t){
		this("General UrjanetException", t);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param message a descriptive message
	 * @param t a nested exception
	 */
	public UrjanetRuntimeException(String message, Throwable t){
		super(message, t);
	}

	/**
	 * Create a new UrjanetException
	 *
	 * @param message a descriptive message
	 */
	public UrjanetRuntimeException(String message){
		this(message, null);
	}

}