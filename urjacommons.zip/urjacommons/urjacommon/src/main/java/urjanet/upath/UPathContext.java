package urjanet.upath;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.jxpath.ClassFunctions;
import org.apache.commons.jxpath.Functions;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathFunctionNotFoundException;
import org.apache.commons.jxpath.JXPathNotFoundException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.axes.PredicateContext;
import org.apache.commons.jxpath.ri.model.beans.BeanPointer;
import org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer;
import org.apache.commons.jxpath.ri.model.beans.CollectionPointer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rburson
 */
public class UPathContext {
	
	private static final Logger log = LoggerFactory.getLogger(UPathContext.class);

	private JXPathContext context;

	public UPathContext(Object o) {
		this.context = JXPathContext.newContext(o);
		this.context.setLenient(false);
	}

	private UPathContext(JXPathContext context){
		this.context = context;
		this.context.setLenient(false);
	}

	public Object get(UPath upath){
		return this.get(upath.getPath());
	}

	public Object get(String upath){
		Pointer pointer = getPointer(upath);
		if (pointer != null) {
			return pointer.getNode();
		}
		return null;
	}

	public void set(UPath upath, Object value){
		this.context.setValue(upath.getPath(), value);
	}

	public List getAll(UPath upath){
		return this.getAll(upath.getPath());
	}

	public List getAll(String upath){
		List allNodes = new ArrayList();
		Pointer pointer = (Pointer) getPointer(upath);
		if (pointer != null) {
			if (pointer instanceof BeanPropertyPointer) {
				return this.context.selectNodes(upath);
			} else if (pointer instanceof CollectionPointer) {
				List nodes = (List) context.getValue(upath);
				allNodes.addAll(nodes);
			} else if (pointer instanceof BeanPointer) {
				Iterator itr1 = this.context.iteratePointers(upath);
				if (itr1 instanceof PredicateContext) {
					if (((PredicateContext)itr1).getContextNodeList().size() == 1 || ((PredicateContext)itr1).getContextNodePointer() == null) {
						allNodes.add(((BeanPointer) pointer).getValue());
					} else {
						Iterator itr = this.context.iterate(upath);
						while (itr.hasNext()) {
							allNodes.add(itr.next());
						}
					}
				} else {
					allNodes.add(((BeanPointer) pointer).getValue());
				}
			} else {
				allNodes.add(pointer.getNode());
			}
		}

		return allNodes;
	}

	private Pointer getPointer(String upath) {
		try {
			return this.context.getPointer(upath);
		} catch (JXPathNotFoundException ex) {
			log.debug(ex.getMessage() + " : " + upath);
			return null;
		} catch (JXPathFunctionNotFoundException ex) {
			log.debug(ex.getMessage() + " : " + upath);
			return null;
		}
	}
	
	public UPathContext getContext(UPath upath){
		return new UPathContext(this.context.getRelativeContext(this.context.getPointer(upath.getPath())));
	}

	public void setExtensionFunction(Class functionClazz, String functionName) {
		this.context.setFunctions(new ClassFunctions(functionClazz, functionName));
	}
	
	public void setFunctions(Functions functions) {
		this.context.setFunctions(functions);
	}

}
