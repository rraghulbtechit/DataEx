package urjanet.upath;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rburson
 */
public class UPathContextManager {

	private Map<Object, UPathContext> map = new HashMap<Object, UPathContext>();

	public UPathContext getOrCreateContext(Object o){

		UPathContext context = map.get(o);
		if(context == null){
			context = new UPathContext(o);
			map.put(o, context);
		}
		return context;
	}

	public void clearCache(){
		this.map = new HashMap<Object, UPathContext>();
	}
	
}
