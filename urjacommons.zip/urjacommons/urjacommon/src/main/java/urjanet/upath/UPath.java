package urjanet.upath;

/**
 *
 * @author rburson
 */
public class UPath {

	private String path;

	public UPath(String path) {
		this.path = path;
	}

	public String getPath() {
		return path;
	}

	@Override
	public String toString(){
		return this.path;
	}

}
