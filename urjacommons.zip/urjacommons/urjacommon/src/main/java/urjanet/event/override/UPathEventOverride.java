package urjanet.event.override;

import java.util.List;

import urjanet.event.EventCode;
import urjanet.upath.UPath;

public class UPathEventOverride {

	private EventCode eventCode;
	
	private List<UPath> qualifiers;
	
	public UPathEventOverride() {
		super();
	}
	
	public UPathEventOverride(EventCode eventCode) {
		this.eventCode = eventCode;
	}

	public UPathEventOverride(EventCode eventCode, List<UPath> qualifiers) {
		this.qualifiers = qualifiers;
		this.eventCode = eventCode;
	}

	public EventCode getEventCode() {
		return eventCode;
	}

	public void setEventCode(EventCode eventCode) {
		this.eventCode = eventCode;
	}

	public List<UPath> getQualifiers() {
		return qualifiers;
	}

	public void setQualifiers(List<UPath> qualifiers) {
		this.qualifiers = qualifiers;
	}

}
