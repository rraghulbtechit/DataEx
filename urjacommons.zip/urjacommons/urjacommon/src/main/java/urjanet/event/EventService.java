package urjanet.event;

public interface EventService {

	public void addEvent(JobInfo info, SystemEvent event);
	public void close(JobInfo info);
}
