package urjanet.event;

public interface IJobInfoTag {
	public String getName();
}
