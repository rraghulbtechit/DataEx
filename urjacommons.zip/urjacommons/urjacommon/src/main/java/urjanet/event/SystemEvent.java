package urjanet.event;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author rburson
 */
public abstract class SystemEvent {

	private EventCode eventCode;
	private EventSeverity status = EventSeverity.ERROR;
	private Map<String, List<Object>> tags = new HashMap<String, List<Object>>();

	private Date timestamp = new Date();

	private boolean overriden;
	private boolean kinesisEnabled = false;
	private String message;

	protected SystemEvent(){
	}

	public SystemEvent(EventCode eventCode, EventSeverity severity, String message) {
		this.eventCode = eventCode;
		this.status = severity;
		this.message = message;
	}

	public SystemEvent(EventCode eventCode, String message) {
		this.eventCode = eventCode;
		this.message = message;
	}

	public SystemEvent(EventCode eventCode) {
		this.eventCode = eventCode;
	}

	public EventSeverity getStatus() {
		return status;
	}

	public void setStatus(EventSeverity status) {
		this.status = status;
	}

	public EventCode getEventCode() {
		return eventCode;
	}

	public void setEventCode(EventCode eventCode) {
		this.eventCode = eventCode;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public Map<String, List<Object>> getTags() {
		return tags;
	}

	public boolean isOverriden() {
		return overriden;
	}

	public void setOverriden(boolean overriden) {
		this.overriden = overriden;
	}

	public void addTag(String key, Object value) {
		List<Object> tag = tags.get(key);
		if (tag == null) {
			tag = new ArrayList<Object>();
			tags.put(key, tag);
		}
		
		if (!tag.contains(value))
			tag.add(value);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

    public boolean isKinesisEnabled() {
        return kinesisEnabled;
    }

    public void setKinesisEnabled(boolean kinesisEnabled) {
        this.kinesisEnabled = kinesisEnabled;
    }

    public enum EventSeverity{ INFO, WARNING, ERROR, CRITICAL, ALERT }

}
