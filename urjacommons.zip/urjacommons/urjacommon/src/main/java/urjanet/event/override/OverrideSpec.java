package urjanet.event.override;

import java.util.HashMap;
import java.util.Map;

import urjanet.event.EventCode;

/**
 *
 * @author rburson
 */
public class OverrideSpec {

	private Map<EventCode, UPathEventOverride> overrideMap = new HashMap<EventCode, UPathEventOverride>();
	private boolean isForceOverrideEnabled = false;

	public OverrideSpec() {
	}

	public OverrideSpec(UPathEventOverride ... overrides) {
		addToOverrideMap(overrides);
	}

	private void addToOverrideMap(UPathEventOverride ... overrides){

		for(UPathEventOverride eo : overrides){
			overrideMap.put(eo.getEventCode(), eo);
		}
	}

	public UPathEventOverride getByEventCode(EventCode eventCode){

		return overrideMap.get(eventCode);

	}

	public void addEventOverrides(UPathEventOverride ... overrides){
		addToOverrideMap(overrides);
	}

	public boolean isForceOverrideEnabled() {
		return isForceOverrideEnabled;
	}

	public void setForceOverrideEnabled(boolean isForceOverrideEnabled) {
		this.isForceOverrideEnabled = isForceOverrideEnabled;
	}
}
