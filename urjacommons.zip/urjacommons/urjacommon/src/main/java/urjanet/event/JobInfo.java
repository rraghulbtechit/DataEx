package urjanet.event;

import java.util.Date;


/**
 *
 * @author rburson
 */
public interface JobInfo {

	public String getId();
	public String getType();
	
	public Date getStartDate();
	public Date getEndDate();
	
	public void setStartDate(Date startDate);
	public void setEndDate(Date endDate);
	
	public void add(IJobInfoTag tag, Object value, EventManager manager);

}
