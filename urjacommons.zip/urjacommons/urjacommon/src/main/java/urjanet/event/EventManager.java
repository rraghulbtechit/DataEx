/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package urjanet.event;

import java.util.List;

import urjanet.UrjanetRuntimeException;
import urjanet.event.SystemEvent.EventSeverity;
import urjanet.event.override.OverrideSpec;

/**
 *
 * @author rburson
 */
public interface EventManager {

	/**
	 * Add event
	 *
	 * @param event
	 * @return true if the event is overridden
	 * @throws UrjanetRuntimeException
	 */
	boolean addEvent(SystemEvent event) throws UrjanetRuntimeException;

	boolean containsErrors();

	List<SystemEvent> getEvents();

	List<SystemEvent> getEvents(EventCode code);

	List<SystemEvent> getEvents(EventCode[] codes);

	SystemEvent getFirstEvent(EventCode code);

	JobInfo getJobInfo();

	<T extends JobInfo> T getJobInfo(Class<T> c);

	SystemEvent getLastEvent();

	OverrideSpec getOverrideSpec();

	List<SystemEvent> getOverridenEvents();

	void setJobInfo(JobInfo jobInfo);

	void setOverrideSpec(OverrideSpec overrideSpec);

	void addEventService(EventService service);

	void addListener(EventListener ... listenerList);
	
	void removeListenerByClass(Class<?> thisClass);

	void addInfoTag(IJobInfoTag key, Object value);

	void addEventTag(String name, Object value);

	void removeEventTag(String name);

	void incrementCounter(Object key);
	
	void incrementCounter(Object key, int count);
	
	void setCounter(Object key, int count);

	Integer getCounterFor(Object key);

	void close();

    void clearEvents();

    int getOverridenEventCount();

    int getEventCount();
    
    int getEventCount(EventSeverity eventSeverity);
    
    void addToEventcontext(Object key, Object value);
    
    Object getEventContextValue(Object key);

}
