package urjanet.event.override;

import java.util.Date;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UPathDateExtension {

	private static final Logger log = LoggerFactory.getLogger(UPathDateExtension.class);

	/**
	 * Whether comparativeDate in context equals date specified in format.
	 * Default format is MM/dd/yyyy.
	 * 
	 * @param context
	 * @param date
	 * @return
	 */
	public static boolean sameDay(ExpressionContext context, Date date, String comparativeDate, String format) {

		if (date != null && comparativeDate != null && !comparativeDate.isEmpty()) {
			Date incomingDate = null;
			try {
				if (format == null || format.isEmpty()) format = "MM/dd/yyyy";
			    DateTimeFormatter fmt = DateTimeFormat.forPattern(format);
				incomingDate = fmt.parseDateTime(comparativeDate).toDate();
			} catch (Exception e) {
				log.error("Error parsing date for incoming string : " + date + " using format " + format + ".", e);
				return false;
			}
			if (incomingDate == null || date == null) {
				log.error("Error getting context date for context " + context.getContextNodePointer() + ".");
				return false;
			}
			if (DateUtils.isSameDay(incomingDate, date)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check using default format (MM/dd/yyyy).
	 * 
	 * @param context
	 * @param date
	 * @return
	 */
	public static boolean sameDay(ExpressionContext context, Date incomingDate, String comparativeDate) {
		return sameDay(context, incomingDate, comparativeDate, null);
	}
	
	/**
	 * 
	 * @param context
	 * @param date
	 * @param comparativeDate1
	 * @param firstDateFormat
	 * @param comparativeDate2
	 * @param secondDateformat
	 * @return
	 */
	public static boolean betweenDates(ExpressionContext context, Date date, String comparativeDate1, String firstDateFormat, String comparativeDate2, String secondDateformat) {
		
		if (date != null && comparativeDate1 != null && !comparativeDate1.isEmpty() 
				&& comparativeDate2 != null && !comparativeDate2.isEmpty()) {
			
			Date incomingDate1 = formatDate(comparativeDate1, firstDateFormat);
			Date incomingDate2 = formatDate(comparativeDate2, secondDateformat);
			if (incomingDate1 == null || incomingDate2 == null || date == null) {
				log.error("Error getting context date for context " + context.getContextNodePointer() + ".");
				return false;
			}
			if (date.compareTo(incomingDate1) >= 0 && date.compareTo(incomingDate2) <= 0) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 	
	 * @param context
	 * @param date
	 * @param comparativeDate1
	 * @param comparativeDate2
	 * @return
	 */
	public static boolean betweenDates(ExpressionContext context, Date date, String comparativeDate1, String comparativeDate2) {
		return betweenDates(context, date, comparativeDate1, "MM/dd/yyyy", comparativeDate2, "MM/dd/yyyy");
	}
		
	/**
	 * 
	 * @param incomingDate
	 * @param format
	 * @return
	 */
	private static Date formatDate(String incomingDate, String format) {
		
		try {
			if (format == null || format.isEmpty()) {
				format = "MM/dd/yyyy";
			}
		    DateTimeFormatter fmt = DateTimeFormat.forPattern(format);
			return fmt.parseDateTime(incomingDate).toDate();
		} catch (Exception e) {
			log.error("Error parsing date for incoming string : " + incomingDate + " using format " + format + ".", e);
			return null;
		}
	}
}
