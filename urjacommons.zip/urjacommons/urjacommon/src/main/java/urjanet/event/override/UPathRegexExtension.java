package urjanet.event.override;

import org.apache.commons.jxpath.ExpressionContext;
import org.apache.commons.jxpath.Pointer;

import urjanet.regex.RegExHandler;

public class UPathRegexExtension {

	public static boolean matches(ExpressionContext context, String regExQualifier) {

		Pointer pointer = context.getContextNodePointer();
		if (pointer != null && regExQualifier != null && !regExQualifier.isEmpty()) {
			if (RegExHandler.stringMatchesMultilineIgnoreCase(pointer.getValue().toString(), regExQualifier)) {
				return true;
			}
		}
		return false;
	}
	
}
