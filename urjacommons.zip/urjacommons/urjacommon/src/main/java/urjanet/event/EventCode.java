package urjanet.event;

/**
 *
 * @author rburson
 */
public interface EventCode {

	public int getEventCodeId();

	public String getEventCodeDetail();

}
