package urjanet.event;

public interface EventListener {

	public void gotEvent(SystemEvent event, EventManager manager);
	public void close(JobInfo id);
}
