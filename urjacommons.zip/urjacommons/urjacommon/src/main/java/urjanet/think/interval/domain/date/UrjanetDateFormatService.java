package urjanet.think.interval.domain.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class UrjanetDateFormatService implements DateFormatService {
	
	//Default is US eastern
	public static final String DEFAULT_TIMEZONE = "US/Eastern";
	
	private static UrjanetDateFormatService justOne;
	
	public static DateFormatService get() {
		if (justOne == null)
			justOne = new UrjanetDateFormatService();
		return justOne;
	}
	
	private UrjanetDateFormatService() {
	}
	
	private Map<String, TimeZoneAwareFormatterCache<UrjanetDateFormat>> dateFormatters = new HashMap<String, TimeZoneAwareFormatterCache<UrjanetDateFormat>>();

	@Override
	public Date parse(String date, String format, String timezone) throws ParseException {
		
		if (timezone == null || timezone.isEmpty())
			throw new ParseException("Must specify timezone. Timezone is: " + timezone, -1);
		
		UrjanetDateFormat formatter = getFormatter(format, timezone);
		return formatter.parse(date);
	}
	
	@Override
	public Date parse(String date, String dateFormat, String time, String timeFormat, String timezone) throws ParseException {
		//By default do not use time as offset
		//better default behavior for daylight savings
		return createDate(date, dateFormat, time, timeFormat, timezone, false);
	}
	
	@Override
	public Date parse(String date, String dateFormat, String time, String timeFormat, String timezone, boolean useTimeAsOffset) throws ParseException {
		return createDate(date, dateFormat, time, timeFormat, timezone, useTimeAsOffset);
	}
	
	@Override
	public Date parse(String date, String format) throws ParseException {
		return parse(date, format, DEFAULT_TIMEZONE);
	}

	@Override
	public Date parse(String date, String dateFormat, String time, String timeFormat) throws ParseException {
		return parse(date, dateFormat, time, timeFormat, DEFAULT_TIMEZONE);
	}
	
	@Override
	public String format(Date date, String format) {
		return format(date, format, DEFAULT_TIMEZONE);
	}

	@Override
	public String format(Date date, String format, String timezone) {
		
		if (timezone == null || timezone.isEmpty())
			throw new RuntimeException("Must specify timezone to for. Timezone is: " + timezone);
		
		UrjanetDateFormat formatter = getFormatter(format, timezone);
		return formatter.format(date);
	}
	

	private Date createDate(String date, String dateFormat, String time, String timeFormat, String timezone, boolean useTimeAsOffset) throws ParseException {
		if (timezone == null || timezone.isEmpty())
			throw new ParseException("Must specify timezone. Timezone is: " + timezone, -1);
		
		if (useTimeAsOffset) {
			
			UrjanetDateFormat dateFormatter = getFormatter(dateFormat, timezone);
			
			//Use GMT for time because we're going to add it to the start date
			//if we didn't use gmt, it will throw off the long (time since 1970)
			//we need the pure time since 1970 in gmt to get exacly how many millis
			//if we let timezone factor in, this would automatically add or subtract time to compensate
			UrjanetDateFormat timeFormatter = getFormatter(timeFormat, "GMT");
			
			Date startDate = dateFormatter.parse(date);
			Date startTime = timeFormatter.parse(time);
			
			return new Date(startDate.getTime() + startTime.getTime());
		} else {
			UrjanetDateFormat dateFormatter = getFormatter(dateFormat + "|" + timeFormat, timezone);
			return dateFormatter.parse(date + "|" + time);
		}
	}
	
	/**
	 * synchronized because we don't want to realloc a formatter or cache if one was just being created
	 * might not be a huge deal if it wasn't synchronized
	 * maybe have a pool of formatters if being used by multiple threads?
	 */
	private synchronized UrjanetDateFormat getFormatter(String format, String timezone) {
		TimeZoneAwareFormatterCache<UrjanetDateFormat> cache = dateFormatters.get(timezone);
		if (cache == null) {
			cache = new TimeZoneAwareFormatterCache<UrjanetDateFormat>(timezone);
			dateFormatters.put(timezone, cache);
		}
		
		UrjanetDateFormat formatter = cache.getFormatter(format);
		
		if (formatter == null) {
			formatter = new UrjanetDateFormat(format, timezone);
			cache.addFormatter(format, formatter);
		}
		return formatter;
	}
	
	private static class TimeZoneAwareFormatterCache<T extends SimpleDateFormat> {
		
		private final String timezone;
		
		//Map of format(string) to corresponding formatter
		private Map<String, T> cachedFormatters = new HashMap<String, T>();
		
		public TimeZoneAwareFormatterCache(String timezone) {
			this.timezone = timezone;
		}
		
		public T getFormatter(String format) {
			return cachedFormatters.get(format);
		}
		
		public void addFormatter(String format, T formatter) {
			formatter.setTimeZone(TimeZone.getTimeZone(timezone));
			cachedFormatters.put(format, formatter);
		}
		
	}
	
	public static void main(String[] args) throws ParseException {
//		SimpleDateFormat format = new SimpleDateFormat(IntervalConstants.DEFAULT_DATE_FORMAT);
//		format.setTimeZone(TimeZone.getTimeZone(DataValues.US_EASTERN.getValue()));
//		System.out.println(format.parse("11/3/2013 02:00"));
//		//This is getting 1 hour behind because it is always offset from 11/3 00:00
//		//instead of actual 2 on 11/3
//		System.out.println(UrjanetDateFormatService.get().parse("11/3/2013", "MM/dd/yyyy", "2:00", "HH:mm", "US/Eastern", true));
//		System.out.println(UrjanetDateFormatService.get().parse("11/3/2013", "MM/dd/yyyy", "2:00", "HH:mm", "US/Eastern", false));
	}

}
