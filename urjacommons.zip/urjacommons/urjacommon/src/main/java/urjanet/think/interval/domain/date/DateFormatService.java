package urjanet.think.interval.domain.date;

import java.text.ParseException;
import java.util.Date;

public interface DateFormatService {
	
	public String format(Date date, String format);
	public String format(Date date, String format, String timezone);
	
	//parses with default timezone
	public Date parse(String date, String format) throws ParseException;
	//parses with default timezone
	public Date parse(String date, String dateFormat, String time, String timeFormat) throws ParseException;
	
	public Date parse(String date, String format, String timezone) throws ParseException;
	public Date parse(String date, String dateFormat, String time, String timeFormat, String timezone) throws ParseException;
	
	//This method creates a date using the time as an offset
	//what this means is if you have 11/3/2013 and 2:00
	//It will take the date 11/3/2013 and add 2 hours.
	//The problem is that if it's daylight savings
	//look at the main in UrjanetDateFormatService
	public Date parse(String date, String dateFormat, String time, String timeFormat, String timezone, boolean useTimeAsOffset) throws ParseException;

	/*
	 	SimpleDateFormat format = new SimpleDateFormat(IntervalConstants.DEFAULT_DATE_FORMAT);
		format.setTimeZone(TimeZone.getTimeZone(DataValues.US_EASTERN.getValue()));
		System.out.println(format.parse("11/3/2013 02:00"));
		//This is getting 1 hour behind because it is always offset from 11/3 00:00
		//instead of actual 2 on 11/3
		System.out.println(UrjanetDateFormatService.get().parse("11/3/2013", "MM/dd/yyyy", "2:00", "HH:mm", "US/Eastern", true));
		System.out.println(UrjanetDateFormatService.get().parse("11/3/2013", "MM/dd/yyyy", "2:00", "HH:mm", "US/Eastern", false));
	 */
}
