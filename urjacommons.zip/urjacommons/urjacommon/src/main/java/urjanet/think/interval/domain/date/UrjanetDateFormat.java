package urjanet.think.interval.domain.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class UrjanetDateFormat extends SimpleDateFormat {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3084685777157180441L;

	public UrjanetDateFormat(String format, String timezone) {
		super(format);
		this.setTimeZone(TimeZone.getTimeZone(timezone));
	}
	
	/**
	 * synchronized parse because simpledateformat is not threadsafe
	 */
	public synchronized Date parse(String date) throws ParseException {
		return super.parse(date);
	}

}
