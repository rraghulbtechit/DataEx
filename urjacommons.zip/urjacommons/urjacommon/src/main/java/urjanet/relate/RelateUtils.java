package urjanet.relate;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.UrjanetRuntimeException;

/**
 *
 * @author rburson
 */
public class RelateUtils {

	private static final Logger log = LoggerFactory.getLogger(RelateUtils.class);
	private static RelateUtils justOneMethodMode = new RelateUtils(true);
	private static RelateUtils justOneFieldMode = new RelateUtils(false);
	private boolean useAccessors;

	public static RelateUtils getInstance() {
		return getInstance(true);
	}

	public static RelateUtils getInstance(boolean useAccessors) {
		return useAccessors ? justOneMethodMode : justOneFieldMode;
	}

	private RelateUtils(boolean useAccessors) {
		this.useAccessors = useAccessors;
	}

	public void addChildToCollection(Object parent, Object childToAdd, String childCollectionName) {
		addChildToCollection(parent, childToAdd, childCollectionName, true);
	}

	public void addChildToCollection(Object parent, Object childToAdd, String childCollectionName, boolean allowDups) {

		try {
			String fieldName = childCollectionName != null ? childCollectionName : collectionFieldNameFromClass(childToAdd.getClass());
			if (!useAccessors) {
				Field field = findField(parent, fieldName);
				if (field != null) {
					field.setAccessible(true);
					Collection childCollection = (Collection) field.get(parent);
					if (!allowDups && childCollection.contains(childToAdd)) {
						return;
					}
					childCollection.add(childToAdd);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have Collection called: " + fieldName);
				}

			} else {

				Method getter = findGetter(parent, fieldName);
				if (getter != null) {
					getter.setAccessible(true);
					Collection childCollection = (Collection) getter.invoke(parent);
					if (!allowDups && childCollection.contains(childToAdd)) {
						return;
					}
					childCollection.add(childToAdd);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have getter for Collection called: " + fieldName);
				}
			}

		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't set association for parent: " + parent.getClass() + " and child: " + childToAdd.getClass(), e);
		}



	}

	public <T> void addChildrenToCollection(Object parent, Collection<T> childrenToAdd, String childCollectionName) {
		addChildrenToCollection(parent, childrenToAdd, childCollectionName, true);
	}

	public <T> void addChildrenToCollection(Object parent, Collection<T> childrenToAdd, String childCollectionName, boolean allowDups) {

		if (childrenToAdd.size() < 1) {
			return;
		}

		try {

			String fieldName = childCollectionName != null ? childCollectionName : collectionFieldNameFromClass(childrenToAdd.toArray()[0].getClass());
			if (!useAccessors) {

				Field field = findField(parent, fieldName);
				if (field != null) {
					field.setAccessible(true);
					Collection childCollection = (Collection) field.get(parent);
					if (!allowDups) {
						for (T childToAdd : childrenToAdd) {
							if (!childCollection.contains(childToAdd)) {
								childCollection.add(childToAdd);
							}
						}
					} else {
						childCollection.addAll(childrenToAdd);
					}
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have Collection called: " + fieldName);
				}
			} else {

				Method getter = findGetter(parent, fieldName);
				if (getter != null) {
					getter.setAccessible(true);
					Collection childCollection = (Collection) getter.invoke(parent);
					if (!allowDups) {
						for (T childToAdd : childrenToAdd) {
							if (!childCollection.contains(childToAdd)) {
								childCollection.add(childToAdd);
							}
						}
					} else {
						childCollection.addAll(childrenToAdd);
					}
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have getter for Collection called: " + fieldName);
				}
			}


		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't set association for parent: " + parent.getClass() + " and child: " + childrenToAdd.toArray()[0].getClass(), e);
		}
	}

	public void setDirectAssociation(Object owner, Object theNewValue, String targetFieldName) {

		if (theNewValue == null) {
			throw new UrjanetRuntimeException("Couldn't set association for owner: " + owner.getClass() + " to null - cannot determine field name");
		}

		String fieldName = null;
		try {
			fieldName = targetFieldName != null ? targetFieldName : fieldNameFromClass(theNewValue.getClass());
			if (!useAccessors) {
				Field field = findField(owner, fieldName);
				if (field != null) {
					setMemberValue(owner, field, theNewValue);
				} else {
					throw new UrjanetRuntimeException("Owner doesn't have field called: " + fieldName);
				}
			} else {
				Method setter = findSetter(owner, fieldName, theNewValue.getClass());
				if (setter != null) {
					setter.setAccessible(true);
					setter.invoke(owner, theNewValue);
				} else {
					throw new UrjanetRuntimeException("Owner doesn't have setter for: " + fieldName);
				}
			}


		} catch (Exception e) {
			String newValueClass = theNewValue != null ? theNewValue.getClass().getSimpleName() : null;
			throw new UrjanetRuntimeException("Couldn't set association for owner: " + owner.getClass() + " and " + newValueClass + " : " + fieldName, e);
		}


	}

	public void removeChildFromCollection(Object parent, Object childToRemove, String childCollectionName) {

		try {
			String fieldName = childCollectionName != null ? childCollectionName : collectionFieldNameFromClass(childToRemove.getClass());
			if (!useAccessors) {
				Field field = findField(parent, fieldName);
				if (field != null) {
					field.setAccessible(true);
					Collection childCollection = (Collection) field.get(parent);
					childCollection.remove(childToRemove);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have Collection called: " + fieldName);
				}
			} else {
				Method getter = findGetter(parent, fieldName);
				if (getter != null) {
					getter.setAccessible(true);
					Collection childCollection = (Collection) getter.invoke(parent);
					childCollection.remove(childToRemove);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have getter for Collection called: " + fieldName);
				}
			}


		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't disassociate from parent: " + parent.getClass() + " child: " + childToRemove.getClass(), e);
		}
	}

	public <T> void removeChildrenFromCollection(Object parent, Collection<T> childrenToRemove, String childCollectionName) {

		if (childrenToRemove.size() < 1) {
			return;
		}

		try {
			String fieldName = childCollectionName != null ? childCollectionName : collectionFieldNameFromClass(childrenToRemove.toArray()[0].getClass());

			if (!useAccessors) {
				Field field = findField(parent, fieldName);
				if (field != null) {
					field.setAccessible(true);
					Collection childCollection = (Collection) field.get(parent);
					childCollection.removeAll(childrenToRemove);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have Collection called: " + fieldName);
				}
			} else {
				Method getter = findGetter(parent, fieldName);
				if (getter != null) {
					getter.setAccessible(true);
					Collection childCollection = (Collection) getter.invoke(parent);
					childCollection.removeAll(childrenToRemove);
				} else {
					throw new UrjanetRuntimeException("Parent doesn't have getter for Collection called: " + fieldName);
				}
			}


		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't remove association for parent: " + parent.getClass() + " and children: " + childrenToRemove.toArray()[0].getClass(), e);
		}
	}

	public void removeDirectAssociation(Object owner, Object target, String targetFieldName) {

		try {
			String fieldName = targetFieldName != null ? targetFieldName : fieldNameFromClass(target.getClass());
			if (!useAccessors) {
				Field field = findField(owner, fieldName);
				if (field != null) {
					field.setAccessible(true);
					field.set(owner, null);
				} else {
					throw new UrjanetRuntimeException("Owner doesn't have field called: " + fieldName);
				}

			} else {
				Method setter = findSetter(owner, fieldName, target.getClass());
				if (setter != null) {
					setter.setAccessible(true);
					setter.invoke(owner, (Object) null);
				} else {
					throw new UrjanetRuntimeException("Owner doesn't have setter for: " + fieldName);
				}
			}



		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't remove association for owner: " + owner.getClass() + " and target: " + target.getClass(), e);
		}


	}
	
	public Field findFieldInClass(Class c, String fieldName) {
		while (c != null && !c.equals(Object.class)) {
			Field[] fields = c.getDeclaredFields();
			for (Field field : fields) {
				if (field.getName().equals(fieldName)) {
					return field;
				}
			}
			c = c.getSuperclass();
		}
		return null;

	}

	public Field findField(Object o, String fieldName) {
		return findField(o.getClass(), fieldName);

	}

	public Field findField(Class current, String fieldName) {

		while (current != null && !current.equals(Object.class)) {
			Field[] fields = current.getDeclaredFields();
			for (Field field : fields) {
				if (field.getName().equals(fieldName)) {
					return field;
				}
			}
			current = current.getSuperclass();
		}
		return null;

	}

	public Method findGetter(Object o, String fieldName) {

		String getterName = getterNameFromFieldName(fieldName);
		try {
			return o.getClass().getMethod(getterName);
		} catch (Exception e) {
			return null;
		}

	}

	public Method findSetter(Object o, String fieldName, Class paramType) {

		String setterName = setterNameFromFieldName(fieldName);
		Method m = null;
		try {
			m = o.getClass().getMethod(setterName, paramType);
		} catch (Exception e) {
			//this is suppressed yes, but these exceptions are simply indicators that the method does not exists
			//which we are expecting, when m is null...
		}

		if (m != null) {
			return m;
		}

		while (!paramType.equals(Object.class) && paramType.getSuperclass() != null && !paramType.getSuperclass().equals(Object.class)) {
			paramType = paramType.getSuperclass();
			try {
				m = o.getClass().getMethod(setterName, paramType);
			} catch (Exception e) {
				//this is suppressed yes, but these exceptions are simply indicators that the method does not exists
				//which we are expecting, when m is null...
			}
		}

		return m;
	}

	/**
	 * Get the declared non-static fields of this class
	 *
	 * @param type the class
	 * @param includeInherited include inherited fields
	 * @return a list of fields
	 */
	public List<Field> getAllFields(Class<?> type, boolean includeInherited) {
		return getAllFields(type, includeInherited, false, false);
	}

	/**
	 * Get the declared fields of this class
	 *
	 * @param type
	 * @param includeInherited
	 * @param includeStatics
	 * @return
	 */
	public List<Field> getAllFields(Class<?> type, boolean includeInherited, boolean includeStatics, boolean parentFieldsFirst) {
		
		List<Class<?>> classes = new ArrayList<Class<?>>();
		Map<Class, Integer> appendMap = new HashMap<Class, Integer>();
		
		for (Class<?> c = type; c != null && !c.equals(Object.class); c = c.getSuperclass()) {
			if (parentFieldsFirst) {
				classes.add(0, c);
			} else {
				classes.add(c);
			}
		}
		
		List<Field> fields = new ArrayList<Field>();
		if (includeInherited) {

			for (Class<?> c : classes) {

				try {
					Field delayField = c.getDeclaredField("FIELD_APPEND_DELAY");
					delayField.setAccessible(true);
					int delay = delayField.getInt(null);
					appendMap.put(c, delay);
					continue;
				} catch (Exception ex) {}

				for (Field f : c.getDeclaredFields()) {
					if (includeStatics || !Modifier.isStatic(f.getModifiers()))
						fields.add(f);
				}

				// decrement all values in map
				Iterator<Entry<Class, Integer>> iter = appendMap.entrySet().iterator();
				while (iter.hasNext()) {
					Entry e = iter.next();
					int val = ((Integer) e.getValue()) - 1;

					if (val == 0) {
						// now we can add this class's fields
						Class clazz = (Class) e.getKey();
						for (Field f : clazz.getDeclaredFields()) {
							if (includeStatics || !Modifier.isStatic(f.getModifiers()))
								fields.add(f);
						}
						iter.remove();

					} else {
						e.setValue(val);
					}
				}

			}

			// append fields of any remaining classes from the map	// TODO: ordering
			for (Class c : appendMap.keySet()) {
				for (Field f : c.getDeclaredFields()) {
					if (includeStatics || !Modifier.isStatic(f.getModifiers()))
						fields.add(f);
				}
			}

		} else {
			if (includeStatics) {
				return Arrays.asList(type.getDeclaredFields());
			} else {
				for (Field f : type.getDeclaredFields()) {
					if (!Modifier.isStatic(f.getModifiers())) {
						fields.add(f);
					}
				}
			}
		}
		return fields;
	}

	/**
	 * Get the value for the supplied field name, which is a field of Object. If useAccessor is true for this RelateUtils instance,
	 * it will use the corresponding getter to access the field.
	 *
	 * @param o
	 * @param f
	 * @return
	 */
	public Object getMemberValue(Object o, String fieldName) {
		return getMemberValue(o, findField(o, fieldName));
	}

	/**
	 * Get the value for the supplied Field of Object. If useAccessor is true for this RelateUtils instance,
	 * it will use the corresponding getter to access the field.
	 *
	 * @param o
	 * @param f
	 * @return
	 */
	public Object getMemberValue(Object o, Field f) {

		if (useAccessors) {
			try {
				Method getter = findGetter(o, f.getName());
				getter.setAccessible(true);
				return getter.invoke(o);
			} catch (Exception e) {
				throw new UrjanetRuntimeException("Could not find getter for Field: " + f.getName(), e);
			}
		} else {
			try {
				f.setAccessible(true);
				return f.get(o);
			} catch (Exception e) {
				throw new UrjanetRuntimeException("Could not get value for Field: " + f.getName(), e);
			}
		}

	}

	/**
	 * Set the value of the given field to the give 'value', on o
	 *
	 * @param o
	 * @param f
	 * @param value
	 */
	public void setMemberValue(Object o, Field f, Object value) {

		if (useAccessors) {
			Method setter = findSetter(o, f.getName(), value.getClass());
			if (setter == null) {
				throw new UrjanetRuntimeException("Could not find setter for Field: " + f.getName());
			}
			try {
				setter.setAccessible(true);
				setter.invoke(o, value);

			} catch (Exception e) {
				throw new UrjanetRuntimeException("Could not set value with setter for Field: " + f.getName(), e);
			}
		} else {
			try {
				f.setAccessible(true);
				f.set(o, value);

			} catch (Exception e) {
				throw new UrjanetRuntimeException("Could not set value for Field: " + f.getName(), e);
			}
		}


	}

	public void addCollectionElement(Object o, Field collectionField, Object elementToAdd, boolean allowDups) {

		try {
			if (!useAccessors) {
				collectionField.setAccessible(true);
				Collection childCollection = (Collection) collectionField.get(o);
				if (!allowDups && childCollection.contains(elementToAdd)) {
					return;
				}
				childCollection.add(elementToAdd);
			} else {

				Method getter = findGetter(o, collectionField.getName());
				if (getter == null) {
					throw new UrjanetRuntimeException("Could not find getter for collection field: " + o.getClass().getSimpleName() + "." + collectionField.getName());
				}
				getter.setAccessible(true);
				Collection childCollection = (Collection) getter.invoke(o);
				if (!allowDups && childCollection.contains(elementToAdd)) {
					return;
				}
				childCollection.add(elementToAdd);
			}
		} catch (UrjanetRuntimeException ure) {
			throw ure;
		} catch (Exception e) {
			throw new UrjanetRuntimeException("Failed to add element to collection " + o.getClass().getSimpleName() + "." + collectionField.getName(), e);

		}
	}

	public void removeCollectionElement(Object o, Field collectionField, Object elementToRemove) {

		try {
			if (!useAccessors) {
				collectionField.setAccessible(true);
				Collection childCollection = (Collection) collectionField.get(o);
				childCollection.remove(elementToRemove);
			} else {

				Method getter = findGetter(o, collectionField.getName());
				if (getter == null) {
					throw new UrjanetRuntimeException("Could not find getter for collection field: " + o.getClass().getSimpleName() + "." + collectionField.getName());
				}
				getter.setAccessible(true);
				Collection childCollection = (Collection) getter.invoke(o);
				childCollection.remove(elementToRemove);
			}
		} catch (UrjanetRuntimeException ure) {
			throw ure;
		} catch (Exception e) {
			throw new UrjanetRuntimeException("Failed to add element to collection " + o.getClass().getSimpleName() + "." + collectionField.getName(), e);

		}
	}

	/**
	 * Get all the declared fields of this class and its super classes as Objects
	 *
	 * @param c
	 * @param parent
	 * @return
	 * @throws UrjanetRuntimeException
	 */
	/*
	 * @TODO
	 * Things to ask Sri about...
	 *
	 * 1) Can we just pass in the Object as the single arguement here and get the class from it?
	 * 2) Can we iterate through 'getter' methods that return an Object (or non-primitive) instead of Fields (and thus field names)?
	 *    This would save the expensvie step of building the method name then calling the getter.  Also what if the getter isn't there?
	 *    Currently, nobody would know they missed a field.  This way, only the defined methods would be traversed.
	 * 3) Why the check for Collections? Why build a new list to put the collections in?  Why not return the collections themselves?
	 *
	 *
	 */
	public List<Object> getFieldsAsObjectsFromParent(Class c, Object parent) throws UrjanetRuntimeException {

		List<Field> fields = getAllFields(c, true);
		List<Object> objectList = new ArrayList<Object>();

		try {
			for (Field field : fields) {
				if (!field.getType().isPrimitive()) {
					Method getter = findGetter(parent, field.getName());
					if (getter != null) {
						Object subNode = getter.invoke(parent);
						if (subNode != null) {
							if (subNode instanceof Collection) {
								// Its a collection
								Collection childCollection = (Collection) subNode;

								// TODO: Mostly the member collections are Set's
								Set<Object> subCollection = new HashSet<Object>();
								if (!childCollection.isEmpty()) {
									Iterator itr = childCollection.iterator();
									while (itr.hasNext()) {
										Object node = itr.next();
										subCollection.add(node);
									}
								}
								if (!subCollection.isEmpty()) {
									objectList.add(subCollection);
								}
							} else {
								objectList.add(subNode);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw new UrjanetRuntimeException("Couldn't get fields for class as Objects: " + c, e);
		}

		return objectList;
	}

	public String setterNameFromFieldName(String fieldName) {

		return "set".concat(fieldName.substring(0, 1).toUpperCase().concat(fieldName.substring(1)));

	}

	public String setterNameFromClass(Class c) {

		String unQClassName = c.getSimpleName();
		return "set".concat(unQClassName);

	}

	public String getterNameFromFieldName(String fieldName) {

		return "get".concat(fieldName.substring(0, 1).toUpperCase().concat(fieldName.substring(1)));

	}

	public String getterNameFromClass(Class c) {

		String unQClassName = c.getSimpleName();
		return "get".concat(unQClassName);

	}

	public String fieldNameFromClass(Class c) {

		String unQClassName = c.getSimpleName();
		return unQClassName.substring(0, 1).toLowerCase().concat(unQClassName.substring(1));

	}

	public String collectionFieldNameFromClass(Class c) {

		String unQClassName = c.getSimpleName();
		return unQClassName.substring(0, 1).toLowerCase().concat(unQClassName.substring(1)).concat("s");

	}

}
