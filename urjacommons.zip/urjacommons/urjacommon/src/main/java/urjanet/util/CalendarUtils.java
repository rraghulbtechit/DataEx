package urjanet.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Interval;
import org.joda.time.MutableDateTime;

import urjanet.UrjanetRuntimeException;

/**
 * Datetime helpers:  date arithmetic and general parsing
 * 
 * @author rburson
 */

public class CalendarUtils {
		
	// this just handles US style date formats where the month comes before the day
	// if needed we can always add European style as a separate map and include a flag in the parse() method
	// to indicate which locale you are working with
	
	private static final Map<Pattern, String> DATE_FORMAT_REGEXPS = new LinkedHashMap<Pattern, String>() {{
		put(Pattern.compile("^\\d{8}$"), "yyyyMMdd");
        put(Pattern.compile("^\\d{1,2}-\\d{1,2}-\\d{2}$"), "MM-dd-yy");
        put(Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{2}$"), "MM/dd/yy");
        put(Pattern.compile("^\\d{1,2}-\\d{1,2}-\\d{4}$"), "MM-dd-yyyy");
        put(Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{4}$"), "MM/dd/yyyy");
        put(Pattern.compile("^\\d{1,2}-[a-z]{3}-\\d{2}$"), "dd-MMM-yy");
        put(Pattern.compile("^\\d{1,2}-[a-z]{3}-\\d{4}$"), "dd-MMM-yyyy");
        put(Pattern.compile("^\\d{4}-\\d{1,2}-\\d{1,2}$"), "yyyy-MM-dd");
        put(Pattern.compile("^\\d{4}/\\d{1,2}/\\d{1,2}$"), "yyyy/MM/dd");
        put(Pattern.compile("^[a-z]{3}\\s\\d{1,2}\\s\\d{4}$"), "MMM dd yyyy");
        put(Pattern.compile("^[a-z]{4,}\\s\\d{1,2}\\s\\d{4}$"), "MMMM dd yyyy");
        put(Pattern.compile("^\\d{12}$"), "yyyyMMddHHmm");
        put(Pattern.compile("^\\d{8}\\s\\d{4}$"), "yyyyMMdd HHmm");
        put(Pattern.compile("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$"), "MM-dd-yyyy HH:mm");
        put(Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$"), "MM/dd/yyyy HH:mm");
        put(Pattern.compile("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$"), "yyyy-MM-dd HH:mm");
        put(Pattern.compile("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$"), "yyyy/MM/dd HH:mm");
        put(Pattern.compile("^[a-z]{3}\\s\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}$"), "MMM dd yyyy HH:mm");
        put(Pattern.compile("^[a-z]{4,}\\s\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}$"), "MMMM dd yyyy HH:mm");
        put(Pattern.compile("^\\d{14}$"), "yyyyMMddHHmmss");
        put(Pattern.compile("^\\d{8}\\s\\d{6}$"), "yyyyMMdd HHmmss");
        put(Pattern.compile("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "MM-dd-yyyy HH:mm:ss");
        put(Pattern.compile("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "MM/dd/yyyy HH:mm:ss");
        put(Pattern.compile("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "yyyy-MM-dd HH:mm:ss");
        put(Pattern.compile("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "yyyy/MM/dd HH:mm:ss");
        put(Pattern.compile("^[a-z]{3}\\s\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "MMM dd yyyy HH:mm:ss");
        put(Pattern.compile("^[a-z]{4,}\\s\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$"), "MMMM dd yyyy HH:mm:ss");
    }};
    
    
    /**
     * Parse the given date string to date object and return a date instance based on the given
     * date string. This makes use of the {@link DateUtil#determineDateFormat(String)} to determine
     * the SimpleDateFormat pattern to be used for parsing.
     * @param dateString The date string to be parsed to date object.
     * @return The parsed date object.
     * @throws ParseException If the date format pattern of the given date string is unknown, or if
     * the given date string or its actual date is invalid based on the date format pattern.
     */
    public static Date parse(String dateString) throws ParseException {
        String dateFormat = determineDateFormat(dateString);
        if (dateFormat == null) {
            throw new ParseException("Unknown date format.", 0);
        }
        return parse(dateString, dateFormat);
    }

    /**
     * Validate the actual date of the given date string based on the given date format pattern and
     * return a date instance based on the given date string.
     * @param dateString The date string.
     * @param dateFormat The date format pattern which should respect the SimpleDateFormat rules.
     * @return The parsed date object.
     * @throws ParseException If the given date string or its actual date is invalid based on the
     * given date format pattern.
     * @see SimpleDateFormat
     */
    public static Date parse(String dateString, String dateFormat) throws ParseException {
    	if (StringUtils.isBlank(dateFormat))
    		return parse(dateString);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        simpleDateFormat.setLenient(false); // Don't automatically convert invalid date.
        return simpleDateFormat.parse(dateString);
    }

    // Validators ---------------------------------------------------------------------------------

    /**
     * Checks whether the actual date of the given date string is valid. This makes use of the
     * {@link DateUtil#determineDateFormat(String)} to determine the SimpleDateFormat pattern to be
     * used for parsing.
     * @param dateString The date string.
     * @return True if the actual date of the given date string is valid.
     */
    public static boolean isValidDate(String dateString) {
        try {
            parse(dateString);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * Checks whether the actual date of the given date string is valid based on the given date
     * format pattern.
     * @param dateString The date string.
     * @param dateFormat The date format pattern which should respect the SimpleDateFormat rules.
     * @return True if the actual date of the given date string is valid based on the given date
     * format pattern.
     * @see SimpleDateFormat
     */
    public static boolean isValidDate(String dateString, String dateFormat) {
        try {
            parse(dateString, dateFormat);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * Determine SimpleDateFormat pattern matching with the given date string. Returns null if
     * format is unknown. You can simply extend with more formats if needed.
     * @param dateString The date string to determine the SimpleDateFormat pattern for.
     * @return The matching SimpleDateFormat pattern, or null if format is unknown.
     * @see SimpleDateFormat
     */
    public static String determineDateFormat(String dateString) {
    	String dateStringLower = dateString.toLowerCase();
        for (Pattern regexp : DATE_FORMAT_REGEXPS.keySet()) {
        	Matcher matcher = regexp.matcher(dateStringLower);
        	if (matcher.matches()) {
                return DATE_FORMAT_REGEXPS.get(regexp);
            }
        }
        return null; // Unknown format.
    }    
    
	public static Date addDays(Date initialDate, int daysToAdd){
		return new DateTime(initialDate).plusDays(daysToAdd).toDate();
	}

	public static Date subtractDays(Date initialDate, int daysToSubtract){
		return new DateTime(initialDate).minusDays(daysToSubtract).toDate();
	}

	public static int numberOfDaysIn(Date startDate, Date endDate){

		return Days.daysBetween(new DateTime(startDate), new DateTime(endDate)).getDays();
	}

	public static int numberOfHoursBetween(Date startDate, Date endDate){
		
		return Hours.hoursBetween(new DateTime(startDate), new DateTime(endDate)).getHours();
	}
	
	public static int numberOfHoursBetweenExcludingWeekends(Date startDate, Date endDate) {
		return numberOfHoursBetweenExcludingWeekends(startDate, endDate, false, false);
	}
	
	public static int numberOfHoursBetweenExcludingWeekends(Date startDate, Date endDate, boolean includeSaturday, boolean includeSunday) {
		int totalHours = numberOfHoursBetween(startDate, endDate);
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(startDate);
		Calendar endCal = Calendar.getInstance();
		endCal.setTime(endDate);
		int startDayOfWeek = startCal.get(Calendar.DAY_OF_WEEK);
		int endDayOfWeek = endCal.get(Calendar.DAY_OF_WEEK);
		
		int weekendDays = 0;
		while (!startCal.after(endCal)) {
			if ( (!includeSaturday && Calendar.SATURDAY == startCal.get(Calendar.DAY_OF_WEEK)) 
				  || (!includeSunday && Calendar.SUNDAY == startCal.get(Calendar.DAY_OF_WEEK))) {
				weekendDays++;
			}
			startCal.add(Calendar.DAY_OF_MONTH, 1);
		}
		int weekendHours = weekendDays * 24;
		
		if ((!includeSaturday && startDayOfWeek == Calendar.SATURDAY) || (!includeSunday && startDayOfWeek == Calendar.SUNDAY))
			weekendHours -= startCal.get(Calendar.HOUR_OF_DAY) + (startCal.get(Calendar.MINUTE) >= 30 ? 1 : 0);
		if ((!includeSaturday && endDayOfWeek == Calendar.SATURDAY) || (!includeSunday && endDayOfWeek == Calendar.SUNDAY))
			weekendHours -= (24 - endCal.get(Calendar.HOUR_OF_DAY) + (endCal.get(Calendar.MINUTE) >= 30 ? 1 : 0));
		
		return totalHours - weekendHours;
	}

	public static boolean containsOrEquals(Date startDate, Date endDate, Date targetDate){

		return (new Interval(startDate.getTime(), endDate.getTime()).contains(targetDate.getTime()) || endDate.equals(targetDate));
	}

	public static boolean doesOverlapOneDayTolerance(Date startDate1, Date endDate1, Date startDate2, Date endDate2) {

		return doesOverlap(startDate1, endDate1, startDate2, endDate2, 1);
	}

	public static boolean doesOverlap(Date startDate1, Date endDate1, Date startDate2, Date endDate2, int daysTolerance) {

		if(daysTolerance > 0){
			endDate1 = CalendarUtils.addDays(endDate1, daysTolerance);
			endDate2 = CalendarUtils.addDays(endDate2, daysTolerance);
		}

		if (startDate1.after(endDate1) || startDate2.after(endDate2)) {
			throw new UrjanetRuntimeException("Start date cannot be greater than the end date.");
		}
		
		Interval firstInterval = new Interval(startDate1.getTime(), endDate1.getTime());
		Interval secondInterval = new Interval(startDate2.getTime(), endDate2.getTime());
		
		return firstInterval.overlaps(secondInterval);
		
	}

	public static Date trimPrecisionToMinutes(Date date){

		MutableDateTime mdt = new MutableDateTime(date);
		mdt.setSecondOfMinute(0);
		mdt.setMillisOfSecond(0);

		return mdt.toDate();
	}
	
	/**
	 * 
	 * @param startDate
	 * @param endDate
	 * @return a negative value if endDate < startDate
	 */
	public static long getNumBusinessDaysBetween(Date startDate, Date endDate) {
		//see http://stackoverflow.com/questions/4600034/calculate-number-of-weekdays-between-two-dates-in-java
	    //Ignore argument check

		Calendar startCal = Calendar.getInstance();
	    startCal.setTime(startDate);        

	    Calendar endCal = Calendar.getInstance();
	    endCal.setTime(endDate);

	    int workDays = 0;

	    //Return 0 if start and end are the same
	    if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
	        return 0;
	    }

	    boolean isEndDateBeforeStartDate = startCal.getTimeInMillis() > endCal.getTimeInMillis();
	    if (isEndDateBeforeStartDate) {
	        startCal.setTime(endDate);
	        endCal.setTime(startDate);
	    }

	    do {
	       //excluding start date
	        startCal.add(Calendar.DAY_OF_MONTH, 1);
	        if (startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY && startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
	            ++workDays;
	        }
	    } while (startCal.getTimeInMillis() < endCal.getTimeInMillis()); //excluding end date

	    return isEndDateBeforeStartDate ? -1*workDays : workDays;
	}
	
	
	public static void main(String[] args) throws ParseException {
//		Calendar cal1 = Calendar.getInstance();
//		cal1.set(2014, 4, 25, 20, 3);
//		Calendar cal2 = Calendar.getInstance();
//		cal2.set(2014, 4, 26, 9, 3);
//		
//		System.out.println(CalendarUtils.numberOfHoursBetweenExcludingWeekends(cal1.getTime(), cal2.getTime()));
		
		Date startDate = new SimpleDateFormat("MM/dd/yyyy").parse("07/15/2017");
		Date endDate = new SimpleDateFormat("MM/dd/yyyy").parse("07/26/2017");
		System.out.println(CalendarUtils.getNumBusinessDaysBetween(startDate, endDate));
		
	}
	
}
