package urjanet.util;

import java.util.Set;

public class UrjanetSetUtils {
	
	public static boolean isValidSet(Set set) {
		return set != null && !set.isEmpty();
	}

}
