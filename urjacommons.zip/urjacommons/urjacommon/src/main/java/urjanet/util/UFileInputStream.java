package urjanet.util;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * 
 * @author xavierd
 *
 */
public class UFileInputStream extends java.io.FileInputStream {

	private String absolutePath;
	
	public UFileInputStream(File file) throws FileNotFoundException {
		super(file);
		this.absolutePath = file.getAbsolutePath();
	}

	public String getAbsolutePath() {
		return absolutePath;
	}

}
