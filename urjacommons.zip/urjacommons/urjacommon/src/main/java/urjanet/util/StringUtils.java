package urjanet.util;

import java.util.Arrays;

/**
 *
 * @author rburson
 */
public class StringUtils {


	public static String[] addStringToArray(String toAdd, String[] notNullArray){

		String[] newArray = Arrays.copyOf(notNullArray, notNullArray.length + 1);
		newArray[notNullArray.length] = toAdd;

		return newArray;

	}

	public static boolean equalOrBothNull(String s1, String s2){

		if(ObjectUtils.bothNull(s1, s2)) return true;

		if(ObjectUtils.xorNull(s1, s2)) return false;

		return s1.equals(s2);
	}

	public static boolean notEqualNeitherNull(String s1, String s2){

		if(ObjectUtils.eitherNull(s1, s2)) return false;

		return !s1.equals(s2);

	}

	public static boolean equalNeitherNull(String s1, String s2){

		if(ObjectUtils.bothNull(s1, s2)) return false;

		if(ObjectUtils.xorNull(s1, s2)) return false;

		return s1.equals(s2);
	}

	public static boolean equalOrBothNullIgnoreCase(String s1, String s2){

		if(ObjectUtils.bothNull(s1, s2)) return true;

		if(ObjectUtils.xorNull(s1, s2)) return false;

		return s1.equalsIgnoreCase(s2);
	}

	public static boolean equalNeitherNullIgnoreCase(String s1, String s2){

		if(ObjectUtils.bothNull(s1, s2)) return false;

		if(ObjectUtils.xorNull(s1, s2)) return false;

		return s1.equalsIgnoreCase(s2);
	}

	public static int compareStringsNullAreEqual(String s1, String s2){

		if(equalOrBothNull(s1, s2)) return 0;

		if(s1 == null){
			return -1;
		}else if(s2 == null){
			return 1;
		}else{
			return s1.compareTo(s2);
		}

	}

	public static String camelCase(String s){

		if(s.length() == 1) return s.toLowerCase();
		return s.substring(0, 1).toLowerCase() + s.substring(1);

		
	}

	public static String trim(String s1) {
		
		int len = s1.length();
		int st = 0;
		char[] val = s1.toCharArray();

		while ((st < len) && (Character.isWhitespace(val[st]) || Character.isSpaceChar(val[st]))) {
		    st++;
		}
		while ((st < len) && (Character.isWhitespace(val[len - 1]) || Character.isSpaceChar(val[len - 1]))) {
		    len--;
		}
		return (st >= 0 && len > 0) ? s1.substring(st, len) : s1;
	}
	
	public static String removeWhitespace(String s) {
		if (s == null || s.isEmpty())
			return s;
		
		char[] in = s.toCharArray();
		StringBuilder out = new StringBuilder(in.length);
		
		for (char c : in) {
			if (Character.isWhitespace(c) || Character.isSpaceChar(c))
				continue;
			out.append(c);
		}
		
		return out.toString();
	}
	
	//Why do we have our own StringUtils???? arg.... I want to use apache!
	public static boolean isBlank(String s) {
		return org.apache.commons.lang.StringUtils.isBlank(s);
	}

}
