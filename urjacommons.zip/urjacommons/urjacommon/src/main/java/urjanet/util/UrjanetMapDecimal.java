package urjanet.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class UrjanetMapDecimal {
	
	private Map<String, BigDecimal> decimalMap = new HashMap<String, BigDecimal>();
	
	public void add(String key, BigDecimal value) {
		BigDecimal number = decimalMap.get(key);
		if (number == null) {
			decimalMap.put(key, value);
		} else {
			decimalMap.put(key, number.add(value));
		}
	}
	
	public void subtract(String key, BigDecimal value) {
		BigDecimal number = decimalMap.get(key);
		if (number == null) {
			decimalMap.put(key, new BigDecimal(0).subtract(value));
		} else {
			decimalMap.put(key, number.subtract(value));
		}
	}
	
	public BigDecimal get(String key) {
		return decimalMap.get(key);
	}
	
	public Map<String, BigDecimal> getMap() {
		return decimalMap;
	}

}
