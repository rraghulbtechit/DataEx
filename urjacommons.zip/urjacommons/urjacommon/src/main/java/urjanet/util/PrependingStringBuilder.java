package urjanet.util;

/*
 * 
 * This is a prepending StringBuilder optimized for constantly prepending 
 * strings to the front of the buffer.
 */

public class PrependingStringBuilder implements CharSequence {
	
	private int size;
 	private int position;
 	private char[] buffer;

 	public PrependingStringBuilder()	{
 		this(16);
 	}

 	public PrependingStringBuilder(final int size) {
 		buffer = new char[size];
 		position = size;
 		this.size = 0;
 	}

 	public PrependingStringBuilder(final String start) {
 		this(start.length() + 16);
 		prepend(start);
 	}
 	
 	public PrependingStringBuilder prepend(final char ch) {
 		int len = 1;
 		if (position < len) {
 			expandCapacity(size + len);
 		}
 		position -= len;
 		buffer[position] = ch;
 		size += len;
 		return this;
 	}

 	public PrependingStringBuilder prepend(final String str) {
 		int len = str.length();
 		if (position < len)	{
 			expandCapacity(size + len);
 		}
 		str.getChars(0, len, buffer, position - len);
		position -= len;
		size += len;
		return this;
	}

	private void expandCapacity(final int minimumCapacity) {
		int newCapacity = (buffer.length + 1) * 2;
		if (minimumCapacity > newCapacity) {
			newCapacity = minimumCapacity;
		}
		char newValue[] = new char[newCapacity];
		System.arraycopy(buffer, position, newValue, newCapacity - size, size);
		buffer = newValue;
		position = newCapacity - size;
	}

	public int length()	{
		return size;
	}

	@Override
	public String toString() {
		return new String(buffer, position, size);
	}

	@Override
	public boolean equals(final Object obj)	{
		if (obj == this) {
			return true;
		}
		else if (obj == null) {
			return false;
		}
		else {
			return toString().equals(obj.toString());
		}
	}
	
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public char charAt(int index) {
		if ((index < 0) || (index >= size))
			throw new StringIndexOutOfBoundsException(index);
		return buffer[position + index];
	}

	@Override
	public CharSequence subSequence(int start, int end) {
		return substring(start, end);
	}

	public String substring(int start, int end) {
		if (start < 0)
			throw new StringIndexOutOfBoundsException(start);
		 if (end > size)
		     throw new StringIndexOutOfBoundsException(end);
		 if (start > end)
		     throw new StringIndexOutOfBoundsException(end - start);
		 return new String(buffer, position + start, end - start);
	}	
	
	public static void main(String[] args) {
		
		PrependingStringBuilder sb = new PrependingStringBuilder(256);
		
		sb.prepend("AAAAA").prepend("BBBBB").prepend("CCCCC").prepend("12345");
		
		System.out.println(sb.toString());
		
		String sub = sb.substring(3, 7);
		
		System.out.println(sub);
		
	}
}