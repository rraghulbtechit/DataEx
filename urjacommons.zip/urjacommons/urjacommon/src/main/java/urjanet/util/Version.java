package urjanet.util;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stamp build-time version info into assemble.jar resource file ('src/main/resources/version.properties')
 * 
 * Please do not commit the generated resource file to source control.
 * 
 * @author trose
 *
 */

public class Version
{
	private static final Logger log = LoggerFactory.getLogger(Version.class);
	
	private static Properties props = null;
	
	static {
		loadProps();
	}
	
	private static void loadProps() {
		
		props = new Properties();
		InputStream in = null;
		try {
			in = Version.class.getClass().getResourceAsStream("/version.properties");
			props.load(in);
		} catch (Exception e) {
			log.warn("Could not load build version properties: " + e.toString());
		} finally {
			if (in != null) 
				try { in.close(); } catch (Exception ignore) { }
		}
	}
	
	public static String getVersion() {
		
		String buildVersion = props.getProperty("buildVersion");
		if (buildVersion == null)
			buildVersion = "";
		return buildVersion;
	}
	
	public static String getDate() {
	
		String buildDate = props.getProperty("buildDate");
		if (buildDate == null)
			buildDate = "";
		return buildDate;		
	}
	
	/*
	// old scheme that used assemble.jar manifest to hold the version
	public static String getVersion()
	{
		String version = "";
		
		try {
			Class clazz = Version.class;
			String className = clazz.getSimpleName() + ".class";
			String classPath = clazz.getResource(className).toString();
			if (classPath.startsWith("jar")) {
				String manifestPath = classPath.substring(0, classPath.lastIndexOf("!") + 1) + "/META-INF/MANIFEST.MF";
				Manifest manifest = new Manifest(new URL(manifestPath).openStream());
				Attributes attr = manifest.getMainAttributes();
				version = attr.getValue("Implementation-Version");
			}
		} catch (Exception ignore) {
			
		}
	
		return version;
	}
	
	public static String getVersion(String jarPath) {

		String version = "";
		
		try {
			JarInputStream jis = new JarInputStream(new FileInputStream(jarPath));
			Manifest manifest = jis.getManifest();
			Attributes attr = manifest.getMainAttributes();
			version = attr.getValue("Implementation-Version");
		} catch (Exception ignore) {
			
		}
	
		return version;		
	}

	*/
	
	
	public static void main(String[] args) {

		System.out.println("buildVersion = " + Version.getVersion());
		System.out.println("buildDate = " + Version.getDate());
	}

}
