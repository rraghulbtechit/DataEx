package urjanet.util;

import java.util.LinkedList;
import java.util.List;

public class UrjanetListUtils
{
	public enum Position
    {
        BEFORE, AFTER
    };

    /**
     * Moves an element `elementToMove` to be just before or just after a `targetElement`.
     *
     * @param list
     * @param elementToMove
     * @param targetElement
     * @param pos
     */
    public static <T> List<T> moveElementTo( List<T> list, T elementToMove, T targetElement, Position pos )
    {
    	if(list == null || elementToMove == null || targetElement == null){
    		return list;
    	}
    	
        if ( elementToMove.equals( targetElement ) )
        {
            return list;
        }
        
        List<T> linkedList = new LinkedList<T>(list);
        
        int srcIndex = linkedList.indexOf( elementToMove );
        int targetIndex = linkedList.indexOf( targetElement );
        if ( srcIndex < 0 )
        {
            throw new IllegalArgumentException( "elementToMove: " + elementToMove + " not in the list!" );
        }
        if ( targetIndex < 0 )
        {
            throw new IllegalArgumentException( "targetElement: " + targetElement + " not in the list!" );
        }
        linkedList.remove( elementToMove );

        // if the element to move is after the targetElement in the list, just remove it
        // else the element to move is before the targetElement. When we removed it, the targetIndex should be decreased by one
        if ( srcIndex < targetIndex )
        {
            targetIndex -= 1;
        }
        switch ( pos )
        {
            case AFTER:
            	linkedList.add( targetIndex + 1, elementToMove );
                break;
            case BEFORE:
            	linkedList.add( targetIndex, elementToMove );
                break;
        }
        
        return linkedList;
    }
    
    /**
     * Moves elements `elementsToMove` List to be just before or just after a `targetElement`.
     * If the `elementsToMove` List is empty, then it does nothing.
     *
     * @param list
     * @param elementToMove
     * @param targetElement
     * @param pos
     */
    public static <T> List<T> moveElementsTo( List<T> list, List<T> elementsToMove, T targetElement, Position pos )
    {
    	
    	if(list == null || elementsToMove == null || targetElement == null){
    		return list;
    	}
    	
        if ( elementsToMove.isEmpty() )
        {
            return list;
        }
        
        List<T> linkedList = new LinkedList<T>(list);

        if(pos == Position.AFTER){
        	//If the Position is "AFTER" then the list needs to be iterated in reverse order so that, after the complete list is moved, the `elementsToMove` list will maintain its original order
        	for(int i = elementsToMove.size(); i > 0;){
        		linkedList = moveElementTo(linkedList, elementsToMove.get(--i), targetElement, pos);
            }
        }else if(pos == Position.BEFORE){
        	for(T elementToMove : linkedList){
        		linkedList =  moveElementTo(linkedList, elementToMove, targetElement, pos);
        	}
        }
        
        return linkedList;
    }
    
    public static boolean isValidList(List list) {
		return list != null && !list.isEmpty();
	}
    
}