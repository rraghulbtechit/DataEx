package urjanet.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

public class StatUtils {

	private static final int DEFAULT_SCALE = 10;
	
	/**
	 * @param list of values
	 * @return the mean of input values
	 */
	public static BigDecimal mean(List<BigDecimal> values) {
		
		if (values.size() > 0) {
			BigDecimal sum = BigDecimal.ZERO;
			for (BigDecimal val : values) {
				sum = sum.add(val);
			}
			return sum.divide(new BigDecimal(values.size()), DEFAULT_SCALE, BigDecimal.ROUND_HALF_UP);
		}
		
		return null;
	}
	
	/**
	 * @param list of values
	 * @return the variance
	 */
	public static BigDecimal variance(List<BigDecimal> values) {
		BigDecimal sigma = BigDecimal.ZERO;
		BigDecimal meanValue = mean(values);
		
		for (BigDecimal val : values) {
			BigDecimal diff = val.subtract(meanValue).pow(2);
			sigma = sigma.add(diff);
		}
		return (sigma.divide(new BigDecimal(values.size()), DEFAULT_SCALE, BigDecimal.ROUND_HALF_UP));
	}

	/**
	 * @param list of values
	 * @return the standard deviation
	 */
	public static BigDecimal standardDeviation(List<BigDecimal> values) {
		return BigSquareRoot.get(variance(values));
	}

	/**
	 * Square root of a BigDecimal value.  Math.sqrt is for 
	 * double values and doesn't maintain the precision.
	 * 
	 * For details of the algorithm - 
	 * @see - http://www.merriampark.com/bigsqrt.htm
	 */
	private static class BigSquareRoot {

		public static BigDecimal ZERO = BigDecimal.ZERO;
		public static BigDecimal ONE = BigDecimal.ONE;
		public static BigDecimal TWO = new BigDecimal("2");
		private static final int DEFAULT_MAX_ITERATIONS = 50;

		private static BigDecimal error;
		private static int iterations;
		private static int scale = DEFAULT_SCALE;
		private static int maxIterations = DEFAULT_MAX_ITERATIONS;

		// ------
		// Scale
		// ------

		public int getScale() {
			return scale;
		}

		public void setScale(int scale) {
			this.scale = scale;
		}

		// -------------------
		// Maximum iterations
		// -------------------

		public int getMaxIterations() {
			return maxIterations;
		}

		public void setMaxIterations(int maxIterations) {
			this.maxIterations = maxIterations;
		}

		// --------------------------
		// Get initial approximation
		// --------------------------

		private static BigDecimal getInitialApproximation(BigDecimal n) {
			BigInteger integerPart = n.toBigInteger();
			int length = integerPart.toString().length();
			if ((length % 2) == 0) {
				length--;
			}
			length /= 2;
			BigDecimal guess = ONE.movePointRight(length);
			return guess;
		}

		// ----------------
		// Get square root
		// ----------------

		public static BigDecimal get(BigInteger n) {
			return get(new BigDecimal(n));
		}

		public static BigDecimal get(BigDecimal n) {

			// Make sure n is a positive number
			if (n.compareTo(ZERO) < 0) {
				throw new IllegalArgumentException();
			}

			if (n.compareTo(ZERO) == 0) {
				return ZERO;
			}

			BigDecimal initialGuess = getInitialApproximation(n);
			BigDecimal lastGuess = ZERO;
			BigDecimal guess = new BigDecimal(initialGuess.toString());

			// Iterate

			iterations = 0;
			boolean more = true;
			while (more) {
				lastGuess = guess;
				guess = n.divide(guess, scale, BigDecimal.ROUND_HALF_UP);
				guess = guess.add(lastGuess);
				guess = guess.divide(TWO, scale, BigDecimal.ROUND_HALF_UP);
				error = n.subtract(guess.multiply(guess));
				if (++iterations >= maxIterations) {
					more = false;
				} else if (lastGuess.equals(guess)) {
					more = error.abs().compareTo(ONE) >= 0;
				}
			}
			return guess;
		}
	}
	
}
