package urjanet.util;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;

/**
 *
 * @author rburson
 */
public class JXPathUtility{

	/**
	 * @param jxpath
	 * @param targetObject
	 * @return Whether or not the reference (or value) specified by the jxpath exists in the targetObject graph. 
	 */
	public static boolean exists(String jxpath, Object targetObject){

		return getContext(targetObject).iterate(jxpath).hasNext();

	}

	/*
	 * Check ALL items in the list for equality by identity
	  * Empty lists return false - it is assumed that this must be a mistake...
	 */
	public static boolean allSameInstance(String jxPath, Object targetObject){

		List list = getContext(targetObject).selectNodes(jxPath);
		if(list.isEmpty()) return false;
		Object lastItem = null;
		for(Object o : list){
			if(lastItem != null && o != lastItem){
				return false;
			}
			lastItem = o;
		}
		return true;

	}


	 /**
	  * Check ALL instances in BOTH lists against themselves and each other for equality by identity
	  * Empty lists return false - it is assumed that this must be a mistake...
	  * 
	  * @param jxPath1
	  * @param jxPath2
	  * @param targetObject
	  * @return 
	  */
	public static boolean allSameInstance(String jxPath1, String jxPath2, Object targetObject){

		List list1 = getContext(targetObject).selectNodes(jxPath1);
		List list2 = getContext(targetObject).selectNodes(jxPath2);
		if(list1.isEmpty() || list2.isEmpty()) return false;

		/*
		 * Check list1 against itself and all items in list2
		 */
		Object lastItem = null;
		for(Object o : list1){
			if(lastItem != null && o != lastItem){
				return false;
			}
			for(Object o2 : list2){
				if(o != o2) return false;
			}
			lastItem = o;
		}
		/*
		 * Check list2 against itself
		 */
		lastItem = null;
		for(Object o : list2){
			if(lastItem != null && o != lastItem){
				return false;
			}
			lastItem = o;
		}
		return true;


	}

	public static boolean numberOfResultsEquals(String jxPath, int numberOfResults, boolean uniqueInstances, Object targetObject){
		if(!uniqueInstances){
			List list = getContext(targetObject).selectNodes(jxPath);
			return list.size() == numberOfResults;
			//return (getContext(targetObject).selectNodes(jxPath).size() == numberOfResults);
		}else{
			List newList = new ArrayList();
			List items = getContext(targetObject).selectNodes(jxPath);
			orig:for(Object o : items){
				for(Object o2 : newList){
					if(o == o2) continue orig;
				}
				newList.add(o);
			}
			return newList.size() == numberOfResults;
		}
	}

	private static JXPathContext getContext(Object targetObject){
		JXPathContext context = JXPathContext.newContext(targetObject);
		context.setLenient(true);
		return context;
	}
}
