package urjanet.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class UrjanetMapSet <K, V> {
	
	private Map<K, Set<V>> map = new LinkedHashMap<K, Set<V>>();
	
	public Set<V> get(K key) {
		return map.get(key);
	}
	
	public boolean add(K key, V value) {
		Set<V> set = map.get(key);
		if (set == null) {
			set = new HashSet<V>();
			map.put(key, set);
		}
		return set.add(value);
	}
	
	public void add(K key) {
		Set<V> set = map.get(key);
		if (set == null) {
			set = new HashSet<V>();
			map.put(key, set);
		}
	}
	
	public Map<K, Set<V>> getMap() {
		return map;
	}

}