package urjanet.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.zip.Adler32;
import java.util.zip.CheckedInputStream;

/**
 * 
 * @author xavierd
 *
 */
public class UrjanetByteArrayInputStream extends ByteArrayInputStream {

	private long contentHashValue = 0l;
	
	public UrjanetByteArrayInputStream(byte[] buf) {
		super(buf);
		calculateChecksum();
	}
	
	public UrjanetByteArrayInputStream(byte buf[], int offset, int length) {
		super(buf, offset, length);
		calculateChecksum();
	}

	/**
	 * 
	 * @return a checksum value of the byte array.
	 */
	public long getChecksumValue() {
		return contentHashValue;
	}
	
	/**
	 * 
	 * @return the byte Array.
	 */
	public byte[] getBytes() {
		return buf;
	}
	
	/**
	 * Calculate the checksum value of the input byte array.
	 */
	private void calculateChecksum() {

		if(buf.length == 0) {
			contentHashValue = 0;
		}
		
		ByteArrayInputStream fis = new ByteArrayInputStream(buf);
		Adler32 adler = new Adler32();
		CheckedInputStream cis = new CheckedInputStream(fis, adler);
		byte[] buffer = new byte[1024];
		long checksum = 0;
		try {
			while (cis.read(buffer) >= 0) {
				checksum += cis.getChecksum().getValue();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		contentHashValue = checksum;
	}
}
