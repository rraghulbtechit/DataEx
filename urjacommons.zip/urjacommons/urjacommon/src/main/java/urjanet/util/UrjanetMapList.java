package urjanet.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class UrjanetMapList<K, V> {
	
	private Map<K, List<V>> map = new LinkedHashMap<K, List<V>>();
	
	public List<V> get(K key) {
		return map.get(key);
	}
	
	public void add(K key, V value) {
		List<V> list = map.get(key);
		if (list == null) {
			list = new ArrayList<V>();
			map.put(key, list);
		}
		list.add(value);
	}
	
	public void addAll(K key, List<V> values) {
		List<V> list = map.get(key);
		if (list == null) {
			list = new ArrayList<V>();
			map.put(key, list);
		}
		list.addAll(values);
	}
	
	public void add(K key) {
		List<V> list = map.get(key);
		if (list == null) {
			list = new ArrayList<V>();
			map.put(key, list);
		}
	}
	
	public void put(K key, V value) {
		List<V> list = new ArrayList<V>();
		map.put(key, list);
		list.add(value);
	}
	
	public void putAll(K key, List<V> values) {
		List<V> list = new ArrayList<V>(values);
		map.put(key, list);
	}
	
	public void put(K key) {
		List<V> list = new ArrayList<V>();
		map.put(key, list);
	}
	
	public Map<K, List<V>> getMap() {
		return map;
	}
	
	public boolean isEmpty() {
		return map.isEmpty();
	}
	
	public K getFirstKey() {
		if (map.isEmpty())
			return null;
		return map.entrySet().iterator().next().getKey();
	}
	
	public UrjanetMapList<V, K> getPivot() {
		UrjanetMapList<V, K> mapList = new UrjanetMapList<V, K>();
		for (Map.Entry<K, List<V>> entry : map.entrySet()) {
			for (V v : entry.getValue())
				mapList.add(v, entry.getKey());
		}
		return mapList;
	}

}