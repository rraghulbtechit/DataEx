package urjanet.util;

public interface Listener {
	
	public void subjectHasChanged(Object subject);

}
