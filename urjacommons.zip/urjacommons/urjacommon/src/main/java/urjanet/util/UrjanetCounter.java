package urjanet.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class UrjanetCounter<T> {
	
	private Map<T, AtomicInteger> counter = new LinkedHashMap<T, AtomicInteger>();
	
	public void increment(T key) {
		incrementAndGet(key);
	}
	
	public int incrementAndGet(T key) {
		AtomicInteger count = counter.get(key);
		if (count == null) {
			count = new AtomicInteger(0);
			counter.put(key, count);
		}
		return count.incrementAndGet();
	}
	
	public void increment(T key, int delta) {
		AtomicInteger count = counter.get(key);
		if (count == null) {
			count = new AtomicInteger(0);
			counter.put(key, count);
		}
		count.addAndGet(delta);
	}
	
	public int get(String key) {
		AtomicInteger count = counter.get(key);
		if (count == null) {
			return 0;
		}
		return count.intValue();
	}
	
	public Map<T, AtomicInteger> getCounter() {
		return counter;
	}

}
