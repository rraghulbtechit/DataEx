package urjanet.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MultiOutputStream extends OutputStream {

	List<OutputStream> streams = new ArrayList<OutputStream>();
	
	public MultiOutputStream(List<OutputStream> outputStreams) {
	
		streams.addAll(outputStreams);
	}
	
	@Override
	public void write(int arg0) throws IOException {

	    for (OutputStream os : streams) {
	        os.write(arg0);
	    }
	}

	@Override
	public void write(byte[] b) throws IOException{

	    for (OutputStream os : streams) {
	        os.write(b);
	    }
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException{

	    for (OutputStream os : streams) {
	        os.write(b, off, len);
	    }
	}

	@Override
	public void close() throws IOException{

	    for (OutputStream os : streams) {
	    	if (os != System.out)
	    		os.close();
	    }
	}

	@Override
	public void flush() throws IOException{

	    for (OutputStream os : streams) {
	        os.flush();
	    }
	}	
	
}
