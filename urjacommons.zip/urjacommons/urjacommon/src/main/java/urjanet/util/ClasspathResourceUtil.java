package urjanet.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.net.URISyntaxException;

/**
 *
 * @author rburson
 */
public class ClasspathResourceUtil {

	private static ClassLoader cl = ClasspathResourceUtil.class.getClassLoader();

	public static File getFileOrDirectoryForResource(String resourcePath) throws URISyntaxException{

		return new File(cl.getResource(resourcePath).toURI());

	}

	public static InputStream getInputStreamForResource(String resourcePath){

		return cl.getResourceAsStream(resourcePath);

	}

	public static File[] getAllFilesInResourceDir(String resourcePath, FilenameFilter ff) throws URISyntaxException, FileNotFoundException{

		File dir = getFileOrDirectoryForResource(resourcePath);
		if(dir == null || !dir.isDirectory()) throw new FileNotFoundException();
		return dir.listFiles(ff);
	}
}
