package urjanet.util;

import java.nio.ByteBuffer;

import gnu.trove.list.array.TLongArrayList;
import urjanet.UrjanetId;

public class UrjanetIdList {
	
	private final TLongArrayList leastSignificantList = new TLongArrayList();
	private final TLongArrayList mostSignificantList = new TLongArrayList();
	
	public void add(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());
		leastSignificantList.add(buffer.getLong());
		mostSignificantList.add(buffer.getLong());
	}
	
	public boolean contains(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());

		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		for (int i = 0 ; i < leastSignificantList.size(); i++) {
			long existingLeastSignificant = leastSignificantList.getQuick(i);
			if (existingLeastSignificant == leastSignificant) {
				if (mostSignificantList.get(i) == mostSignificant)
					return true;
			}
		}
		return false;
	}
	
	public UrjanetId get(int index) {
		return new UrjanetId(ByteBuffer.allocate(16).putLong(leastSignificantList.get(index)).putLong(mostSignificantList.get(index)).array());
	}
	
	public int size() {
		//only need to look at leastSignificantList because relationship with both lists is 1-1
		return leastSignificantList.size();
	}
	
	public boolean isEmpty() {
		//only need to look at leastSignificantList because relationship with both lists is 1-1
		return leastSignificantList.isEmpty();
	}

}
