package urjanet.util;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rburson
 */
public class RetryOperation<T> implements Operation <T>{

	private static Logger log = LoggerFactory.getLogger(RetryOperation.class);

	private static int DEFAULT_NUMBER_RETRIES = 3;
	private static long DEFAULT_MILLIS_BETWEEN_RETRIES = 0;

	private Operation<T> operation;
	private List<? extends Class<? extends Exception>> retryOnExceptions;
	private int numberRetries;
	private long millisBetweenRetries;

	public RetryOperation(Operation<T> operation, List<? extends Class<? extends Exception>> retryOnExceptions, int numberRetries, long millisBetweenRetries) {
		this.operation = operation;
		this.retryOnExceptions = retryOnExceptions;
		this.numberRetries = numberRetries;
		this.millisBetweenRetries = millisBetweenRetries;
	}

	public RetryOperation(Operation<T> operation, List<? extends Class<? extends Exception>> retryOnExceptions) {
		this(operation, retryOnExceptions, DEFAULT_NUMBER_RETRIES, DEFAULT_MILLIS_BETWEEN_RETRIES);
	}

	public RetryOperation(Operation<T> operation, List<? extends Class <? extends Exception>> retryOnExceptions, int numberRetries) {
		this(operation, retryOnExceptions, numberRetries, DEFAULT_MILLIS_BETWEEN_RETRIES);
	}

	public RetryOperation(Operation<T> operation, List<? extends Class <? extends Exception>> retryOnExceptions, long millisBetweenRetries) {
		this(operation, retryOnExceptions, DEFAULT_NUMBER_RETRIES, millisBetweenRetries);
	}

	@Override
	public T performOperation() throws Exception {
		return performOperation(0);
	}

	private T performOperation(int iteration) throws Exception {

		try{
			return operation.performOperation();
		}catch(Exception e){
			log.debug("Got exception in retryoperation...", e);
			if(exceptionQualifies(e) && iteration < numberRetries){
				if(millisBetweenRetries > 0) try{ Thread.currentThread().sleep(millisBetweenRetries); }catch(InterruptedException ie){ ie.printStackTrace(); }
				log.debug("Retrying operation...");
				return performOperation(++iteration);
			}else{
				throw e;
			}
		}

	}

	private boolean exceptionQualifies(Exception e){

		for(Class<? extends Exception> c: retryOnExceptions){
			if(c.isInstance(e)){
				return true;
			}
		}
		return false;
	}

}
