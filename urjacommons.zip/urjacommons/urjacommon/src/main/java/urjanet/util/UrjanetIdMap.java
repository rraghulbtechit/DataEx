package urjanet.util;

import gnu.trove.map.hash.TLongObjectHashMap;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import urjanet.UrjanetId;

public class UrjanetIdMap <T> {

	private final TLongObjectHashMap<BucketEntry<T>[]> map;
	private int collisions = 0;
	
	public UrjanetIdMap() {
		this.map = new TLongObjectHashMap<BucketEntry<T>[]>();
	}
	
	public UrjanetIdMap(int capacity) {
		this.map = new TLongObjectHashMap<BucketEntry<T>[]>(capacity);
	}
	
	public UrjanetIdMap(int capacity, float loadFactor) {
		this.map = new TLongObjectHashMap<BucketEntry<T>[]>(capacity, loadFactor);
	}
	
	
	/**
	 * WTF????
	 * This method only looks like it puts if the value doesn't exist
	 * That doesn't seem right for a Map type....
	 * nice going tim...
	 * 
	 * TODO see where this is being called from and fix it without introducint any bugs elsewhere
	 * 
	 * @param id
	 * @param obj
	 * @return
	 */
	public boolean put(UrjanetId id, T obj) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());
		
		//Using leastSignificant long because it has the most variability as the key
		//most significant correlates to timestamp so has less variability given a particular time frame
		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		BucketEntry<T>[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray == null) {
			matchingLeastSignificantArray = new BucketEntry[1];
			matchingLeastSignificantArray[0] = new BucketEntry<T>(mostSignificant, obj); 
		} else {
			for (BucketEntry<T> existingMostSignificant : matchingLeastSignificantArray) {
				if (existingMostSignificant.getKey() == mostSignificant) {
					//already exists
					return false;
				}
			}
			BucketEntry<T>[] newStoredArray = new BucketEntry[matchingLeastSignificantArray.length + 1];
			for (int i = 0; i < matchingLeastSignificantArray.length; i++) {
				newStoredArray[i] = matchingLeastSignificantArray[i];
			}
			newStoredArray[newStoredArray.length - 1] = new BucketEntry<T>(mostSignificant, obj);
			matchingLeastSignificantArray = newStoredArray;
			collisions++;
		}
		
		map.put(leastSignificant, matchingLeastSignificantArray);
		
		return true;
		
	}
	
	public T remove(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());
		
		//Using leastSignificant long because it has the most variability as the key
		//most significant correlates to timestamp so has less variability given a particular time frame
		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		BucketEntry<T>[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray != null) {
			BucketEntry<T> entry = null;
			for (BucketEntry<T> existingMostSignificant : matchingLeastSignificantArray) {
				if (existingMostSignificant.getKey() == mostSignificant) {
					entry = existingMostSignificant;
					break;
				}
			}
			
			if (entry != null) {
				
				if (matchingLeastSignificantArray.length == 1) {
					map.remove(leastSignificant);
				} else {
					BucketEntry<T>[] newStoredArray = new BucketEntry[matchingLeastSignificantArray.length - 1];
					
					int i = 0;
					for (BucketEntry<T> bucket : matchingLeastSignificantArray) {
						if (bucket != entry)
							newStoredArray[i++] = bucket;
					}
					
					map.put(leastSignificant, newStoredArray);
				}
				return entry.getObj();
			}
			
		}
		
		return null;
		
	}
	
	/**
	 * please use size() instead
	 * @return
	 */
	@Deprecated
	public int getSize() {
		return map.size() + collisions;
	}
	
	public int size() {
		return map.size() + collisions;
	}
	
	public List<UrjanetId> getIds() {
		List<UrjanetId> ids = new ArrayList<UrjanetId>(map.size());
		for (long key : map.keys()) {
			BucketEntry<T>[] array = map.get(key);
			for (BucketEntry<T> entry : array) {
				ids.add(new UrjanetId(ByteBuffer.allocate(16).putLong(key).putLong(entry.getKey()).array()));
			}
		}
		return ids;
	}
	
	public List<T> getValues() {
		List<T> ts = new ArrayList<T>(map.size());
		for (long key : map.keys()) {
			BucketEntry<T>[] array = map.get(key);
			for (BucketEntry<T> entry : array) {
				ts.add(entry.getObj());
			}
		}
		return ts;
	}
	
	public boolean contains(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());

		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		BucketEntry<T>[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray == null)
			return false;
		
		for (BucketEntry<T> existingMostSignificant : matchingLeastSignificantArray) {
			if (existingMostSignificant.getKey() == mostSignificant)
				return true;
		}
		return false;
	}
	
	public T get(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());

		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		BucketEntry<T>[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray == null)
			return null;
		
		for (BucketEntry<T> existingMostSignificant : matchingLeastSignificantArray) {
			if (existingMostSignificant.getKey() == mostSignificant)
				return existingMostSignificant.getObj();
		}
		return null;
	}
	
	private static class BucketEntry <T> {
		private final long key;
		private final T obj;
		
		public BucketEntry(long key, T obj) {
			this.key = key;
			this.obj = obj;
		}

		public long getKey() {
			return key;
		}

		public T getObj() {
			return obj;
		}
	}

	public boolean isEmpty() {
		return map.isEmpty();
	}
}
