package urjanet.util;

import gnu.trove.map.hash.TLongObjectHashMap;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import urjanet.UrjanetId;

public class UrjanetIdSet {
	
	private final TLongObjectHashMap<long[]> map;
	private int collisions = 0;
	
	public UrjanetIdSet() {
		this.map = new TLongObjectHashMap<long[]>();
	}
	
	public UrjanetIdSet(int capacity) {
		this.map = new TLongObjectHashMap<long[]>(capacity);
	}
	
	public UrjanetIdSet(int capacity, float loadFactor) {
		this.map = new TLongObjectHashMap<long[]>(capacity, loadFactor);
	}
	
	public boolean put(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());
		
		//Using leastSignificant long because it has the most variability as the key
		//most significant correlates to timestamp so has less variability given a particular time frame
		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		long[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray == null) {
			matchingLeastSignificantArray = new long[1];
			matchingLeastSignificantArray[0] = mostSignificant; 
		} else {
			for (long existingMostSignificant : matchingLeastSignificantArray) {
				if (existingMostSignificant == mostSignificant) {
					//already exists
					return false;
				}
			}
			long[] newStoredArray = new long[matchingLeastSignificantArray.length + 1];
			for (int i = 0; i < matchingLeastSignificantArray.length; i++) {
				newStoredArray[i] = matchingLeastSignificantArray[i];
			}
			newStoredArray[newStoredArray.length - 1] = mostSignificant;
			matchingLeastSignificantArray = newStoredArray;
			collisions++;
		}
		
		map.put(leastSignificant, matchingLeastSignificantArray);
		
		return true;
		
	}
	
	public int getSize() {
		return map.size() + collisions;
	}
	
	public List<UrjanetId> getIds() {
		List<UrjanetId> ids = new ArrayList<UrjanetId>(map.size());
		for (long key : map.keys()) {
			long[] array = map.get(key);
			for (long value : array) {
				ids.add(new UrjanetId(ByteBuffer.allocate(16).putLong(key).putLong(value).array()));
			}
		}
		return ids;
	}
	
	public boolean contains(UrjanetId id) {
		ByteBuffer buffer = ByteBuffer.wrap(id.getUuidInternalBinaryRepresentation());

		long leastSignificant = buffer.getLong();
		long mostSignificant = buffer.getLong();
		
		long[] matchingLeastSignificantArray = map.get(leastSignificant);
		
		if (matchingLeastSignificantArray == null)
			return false;
		
		for (long existingMostSignificant : matchingLeastSignificantArray) {
			if (existingMostSignificant == mostSignificant)
				return true;
		}
		return false;
	}
}
