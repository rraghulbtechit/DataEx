package urjanet.util;

/**
 *
 * @author rburson
 */
public class ObjectUtils {

	public static boolean bothNull(Object o1, Object o2){
		return (o1 == null && o2 == null);
	}

	public static boolean xorNull(Object o1, Object o2){
		return (o1 == null ^ o2 == null);
	}

	public static boolean eitherNull(Object o1, Object o2){
		return (o1 == null || o2 == null);
	}

	public static boolean neitherNull(Object o1, Object o2){
		return (o1 != null && o2 != null);
	}

	public static boolean equalOrBothNull(Object o1, Object o2){

		if(ObjectUtils.bothNull(o1, o2)) return true;

		if(ObjectUtils.xorNull(o1, o2)) return false;

		return o1.equals(o2);
	}

	public static boolean equalNeitherNull(Object o1, Object o2){

		if(ObjectUtils.bothNull(o1, o2)) return false;

		if(ObjectUtils.xorNull(o1, o2)) return false;

		return o1.equals(o2);
	}
	
	public static boolean theSame(Object o1, Object o2) {
		if (o1 != o2) {
			//this means that one is null and the other is not
			//they are not the same
			return false;
		} else if (o1 != null) {
			//this means that both are not null, because we already qualified that they are the same (both null or both not null) above
			//so now use object comparison
			return o1.equals(o2);
		} else {
			//this means that both objects are null
			//so they are the same
			return true;
		}
		
	}
	
	public static boolean theSameOrBothNull(Object o1, Object o2) {
		if (o1 != null && o2 != null) {
			return o1.equals(o2);
		} else if (o1 == null && o2 == null) {
			return true;
		} else {
			return false;
		}
		
	}
}