package urjanet.util;

/**
 *
 * @author rburson
 */
public interface Operation<T>{

	public T performOperation() throws Exception;
}
