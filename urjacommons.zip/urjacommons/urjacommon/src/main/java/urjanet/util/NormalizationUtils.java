package urjanet.util;

import java.util.ArrayList;
import java.util.List;

import urjanet.clean.format.Formatter;
import urjanet.clean.format.TextFormatter;

public class NormalizationUtils {
	
	/**
	 *This will normalize all the values in the list.
	 *returns normalize list
	 * 
	 */
	public static List<String> leadingZeroNormalizeInList(List<String> inputString){

		if(inputString == null) return null;
		List<String> normalizedStringList = new ArrayList<String>();
		for(String s : inputString) {
		normalizedStringList.add(leadingZeroNormalize(s));
		}

		return normalizedStringList;

	}
	

	/**
	 * New normalization logic which strips leading zeros.
	 * @param str
	 * @return
	 */
	public static String leadingZeroNormalize(String str) {
		if (str == null)
			return null;
		return TextFormatter.wordCharsOnly(str).replaceFirst("^0+", "");
	}
	
	/**
	 * This method uses our old normalizedAccountNumber logic, where leading zeros are retained
	 * @param str
	 * @return
	 */
	public static String normalize(String str) {
		if (str == null || str.isEmpty())
			return str;
		return TextFormatter.wordCharsOnly(str);
	}
	
	/**
	 * This function should be called on all user-input EXCEPT passwords, or just call Formatter.clean() directly..
	 * @param s
	 * @return
	 */
	public static String normalizeUserInput(String s) {
		return Formatter.clean(s, true);
	}
	
	
	public static void main(String[] args) {
		System.out.println("\"" + normalizeUserInput("  PG and  E  ") + "\"");
		System.out.println("\"" + Formatter.normalizeWhitespace("  PG and  E  ") + "\"");
		System.out.println("\"" + StringUtils.removeWhitespace("  PG and  E  ") + "\"");
	}
	
}