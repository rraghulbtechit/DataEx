package urjanet.hit.template.source;

import java.lang.reflect.Method;

import urjanet.pull.template.AceDisposalUTTemplateProvider;

public class ManualTest {
    public static void main(String[] args) {
        Method[] declaredMethods = AceDisposalUTTemplateProvider.class.getMethods();

        for (Method declaredMethod : declaredMethods) {
            if (declaredMethod.getName().equalsIgnoreCase("getPdfPageSpec")) {
                System.out.println(Methods.getParameterNames(declaredMethod));
                break;
            }
        }
    }
}