/**
 * Using Groovy and ConfigSlurper for properties as the best option over plain Java properties, xml, json, yaml etc.
 *
 */
package conf

templatePath="unset"

/* Properties can be defined as a hierarchy with values, map and lists.
 * This is flattened to get nested keys by name as so: section.subsection.subkey
 * Change HiTProperties load to not flatten if the hierarchy is to be retained */
section {
    key = "some value"
    subsection {
        subkey="subkey value"
        subarray=[1, 2, "a"]
        aMap=[a:1,b:2,c:3]
    }
}

/* Overridden values for different environments */
environments {
    win {
        templatePath = "C:\\dev\\programs\\Git\\opt\\repos\\templates\\templates\\src\\main\\java\\urjanet\\pull\\template"
    }

    dev {
        section.key = "yet another"
    }
}
