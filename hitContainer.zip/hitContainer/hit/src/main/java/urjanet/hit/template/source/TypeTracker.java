package urjanet.hit.template.source;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.PrimitiveType.Code;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.Type;

import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.utils.TypeUtils;

public class TypeTracker {
	
	private ImportManager importManager;
	
	private AST ast;
	private CompilationUnit cu;
	private List<Type> types;
	
	// TODO turn this into Map with signatures
	private List<String> methods = new ArrayList<String>();
	
	public TypeTracker( CompilationUnit cu ) {
		this.cu = cu;
		this.ast = cu.getAST();
		importManager = new ImportManager( cu );
		types = new ArrayList<Type>();
	}
	
	// TODO create qualified type if a type with similar simple name exists
	public Type getType( Class clazz ) {
		
		Type existingType = getExistingType(clazz.getSimpleName());
		if ( existingType == null && ! clazz.getName().startsWith("java.lang") )
			importManager.addimport( new TemplateItemType( clazz ));
		if( TypeUtils.isWrapperType(clazz)){
			try {
				Class intClass = (Class) clazz.getField("TYPE").get(null);
				return ast.newPrimitiveType(getPrimitiveTypeCode(intClass.getName()));
				
			} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
				e.printStackTrace();
			}

		}
		
		Type type = JavaElementBuilder.createSimpleType(ast, clazz.getSimpleName());
		types.add(type);
		return type;
	}
	public Type getType( Object object ) {
		
		return getType( object.getClass() );
	}
	
	
	private Code getPrimitiveTypeCode( String primitiveTypeName ) {

		switch ( primitiveTypeName ){
			case "int":
				return PrimitiveType.INT;
			case "float":
				return PrimitiveType.FLOAT;
			case "boolean":
				return PrimitiveType.BOOLEAN;
			case "char":
				return PrimitiveType.CHAR;
			case "byte":
				return PrimitiveType.BYTE;
			case "short":
				return PrimitiveType.SHORT;
			case "long":
				return PrimitiveType.LONG;
			case "double":
				return PrimitiveType.DOUBLE;
			case "void":
				return PrimitiveType.VOID;
				
		}
		return null;
	}
	private Type getExistingType( String typeName ) {

		for (Type type : types) {
			if( type instanceof SimpleType )
				if ( ((SimpleType) type).getName().toString().equals(typeName))
					return type;
		}
		
		return null;
	}
	
	
	public List<Type> getTypes() {

		return types;
	}
	
	
	public ImportManager getImportManager() {

		return importManager;
	}
	
	
	public void addImports() {
		
		importManager.resolveImports();
	}

	private boolean doesMethodExist( String methodName ){
		
		if ( methods.contains( methodName ))
			return true;
		return false;
	}
	
	// TODO also check signature
	public String resolveMethodName( String methodName ){
		
		if( !doesMethodExist( methodName )){
			methods.add( methodName );
			return methodName;
		}
		
		methodName = methodName + "_" + (int)(Math.random() * 100);
		methods.add( methodName );

		return methodName;
	}
}
