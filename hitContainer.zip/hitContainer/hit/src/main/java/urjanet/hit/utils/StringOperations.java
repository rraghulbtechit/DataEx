package urjanet.hit.utils;

import javafx.util.StringConverter;
import javafx.util.converter.*;
import urjanet.hit.HiTException;

import java.util.Arrays;

public class StringOperations {

	/**
	 * 
	 * @param numberOfSpaces
	 * @return
	 */
	public static String fillSpaces( int numberOfSpaces ){
		
		char[] spaces = new char[numberOfSpaces];
		Arrays.fill(spaces, ' ');
		
		return new String ( spaces );
		
	}

	public static String capitalizeFirstLetter(String original) {
		if (original == null || original.length() == 0) {
			return original;
		}
		return original.substring(0, 1).toUpperCase() + original.substring(1);
	}

	/**
	 * Gets a converter for a String or Primitive
	 *
	 * @param clazz	the Class for which StringConverter is
	 * @return		the StringConverter or null otherwise
     */
	public static StringConverter getConverter(Class clazz) throws HiTException {
		if(! (clazz.isPrimitive() || String.class.isAssignableFrom(clazz)) )
			return null;

		StringConverter converter = null;
		if(Integer.TYPE.equals(clazz))
			converter = new IntegerStringConverter();
		else if(Float.TYPE.equals(clazz))
			converter = new FloatStringConverter();
		else if(Double.TYPE.equals(clazz))
			converter = new DoubleStringConverter();
		else if(Long.TYPE.equals(clazz))
			converter = new LongStringConverter();
		else if(Short.TYPE.equals(clazz))
			converter = new ShortStringConverter();
		else if(Boolean.TYPE.equals(clazz))
			converter = new BooleanStringConverter();
		else if(String.class.isAssignableFrom(clazz))
			converter = new DefaultStringConverter();
		else
			throw new HiTException("Converter not available for " + clazz.getName());

		return converter;
	}

	/**
	 * Turns a String Java expression into a scriptlet. This is meant for the code generator to turn the input expression into suitable Java code.
	 *
	 * @param expression
	 * @return
     */
	public static String toScriptlet( String expression ) {

		return "${" + expression + "}";
	}
}
