package urjanet.hit.ui.view.attributes;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.ExpandableNavTarget;

/**
 * Created by shankerj on 6/27/2016.
 */
public class ExpandableNavTargetAttributes<T> implements Initializable, TemplateAttributesPane {

    static final String resourcePath = "/ExpandableNavTargetAttributes.fxml";

    @FXML public CheckBox   doNotUseAbsoluteXPathCheck;
    private Property doNotUseAbsoluteXPathCheckProperty;
    @FXML protected VBox    clickableNavTargetAttributesVBox;
    @FXML protected ClickableNavTargetAttributes clickableNavTargetAttributesVBoxController;

    protected TemplateTreeItem<T> treeItem;
    protected TreeView<T>                   treeView;

    public ExpandableNavTargetAttributes( ) {
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;

        ExpandableNavTarget expandableNavTarget = (ExpandableNavTarget) item.getValue();
        
        if( doNotUseAbsoluteXPathCheckProperty != null ) FXMLUtils.unbindField( doNotUseAbsoluteXPathCheck, doNotUseAbsoluteXPathCheckProperty );
        doNotUseAbsoluteXPathCheckProperty = FXMLUtils.bindField( doNotUseAbsoluteXPathCheck, expandableNavTarget, "doNotUseAbsoluteXPath" );

        clickableNavTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        clickableNavTargetAttributesVBoxController.setTreeView( treeView );
    }
}
