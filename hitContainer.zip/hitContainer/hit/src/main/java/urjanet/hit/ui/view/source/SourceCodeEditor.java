package urjanet.hit.ui.view.source;

import java.net.URL;

import javafx.scene.web.WebView;
import urjanet.hit.MainApp;

/**
 * A syntax highlighting code editor for JavaFX created by wrapping a
 * CodeMirror code editor in a WebView.
 *
 * See http://codemirror.net for more information on using the codemirror editor.
 */
public class SourceCodeEditor {
	/** a webview used to encapsulate the CodeMirror JavaScript. */
	final WebView webview = new WebView();

	/** a snapshot of the code to be edited kept for easy initilization and reversion of editable code. */
	private String editingCode;

	/**
	 * a template for editing code - this can be changed to any template derived from the
	 * supported modes at http://codemirror.net to allow syntax highlighted editing of
	 * a wide variety of languages.
	 */
	private String editingTemplate =
		"<!doctype html>" +
		"<html>" +
		"<head>" +
		"${css}" +
		"${js}" +
		"</head>" +
		"<body>" +
		"<form><textarea id=\"code\" name=\"code\" rows=\"50\">\n" +
		"${code}" +
		"</textarea></form>" +
		"<script>" +
		"	var editor = CodeMirror.fromTextArea(document.getElementById(\"code\"), {" +
		"		lineNumbers: true," +
		"		matchBrackets: true," +
		"		mode: \"text/x-java\"" +
		"	});" +
		"</script>" +
		"</body>" +
		"</html>";

	/** applies the editing template to the editing code to create the html+javascript source for a code editor. */
	private String applyEditingTemplate() {
		return editingTemplate.replace("${code}", editingCode);
	}

	/** sets the current code in the editor and creates an editing snapshot of the code which can be reverted to. */
	public void setCode(String newCode) {
		this.editingCode = newCode;
		webview.getEngine().loadContent(applyEditingTemplate());
	}

	/** returns the current code in the editor and updates an editing snapshot of the code which can be reverted to. */
	public String getCodeAndSnapshot() {
		this.editingCode = (String ) webview.getEngine().executeScript("editor.getValue();");
		return editingCode;
	}

	/** revert edits of the code to the last edit snapshot taken. */
	public void revertEdits() {
		setCode(editingCode);
	}

	/**
	 * Create a new code editor.
	 * @param editingCode the initial code to be edited in the code editor.
	 */
	public SourceCodeEditor(String editingCode) {
		this.editingCode = editingCode;

		// TODO is this right?
		webview.setPrefSize(800, 1500);

		addCssAndJsResource();
		webview.getEngine().loadContent(applyEditingTemplate());

	}
	
	
	private void addCssAndJsResource() {
			
		try {
	
			URL cssURL = MainApp.class.getResource("/css/codemirror.css");
			String linkCss = "<link rel=\"stylesheet\" href=\"" + cssURL.toURI().toString() + "\">";
			editingTemplate = editingTemplate.replace( "${css}", linkCss);
			
			URL js1 = MainApp.class.getResource("/js/codemirror.js");
			URL js2 = MainApp.class.getResource("/js/clike.js");

			String addJs1 = "<script src=\"" + js1.toURI().toString() + "\"></script> ";
			String addJs2 = "<script src=\"" + js2.toURI().toString() + "\"></script> ";
			editingTemplate = editingTemplate.replace( "${js}", addJs1 + addJs2);
			
		} catch ( Exception e ){
			e.printStackTrace();
		}

		
	}

	public WebView getWebview() {

		return webview;
	}
}