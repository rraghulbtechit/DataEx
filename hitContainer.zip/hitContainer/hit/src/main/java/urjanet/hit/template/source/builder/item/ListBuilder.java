package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.MethodInvocationWrapper;
import urjanet.hit.template.source.TypeTracker;

public class ListBuilder implements TemplateItemBuilder{
	
	private static final ListBuilder theInstance = new ListBuilder();
	
	public static ListBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private ListBuilder() {}

	@Override
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration,Object object, TypeTracker typeTracker) {
	
		return createClassInstance( typeDeclaration, methodDeclaration, object, typeTracker );
	}

	@Override
	public Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration,Object object, final TypeTracker typeTracker ) {
		
//		List<?> list = (List<?>)object;
//		List<Object> parameterExpressions = new ArrayList<>();
//		for( Object parameter : list ) {
//			
//			TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( parameter );
//			Expression expression =  templateItemBuilder.createClassInstance( typeDeclaration, methodDeclaration, parameter, typeTracker );
//			
//			parameterExpressions.add( expression );
//		}
		
		return new MethodInvocationWrapper( typeDeclaration, methodDeclaration, typeTracker)
			.setMethodName( "asList" )
			.setExpression( ((SimpleType)typeTracker.getType( Arrays.class )).getName() )
			.setParameters( ( List<Object> )object )
			.invoke();
	}

}
