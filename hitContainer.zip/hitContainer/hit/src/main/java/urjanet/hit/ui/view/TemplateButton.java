package urjanet.hit.ui.view;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.MenuButton;
import javafx.scene.control.SplitMenuButton;

/**
 * Template Object aware button that handles action on template tree.
 */
public class TemplateButton extends MenuButton {

    private String representsClassName;

    public String getRepresentsClassName() {
        return representsClassName;
    }

    public void setRepresentsClassName(String representsClassName) {
        this.representsClassName = representsClassName;
    }

    protected ObservableList<Node> getTemplateMenuItems() {

        return super.getChildren();
    }
}
