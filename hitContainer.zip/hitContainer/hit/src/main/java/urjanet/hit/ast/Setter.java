package urjanet.hit.ast;

import java.util.Arrays;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;

public class Setter extends BeanMethod{
	
	private static String beanType = "set";

	private Object value;
	
	public Setter( String property, Object value ) {
		
		super( beanType + WordUtils.capitalize( property ));
		this.value = value;
		
		addParameter( Arrays.asList( this.value ) );
	}

}
