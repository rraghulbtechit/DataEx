package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.utils.TypeUtils;
import urjanet.keys.DomainKeys;

public class BasicTypeBuilder implements TemplateItemBuilder {

	private static final BasicTypeBuilder theInstance = new BasicTypeBuilder();
	
	public static BasicTypeBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private BasicTypeBuilder() {}
	
	@Override
	public Expression createTemplateItem( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration,
		Object object, TypeTracker typeTracker ) {
		
		AST ast = typeDeclaration.getAST();
		
		Expression parameterExpression = null;
		if( object instanceof String )
			parameterExpression = JavaElementBuilder.getValueLiteralForType( ast, typeTracker.getType(object), ( String )object);
		else if( TypeUtils.isWrapperType(object.getClass()) ){
			parameterExpression = JavaElementBuilder.getValueLiteralForType( ast, typeTracker.getType(object), object) ;
		}
		else if (object instanceof Enum<?>) {
			String enumDeclaringClassName = ((Enum)object).getDeclaringClass().getSimpleName();
			Type type = typeTracker.getType(object);

			parameterExpression = ast.newQualifiedName( ast.newSimpleName(  /*type.toString()*/ enumDeclaringClassName ), ast.newSimpleName( ((Enum)object).name() ) );
			if ( object instanceof DomainKeys )
				parameterExpression = JavaElementBuilder.createMethodInvocation(ast, parameterExpression, "getValue");
		}
		
		return parameterExpression;
	}

	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		return null;
	}


}
