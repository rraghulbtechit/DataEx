package urjanet.hit.ui.view.attributes.qualifier;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.pdf.PdfDataTargetQualifier;

public class PdfDataTargetQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/PdfDataTargetQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane; 
	
	@FXML protected TemplateButton dataTargetsBtn;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private PdfDataTargetQualifier pdfDataTargetQualifier;
	
	public PdfDataTargetQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		for(MenuItem item : dataTargetsBtn.getItems()) {
            item.setOnAction( dataTargetHandler );
        }
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		pdfDataTargetQualifier = ((PdfDataTargetQualifier)item.getValue());
	}
	
	private EventHandler dataTargetHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTarget newTarget = ((DataTarget)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor

            this.treeItem.getChildren().clear();
            pdfDataTargetQualifier.setQualifyingTarget(newTarget);
            
            dataTargetItem = new TemplateTreeItem( newTarget );
            addSelectNode(dataTargetItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
	
}