package urjanet.hit.template.source.refactor;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.JavaElementBuilder;

@Deprecated
public class ExtractMethod extends RefactorAction {

	
	private String methodName;
	private List<Modifier> modifiers = new ArrayList<Modifier>();

	@Override
	public RefactorResult refactor(TypeDeclaration typeDeclaration, Expression expression) {

			AST ast = typeDeclaration.getAST();
			
			MethodDeclaration methedDeclaration = JavaElementBuilder.createMethodDeclaration(ast, methodName);
			
			Expression newExpression = null;
			newExpression = (ClassInstanceCreation) ASTNode.copySubtree(ast, expression);

			Block block = ast.newBlock();
			
			ReturnStatement returnStatement = ast.newReturnStatement();
			returnStatement.setExpression(newExpression );
			block.statements().add(returnStatement);
			
			String typeName = ((ClassInstanceCreation)expression).getType().toString();
			Type type = JavaElementBuilder.createSimpleType(ast, typeName);
			methedDeclaration.setReturnType2( type );
			methedDeclaration.setBody( block );
			methedDeclaration.modifiers().addAll(modifiers);
			
			typeDeclaration.bodyDeclarations().add(methedDeclaration);
			
			MethodInvocation methodInvocation = JavaElementBuilder.createMethodInvocation(ast, null, methedDeclaration.getName().getIdentifier());

			return new RefactorResult( methedDeclaration, methodInvocation );
	}

	public void setMethodName(String methodName) {

		this.methodName = methodName;
	}

	public void addModifier(Modifier modifier) {

		modifiers.add(modifier);
	}

	@Override
	public String toString() {

		return "ExtractMethod [methodName=" + methodName + ", modifiers=" + modifiers + "]";
	}
	
	
}
