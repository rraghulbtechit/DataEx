package urjanet.hit.ui.model;

import java.util.*;

import javafx.scene.control.TreeItem;
import urjanet.clean.validation.ValidationException;
import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.web.GroupPolicy.GroupAction;
import urjanet.pull.web.WebPullJobTemplate;

/**
 * Turns a urjanet.pull.core.PullJobTemplate into a displayable Tree
 * Created by shankerj on 4/18/2016.
 */
public class TemplateTree {

    /** Template for which this tree is being constructed */
    private PullJobTemplate             template;
    private TemplateTreeItem            root;

    /**
     * Build an empty tree for first time template
     *
     * @return
     * @throws HiTException
     */
    public static TemplateTree getTemplateTree() throws HiTException {

        return getTemplateTree(null);
    }

    public static TemplateTree getTemplateTree(PullJobTemplate template) throws HiTException {

        TemplateTree tree = new TemplateTree();
        tree.setTemplate(template);
        tree.buildTree();

        return tree;
    }

    public TemplateTreeItem getRoot() {
        return root;
    }

    /**
     * Initialize a new tree by building the first level of nodes
     * @throws HiTException
     */
    public void buildTree() throws HiTException {

        if (template == null) {
            template = new WebPullJobTemplate("url", null, "New Template", null, null);
        }

        root = new TemplateTreeItem(template);
    }

    public PullJobTemplate getTemplate() {
        return template;
    }

    public void setTemplate(PullJobTemplate template) {
        this.template = template;
    }

    private int getItemLevel(TreeItem item) {
        if (item.getParent() == null)
            return 1;

        return 1 + getItemLevel(item.getParent());
    }

    public void printTree() {

        List<String> treeNodeText = new ArrayList<>();
        itemStrings(getRoot(), treeNodeText, true);
        treeNodeText.forEach( txt -> {
            System.out.println( txt );
        });
    }

    public Set<String> nodesText() {

        Set<String> treeNodeText = new TreeSet<>();
        itemStrings( getRoot(), treeNodeText, false );
        return treeNodeText;
    }

    //TODO change to lambda and use filterItems
    private void itemStrings(TreeItem item, Set<String> nodesText, boolean indented) {

        if( item == null ) return;

        String nodeText = (indented) ? String.format("%1d %2$"+getItemLevel(item)+"s\n", getItemLevel(item), item.toString())
                : item.toString();
        nodesText.add( nodeText );

        item.getChildren().forEach( o -> itemStrings((TreeItem) o, nodesText, indented));
    }

    private void itemStrings(TreeItem item, List<String> nodesText, boolean indented) {

        if( item == null ) return;

        String nodeText = (indented) ? String.format("%1d %2$"+getItemLevel(item)+"s\n", getItemLevel(item), item.toString())
                : item.toString();
        nodesText.add( nodeText );

        item.getChildren().forEach( o -> itemStrings((TreeItem) o, nodesText, indented));
    }

    public List<TemplateTreeItem> locateNodes(String nodeText) {

        List<TemplateTreeItem> nodes = new ArrayList<>();
        filterItems( getRoot(), nodes, nodeText );
        return nodes;
    }

    //TODO make this a generic visitor by passing in lambda
    private void filterItems(TemplateTreeItem item, List<TemplateTreeItem> nodes, String nodeText) {

        if( item == null ) return;

        if( item.toString().contains( nodeText) ) {
            nodes.add( item );
        }

        item.getChildren().forEach( c -> filterItems((TemplateTreeItem)c, nodes, nodeText));
    }

    /*
        Test code
     */
    public static void main(String[] args) throws HiTException {

        //String template = (args.length < 1) ? "AceDisposalUTTemplateProvider" : args[0];
        String template = "BCHydroTemplateProvider";
        PullJobTemplate t = PlatformAccessor.getTemplate(template);
        TemplateTree tree = TemplateTree.getTemplateTree(t);
        tree.printTree();
    }

    static class TemplateTreeTraversalListenerImpl implements TemplateTreeTraversalListener {

    	Map< String, List<TreeItem>> similarGroupTreeItems = new HashMap<>();
    	
    	@Override
    	public void beginTraversal( TreeItem treeItem ) {}

    	@Override
    	public void fireGroupEncountered( String groupName, GroupAction groupAction, TreeItem source ) {
    		
    		List<TreeItem> existingSimilarGroups = similarGroupTreeItems.get( groupName );
    		if( existingSimilarGroups != null ){
    			existingSimilarGroups.add( source );
    			similarGroupTreeItems.put( groupName, existingSimilarGroups );
    		} else {
    			similarGroupTreeItems.put( groupName, new ArrayList<>(Arrays.asList( source )) );
    		}
    	}

    	@Override
    	public void firePageSpecEncountered( TreeItem pageSpecTreeItem, TemplateTreeTraversalListener tl ) {}

    	@Override
    	public void fireTargetGroupEncountered( TreeItem targetGroupTreeItem, TemplateTreeTraversalListener tl ) {}

    	@Override
    	public void fireNavTargetEncountered( TreeItem navTargetTreeItem, TemplateTreeTraversalListener tl ) {}

    	@Override
    	public void fireDataTargetEncountered( TreeItem dataTargetTreeItem, TemplateTreeTraversalListener tl ) {}

    	@Override
    	public void endTraversal( TreeItem treeItem ) {}
    	
    	public Map<String, List<TreeItem>> getSimilarGroupTreeItems() {

			return similarGroupTreeItems;
		}
    }
    
	public Map<String, List<TreeItem>> getItemsWithSameGroupName() {

		TemplateTreeTraversalListenerImpl listener = new TemplateTreeTraversalListenerImpl();
		try {
			new TemplateTreeTraversal().preOrderTraverse( getRoot(), listener );
		} catch( ValidationException e ) {
			e.printStackTrace();
		}
		
		return listener.getSimilarGroupTreeItems();
	}
	
}