package urjanet.hit.ui.view.attributes.extractOperators;

import java.math.RoundingMode;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.DecimalFormatOperator;

public class DecimalFormatOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/DecimalFormatOperatorAttributes.fxml";
	
	@FXML private TextField formatPatternText;
	private Property formatPatternTextProperty;
	@FXML private ComboBox<RoundingMode> roundingModeCombo;
	private Property roundingModeComboProperty;
	
	private DecimalFormatOperator decimalFormatOperator;
	
	public DecimalFormatOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof DecimalFormatOperator))
            throw new HiTException("Could not create Form for DecimalFormatOperator due to incompatible node. Received " + Obj.getClass());
        
        this.decimalFormatOperator = (DecimalFormatOperator) Obj;
        
        if( formatPatternTextProperty != null ) FXMLUtils.unbindField( formatPatternText, formatPatternTextProperty );
        formatPatternTextProperty = FXMLUtils.bindField(formatPatternText, decimalFormatOperator, "formatter");
		
		if( roundingModeComboProperty != null ) FXMLUtils.unbindField( roundingModeCombo, roundingModeComboProperty );
		roundingModeComboProperty = FXMLUtils.bindField(roundingModeCombo, decimalFormatOperator, "mode");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}
