package urjanet.hit.ast;

import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CharacterLiteral;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MarkerAnnotation;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.PrimitiveType.Code;
import org.eclipse.jdt.core.dom.QualifiedType;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

/**
 * A utility class that instantiates an AST object and provides some
 * helper method for building some commonly used Expressions.
 */
@SuppressWarnings("unchecked")
public class JavaElementBuilder {

	private static String templateId = "TownAndCountryDisposalCOTemplateProvider";

	public static Type createSimpleType( AST ast, Object object ){

		return createSimpleType( ast, object.getClass().getSimpleName() );
	}
	
	public static Type createSimpleType( AST ast, String typeName ){

		return ast.newSimpleType(ast.newSimpleName( typeName ));
	}
	
	public static Expression getValueLiteralForType(AST ast, Type type ) {
	
		return getValueLiteralForType(ast, type, null);
	}
	
	/**
	 * Builds and returns an Expression that has a value for the given
	 * Type
	 * 
	 * @param type
	 * @return an Expression that has a value for the given Type.
	 */
	public static Expression getValueLiteralForType(AST ast, Type type, Object wrapperObject) {
		Expression valueLiteral = ast.newNullLiteral();
	
		if (type.isPrimitiveType()) {
	
			PrimitiveType primType = (PrimitiveType) type;
			Code primTypeCode = primType.getPrimitiveTypeCode();
	
			if (primTypeCode.equals(PrimitiveType.BOOLEAN)) {
				boolean value = false;
				if (wrapperObject != null)
					value = ((Boolean)value).booleanValue();
				valueLiteral = ast.newBooleanLiteral(false);
			} else if (primTypeCode.equals(PrimitiveType.BYTE)
				|| primTypeCode.equals(PrimitiveType.DOUBLE)
				|| primTypeCode.equals(PrimitiveType.FLOAT)
				|| primTypeCode.equals(PrimitiveType.INT)
				|| primTypeCode.equals(PrimitiveType.LONG)
				|| primTypeCode.equals(PrimitiveType.SHORT)) {
				
				valueLiteral = ast.newNumberLiteral();

				if ( wrapperObject != null ){
					((NumberLiteral)valueLiteral).setToken(" " + wrapperObject);
				}
			} else if (primTypeCode.equals(PrimitiveType.CHAR)) {
				
				valueLiteral = ast.newCharacterLiteral();
				((CharacterLiteral) valueLiteral).setCharValue('c');
			}
	
		}

	return valueLiteral;
	}
	
	public static Expression getValueLiteralForType(AST ast, Type type, String value) {

		Expression valueLiteral = ast.newStringLiteral();
		((StringLiteral) valueLiteral).setLiteralValue( value );;
		
		return valueLiteral;
	}

	public static TypeDeclaration createTypeDecelaration(AST ast, boolean isPublic, boolean isInterface, String name) {
		
		return createTypeDecelaration(ast, isPublic, isInterface, null, name);
	}
	
	public static TypeDeclaration createTypeDecelaration(AST ast, boolean isPublic, boolean isInterface, List<Type> superInterfaces, String name) {
		
		TypeDeclaration typeDeclaration = ast.newTypeDeclaration();
		typeDeclaration.setInterface(isInterface);
		typeDeclaration.setName(ast.newSimpleName(name));
		
		if( superInterfaces != null)
			typeDeclaration.superInterfaceTypes().addAll(superInterfaces);
		if (isPublic)
			typeDeclaration.modifiers().add(JavaElementBuilder.createPublicModifier(ast));
		return typeDeclaration;
	}
	
	public static VariableDeclarationStatement createVariableDeclarationStatement(AST ast, String typeOfFields, VariableDeclarationFragment... fragments) {
		
		return JavaElementBuilder.createVariableDeclarationStatement(ast, ast.newSimpleType(ast.newName(typeOfFields)), fragments);
	}

	public static VariableDeclarationStatement createVariableDeclarationStatement( AST ast, Type typeOfFields, VariableDeclarationFragment... fragments) {
	
		VariableDeclarationStatement variableDeclarationStatement = ast.newVariableDeclarationStatement(fragments[0]);

		variableDeclarationStatement.setType(typeOfFields);
		for (int i = 1; i < fragments.length; i++)
			variableDeclarationStatement.fragments().add(fragments[i]);
		
		return variableDeclarationStatement;
	}

	public static VariableDeclarationFragment createVariableDeclarationFragment( AST ast, String fieldName, Expression initializer) {
		
		VariableDeclarationFragment vdf = ast.newVariableDeclarationFragment();
		vdf.setName(ast.newSimpleName(fieldName));
		vdf.setInitializer(initializer);
		
		return vdf;
	}

	public static MethodDeclaration createMethodDeclaration( AST ast, String methodName ){
		
		MethodDeclaration md = ast.newMethodDeclaration();
		md.setName( ast.newSimpleName( methodName ) );
		
		return md;
	}
	
	public static MethodInvocation createMethodInvocation(AST ast, Expression expression, String methodName) {
	
		MethodInvocation methodInvocation = ast.newMethodInvocation();
		methodInvocation.setName(ast.newSimpleName(methodName));
		methodInvocation.setExpression(expression);
		
		return methodInvocation;
	}

	public static MethodInvocation createMethodInvocation(AST ast, Expression expression, String methodName, List<Expression> arguments) {
		
		MethodInvocation methodInvocation = ast.newMethodInvocation();
		methodInvocation.setName(ast.newSimpleName(methodName));
		methodInvocation.setExpression(( Expression )ASTNode.copySubtree( ast, expression ));
		for (Expression e : arguments) {
			methodInvocation.arguments().add( ( Expression )ASTNode.copySubtree( ast, e ) );
		}
		
		return methodInvocation;
	}
	
	public static MethodInvocation createMethodInvocation(AST ast, Expression expression, String methodName, Expression... arguments) {
		
		MethodInvocation methodInvocation = ast.newMethodInvocation();
		methodInvocation.setName(ast.newSimpleName(methodName));
		methodInvocation.setExpression(expression);
		for (int i = 0; i < arguments.length; i++)
			methodInvocation.arguments().add(arguments[i]);
		
		return methodInvocation;
	}
	
	public static MethodInvocation createMethodInvocation(AST ast, String fieldName, String methodName, Expression... arguments) {
	
		return createMethodInvocation(ast, ast.newSimpleName(fieldName), methodName, arguments);
	}

	public static MethodInvocation createMethodInvocationStringArgs(AST ast, String fieldName, String methodName, String... arguments) {
		
		return JavaElementBuilder.createMethodInvocationStringArgs(ast, ast.newSimpleName(fieldName), methodName, arguments);
	}

	public static MethodInvocation createMethodInvocationStringArgs(AST ast, Expression expression, String methodName, String... arguments) {
		
		Expression[] expressions = new Expression[arguments.length];
		for (int i = 0; i < arguments.length; i++) {
			expressions[i] = ast.newSimpleName(arguments[i]);
		}
		
		return createMethodInvocation(ast, expression, methodName, expressions);
	}

	public static ClassInstanceCreation createClassInstanceCreation(AST ast, Type type) {
		
		ClassInstanceCreation cic = ast.newClassInstanceCreation();
		cic.setType(type);
		
		return cic;
	}
	
	public static ClassInstanceCreation createClassInstanceCreation(AST ast, Type type, List<Object> properties ) {
		
		// TODO implement
		return null;
	}

	public static ClassInstanceCreation createClassInstanceCreation(AST ast, String type) {
		
		return createClassInstanceCreation(ast, ast.newSimpleType(ast.newName(type)));
	}


	public static Modifier createPublicModifier(AST ast) {
	
		return ast.newModifier(ModifierKeyword.PUBLIC_KEYWORD);
	}

	public static MarkerAnnotation createOverrideMarker(AST ast) {

		return createMarkerAnnotation( ast, "Override" );
	}
	
	public static MarkerAnnotation createMarkerAnnotation(AST ast, String annotationName) {

		MarkerAnnotation ma = ast.newMarkerAnnotation();
		ma.setTypeName(ast.newName(annotationName));
		return ma;
	}
}
