package urjanet.hit.ui.view.attributes.qualifier;

import javafx.beans.property.Property;
import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.DateQualifier;

public class DateQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/DateQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane;
	@FXML Pane comparisonDataTargetPane;
	@FXML TextField dateFormatText;
	Property dateFormatProperty;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private ComparisonDataTargetQualifierAttributes comparisonDataTargetAttr;

	private DateQualifier dateQualifier = new DateQualifier();
	
	public DateQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		FXMLLoader loaderComparisonQualifiers = new FXMLUtils().loader(ComparisonDataTargetQualifierAttributes.resourcePath);
		
        comparisonDataTargetPane.getChildren().add(loaderComparisonQualifiers.getRoot());
		comparisonDataTargetAttr = loaderComparisonQualifiers.getController();

		dateFormatProperty = FXMLUtils.bindField( dateFormatText, dateQualifier, "dateFormat" );
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		comparisonDataTargetAttr.setTemplateItem(item);
		comparisonDataTargetAttr.setTreeView(treeView);
		
		dateQualifier = ((DateQualifier)item.getValue());

        //bind
		dateFormatProperty = FXMLUtils.rebindField(dateFormatText, dateFormatProperty, dateQualifier, "dateFormat");
	}
}