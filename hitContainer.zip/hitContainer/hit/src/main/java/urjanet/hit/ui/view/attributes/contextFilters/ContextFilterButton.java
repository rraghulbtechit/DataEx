package urjanet.hit.ui.view.attributes.contextFilters;

import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;

/**
 * A menu button for ContextFilter classes
 */
public class ContextFilterButton extends TemplateButton {

    TemplateMenuItem directionFilterAttributesMenuItem = new TemplateMenuItem( urjanet.pull.web.pdf.filter.DirectionFilter.class.getName(), "DirectionFilter");
    TemplateMenuItem horizontalFilterAttributesMenuItem = new TemplateMenuItem( urjanet.pull.web.pdf.filter.HorizontalFilter.class.getName(), "HorizontalFilter");
    TemplateMenuItem previousFilterAttributesMenuItem = new TemplateMenuItem( urjanet.pull.web.pdf.filter.PreviousFilter.class.getName(), "PreviousFilter");
    TemplateMenuItem rangeFilterAttributesMenuItem = new TemplateMenuItem( urjanet.pull.web.pdf.filter.RangeFilter.class.getName(), "RangeFilter");
    TemplateMenuItem verticalFilterAttributesMenuItem = new TemplateMenuItem( urjanet.pull.web.pdf.filter.VerticalFilter.class.getName(), "VerticalFilter");

    public ContextFilterButton() {
        this.setRepresentsClassName(urjanet.pull.web.pdf.filter.ContextFilter.class.getName());
        createMenuItems();
    }

    private void createMenuItems() {
        this.getItems().addAll(
                directionFilterAttributesMenuItem,
                horizontalFilterAttributesMenuItem,
                previousFilterAttributesMenuItem,
                rangeFilterAttributesMenuItem,
                verticalFilterAttributesMenuItem
        );
    }
}
