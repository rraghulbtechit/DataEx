package urjanet.hit.utils;

import org.junit.Assert;
import org.junit.Test;


public class DefaultValueTest {

	// These gets initialized to their default values
	private static boolean DEFAULT_BOOLEAN;
	private static byte DEFAULT_BYTE;
	private static short DEFAULT_SHORT;
	private static int DEFAULT_INT;
	private static long DEFAULT_LONG;
	private static float DEFAULT_FLOAT;
	private static double DEFAULT_DOUBLE;

	@Test
	public void isDefaultTest() {
		
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_BOOLEAN ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_BYTE ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_DOUBLE ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_FLOAT ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_INT ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_LONG ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( DEFAULT_SHORT ));
		
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Boolean( DEFAULT_BOOLEAN) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Byte( DEFAULT_BYTE ) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Double( DEFAULT_DOUBLE ) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Float( DEFAULT_FLOAT ) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Integer( DEFAULT_INT ) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Long( DEFAULT_LONG ) ));
		Assert.assertTrue( DefaultValue.doesContainDefaultValue( new Short( DEFAULT_SHORT ) ));

	}
	
	
}
