package urjanet.hit.ui.view.attributes.contextFilters;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.pull.web.pdf.filter.OverlapPosition;
import urjanet.pull.web.pdf.filter.VerticalFilter;

public class VerticalFilterAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/VerticalFilterAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;

	@FXML protected TextField leftBufferTf;
	protected Property leftBufferProperty;
	@FXML protected TextField rightBufferTf;
	protected Property rightBufferProperty;
	@FXML protected TextField forceLeftCoordinateTf;
	protected Property forceLeftCoordinateProperty;
	@FXML protected TextField forceRightCoordinateTf;
	protected Property forceRightCoordinateProperty;
	@FXML protected TextField maxDistanceTf;
	protected Property maxDistanceProperty;
	@FXML protected CheckBox forwardCb;
	protected Property forwardProperty;
	@FXML protected ComboBox overlapTextPositionCombo;
	protected Property overlapTextPositionProperty;
	
	private VerticalFilter verticalFilter;
	private KeysAttributes keyAttributes;
	
	public VerticalFilterAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loader.getRoot());
		keyAttributes = loader.getController();
		
		overlapTextPositionCombo.getItems().addAll(OverlapPosition.values());
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        keyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof VerticalFilter))
            throw new HiTException("Could not create Form for VerticalFilter due to incompatible node. Received " + Obj.getClass());
        
        this.verticalFilter = (VerticalFilter) Obj;
        
        addBinding();
        
        keyAttributes.setTemplateItem(item);
	}
	
	public void addBinding() {
		
		try {
        	//bind
			if( leftBufferProperty != null ) FXMLUtils.unbindField( leftBufferTf, leftBufferProperty );
			leftBufferProperty = FXMLUtils.bindField(leftBufferTf, verticalFilter, "leftBuffer");
        	
        	if( rightBufferProperty != null ) FXMLUtils.unbindField( rightBufferTf, rightBufferProperty );
        	rightBufferProperty = FXMLUtils.bindField(rightBufferTf, verticalFilter, "rightBuffer");
        	
        	if( forceLeftCoordinateProperty != null ) FXMLUtils.unbindField( forceLeftCoordinateTf, forceLeftCoordinateProperty );
        	forceLeftCoordinateProperty = FXMLUtils.bindField(forceLeftCoordinateTf, verticalFilter, "forceLeftCoordinate");
        	
        	if( forceRightCoordinateProperty != null ) FXMLUtils.unbindField( forceRightCoordinateTf, forceRightCoordinateProperty );
        	forceRightCoordinateProperty = FXMLUtils.bindField(forceRightCoordinateTf, verticalFilter, "forceRightCoordinate");
        	
        	if( forwardProperty != null ) FXMLUtils.unbindField( forwardCb, forwardProperty );
        	forwardProperty = FXMLUtils.bindField(forwardCb, verticalFilter, "forward");
        	
        	if( maxDistanceProperty != null ) FXMLUtils.unbindField( maxDistanceTf, maxDistanceProperty );
        	maxDistanceProperty = FXMLUtils.bindField(maxDistanceTf, verticalFilter, "maxDistance");
        	
        	if( overlapTextPositionProperty != null ) FXMLUtils.unbindField( overlapTextPositionCombo, overlapTextPositionProperty );
        	overlapTextPositionProperty = FXMLUtils.bindField(overlapTextPositionCombo, verticalFilter, "overlapTextPosition");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }

	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}