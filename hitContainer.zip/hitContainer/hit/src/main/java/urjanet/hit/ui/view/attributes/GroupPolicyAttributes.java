package urjanet.hit.ui.view.attributes;

import java.util.List;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.control.AlertDialog;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.GroupPolicy.GroupAction;

public class GroupPolicyAttributes extends BaseTemplateAttributes<T> {

	Logger log = LoggerFactory.getLogger( GroupPolicyAttributes.class );

	private static final String resourcePath = "/GroupPolicyAttributes.fxml";

	@FXML protected ComboBox    groupNameCb;
	protected Property 			groupNameProperty;
    @FXML protected ComboBox    groupActionCb;
    protected Property 			groupActionProperty;

    private GroupPolicy 		groupPolicy;
    
    public GroupPolicyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load( resourcePath ) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	groupActionCb.getItems().addAll( GroupPolicy.GroupAction.values() );
    	
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void setTemplateItem( TemplateTreeItem item ) throws HiTException {

		if( groupNameProperty != null ) FXMLUtils.unbindField( groupNameCb, groupNameProperty );
		if( groupActionProperty != null ) FXMLUtils.unbindField( groupActionCb, groupActionProperty );

		this.treeItem = item;
		this.groupPolicy = (GroupPolicy) item.getValue();

		setGroupNamesList( );

		groupNameProperty = FXMLUtils.bindField( groupNameCb, groupPolicy, "groupName" );
		groupActionProperty = FXMLUtils.bindField( groupActionCb, groupPolicy, "action" );
		
		if(groupPolicy.getAction() == null) {
			groupActionCb.getSelectionModel().select(GroupAction.ENUMERATE_NEXT);
		}
		//select groupName
		//log.info("Setting groupName in ComboBox to: "+groupPolicy.getGroupName()+" in "+groupPolicy );
		groupNameCb.setValue( groupPolicy.getGroupName() );
	}

	private List<String> groupNames = null;

	private void setGroupNamesList(  ) throws HiTException {

		setValidGroupNames();

		if( ( groupPolicy.getGroupName() != null ) && (! groupNames.contains( groupPolicy.getGroupName() ))) {//invalid condition
			String error = "Mismatch between selected GroupPolicy and allowed choices.";
			AlertDialog.create( AlertDialog.TITLE.ERROR.name(), AlertDialog.HEADER.INVALID_STATE.text(), error+" Removing selected groupName." );
			groupPolicy.setGroupName( null );

			//throw new HiTException( error );
		}
	}

	/**
	 * To be called by parent treeItems if their group is changed
	 */
	public void resetGroupNames() {
		groupNames = null;
	}

	private void setValidGroupNames() throws HiTException {

		groupNames = findValidGroupNames( this.treeItem );
		groupNameCb.getItems().clear();
		groupNameCb.getItems().addAll( groupNames );
	}

	public List<String> findValidGroupNames( TemplateTreeItem item ) throws HiTException {

		String groupName = PlatformAccessor.getRootGroup();
		GroupPolicy parentGroupPolicy = findParentGroupPolicy((TemplateTreeItem)item.getParent() );
		if( parentGroupPolicy != null )
			groupName = parentGroupPolicy.getGroupName();

		return PlatformAccessor.getValidChildGroupNames( groupName );
	}

	public static GroupPolicy findParentGroupPolicy( TemplateTreeItem item ) {

		TreeItem parentObj = item.getParent();

		if( parentObj != null ) {
			TemplateTreeItem parent = ( TemplateTreeItem )parentObj;
			ObservableList<TemplateTreeItem> childNodes = parent.getChildren();

			for(TemplateTreeItem childNode:childNodes) {

				Object childObj = childNode.getValue();
				if(childObj instanceof GroupPolicy && (((GroupPolicy)childObj).getGroupName() != null )) {
					//TODO set invalidation listener to parent to reset values
					return (GroupPolicy)childObj;
				}
			}
			return findParentGroupPolicy(parent);
		}

		return null;
	}
	
	@Override
	public void onHide() {
		
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
		//log.info("Setting groupName to: "+groupPolicy.getGroupName()+" in "+groupPolicy );
	}

	private Object getGroupName() {

		return groupNameCb.getValue();
	}

	private Object getGroupAction() {

		return groupActionCb.getValue();
	}
}