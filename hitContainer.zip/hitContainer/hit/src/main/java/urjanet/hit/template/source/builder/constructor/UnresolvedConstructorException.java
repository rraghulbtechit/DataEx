package urjanet.hit.template.source.builder.constructor;

public class UnresolvedConstructorException extends Exception{

    private static final long serialVersionUID = 1997753363232807009L;

		public UnresolvedConstructorException()
		{
		}

		public UnresolvedConstructorException(String message)
		{
			super(message);
		}

		public UnresolvedConstructorException(Throwable cause)
		{
			super(cause);
		}

		public UnresolvedConstructorException(String message, Throwable cause)
		{
			super(message, cause);
		}

		public UnresolvedConstructorException(String message, Throwable cause, 
                                           boolean enableSuppression, boolean writableStackTrace)
		{
			super(message, cause, enableSuppression, writableStackTrace);
		}

}
