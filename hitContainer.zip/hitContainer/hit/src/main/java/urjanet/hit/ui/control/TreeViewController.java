package urjanet.hit.ui.control;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.LinkedList;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.stream.Collectors;

import org.controlsfx.control.textfield.TextFields;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.model.TemplateObjectMapper;
import urjanet.hit.ui.model.TemplateTree;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.AttributePaneFactory;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.dockfx.DockNode;
import urjanet.hit.ui.view.dockfx.DockPane;
import urjanet.hit.ui.view.dockfx.DockPos;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.ftp.FtpPullJobTemplate;
import urjanet.pull.web.WebPullJobTemplate;

/**
 * A ViewController for Template Tree View pane as defined in templateTreeView.fxml
 */
public class TreeViewController implements Initializable {

//	static Logger log = Logger.getLogger(
//        TreeViewController.class.getName());

    @FXML private Button                    expand_all_button;
    @FXML private Button                    collapse_all_button;
    @FXML private ToolBar                   tree_action_toolbar;
    @FXML private CheckBox                  showPdfPageSpecCheck;
    @FXML private ScrollPane                woot_scroll_pane;
    @FXML private TextField                 searchNodeText;
    @FXML private VBox                      treeViewVBox;
    @FXML private TabPane                   events_console_tab_pane;
    @FXML private SplitPane                 treeConsoleSplitPane;
    @FXML private ScrollPane                treePane;
    @FXML private ScrollPane                consoleScrollPane;
    @FXML private TextArea                  consoleTextFlow;

    @FXML protected VBox                    propertiesVBox;

    protected TreeView                      templateTreeView;
    public TreeView getTemplateTreeView() {
        return templateTreeView;
    }

    protected TemplateTreeItem              selectedItem;
    protected ScrollPane                    currentAttributePane;
    protected TemplateTree                  tree = null;

    private Set<String>                     nodesText;
    private int                             searchIndex = 0;
    private LinkedList<TemplateTreeItem>    matches;
    private SimpleObjectProperty<Class>     selectedNodeClassProperty;
    private TemplateAttributesPane          currentAttributeController;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        selectedNodeClassProperty = new SimpleObjectProperty<>(WebPullJobTemplate.class);

        initTemplateTreeAndProperties();
        
        consoleTextFlow.setEditable(false);
        
        //redo console pane as a dock pane
        treeConsoleSplitPane.getItems().remove( consoleScrollPane );
        DockPane consolePane = getConsolePane();
        treeConsoleSplitPane.getItems().add( consolePane );
        treeConsoleSplitPane.setDividerPositions( 0.85 ); //need to do this here due to DockPane redoing the console pane

        initToolBar();
    }

    //TODO consolePane as its own class
    protected DockPane getConsolePane() {

        DockPane consolePane = new DockPane();
        DockNode treeDock = new DockNode( consoleScrollPane, "Console" );
        treeDock.dock( consolePane, DockPos.LEFT );
        treeDock.setClosable( false );

        //redirect stdout to it
        OutputStream os = new OutputStream() {
            @Override
            public void write(int b) throws IOException {
                appendText((char) b);
            }
        };
        System.setOut( new PrintStream( os, true ));

        return consolePane;
    }

    protected void appendText(char b) {
        Platform.runLater( () -> {
            consoleTextFlow.setText( consoleTextFlow.getText() + b);
            consoleTextFlow.positionCaret(consoleTextFlow.getLength());
        });
    }

    private void initTemplateTreeAndProperties() {

    	templateTreeView = new TreeView();
        templateTreeView.setPrefSize(1300, 800);
        templateTreeView.setOnKeyReleased( keyEventEventHandler );

        treePane.setContent(templateTreeView);
    }

    private EventHandler<KeyEvent> keyEventEventHandler = event -> {

            if( event.getCode() == KeyCode.ENTER ) {
                if(! searchNodeText.getText().isEmpty() ) { //we are in search mode. Go to next result

                    if( event.isShiftDown() ) {
                        if( searchIndex > 0 ) searchIndex--;
                    } else {
                        if( searchIndex < (matches.size() - 1) ) searchIndex++;
                    }

                    templateTreeView.getSelectionModel().select( matches.get(searchIndex) );
                    templateTreeView.getFocusModel().focus( templateTreeView.getSelectionModel().getSelectedIndex() );
                }
            }
        };


    protected void initToolBar() {
        //node search

        searchNodeText.focusedProperty().addListener( searchNodeChangeListener );
        TextFields.bindAutoCompletion( searchNodeText, param -> {
            //System.out.println( param.getUserText() );
            return nodesText.stream().filter( it -> it.contains( param.getUserText() )).collect(Collectors.toList());
        });
        //Disable all tree buttons except 'New'
        //Associate button to selected template tree node
        /*tree_action_toolbar.getItems().stream()
                .filter(button -> button instanceof TemplateButton)
                .forEach(button -> button.disableProperty().bind(btnBinding((TemplateButton) button)));*/
    }

    protected BooleanBinding btnBinding(TemplateButton btn) {
        return Bindings.createBooleanBinding(() -> {
            Class btnClazz = Class.forName(btn.getRepresentsClassName());
            boolean isBindable = (selectedNodeClassProperty.get() != null)
                    ? TemplateObjectMapper.isContainedAttribute(selectedNodeClassProperty.get(), btnClazz)
                    : false;
            return (! isBindable);
        }, selectedNodeClassProperty);
    }

    /**
     * Triggered when the user selecting or creating a template.
     *
     * @return
     */
    void loadTreeItems(String template) {
        loadTreeItems(template, WebPullJobTemplate.class);
    }

    void loadTreeItems(String template, Class pullJobClazz) {

        //String template = "AceDisposalUTTemplateProvider";
        PullJobTemplate pjt = null;
        try {
            if( template != null )
                pjt = PlatformAccessor.getTemplate(template);
            else if( FtpPullJobTemplate.class.equals( pullJobClazz) ){
                pjt = new FtpPullJobTemplate( null, "New Template", null, null );
            } else {
                pjt = new WebPullJobTemplate( "url", null, "New Template", null, null );
            }
            tree = TemplateTree.getTemplateTree(pjt);
        } catch (HiTException e) {
            e.printStackTrace();
        }

        // print complete tree for info. Only first level of children are shown to minimize memory use
        //tree.printTree();

        //TreeView<Object> treeView = TemplateTreeView.getTemplateTreeView(tree.getRoot());
        templateTreeView.setCellFactory(p -> new TreeCellImpl());
        templateTreeView.setShowRoot(true);
        templateTreeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        templateTreeView.setEditable(false);

        // when a TreeItem is selected
        templateTreeView.getSelectionModel().selectedItemProperty().addListener((ObservableValue observable, Object oldValue, Object newValue) -> {

            selectedItem = (TemplateTreeItem) newValue;
            if(selectedItem == null || selectedItem.getValue() == null) {
                selectedNodeClassProperty.setValue( null );
                return;
            }

            selectedNodeClassProperty.setValue(selectedItem.getValue().getClass());
            try {
                showAttributes( selectedItem );
                selectedItem.setExpanded( true );
            } catch (HiTException e) {
                e.printStackTrace();
            }
        });

        //TODO This is very slow... optimize with pre-created strings?
        //refreshSearchStrings();

        showTree();
    }

    /**
     * Builds a list of strings to search for nodes
     */
    private void refreshSearchStrings() {

        nodesText = tree.nodesText();
    }


    //show pdfPageSpec onwards or all
    protected void showTree() {

        boolean showPdf = showPdfPageSpecCheck.isSelected();

        if(tree.getRoot().isShowPdfOnly() != showPdf ) {
            templateTreeView.setRoot(null);
            try {
                tree.buildTree();
            } catch (HiTException e) {
                e.printStackTrace();
            }
        }
        TemplateTreeItem root = tree.getRoot();
        root.setShowPdfOnly( showPdf );
        templateTreeView.setRoot( root );
        root.setExpanded( true );
        templateTreeView.getSelectionModel().select(root);
        templateTreeView.refresh();
    }

    public void onShowPdf(ActionEvent actionEvent) {

        showTree();
    }

    public void showAttributes( TemplateTreeItem treeItem ) throws HiTException {

        if(treeItem == null) return;

        //this logic is needed to show/hide for forms to restore/save data
        if(currentAttributePane != null) {
            currentAttributeController.onUnload();
            currentAttributePane.setVisible( false );
        }

        currentAttributePane = AttributePaneFactory.getAttributePane(treeItem, templateTreeView);
        currentAttributeController = AttributePaneFactory.getController( treeItem );
        propertiesVBox.getChildren().clear();
        propertiesVBox.getChildren().add( currentAttributePane );
        currentAttributePane.setVisible(true);
    }

    private void expandTreeView(TreeItem<?> item){

        if(item != null && !item.isLeaf()){
            item.setExpanded(true);
            for(TreeItem<?> child:item.getChildren()){
                expandTreeView(child);
            }
        }
    }

    private void collapseTreeView(TreeItem<?> item){

        if(item != null && !item.isLeaf()){
            item.setExpanded(false);
            for(TreeItem<?> child:item.getChildren()){
                collapseTreeView(child);
            }
        }
    }

    public void onExpandAll(ActionEvent actionEvent) {

        expand_all_button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                expandTreeView(templateTreeView.getRoot());
            }
        });
    }

    public void onCollapseAll(ActionEvent actionEvent) {

        collapse_all_button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                collapseTreeView(templateTreeView.getRoot());
            }
        });
    }

    public void onKeyTyped(Event event) {
        //TODO

    }

    /**
     * Next search result if enter key is pressed
     * @param event
     */
    public void onTreeKeyRelease(KeyEvent event) {

        if( event.getCode() == KeyCode.ENTER ) {
            if(! searchNodeText.getText().isEmpty() ) { //we are in search mode. Go to next result

                if( event.isShiftDown() ) {
                    if( searchIndex > 0 ) searchIndex--;
                } else {
                    if( searchIndex < (matches.size() - 1) ) searchIndex++;
                }

                templateTreeView.getSelectionModel().select( matches.get(searchIndex) );
                templateTreeView.getFocusModel().focus( templateTreeView.getSelectionModel().getSelectedIndex() );
            }
        }
    }

    public void onSearchKeyRelease(KeyEvent event) {

        if( event.getCode() == KeyCode.ENTER ) {
            if (!searchNodeText.getText().isEmpty()) {
                //TODO focus not moving to tree
                templateTreeView.getFocusModel().focus(0);
            }
        }
    }

    private ChangeListener<Boolean> searchNodeChangeListener = (observable, wasFocused, nowFocused) -> {

        if( nowFocused ) return;

        System.out.println("Lost focus");

        String searchText = searchNodeText.getText();
        if( searchText == null || searchText.trim().isEmpty() ) {

            if(matches != null) matches.clear();
            return;
        }

        //locate nodes in depth-first order
        matches = new LinkedList<>(tree.locateNodes( searchText ));

        //select nodes in that order
        if( matches.size() > 0 ) {
            searchIndex = 0;
            templateTreeView.getSelectionModel().select( matches.get( searchIndex ) );
        }
    };

    public static final class TreeCellImpl<T> extends TreeCell<T> {

        @Override
        public void updateItem(T item, boolean empty) {
            super.updateItem(item, empty);

            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                setText(getTreeItem().toString());
                setGraphic(getTreeItem().getGraphic());
                setContextMenu(((TemplateTreeItem) getTreeItem()).getContextMenu());
            }
        }
    }
}
