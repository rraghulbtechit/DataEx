package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.pdf.context.TargetContext;
import urjanet.pull.web.pdf.context.TargetContext.TargetContextDirection;

public class TargetContextConstructorResolution {

	public static List<Object> resolveConstructorParameters( TargetContext targetContext ) {
		
		TargetContextDirection targetContextDirection = targetContext.getTargetContext();
		int depth = targetContext.getDepth();
		boolean isRestrictedContextDelta = targetContext.isRestrictedContextDelta();
		List<Object> properties = new ArrayList<Object>();
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, targetContextDirection );
		
		if( depth != 0 )
			properties.add(depth);
		if( depth == 0 && isRestrictedContextDelta ){
			properties.add(depth);
			properties.add(isRestrictedContextDelta);
		}
		if( depth != 0 && isRestrictedContextDelta ){
			properties.add(isRestrictedContextDelta);
		}
		
		return properties;
	}

}
