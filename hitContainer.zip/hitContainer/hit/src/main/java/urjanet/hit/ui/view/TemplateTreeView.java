package urjanet.hit.ui.view;

import javafx.scene.control.*;
import urjanet.pull.web.WebPullJobTemplate;

import java.util.HashMap;
import java.util.Map;

@Deprecated
public class TemplateTreeView extends TreeView{

	private TemplateTreeView() {}

	private TemplateTreeView( TreeItem root ){
		super(root);
	}
	
	public static TemplateTreeView getTemplateTreeView( TreeItem root ) {
		
		TemplateTreeView instance = new TemplateTreeView( root );
		
		return instance;
	}

}