package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.text.TextDataTarget;
import urjanet.pull.web.text.TextTargetDefinition;

import java.net.URL;
import java.util.ResourceBundle;

public class TextDataTargetAttributes implements Initializable, TemplateAttributesPane {

    public static final  String resourcePath = "/TextDataTargetAttributes.fxml";

    @FXML private TextField     searchLabelText;
    private Property            searchLabelProperty;
    @FXML private CheckBox      includeWholeLineCheck;
    private Property            includeWholeLineProperty;
    @FXML private ComboBox      searchDirectionCb;
    private Property            searchDirectionProperty;
    @FXML private TextField     lineNumberText;
    private Property            lineNumberProperty;
    @FXML private TextField     wordNumberText;
    private Property            wordNumberProperty;
    @FXML private VBox          dataTargetAttributesVBox;
    @FXML private DataTargetAttributes  dataTargetAttributesVBoxController;

    protected TreeView          treeView;
    protected TemplateTreeItem  treeItem;
    protected TextDataTarget    textDataTarget;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        searchDirectionCb.getItems().addAll( TextTargetDefinition.Direction.values() );
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        textDataTarget = (TextDataTarget) item.getValue();

        if( searchLabelProperty != null ) FXMLUtils.unbindField( searchLabelText, searchLabelProperty );
        searchLabelProperty = FXMLUtils.bindField( searchLabelText, textDataTarget, "searchLabel" );
        if( includeWholeLineProperty != null ) FXMLUtils.unbindField( includeWholeLineCheck, includeWholeLineProperty );
        includeWholeLineProperty = FXMLUtils.bindField( includeWholeLineCheck, textDataTarget, "includeWholeLine" );
        if( searchDirectionProperty != null ) FXMLUtils.unbindField( searchDirectionCb, searchDirectionProperty );
        searchDirectionProperty = FXMLUtils.bindField( searchDirectionCb, textDataTarget.getTargetDefinition(), "searchDirection" );
        if( lineNumberProperty != null ) FXMLUtils.unbindField( lineNumberText, lineNumberProperty );
        lineNumberProperty = FXMLUtils.bindField( lineNumberText, textDataTarget.getTargetDefinition().getSearchKey(), "lineNumber" );
        if( wordNumberProperty != null ) FXMLUtils.unbindField( wordNumberText, wordNumberProperty );
        wordNumberProperty = FXMLUtils.bindField( wordNumberText, textDataTarget.getTargetDefinition().getSearchKey(), "wordNumber" );

        dataTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
    }
}
