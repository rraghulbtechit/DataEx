package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.ReplaceOperator;

public class ReplaceOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/ReplaceOperatorAttributes.fxml";
	
	@FXML private TextField regExText;
	private Property regExTextProperty;
	@FXML private TextField replaceWithText;
	private Property replaceWithTextProperty;
	
	private ReplaceOperator replaceOperator;
	
	public ReplaceOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof ReplaceOperator))
            throw new HiTException("Could not create Form for replaceOperator due to incompatible node. Received " + Obj.getClass());
        
        this.replaceOperator = (ReplaceOperator) Obj;
        
        if( regExTextProperty != null ) FXMLUtils.unbindField( regExText, regExTextProperty );
		regExTextProperty = FXMLUtils.bindField(regExText, replaceOperator, "regEx");
		
		if( replaceWithTextProperty != null ) FXMLUtils.unbindField( replaceWithText, replaceWithTextProperty );
		replaceWithTextProperty = FXMLUtils.bindField(replaceWithText, replaceOperator, "replaceWith");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}
