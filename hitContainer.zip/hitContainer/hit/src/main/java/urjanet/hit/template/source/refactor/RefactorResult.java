package urjanet.hit.template.source.refactor;

import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.Expression;

@Deprecated
public class RefactorResult {

	private BodyDeclaration extract;
	private Expression extractInvocation;
	
	public RefactorResult( BodyDeclaration extract, Expression extractInvocation ) {
		
		this.extract = extract;
		this.extractInvocation = extractInvocation;
	}
	
	
	public BodyDeclaration getExtract() {

		return extract;
	}
	
	
	public Expression getExtractInvocation() {

		return extractInvocation;
	}
}
