package urjanet.hit.utils;

import java.lang.reflect.Field;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import urjanet.keys.AccountKeys;
import urjanet.keys.AccountSearchKeys;
import urjanet.keys.AddressKeys;
import urjanet.keys.ChargeKeys;
import urjanet.keys.Charges;
import urjanet.keys.DataValues;
import urjanet.keys.DomainKeys;
import urjanet.keys.IntervalKeys;
import urjanet.keys.MessageKeys;
import urjanet.keys.MetaKeys;
import urjanet.keys.MeterKeys;
import urjanet.keys.ProviderKeys;
import urjanet.keys.RecentPaymentKeys;
import urjanet.keys.SmartMeterKeys;
import urjanet.keys.StatKeys;
import urjanet.keys.StatementKeys;
import urjanet.keys.SummaryKeys;
import urjanet.keys.TemporalKeys;
import urjanet.keys.UnrelatedChargeKeys;
import urjanet.keys.UsageKeys;
import urjanet.keys.uds.GroupingKeys;
import urjanet.pull.template.TemplateProvider;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.DataTargetPageCondition;
import urjanet.pull.web.TrackLoginFailurePageSpec;

public class ReflectionUtils {

	public static <T> Set<Class<? extends T>> findAllMatchingTypes(Class<T> toFind) {
		Reflections reflections = new Reflections(toFind.getPackage().getName());	
		Set<Class<? extends T>> classes = reflections.getSubTypesOf(toFind);
		
		return classes;
	}
	
	
	public static DomainKeys getDomainKeyEnumConstant( String key ) {

		Set<Class<? extends DomainKeys>> matchingTypes = findAllMatchingTypes(DomainKeys.class);
		for (Class<? extends DomainKeys> clazz : matchingTypes) {
			Enum[] e=(Enum[]) clazz.getEnumConstants();
			if( e!= null ) {
				for (Enum enum1 : e) {
					DomainKeys domainKey = null;
					if( enum1 instanceof AccountKeys ){
						domainKey = AccountKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MetaKeys ){
						domainKey = MetaKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof UsageKeys ){
						domainKey = UsageKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MessageKeys ){
						domainKey = MessageKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof Charges){
						domainKey = Charges.valueOf( enum1.name() );
					} else if ( enum1 instanceof UnrelatedChargeKeys ){
						domainKey = UnrelatedChargeKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof RecentPaymentKeys ){
						domainKey = RecentPaymentKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MeterKeys){
						domainKey = MeterKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof IntervalKeys ){
						domainKey = IntervalKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof GroupingKeys ){
						domainKey = GroupingKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof StatementKeys ){
						domainKey = StatementKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof AddressKeys ){
						domainKey = AddressKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof TemporalKeys ){
						domainKey = TemporalKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof SmartMeterKeys ){
						domainKey = SmartMeterKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof SummaryKeys ){
						domainKey = SummaryKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof AccountSearchKeys ){
						domainKey = AccountSearchKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof StatKeys ){
						domainKey = StatKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof ProviderKeys ){
						domainKey = ProviderKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof ChargeKeys ){
						domainKey = ChargeKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof DataValues ){
						domainKey = DataValues.valueOf( enum1.name() );
					}
					
					if ( domainKey.getValue().equals( key ) )
						return domainKey;
				}
			}
		}
		return null;
	}
	
	public static Set<Class<? extends Object>> getClassesInPackage( String packageName ){
		
		List<ClassLoader> classLoadersList = new LinkedList<ClassLoader>();
		classLoadersList.add(ClasspathHelper.contextClassLoader());
		classLoadersList.add(ClasspathHelper.staticClassLoader());

		Reflections reflections = new Reflections(new ConfigurationBuilder()
			.setScanners(
				new SubTypesScanner(
					false /* don't exclude Object.class */), 
				new ResourcesScanner())
			.setUrls(ClasspathHelper.forClassLoader(classLoadersList.toArray(new ClassLoader[0])))
			.filterInputsBy(new FilterBuilder().include(FilterBuilder.prefix( packageName ))));

		Set<Class<? extends Object>> allClasses = reflections.getSubTypesOf(Object.class);
		
		return allClasses;
	}

	/**
	 * Gets a field from the given class or any of its superclasses
	 *
	 * @param clazz
	 * @param fieldName
     * @return
     */
	public static Field getField( Class clazz, String fieldName ) {

		Field field = null;
		try {
			field = clazz.getDeclaredField( fieldName );
			return field;
		} catch (NoSuchFieldException e) {
			Class parent = clazz.getSuperclass();
			if( parent != null )
				field = getField( parent, fieldName );
		}
		return field;
	}

	public static void setField( Object object, String fieldName, Object value ) throws IllegalAccessException {
		Field field = getField( object.getClass(), fieldName );
		field.setAccessible( true );
		field.set( object, value );
	}

	//test
	public static void main(String[] args) throws Exception {
		TrackLoginFailurePageSpec pgSpec = new TrackLoginFailurePageSpec( null, null );
		setField( pgSpec, "pageCondition", new DataTargetPageCondition());
		setField( pgSpec, "pageSpec", new BasePageSpec(ContentType.CSV));
		System.out.println( pgSpec.getPageSpec().getExpectedContentType());

	}
}
