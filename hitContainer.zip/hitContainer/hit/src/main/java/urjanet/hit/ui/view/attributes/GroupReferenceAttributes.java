package urjanet.hit.ui.view.attributes;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.keys.GroupingKeys;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.reference.GroupReference;

public class GroupReferenceAttributes extends BaseTemplateAttributes<T> {
	
	private static final String resourcePath = "/GroupReferenceAttributes.fxml";
	@FXML protected ComboBox<GroupingKeys> scopeCb;
	protected Property scopeProperty;
	@FXML protected TemplateButton dataTargetsBtn;
	@FXML protected ComboBox<TemplateTreeItem> existingDataTargetsList;
	private GroupReference groupReference;
	
	public GroupReferenceAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
    	scopeCb.getItems().addAll(urjanet.keys.uds.GroupingKeys.values());
    	this.treeView = treeView;
        setTemplateItem(treeItem);
        
        for(MenuItem item : dataTargetsBtn.getItems()) {
            item.setOnAction( dataTargetHandler );
        }
        
        existingDataTargetsList.valueProperty().addListener(new ChangeListener<TemplateTreeItem>() {
            @Override 
            public void changed(ObservableValue ov, TemplateTreeItem t, TemplateTreeItem t1) {
            	
            	if(t1 != null) {
	            	DataTarget value = (DataTarget) t1.getValue();
	            	try {
						createDataTargetTreeNode(value);
					} catch (HiTException e) {
						e.printStackTrace();
					}
            	}
            }    
        });
    }
    
    EventHandler dataTargetHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTarget newTarget = ((DataTarget)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor
            createDataTargetTreeNode(newTarget);
            
            //this.treeItem.setChildrenAssigned( false );
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch( HiTException e ) {
            System.out.println( e );
        }
    };

	private void createDataTargetTreeNode(DataTarget newTarget) throws HiTException {
		TemplateTreeItem<T> dataTargetItem;
		List<DataTarget> list = groupReference.getTargets();
		if( list != null && list.size() > 0 ) {
		    if(! (newTarget.getClass().isAssignableFrom(list.get(0).getClass())))
		        throw new HiTException("Cannot add incompatible types to list of DataTargets" );
		    list = new ArrayList<>( list );
		    list.add( newTarget );
		} else {
		    list = new ArrayList<>();
		    list.add(newTarget);
		}

		//this.treeItem.getChildren().clear();
		groupReference.setTargets(list);
		
		dataTargetItem = new TemplateTreeItem( newTarget );
		addSelectNode(dataTargetItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof GroupReference))
            throw new HiTException("Could not create Form for GroupReference due to incompatible node. Received " + Obj.getClass());
        
        this.groupReference = (GroupReference) Obj;
        
        existingDataTargetsList.getItems().clear();
        existingDataTargetsList.getItems().addAll(FXCollections.observableArrayList(getReferenceDataTargetList()));
        
        //bind
        if( scopeProperty != null ) FXMLUtils.unbindField( scopeCb, scopeProperty );
        scopeProperty = FXMLUtils.bindField(scopeCb, groupReference, "scope");
            
	}
	
	private List<TemplateTreeItem> getReferenceDataTargetList(){
		
		TemplateTreeItem root = (TemplateTreeItem) treeView.getRoot();
		List<TemplateTreeItem> referenceDataTargetList = new ArrayList<TemplateTreeItem>();
		
		if(!root.isLeaf())
			referenceDataTargetList = parseTree(root, referenceDataTargetList);
		
		return referenceDataTargetList;
	}
	
	private List<TemplateTreeItem> parseTree(TemplateTreeItem parent, List<TemplateTreeItem> referenceDataTargetList) {
		
		if(parent != null) {
			
			ObservableList<TemplateTreeItem> children = parent.getChildren();
			
			for(TemplateTreeItem child: children) {
				
				if(child.getValue() instanceof DataTarget) {
					
					DataTarget dataTarget = (DataTarget)child.getValue();
					if(dataTarget.getName() != null)
						referenceDataTargetList.add(child);
				}
				
				if(!child.isLeaf())
					referenceDataTargetList = parseTree(child, referenceDataTargetList);
			}
		}
		
		return referenceDataTargetList;
	}
}
