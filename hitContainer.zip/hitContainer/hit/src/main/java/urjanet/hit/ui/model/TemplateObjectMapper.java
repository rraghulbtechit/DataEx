package urjanet.hit.ui.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import urjanet.hit.HiTException;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.UrlNavTarget;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;

import java.lang.reflect.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Provides template constructor and setter properties for display in forms. Also provides the best matching constructor
 * and setters given a list of Arguments.
 */
//TODO fix generic type to use an instance
public class TemplateObjectMapper<T> {

    private static Map<Class, List<List<Arg>>>     constructorArgs = new HashMap<>();
    private static Map<Class, List<Arg>>           setterArgs = new HashMap<>();
    private static Map<Class, List<Arg>>           getterArgs = new HashMap<>();

    private static final Logger log = LoggerFactory.getLogger(TemplateObjectMapper.class);

    /**
     * For the input Class, returns the arguments taken in by constructor.
     * IMPORTANT: To get the prameter names in code, the class has to be compiled as javac -parameters
     *
     * @param templateObjClass
     * @return
     */
    public static List<List<Arg>> getConstructorArgs(Class templateObjClass) throws HiTException {

        if(templateObjClass.isInterface()) {
            throw new HiTException("The input Class needs to be a concrete class. Received an interface - " + templateObjClass.getName());
        }
        List<List<Arg>> ctorList = constructorArgs.get(templateObjClass);
        if(ctorList != null)
            return ctorList;
        else
            ctorList = new ArrayList<List<Arg>>();

        Constructor[] ctors = templateObjClass.getConstructors();
        for(Constructor ctor : ctors) {
            List<Arg> argList = new ArrayList<>();
            for(Parameter p : ctor.getParameters()) {
                Arg arg = new Arg(p.getName(), p.getType());
                argList.add(arg);
            }
            ctorList.add(argList);
        }

        constructorArgs.put(templateObjClass, ctorList);
        return ctorList;
    }

    /**
     * Gets the setter arguments for the input class
     *
     * @param templateObjClass
     * @return
     */
    public static List<Arg> getSetterArgs(Class templateObjClass) {

        return getArgs(templateObjClass, "set");
    }

    /**
     * Gets the setter arguments for the input class
     *
     * @param templateObj
     * @return
     */
    public static List<Arg> getSetterArgs(Object templateObj) {

        return getArgs(templateObj, "set");
    }

    /**
     * Gets the setter arguments for the input class
     *
     * @param templateObjClass
     * @return
     */
    public static List<Arg> getGetterArgs(Class templateObjClass) {

        return getArgs(templateObjClass, "get");
    }

    /**
     * Gets the setter arguments for the input class
     *
     * @param templateObj
     * @return
     */
    public static List<Arg> getGetterArgs(Object templateObj) {

        return getArgs(templateObj, "get");
    }

    /**
     * This version sets contained subtypes using the object instance in parameter
     *
     * @param templateObj
     * @param prefix
     * @return
     */
    private static List<Arg> getArgs(Object templateObj, String prefix) {

        List<Arg> args = getArgs(templateObj.getClass(), prefix);
        //Using the object instance set subtypes

        for(Arg arg : args) {
            if(! arg.isContainer())
                continue;
            Object container = null;
            try {
                container = templateObj.getClass().getMethod("get"+arg.getName()).invoke(templateObj);
                if(container instanceof List) {
                    Object value = ((List)container).get(0);
                    arg.setContainedType(value.getClass());
                }
            } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                e.printStackTrace();
            } catch (IndexOutOfBoundsException e) {
                arg.setContainedType(Object.class);
                log.debug( "No element to determine contained type for ", container );
            }
        }
        return args;
    }

    /**
     * Gets the arguments for the input class
     *
     * @param templateObjClass
     * @return
     */
    private static List<Arg> getArgs(Class templateObjClass, String prefix) {

        List<Arg> args;
        if(prefix.equals("get"))
            args = getterArgs.get(templateObjClass);
        else
            args = setterArgs.get(templateObjClass);

        if(args != null) {
            return args;
        } else {
            args = new ArrayList<>();
        }

        Method[] methods = templateObjClass.getMethods(); //TODO getDeclaredMethods
        for(Method m : methods) {
            if(! m.getName().startsWith(prefix))
                continue;

            try {
                char c = m.getName().charAt(prefix.length());
                if(!Character.isUpperCase(c))
                    continue;
            } catch(Exception e) {
                System.out.println("Exception processing " + m.getName() + e);
            }

            int paramCount = prefix.equals("get") ? 0 : 1;
            if(m.getParameterCount() != paramCount)
                continue;

            Arg theArg = new Arg(m.getName().substring(prefix.length()),
                    prefix.equals("get") ? m.getReturnType() : m.getParameters()[0].getType(),
                    true);
            //Type type = prefix.equals("get") ? m.getGenericReturnType() : m.getGenericParameterTypes()[0];
            if(theArg.isContainer())
                theArg.setContainedType(Object.class); //needs to be populated with an instance

            args.add( theArg );
        }

        if(prefix.equals("get"))
            getterArgs.put(templateObjClass, args);
        else
            setterArgs.put(templateObjClass, args);

        return args;
    }

    /**
     * Given an input argument list, returns the constructor arguments that match that list
     *
     * @param templateObjClass
     * @param properties
     * @return the constructor argument list, or null if no constructor matches input
     * @throws HiTException
     */
    public static List<Arg> getBestConstructor(Class templateObjClass, List<Arg> properties) throws HiTException {

        List<List<Arg>> ctorArgs = constructorArgs.get(templateObjClass);
        if(ctorArgs == null)
            throw new HiTException("Constructor list not initialized to get best matching constructor");

        constructor: for(List<Arg> ctor : ctorArgs) {
            if(ctor.size() != properties.size())
                continue constructor;

            int idx = 0;
            for(Arg arg : ctor) {
                if(! arg.equals(properties.get(idx++)))
                    continue constructor;
            }
            return ctor;
        }

        return null;
    }

    /**
     * True if the input <i>type</i> is a constructor or setter argument for templateObjectClass
     * @param templateObjClass
     * @param type
     * @return
     */
    public static boolean isContainedAttribute(Class templateObjClass, Class type) {

        List<Arg> attributes = getSetterArgs(templateObjClass);
        if(attributes == null)
            return false;

        for(Arg attribute: attributes) {
            if(type.isAssignableFrom(attribute.getType()))
                return true;
            else if(Collections.class.isAssignableFrom(attribute.getType())) {
                System.out.println(">>>>>>>>>>" + attribute.getType().getTypeParameters());
                return true;
            }
        }

        try {
            List<List<Arg>> ctorArgs = getConstructorArgs(templateObjClass);
            for(List<Arg> listOfArgs : ctorArgs) {
                for(Arg attribute : listOfArgs) {
                    if(type.isAssignableFrom(attribute.getType()))
                        return true;
                }
            }
        } catch (HiTException e) {
            e.printStackTrace();
        }

        return false;
    }
/*
    public Constructor getBestConstructor(T templateObject) {

        return null;
    }*/

    /**
     * Given a list of arguments, returns a list of setter arguments.
     *
     * @param properties
     * @return
     */
    public static List<Arg> getSetters(List<Arg> properties) {

        return properties; //TODO validate and prune
    }

  /*  public List<Method> getSetters(T templateObject) {

        return null;
    }
*/

    public static void print(List<List<Arg>> constructors) {
        int idx = 1;
        for(List<Arg> args : constructors) {
            System.out.println("Constructor["+ idx++ +"]");
            printArgs(args);
        }
    }

    public static void printArgs(List<Arg> args) {
        for(Arg a : args) {
            System.out.print(a.getName() + "-" + a.getType()+", ");
        }
        System.out.println();
    }

    /**
     * Represents an Argument
     */
    public static class Arg<T> {

        private boolean     isMandatory = true;
        private String      name = "";
        private Class       type;
        private T           value;
        //If the Arg is a container, this contains the contained type
        private Class        containedType;

        public Arg(String name, Class type) {
            this(name, type, true);
        }
        public Arg(String name, Class type, Class containedType) {
            this(name, type, true, null, containedType);
        }
        public Arg(String name, Class type, boolean isMandatory) {
            this(name, type, isMandatory, null, null);
        }
        public Arg(String name, Class type, boolean isMandatory, Class containedType) {
            this(name, type, isMandatory, null, containedType);
        }
        public Arg(String name, Class type, boolean isMandatory, T value) { this(name, type, isMandatory, value, null); }

        public Arg(String name, Class type, boolean isMandatory, T value, Class containedType) {
            this.name = name;
            this.type = type;
            this.isMandatory = isMandatory;
            this.value = value;
            this.containedType = containedType;
        }

        public String getName() {
            return name;
        }

        public Class getType() {
            return type;
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        public boolean isMandatory() {
            return isMandatory;
        }

        public void setMandatory(boolean mandatory) {
            isMandatory = mandatory;
        }

        public Class getContainedType() {
            return containedType;
        }

        public void setContainedType(Class containedType) {
            this.containedType = containedType;
        }

        @Override
        public boolean equals(Object obj) {

            if(! (obj instanceof Arg))
                return false;

            return ((Arg)obj).name.equals(name) && ((Arg)obj).type.equals(type);
        }

        public boolean isContainer() {
            log.info("Checking for container type", getType().getName());
            if(Collection.class.isAssignableFrom(this.getType())) { //TODO other types
                log.info(getType().getName() + " is a container");
                return true;
            }

            return false;
        }

        @Override
        public String toString() {
            return getName() + " " + getType();
        }
    }


    public static String[] contentTypes() {
        return Stream.of(ContentType.values()).map(ContentType::name).toArray(String[]::new);
    }

    //Test code
    public static void main(String[] args) throws HiTException {

        System.out.println(contentTypes());

        Class clazz = WebPullJobTemplate.class;
        //Class clazz = UrlNavTarget.class;

        //Get List of Constructors
        List<List<Arg>> constructors = TemplateObjectMapper.getConstructorArgs(clazz);
        System.out.println("Constructors for WebPullJobTemplate:");
        TemplateObjectMapper.print(constructors);

        //Get List of Setter params
        clazz = PullJobTemplate.class; //WebPullJobTemplate.class
        // List<Arg> setterArgs = TemplateObjectMapper.getSetterArgs(clazz);
        List<Arg> setterArgs = TemplateObjectMapper.getSetterArgs(clazz);
        System.out.println("Setters for " + clazz.getName());
        TemplateObjectMapper.printArgs(setterArgs);

        List<Arg> getterArgs = TemplateObjectMapper.getGetterArgs(clazz);
        System.out.println("Getters for " + clazz.getName());
        TemplateObjectMapper.printArgs(getterArgs);

        //isAssignable
        clazz = WebPullJobTemplate.class;
        assert TemplateObjectMapper.isContainedAttribute(clazz, urjanet.pull.core.PageSpec.class);

        //Modify

        //Get best constructor for selection
        List<Arg> bestArgs = TemplateObjectMapper.getBestConstructor(clazz, constructors.get(0));
        System.out.println("Best Constructor for WebPullJobTemplate args: ");
        TemplateObjectMapper.printArgs(constructors.get(0));
        System.out.println("Matches with: ");
        TemplateObjectMapper.printArgs(bestArgs);

        //Get Methods for selected params
        List<Arg> settersList = TemplateObjectMapper.getSetters(setterArgs);
        System.out.println("Setters list: ");
        TemplateObjectMapper.printArgs(settersList);
    }
}
