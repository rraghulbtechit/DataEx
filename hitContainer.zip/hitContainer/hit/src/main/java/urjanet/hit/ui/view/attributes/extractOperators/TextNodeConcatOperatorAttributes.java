package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.TextNodeConcatOperator;

public class TextNodeConcatOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/TextNodeConcatOperatorAttributes.fxml";
	
	@FXML private TextArea xpathsText;
	private Property xpathsTextProperty;
	@FXML private TextField delimiterText;
	private Property delimiterTextProperty;
	
	private TextNodeConcatOperator textNodeConcatOperator;
	
	public TextNodeConcatOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
	
	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof TextNodeConcatOperator))
            throw new HiTException("Could not create Form for textNodeConcatOperator due to incompatible node. Received " + Obj.getClass());
        
        this.textNodeConcatOperator = (TextNodeConcatOperator) Obj;
        
        if( xpathsTextProperty != null ) FXMLUtils.unbindField( xpathsText, xpathsTextProperty );
		xpathsTextProperty = FXMLUtils.bindField(xpathsText, textNodeConcatOperator, "xPaths");
		
		if( delimiterTextProperty != null ) FXMLUtils.unbindField( delimiterText, delimiterTextProperty );
		delimiterTextProperty = FXMLUtils.bindField(delimiterText, textNodeConcatOperator, "delimiter");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}