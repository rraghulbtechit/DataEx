package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.GroupPolicyButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;

import java.net.URL;
import java.util.ResourceBundle;

public class NavTargetAttributes<T> implements Initializable, TemplateAttributesPane {

    protected static String resourcePath = "/NavTargetAttributes.fxml";

    @FXML private TextField                 waitForXpathDataTargetStringToAppearText;
    private Property                        waitForXpathDataTargetStringToAppearProperty;
    @FXML private CheckBox                  currentPageAsEnclosedPageCheck;
    private Property                        currentPageAsEnclosedPageProperty;
    @FXML private TextArea                  conditionalNavigationText;
    private Property                        conditionalNavigationProperty;
    @FXML private VBox                      groupPolicyVBox;
    @FXML private TemplateMenuItem          basePageSpecItem;
    @FXML private GroupPolicyButton         groupPolicyBtn;
    @FXML private TitledPane                navOptionsPane;
    @FXML private NavigationOptionsPane     navOptionsPaneController;

    protected TemplateTreeItem<T>           treeItem;
    protected TreeView                      treeView;
    protected NavTarget                     navTarget;

    private VBox root;

    public VBox getRoot() { return root; }

    public NavTargetAttributes() {
        navTarget  = new NavTarget() {
            @Override
            public boolean isDynamicTarget() {
                return false;
            }
        };
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        basePageSpecItem.setOnAction( pgSpecHandler );
        try {
            waitForXpathDataTargetStringToAppearProperty = FXMLUtils.bindField( waitForXpathDataTargetStringToAppearText, navTarget, "waitForXPathDataTargetStringToAppear" );
            currentPageAsEnclosedPageProperty = FXMLUtils.bindField( currentPageAsEnclosedPageCheck, navTarget, "currentPageAsEnclosedPage" );
            /*TODO
            conditionalNavigationProperty = new SimpleStringProperty();
            conditionalNavigationText.textProperty().bindBidirectional( conditionalNavigationProperty );*/
            groupPolicyBtn.setEventFilter( groupPolicyFilter );
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        groupPolicyBtn.setTreeView( treeView );
    }

    @Override
    public void setTemplateItem( TemplateTreeItem item ) throws HiTException {

        this.treeItem = item;
        navTarget = (NavTarget)item.getValue();

        FXMLUtils.rebindField(waitForXpathDataTargetStringToAppearText, waitForXpathDataTargetStringToAppearProperty, navTarget, "waitForXPathDataTargetStringToAppear");
        FXMLUtils.rebindField(currentPageAsEnclosedPageCheck, currentPageAsEnclosedPageProperty, navTarget, "currentPageAsEnclosedPage");
        //TODO ConditionalNavigation object needs to be created from source string
        //FXMLUtils.bindField(conditionalNavigationText, navTarget, "condition");

        //initialize groupPolicy button with current values.
        //NavTargetAttributes.groupPolicyFilter will set a new object if null when button is clicked
        groupPolicyBtn.setParentTreeItem( treeItem );
        groupPolicyBtn.setGroupPolicy( navTarget.getGroupPolicy() );
        groupPolicyBtn.setTemplateTreeItem( treeItem.getChildItem( navTarget.getGroupPolicy() ));

        navOptionsPaneController.setNavigationOptions( navTarget.getNavigationOptions() );
    }

    EventHandler groupPolicyFilter = event -> {
        if( navTarget.getGroupPolicy() == null ) {
            navTarget.setGroupPolicy( new GroupPolicy() );
        }
        groupPolicyBtn.setGroupPolicy( navTarget.getGroupPolicy() );
    };

    EventHandler pgSpecHandler =  event -> {

        TemplateTreeItem pgSpecItem = null;
        if( (treeItem.getValue() instanceof NavTarget)
                && (((NavTarget)treeItem.getValue()).getTargetPageSpec() == null) ) {
            //create PageSpec
            PageSpec pgSpec = null;
            try {
                pgSpec = (PageSpec)Class.forName(((TemplateMenuItem)event.getSource()).getRepresentsClassName()).newInstance();
                ((NavTarget)treeItem.getValue()).setTargetPageSpec(pgSpec);
                pgSpecItem = new TemplateTreeItem<>( pgSpec );
                treeItem.getChildren().add(pgSpecItem);
                treeView.getSelectionModel().select(pgSpecItem);
            } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            for( TemplateTreeItem item : treeItem.getChildren() ) {
                if (item.getValue() instanceof PageSpec) {
                    pgSpecItem = item;
                    break;
                }
            }
            treeView.getSelectionModel().select(pgSpecItem);
        }
    };
}
