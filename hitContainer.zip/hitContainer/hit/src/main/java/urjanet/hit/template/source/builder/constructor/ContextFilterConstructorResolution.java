package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.coordinate.CoordinateTargetDefinition.Direction;
import urjanet.pull.web.pdf.context.TargetContext.TargetContextDirection;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.filter.DirectionFilter;
import urjanet.pull.web.pdf.filter.HorizontalFilter;
import urjanet.pull.web.pdf.filter.PreviousFilter;
import urjanet.pull.web.pdf.filter.RangeFilter;
import urjanet.pull.web.pdf.filter.VerticalFilter;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.ContextKey;

public class ContextFilterConstructorResolution {

	public static List<Object> resolveConstructorParameters( ContextFilter object) throws UnresolvedConstructorException {
		
		if( object instanceof VerticalFilter)
			return resolveConstructorParameters( (VerticalFilter) object );
		else if( object instanceof HorizontalFilter)
			return resolveConstructorParameters( (HorizontalFilter) object );
		else if( object instanceof DirectionFilter)
			return resolveConstructorParameters( (DirectionFilter) object );
		else if( object instanceof RangeFilter)
			return resolveConstructorParameters( (RangeFilter) object );
		else if( object instanceof PreviousFilter)
			return resolveConstructorParameters( (PreviousFilter) object );
		
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( VerticalFilter verticalFilter ) {
		
		ContextKey filter = verticalFilter.getStartKey();
		double leftBuffer = verticalFilter.getLeftBuffer();
		double rightBuffer = verticalFilter.getRightBuffer();
		boolean forward = verticalFilter.isForward();
		
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, filter );
		
		if ( leftBuffer != 0.0 ){
			properties.add(leftBuffer);
			properties.add(rightBuffer);
		} else if ( rightBuffer != 0.0 ){
			properties.add(rightBuffer);
		}
		
		if ( !forward )
			properties.add(forward);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( HorizontalFilter filter ) {
		
		ContextKey startKey = filter.getStartKey();
		double topBuffer = filter.getTopBuffer();
		double bottomBuffer = filter.getBottomBuffer();
		double offset = filter.getOffset();
		boolean forward = filter.isForward();
		
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, startKey );
		
		if ( topBuffer != 0.0 ){
			properties.add(topBuffer);
			properties.add(bottomBuffer);
		} else if ( bottomBuffer != 0.0 ){
			properties.add(bottomBuffer);
		}
		if ( offset != 0.0 ){
			properties.add(offset);
		}
		
		if ( forward )
			properties.add(forward);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( DirectionFilter directionFilter ) {
		
		ContextKey filter = directionFilter.getKey();
		Direction direction = directionFilter.getDirection();
		TargetFormat targetFormat = directionFilter.getTargetFormat();
		double maxDistance = directionFilter.getMaxDistance();
		
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, filter, direction );
		
		if(!(targetFormat instanceof SingleWordTargetFormat))
			properties.add(targetFormat);
			
		if ( maxDistance != 0.0 )
			properties.add(maxDistance);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( RangeFilter rangeFilter ) {
		
		ContextKey startKey = rangeFilter.getStartKey();
		ContextKey endKey = rangeFilter.getEndKey();
		
		
		List<Object> properties = new ArrayList<Object>();
		properties.add(startKey);
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, endKey );
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( PreviousFilter previousFilter ) {
		
		int depth = previousFilter.getDepthOfPreviousContexts();
		TargetContextDirection targetContextDirection = previousFilter.getTargetContextDirection();
		
		
		List<Object> properties = new ArrayList<Object>();
		properties.add(depth);
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, targetContextDirection );
		
		return properties;
	}

}
