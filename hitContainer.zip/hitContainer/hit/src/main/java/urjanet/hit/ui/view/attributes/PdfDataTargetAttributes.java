package urjanet.hit.ui.view.attributes;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextFilters.ContextFilterAttributes;
import urjanet.pull.web.pdf.PdfDataTarget;

public class PdfDataTargetAttributes extends BaseTemplateAttributes<T> {

	private static final String resourcePath = "/PdfDataTargetAttributes.fxml";
	
	@FXML protected Pane dataTargetPane;
	@FXML protected Pane filtersPane;
	
	private PdfDataTarget pdfdatatarget;
	private DataTargetAttributes dataTargetAttributes;
	private ContextFilterAttributes contextFilterAttr;
	
	public PdfDataTargetAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(DataTargetAttributes.resourcePath);
		dataTargetPane.getChildren().add(loader.getRoot());
		dataTargetAttributes = loader.getController();
		
		FXMLLoader loaderFilters = new FXMLUtils().loader(ContextFilterAttributes.resourcePath);
		
		filtersPane.getChildren().add(loaderFilters.getRoot());
		contextFilterAttr = loaderFilters.getController();
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
		
		
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        dataTargetAttributes.setTreeView(treeView);
        contextFilterAttr.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
		dataTargetAttributes.setTemplateItem(treeItem);
        Object Obj = item.getValue();
        if(! (Obj instanceof PdfDataTarget))
            throw new HiTException("Could not create Form for PdfDataTarget due to incompatible node. Received " + Obj.getClass());
        
        this.pdfdatatarget = (PdfDataTarget) Obj;

        contextFilterAttr.setTemplateItem(treeItem);
        
	}
	
	@Override
    protected void onHide() {
		
		dataTargetAttributes.onHide();
    }
}
