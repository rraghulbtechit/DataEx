package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.TypeTracker;
import urjanet.keys.InputKeys;
import urjanet.pull.web.InputElement;
import urjanet.pull.web.VariableInputElement;

public final class InputElementBuilder  implements TemplateItemBuilder {

	private static final InputElementBuilder theInstance = new InputElementBuilder();
	
	public static InputElementBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private InputElementBuilder() {}
	
	
	@Override
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, final Object object, final TypeTracker typeTracker) {

		return new ClassInstantiation( typeDeclaration, methodDeclaration, object, typeTracker ).instantiate();
	}
	
	@Override
	public Expression createClassInstance(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker) {
		
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();

	}

	public static void main( String[] args ) {

		AST ast = AST.newAST( AST.JLS3 );
		CompilationUnit cu = ast.newCompilationUnit();
		TypeTracker typeTracker = new TypeTracker( cu );
		
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  "Sample" );
		cu.types().add(typeDeclaration);
		
		MethodDeclaration methodDeclaration = null;
		methodDeclaration = JavaElementBuilder.createMethodDeclaration(ast, "Test");
		
		InputElement username = new VariableInputElement("//input[contains(@name,'UserName')]", InputKeys.LOGIN_ID.getValue());
		InputElement password = new VariableInputElement("//input[contains(@name,'Password')]", InputKeys.LOGIN_PASS.getValue());
		List<InputElement> loginInputElements = Arrays.asList(username, password);
		
		System.out.println( new InputElementBuilder().createTemplateItem( typeDeclaration, methodDeclaration, loginInputElements, typeTracker ) );
		System.out.println( typeDeclaration );
	}

}
