package urjanet.hit;

public class HiTException extends Exception
{

    private static final long serialVersionUID = 1997753363232807009L;

		public HiTException()
		{
		}

		public HiTException(String message)
		{
			super(message);
		}

		public HiTException(Throwable cause)
		{
			super(cause);
		}

		public HiTException(String message, Throwable cause)
		{
			super(message, cause);
		}

		public HiTException(String message, Throwable cause, 
                                           boolean enableSuppression, boolean writableStackTrace)
		{
			super(message, cause, enableSuppression, writableStackTrace);
		}

}
