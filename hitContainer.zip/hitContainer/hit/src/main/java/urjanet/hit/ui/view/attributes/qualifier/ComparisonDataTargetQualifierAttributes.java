package urjanet.hit.ui.view.attributes.qualifier;

import java.net.URL;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.ComparisonDataTargetQualifier;
import urjanet.pull.bool.ComparisonDataTargetQualifier.ComparisonOperator;
import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.DataTarget;

public class ComparisonDataTargetQualifierAttributes implements Initializable, TemplateAttributesPane {

	public static final String resourcePath = "/ComparisonDataTargetQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane;
	
	@FXML ComboBox comparisonOpCombo;
	@FXML protected TemplateButton dataTargetsBtn;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private ComparisonDataTargetQualifier comparisonDataTargetQualifier;
	protected TreeView<T>  treeView;
	protected TemplateTreeItem<T> treeItem;
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof BaseDataTargetQualifier))
            throw new HiTException("Could not create Form for BaseDataTargetQualifier due to incompatible node. Received " + Obj.getClass());
        
        this.comparisonDataTargetQualifier = (ComparisonDataTargetQualifier) Obj;
        
        for(MenuItem itemDataTarget : dataTargetsBtn.getItems()) {
            itemDataTarget.setOnAction( dataTargetHandler );
        }
        
        baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
        
		comparisonOpCombo.getItems().addAll(ComparisonOperator.values());
		
        FXMLUtils.unbindAll(this);
        //bind
        try {
            FXMLUtils.bindField(comparisonOpCombo, comparisonDataTargetQualifier, "comparisonOperator");
        } catch( Exception e ) {
            e.printStackTrace();
        }
	}
	
	private EventHandler dataTargetHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTarget newTarget = ((DataTarget)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor

            this.treeItem.getChildren().clear();
            
            if(comparisonDataTargetQualifier.getQualifyingTarget1() == null) {
            	comparisonDataTargetQualifier.setQualifyingTarget1(newTarget);
            } else {
            	comparisonDataTargetQualifier.setQualifyingTarget2(newTarget);
            }
            
            dataTargetItem = new TemplateTreeItem( newTarget );
            addSelectNode(dataTargetItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
    
    private void addSelectNode(TemplateTreeItem templateTreeItem) {
        treeItem.getChildren().add(templateTreeItem);
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
	}	
}