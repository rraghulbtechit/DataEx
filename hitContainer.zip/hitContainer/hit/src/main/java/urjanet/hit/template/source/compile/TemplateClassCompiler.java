package urjanet.hit.template.source.compile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.config.RuntimeConfiguration;
import urjanet.config.RuntimeConfiguration.RuntimeFeature;
import urjanet.hit.HiTException;
import urjanet.hit.template.source.TemplateSource;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;
import urjanet.think.update.development.DevelopmentUpdateRunner;
import urjanet.think.update.development.DevelopmentUpdateRunnerOptions;

/**
 * Compiles Java source preserving Parameter names
 *
 */
public class TemplateClassCompiler {

    private static final Logger log = LoggerFactory.getLogger(TemplateClassCompiler.class);
    
    public static Class compile(TemplateSource source) {

        return Javac.compile( source.getSourceCode() );
    }

    protected static Class compile(String javaSource) {

        return Javac.compile( javaSource );
    }

    /**
     * Compiles PullJobTemplate and related template classes to preserve parameter names.
     * Dropped this in favor of packaging relevant classes with the tool
     *
     * @Deprecated
     */
    public static void compileWithParams() {
        //Start with a root source and compile all contained classes


    }
    
    /**
     * uses {@link DevelopmentUpdateRunner} to run template
     * @param templateId
     * @param sourceDirectory
     * @return
     */
    public static String runTemplate( String templateId, String sourceDirectory ){
        
        File temporaryLogFile = null;
        
        final PrintStream actualOutputStream = System.out;
        
        try {
            temporaryLogFile = urjanet.hit.utils.FileUtils.getTemporaryLogFile();
            temporaryLogFile.deleteOnExit();
            
            log.info( "Redirecting System output to file " + temporaryLogFile + " ..." );
            
            System.setOut( new PrintStream(new BufferedOutputStream(new FileOutputStream( 
                temporaryLogFile))));
        } catch( IOException e ) {
            e.printStackTrace();
        }
        
        String credential = "a=e";
        String arguments[] = {
            "-t", templateId,
            "-c", credential,
            "-d", sourceDirectory
        };
        
        RuntimeConfiguration.get().toggleFeature(RuntimeFeature.NO_SOURCE_STORAGE, true);
        
        DevelopmentUpdateRunnerOptions options = new DevelopmentUpdateRunnerOptions(arguments);
        
        DevelopmentUpdateRunner.runTemplate( templateId, options.getInputMaps(), options.getExtractionChannelId(), options.getPullServiceOptions());
        
        String consoleLog = null;
        try {
            consoleLog = FileUtils.readFileToString( temporaryLogFile );
        } catch( IOException e ) {
            e.printStackTrace();
        }
        
        String woot = consoleLog.substring(consoleLog.indexOf("[woot]"), consoleLog.indexOf("[/woot]") + 6 );
        
        log.info( "Redirecting Sytem output back to System.out" );
        System.setOut( actualOutputStream );
        return woot;
    }
}
