package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.XmlTargetGroup;

public class TargetGroupConstructorResolution {

	public static List<Object> resolveConstructorParameters( XmlTargetGroup xmlTargetGroup ) {
		
		String baseXPath = xmlTargetGroup.getBaseXPath();
		GroupPolicy groupPolicy = xmlTargetGroup.getGroupPolicy();
		
		Object dataTargets = null, navTargets;
		dataTargets = xmlTargetGroup.getDataTargets();
		navTargets = xmlTargetGroup.getNavTargets();
		
		if ( dataTargets == null && navTargets != null )
			navTargets = ((List)navTargets).toArray( new NavTarget[ ((List)navTargets).size()]);
		
		if ( navTargets == null && dataTargets != null)
			dataTargets = ((List)dataTargets).toArray( new DataTarget[ ((List)dataTargets).size()]);
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll( properties, baseXPath, groupPolicy, dataTargets, navTargets );
	
		return properties;
	}

}
