package urjanet.hit.ast.compare;

import java.util.List;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Statement;

import urjanet.hit.template.compare.UnsupportedComparisonException;


public class StatementCompare {

	public static List<Expression> compare( Statement statement1, Statement statement2 ) throws UnsupportedComparisonException{

		if( statement1 instanceof ReturnStatement )
			return compare( (ReturnStatement) statement1, (ReturnStatement) statement2 );
		
		throw new UnsupportedComparisonException( "Could not compare type " + statement1.getClass() + " and " + statement1.getClass() );
		
	}
	
	public static List<Expression> compare( ReturnStatement returnStatement1, ReturnStatement returnStatement2 ) throws UnsupportedComparisonException{
		
		Expression expression1 = returnStatement1.getExpression();
		Expression expression2 = returnStatement2.getExpression();
		
		
		return ExpressionCompare.compare( expression1, expression2);
	}
}
