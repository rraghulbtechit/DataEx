package urjanet.hit.ui.view.attributes;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.ConditionalPageSpec;
import urjanet.pull.web.DataTargetPageCondition;
import urjanet.pull.web.XmlDataTarget;

public class ConditionalPageSpecAttributes extends BaseTemplateAttributes {

	private static final String resourcePath = "/ConditionalPageSpecAttributes.fxml";

	@FXML private CheckBox 			enforceExtractionHandlerCheck;
	@FXML private TemplateMenuItem	xmlDataTargetItem;
	@FXML private TemplateMenuItem	expandableDataTargetItem;
	@FXML private TemplateButton	truePageSpecBtn;
	@FXML private TemplateMenuItem 	trueBasePageSpecItem;
	@FXML private TemplateMenuItem 	trueConditionalPageSpecItem;
	@FXML private TemplateButton	falsePageSpecBtn;
	@FXML private TemplateMenuItem 	falseBasePageSpecItem;
	@FXML private TemplateMenuItem 	falseConditionalPageSpecItem;
	@FXML private TemplateButton	targetPageSpecBtn;
	@FXML private TemplateMenuItem 	targetBasePageSpecItem;
	@FXML private TemplateMenuItem 	targetConditionalPageSpecItem;

	private TemplateTreeItem<XmlDataTarget> dataTargetItem = null;
	private TemplateTreeItem<PageSpec> 		trueSpecItem = null;
	private TemplateTreeItem<PageSpec> 		falseSpecItem = null;
	private TemplateTreeItem<PageSpec> 		targetSpecItem = null;

	private BooleanProperty 				dataTargetNotPresentProperty;
	private ConditionalPageSpec				conditionalPageSpec;

	public ConditionalPageSpecAttributes(TemplateTreeItem treeItem, TreeView treeView) {
		try {
			if( load(resourcePath) ) {
				initControls();
				setTreeView( treeView );
				setTemplateItem(treeItem);
			}
		} catch (HiTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initializes the required child objects and tree
	 */
	private void initControls() throws HiTException {

		//button handlers
		xmlDataTargetItem.setOnAction( dataTargetHandler );
		expandableDataTargetItem.setOnAction( dataTargetHandler );

		trueBasePageSpecItem.setOnAction( trueSpecHandler );
		trueConditionalPageSpecItem.setOnAction( trueSpecHandler );
		falseBasePageSpecItem.setOnAction( falseSpecHandler );
		falseConditionalPageSpecItem.setOnAction( falseSpecHandler );
		targetBasePageSpecItem.setOnAction( targetSpecHandler );
		targetConditionalPageSpecItem.setOnAction( targetSpecHandler );

		//binding properties
		dataTargetNotPresentProperty = new SimpleBooleanProperty( true );
		truePageSpecBtn.disableProperty().bind( dataTargetNotPresentProperty );
		falsePageSpecBtn.disableProperty().bindBidirectional( dataTargetNotPresentProperty );
		targetPageSpecBtn.disableProperty().bindBidirectional( dataTargetNotPresentProperty );
	}

	EventHandler dataTargetHandler = event -> {
		try {
			String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
			Class theDataTargetClazz = Class.forName(targetClassName);
			XmlDataTarget targetRequirement = ((DataTargetPageCondition)conditionalPageSpec.getPageCondition()).getDataTargetRequirement();

			if( targetRequirement == null || ! (targetRequirement.getClass().equals( theDataTargetClazz ))) {
				targetRequirement = (XmlDataTarget) theDataTargetClazz.newInstance();
				conditionalPageSpec.setPageCondition(
						new DataTargetPageCondition(targetRequirement,
								((DataTargetPageCondition) conditionalPageSpec.getPageCondition()).isEnforceExtractionHandler()));

				if( ! targetRequirement.getClass().equals( theDataTargetClazz ))
					;//TODO Alert if existing object is of a different type than selected

				dataTargetItem.setValue( targetRequirement );
			}

			selectNode( dataTargetItem );
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	};

	EventHandler trueSpecHandler = event -> {
		try {
			String targetClassName = ((TemplateMenuItem) event.getSource()).getRepresentsClassName();
			Class specClazz = Class.forName(targetClassName);
			PageSpec trueSpec = conditionalPageSpec.getConditionTrueSpec();

			if (trueSpec == null || !(trueSpec.getClass().equals( specClazz ))) {
				//TODO Alert if existing object is of a different type than selected
				trueSpec = (PageSpec) specClazz.newInstance();
				conditionalPageSpec.setConditionTrueSpec( trueSpec );
				trueSpecItem.setValue( trueSpec );
			}

			selectNode( trueSpecItem );
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	};

	EventHandler falseSpecHandler = event -> {
		try {
			String targetClassName = ((TemplateMenuItem) event.getSource()).getRepresentsClassName();
			Class specClazz = Class.forName(targetClassName);
			PageSpec falseSpec = conditionalPageSpec.getConditionFalseSpec();

			if (falseSpec == null || !(falseSpec.getClass().equals( specClazz ))) {
				//TODO Alert if existing object is of a different type than selected
				falseSpec = (PageSpec) specClazz.newInstance();
				conditionalPageSpec.setConditionFalseSpec( falseSpec );
				falseSpecItem.setValue( falseSpec );
			}

			selectNode( falseSpecItem );
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	};

	EventHandler targetSpecHandler = event -> {
		try {
			String targetClassName = ((TemplateMenuItem) event.getSource()).getRepresentsClassName();
			Class specClazz = Class.forName(targetClassName);
			PageSpec targetSpec = conditionalPageSpec.getTargetSpec();

			if (targetSpec == null || !(targetSpec.getClass().equals( specClazz ))) {
				//TODO Alert if existing object is of a different type than selected
				targetSpec = (PageSpec) specClazz.newInstance();
				conditionalPageSpec.setTargetSpec( targetSpec );
				targetSpecItem.setValue( targetSpec );
			}

			selectNode( targetSpecItem );
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	};

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {

		if( item == null ) {
			throw new HiTException("Could not create Form for ConditionalPageSpec. No object received." );
		} else if( !(item.getValue() instanceof ConditionalPageSpec)) {
			throw new HiTException("Could not create Form for ConditionalPageSpec due to incompatible node. Received " + treeItem.getValue().getClass());
		}
		FXMLUtils.unbindAll( this );

		this.treeItem = item;
		conditionalPageSpec = (ConditionalPageSpec) item.getValue();

		if( conditionalPageSpec.getPageCondition() == null )
			conditionalPageSpec.setPageCondition( new DataTargetPageCondition() );
		dataTargetNotPresentProperty.setValue( false );

		FXMLUtils.bindField(enforceExtractionHandlerCheck, conditionalPageSpec.getPageCondition(), "enforceExtractionHandler");
			dataTargetNotPresentProperty.setValue(conditionalPageSpec.getPageCondition() == null
					|| ((DataTargetPageCondition) conditionalPageSpec.getPageCondition()).getDataTargetRequirement() == null);

		setPageSpecItems();
	}

	/**
	 * Assign PageSpec items in this order true -> false -> target
	 * //TODO add if required. This assumes the child items are already created
	 */
	private void setPageSpecItems() {
		if( dataTargetItem == null) {
			dataTargetItem = new TemplateTreeItem<>( ((DataTargetPageCondition)conditionalPageSpec.getPageCondition()).getDataTargetRequirement() );
			addChildNode( dataTargetItem );
		} else {
			dataTargetItem.setValue(((DataTargetPageCondition) conditionalPageSpec.getPageCondition()).getDataTargetRequirement());
		}

		if (trueSpecItem == null) {
			trueSpecItem = new TemplateTreeItem<>(conditionalPageSpec.getConditionTrueSpec());
			addChildNode( trueSpecItem, dataTargetItem );
		} else {
			trueSpecItem.setValue( conditionalPageSpec.getConditionTrueSpec() );
		}
		if (falseSpecItem == null) {
			falseSpecItem = new TemplateTreeItem<>(conditionalPageSpec.getConditionFalseSpec());
			addChildNode( falseSpecItem, trueSpecItem );
		} else {
			falseSpecItem.setValue( conditionalPageSpec.getConditionFalseSpec() );
		}
		if (targetSpecItem == null) {
			targetSpecItem = new TemplateTreeItem<>(conditionalPageSpec.getTargetSpec());
			addChildNode(targetSpecItem, falseSpecItem );
		} else {
			targetSpecItem.setValue( conditionalPageSpec.getTargetSpec() );
		}
	}

	//TODO add delete Handler
}
