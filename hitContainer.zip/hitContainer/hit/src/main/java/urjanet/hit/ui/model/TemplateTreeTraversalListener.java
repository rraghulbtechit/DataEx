package urjanet.hit.ui.model;

import javafx.scene.control.TreeItem;
import urjanet.pull.clean.validate.TemplateTraversal;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy.GroupAction;
import urjanet.pull.web.NavTarget;

/**
 *
 * @author rburson
 */
public interface TemplateTreeTraversalListener {


	public void beginTraversal(TreeItem treeItem);

	public void fireGroupEncountered(String newGroupName, GroupAction groupAction, TreeItem source);

//	public void fireGroupPopped(String groupName, TreeItem source);

	public void firePageSpecEncountered(TreeItem pageSpecTreeItem, TemplateTreeTraversalListener tl);

	public void fireTargetGroupEncountered(TreeItem targetGroupTreeItem, TemplateTreeTraversalListener tl);

	public void fireNavTargetEncountered(TreeItem navTargetTreeItem, TemplateTreeTraversalListener tl);

	public void fireDataTargetEncountered(TreeItem dataTargetTreeItem, TemplateTreeTraversalListener tl);

	public void endTraversal(TreeItem treeItem);

}
