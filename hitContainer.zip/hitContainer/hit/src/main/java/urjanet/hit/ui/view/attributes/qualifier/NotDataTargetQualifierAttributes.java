package urjanet.hit.ui.view.attributes.qualifier;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.NotDataTargetQualifier;
import urjanet.pull.web.DataTargetQualifier;

public class NotDataTargetQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/NotDataTargetQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane; 
	
	@FXML protected TemplateButton dataTargetQualifierBtn;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private NotDataTargetQualifier notDataTargetQualifier;
	
	public NotDataTargetQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		notDataTargetQualifier = ((NotDataTargetQualifier)item.getValue());
		
		for(MenuItem menuItem : dataTargetQualifierBtn.getItems()) {
			menuItem.setOnAction( dataTargetQualifierHandler );
        }
		
	}
	
	private EventHandler dataTargetQualifierHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetQualifierItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTargetQualifier newTargetQualifier = ((DataTargetQualifier)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor
            
            notDataTargetQualifier.setTarget(newTargetQualifier);
            this.treeItem.getChildren().clear();
            dataTargetQualifierItem = new TemplateTreeItem( newTargetQualifier );
            addSelectNode(dataTargetQualifierItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
}