package urjanet.hit.template.source.refactor;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.JavaElementBuilder;

@Deprecated
public class AddSuperInterfaceToTypeDeclaration extends RefactorSideEffect{

	List<Type> interfaces = new ArrayList<Type>();
	
	@Override
	public void apply(TypeDeclaration typeDeclaration, BodyDeclaration bodyDeclaration) {

		typeDeclaration.superInterfaceTypes().addAll(interfaces);
		bodyDeclaration.modifiers().add( JavaElementBuilder.createMarkerAnnotation(typeDeclaration.getAST(), "Override"));
	}
	
	public void addSuperInterface( Type superInterfaceType){
		
		interfaces.add( superInterfaceType );
	}

	@Override
	public String toString() {

		return "AddSuperInterfaceToTypeDeclaration [interfaces=" + interfaces + "]";
	}
	
	

}
