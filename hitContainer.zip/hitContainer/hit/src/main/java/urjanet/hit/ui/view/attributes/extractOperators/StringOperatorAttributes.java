package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.StringOperator;
import urjanet.pull.operator.StringOperator.StringOperation;

public class StringOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/StringOperatorAttributes.fxml";
	
	@FXML private TextField valueText;
	private Property valueTextProperty;
	@FXML private ComboBox<StringOperation> stringOperationCombo;
	private Property stringOperationComboProperty;
	
	private StringOperator stringOperator;
	
	public StringOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
            stringOperationCombo.getItems().addAll(StringOperation.values());
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof StringOperator))
            throw new HiTException("Could not create Form for StringOperator due to incompatible node. Received " + Obj.getClass());
        
        this.stringOperator = (StringOperator) Obj;
        
        if( valueTextProperty != null ) FXMLUtils.unbindField( valueText, valueTextProperty );
		valueTextProperty = FXMLUtils.bindField(valueText, stringOperator, "value");
		
		if( stringOperationComboProperty != null ) FXMLUtils.unbindField( stringOperationCombo, stringOperationComboProperty );
		stringOperationComboProperty = FXMLUtils.bindField(stringOperationCombo, stringOperator, "operation");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}