package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.MathOperator;
import urjanet.pull.operator.MathOperator.MathOperation;

public class MathOperatorAttributes extends BaseTemplateAttributes<T> {
	
	public static final String resourcePath = "/MathOperatorAttributes.fxml";

	@FXML private TextField numberText;
	private Property numberTextProperty;
	@FXML private ComboBox<MathOperation> mathOperationCombo;
	private Property mathOperationComboProperty;
	
	private MathOperator mathOperator;
	
	public MathOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
            mathOperationCombo.getItems().addAll(MathOperation.values());
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof MathOperator))
            throw new HiTException("Could not create Form for MathOperator due to incompatible node. Received " + Obj.getClass());
        
        this.mathOperator = (MathOperator) Obj;
        
        if( numberTextProperty != null ) FXMLUtils.unbindField( numberText, numberTextProperty );
		numberTextProperty = FXMLUtils.bindField(numberText, mathOperator, "number");
		
		if( mathOperationComboProperty != null ) FXMLUtils.unbindField( mathOperationCombo, mathOperationComboProperty );
		mathOperationComboProperty = FXMLUtils.bindField(mathOperationCombo, mathOperator, "operation");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}
