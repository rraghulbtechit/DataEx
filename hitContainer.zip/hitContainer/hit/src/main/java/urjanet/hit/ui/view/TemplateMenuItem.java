package urjanet.hit.ui.view;

import javafx.scene.control.MenuItem;

/**
 *
 */
public class TemplateMenuItem extends MenuItem {

    private String representsClassName;

    public TemplateMenuItem() {}

    public TemplateMenuItem( String representsClassName, String text ) {
        this.representsClassName = representsClassName;
        this.setText( text );
    }

    public String getRepresentsClassName() {
        return representsClassName;
    }

    public void setRepresentsClassName(String representsClassName) {
        this.representsClassName = representsClassName;
    }


}
