package urjanet.hit.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import urjanet.clean.validation.ValidationException;
import urjanet.pull.clean.validate.TemplateTraversal;
import urjanet.pull.clean.validate.TemplateTraversalListener;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy.GroupAction;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.WebPullJobTemplate;

public class TemplateUtils {

	public static PageSpec getPdfPageSpec( WebPullJobTemplate wpjt){
		
		TemplateTraversalListenerImpl templateListener = new TemplateTraversalListenerImpl();
		try {
			new TemplateTraversal().traverse(wpjt, templateListener);
		} catch( Exception e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return templateListener.getPdfPageSpec();
		
	}

    /**
     * 
     * @return true, if the template tree item is a dataTarget and it takes key value pair.
     * false, if the template tree item is a dataTarget with GroupPolicy or a dataTarget with relative dataTargets.
     */
    public static boolean isKeyDataTarget( DataTarget dataTarget ) {

    	if ( dataTarget instanceof PdfDataTarget ){
    		if( !( 															// not 
    			( dataTarget).getGroupPolicy() != null || 			// containing groupPolicy or   
    			( dataTarget).getRelativeDataTargets() != null )) 	// relativeDataTargets
    		return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreeItem is a dataTarget with groupPolicy
     */
    public static boolean isGroupDataTarget( DataTarget dataTarget ) {

    	if ( dataTarget instanceof DataTarget ){
    		if ( dataTarget.getGroupPolicy() != null ) 
    			return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreeItem is dataTarget with baseFilter and some collection of other datatargets
     */
    public static boolean isContainerDataTarget( DataTarget dataTarget ) {

    	if ( dataTarget instanceof DataTarget ){
    		if ( /*((PdfDataTarget) item).getGroupPolicy() == null ||*/
    			( dataTarget).getRelativeDataTargets() != null )
    			return true;
    	}
    	
		return false;
	}

    
	public static Map<String, List> getSimilarGroups( WebPullJobTemplate wpjt ) {
	
		
		
		
		TemplateTraversalListenerImpl templateListener = new TemplateTraversalListenerImpl();
		try {
			new TemplateTraversal().traverse(wpjt, templateListener);
		} catch( Exception e ) {
			e.printStackTrace();
		}
		
		return templateListener.getSimilarGroups() ;
	
	}

	public static class TemplateTraversalListenerImpl implements TemplateTraversalListener {
		
		public PageSpec pdfPageSpec; 
		Map<String, List> similarGroups = new HashMap<String, List>();
		
		@Override
		public void fireTargetGroupEncountered(TargetGroup targetGroup, TemplateTraversal tl) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void firePageSpecEncountered(PageSpec pageSpec, TemplateTraversal tl) {
			
			if ( ContentType.PDF.equals(pageSpec.getExpectedContentType()))
				pdfPageSpec = pageSpec;
		}
		
		@Override
		public void fireNavTargetEncountered(NavTarget navTarget, TemplateTraversal tl) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void fireGroupPushed(String newGroupName, GroupAction groupAction, String formerGroupName, Object source) {

			List previousList =  similarGroups.get( newGroupName );
			
			if( previousList != null )
				previousList.add( source );
			else 
				similarGroups.put( newGroupName, new ArrayList<>(Arrays.asList( source  )) );
		}
		
		@Override
		public void fireGroupPopped(String groupName, Object source) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void fireDataTargetEncountered(DataTarget dataTarget, TemplateTraversal tl) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void endTraversal(PullJobTemplate pjt) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void beginTraversal(PullJobTemplate pjt) {
			
			
			// TODO Auto-generated method stub
			
		}
		
		
		public PageSpec getPdfPageSpec() {

			return pdfPageSpec;
		}
		
		public Map<String, List> getSimilarGroups() {

			return similarGroups;
		}
	}
}
