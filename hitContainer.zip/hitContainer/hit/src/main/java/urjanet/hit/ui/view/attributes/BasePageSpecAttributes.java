package urjanet.hit.ui.view.attributes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.controlsfx.control.spreadsheet.*;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.utils.StringOperations;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ContentType;

import java.util.*;

/**
 * Attributes of WebPullJobTemplates that will be shown in a form
 */
public class BasePageSpecAttributes<T> extends BaseTemplateAttributes {

    private static final String resourcePath = "/BasePageSpecAttributes.fxml";

    private static final int MAX_CONFIG_OPTS = 8;

    @FXML private ComboBox<ContentType>     contentTypeCb;
    @FXML private SpreadsheetView           gridViewSS;
    @FXML private TemplateMenuItem          xmlTargetGroup;
    @FXML private TemplateMenuItem          textTargetGroup;

    private BasePageSpec basePageSpec;

    public BasePageSpecAttributes(TemplateTreeItem<T> treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem item, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        this.setFitToWidth( true );
        gridViewSS.setMinWidth( this.getWidth() );
        contentTypeCb.getItems().setAll(ContentType.values());

        initConfigOptions();
        setTemplateItem(item);

        xmlTargetGroup.setOnAction(targetGroupEvtHandler);
        textTargetGroup.setOnAction(targetGroupEvtHandler);
    }

    private void initConfigOptions() {

        ObservableList<SpreadsheetColumn> columns = gridViewSS.getColumns();
        columns.forEach( col -> col.setPrefWidth( 180 )); //TODO (gridViewSS.getWidth() - 50)/columns.size() doesn't work as getWidth()=0
    }

    @Override
    public void setTemplateItem( TemplateTreeItem item ) throws HiTException {

        if(item == null)
            throw new HiTException( "Could not create Form. No object present in tree item." );
        else if( ! (item.getValue() instanceof BasePageSpec) )
            throw new HiTException("Could not create Form for BasePageSpec due to incompatible node. Received " + item.getValue().getClass());

        this.treeItem = item;
        BasePageSpec pageSpec = (BasePageSpec)item.getValue();
        setBasePageSpec(pageSpec);
        setContentType();
        setConfigOptions();
    }

    @Override
    protected void onHide() {

        saveContentType();
        saveConfigOptions();
    }

    public void setBasePageSpec(BasePageSpec basePageSpec) {

        this.basePageSpec = basePageSpec;
    }

    protected void setContentType() {

        contentTypeCb.setValue( basePageSpec.getExpectedContentType() );
    }

    protected void saveContentType() {
        basePageSpec.setExpectedContentType( contentTypeCb.getValue() );
    }

    //See http://stackoverflow.com/questions/16941980/populate-tableview-with-observablemap-javafx/21339428#21339428
    protected void setConfigOptions() {

        ObservableList<Map.Entry> entries = FXCollections.observableList(getOptions());
        int numRows = entries.size() > MAX_CONFIG_OPTS ? entries.size() : MAX_CONFIG_OPTS;

        GridBase grid = new GridBase(numRows, 2);
        ObservableList<ObservableList<SpreadsheetCell>> rows = FXCollections.observableArrayList();
        for( int row = 0; row < grid.getRowCount(); ++row ) {
            final ObservableList<SpreadsheetCell> list = FXCollections.observableArrayList();
            String key = "";
            String value = "";
            if( entries.size() > row ) {
                key = entries.get(row).getKey().toString();
                value = entries.get(row).getValue().toString();
            }
            SpreadsheetCell cell = SpreadsheetCellType.STRING.createCell(row, 0, 1, 1, key);
            //cell.setEditable( entries.size() > row ); //exiting keys aren't editable as there is code behind it
            list.add( cell );
            cell = SpreadsheetCellType.STRING.createCell(row, 1, 1, 1, value);
            //cell.setEditable( entries.size() > row );
            list.add( cell );
            rows.add(list);
        }
        grid.setRows(rows);

        gridViewSS.setGrid( grid );
    }

    /**
     * Add a ConfigOption, delete corresponding option if the row is blank, or set value for an existing option
     */
    private void saveConfigOptions() {

        List<Map.Entry> entries = getOptions();

        Grid grid = gridViewSS.getGrid();
        ObservableList<ObservableList<SpreadsheetCell>> rows = grid.getRows();
        for (int row = 0; row < grid.getRowCount(); row++) {
            ObservableList<SpreadsheetCell> aRow = rows.get(row);
            SpreadsheetCell key = aRow.get(0);
            SpreadsheetCell value = aRow.get(1);
            if( !key.getText().isEmpty() && !value.getText().isEmpty() ) {
                //if values is changed, should update corresponding value
                /*TODO if( key.getText().equals(entries.get(row).getKey().toString()) ) {
                    if( !(value.getText().equals(entries.get(row).getValue().toString())) )
                        basePageSpec.getConfigOptions().put(key, value);
                }*/

                //TODO if row is deleted, remove corresponding entry
                //if row is added, wrap with $() for both key and value
                if( row >= entries.size() ) {
                    addOption(StringOperations.toScriptlet( key.getText() ), StringOperations.toScriptlet( value.getText() ));
                }
            }
        }
    }

    private List<Map.Entry> getOptions() {
        Map<String, Object> configOptions
                = basePageSpec.getConfigOptions() != null
                ? basePageSpec.getConfigOptions().getOptions()
                : new HashMap<String, Object>();

        return new ArrayList<Map.Entry>( configOptions.entrySet() );
    }

    /**
     * Adds new config options. Creates ConfigOption if required
     */
    private void addOption( String key, String value ) {
        if( basePageSpec.getConfigOptions() == null )
            basePageSpec.setConfigOptions( new ConfigOptions() );

        basePageSpec.getConfigOptions().addOption(key, value);
    }

    EventHandler targetGroupEvtHandler = event -> {

        TemplateTreeItem<TargetGroup> targetGroupItem = null;
        try {
            String tgClass = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            TargetGroup tg = (TargetGroup)Class.forName(tgClass).newInstance();
            List<? extends TargetGroup> pgTargetGroups = basePageSpec.getTargetGroups();
            List<TargetGroup> targetGroups;
            if( pgTargetGroups == null ) {
                targetGroups = new ArrayList<>();
            } else {
                targetGroups = new ArrayList<>( pgTargetGroups );
            }

            targetGroups.add( tg );
            basePageSpec.setTargetGroups( targetGroups );
            targetGroupItem = new TemplateTreeItem<>(tg);
            addSelectNode(targetGroupItem);
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
}