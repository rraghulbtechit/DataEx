package urjanet.hit.ui.view.attributes;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.pull.web.coordinate.CoordinateKey;

public class CoordinateKeyAttributes implements Initializable {

    public static final String resourcePath = "CoordinateKeyAttributes.fxml";

    @FXML protected TextField       keyText;
    protected Property              keyProperty;
    @FXML protected ComboBox        keyStructureCb;
    protected Property              keyStructureProperty;
    @FXML protected ComboBox        includePatternCb;
    protected Property              includePatternProperty;
    @FXML protected ComboBox        searchPatternCb;
    protected Property              searchPatternProperty;
    @FXML protected ComboBox        separationPatternCb;
    protected Property              separationPatternProperty;
    @FXML protected TextField       lineNumberText;
    protected Property              lineNumberProperty;
    @FXML protected TextField       wordNumberText;
    protected Property              wordNumberProperty;

    private CoordinateKey           theKey = new CoordinateKey("key");

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        keyStructureCb.getItems().addAll( CoordinateKey.KeyStructure.values() );
        includePatternCb.getItems().addAll( CoordinateKey.KeyIncludePattern.values() );
        searchPatternCb.getItems().addAll( CoordinateKey.KeySearchPattern.values() );
        separationPatternCb.getItems().addAll( CoordinateKey.KeySeperationPattern.values() );

        try {
            keyProperty = FXMLUtils.bindField( keyText, theKey, "key" );
            keyStructureProperty = FXMLUtils.bindField( keyStructureCb, theKey, "keyStructure" );
            includePatternProperty = FXMLUtils.bindField( includePatternCb, theKey, "includePattern" );
            searchPatternProperty = FXMLUtils.bindField( searchPatternCb, theKey, "searchPattern" );
            separationPatternProperty = FXMLUtils.bindField( separationPatternCb, theKey, "seperationPattern" );
            lineNumberProperty = FXMLUtils.bindField( lineNumberText, theKey, "lineNumber" );
            wordNumberProperty = FXMLUtils.bindField( wordNumberText, theKey, "wordNumber" );
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    public void setKey( CoordinateKey key ) throws HiTException {

        theKey = key;

        keyProperty = FXMLUtils.rebindField( keyText, keyProperty, theKey, "key" );
        keyStructureProperty = FXMLUtils.rebindField( keyStructureCb, keyStructureProperty, theKey, "keyStructure" );
        includePatternProperty = FXMLUtils.rebindField( includePatternCb, includePatternProperty, theKey, "includePattern" );
        searchPatternProperty = FXMLUtils.rebindField( searchPatternCb, searchPatternProperty, theKey, "searchPattern" );
        separationPatternProperty = FXMLUtils.rebindField( separationPatternCb, separationPatternProperty, theKey, "seperationPattern" );
        lineNumberProperty = FXMLUtils.rebindField( lineNumberText, lineNumberProperty, theKey, "lineNumber" );
        wordNumberProperty = FXMLUtils.rebindField( wordNumberText, wordNumberProperty, theKey, "wordNumber" );
    }

    public CoordinateKey getKey() {

        return theKey;
    }
}
