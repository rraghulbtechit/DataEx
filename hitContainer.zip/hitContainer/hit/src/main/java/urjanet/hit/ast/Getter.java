package urjanet.hit.ast;

import org.apache.commons.lang.WordUtils;

public class Getter extends BeanMethod{

	private static String beanType = "get";
	
	public Getter( String property ) {
	
		super( beanType + WordUtils.capitalize( property ));
	}
}
