package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.hit.utils.DomainKeyUtils;
import urjanet.keys.DomainKeys;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.ExpandablePdfPageDataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfPageDataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.key.ContextKey;

public class DataTargetConstructorResolution {

	public static List<Object> resolveConstructorParameters( DataTarget dataTarget ) throws UnresolvedConstructorException{
		
		if( dataTarget instanceof ExpandablePdfPageDataTarget )
			return resolveConstructorParameters( (ExpandablePdfPageDataTarget) dataTarget );
		else if( dataTarget instanceof ExpandablePdfDataTarget )
			return resolveConstructorParameters( (ExpandablePdfDataTarget) dataTarget );
		else if( dataTarget instanceof PdfPageDataTarget )
			return resolveConstructorParameters( (PdfPageDataTarget) dataTarget );
		else if( dataTarget instanceof PdfDataTarget )
			return resolveConstructorParameters( (PdfDataTarget) dataTarget );
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + dataTarget.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( PdfPageDataTarget pdfPageDataTarget ) {
		
		int startPage = pdfPageDataTarget.getStartPage();
		int endPage = pdfPageDataTarget.getEndPage();
		GroupPolicy groupPolicy = pdfPageDataTarget.getGroupPolicy();
		String name = pdfPageDataTarget.getName();
		List<? extends DataTarget> relativeDataTargets = pdfPageDataTarget.getRelativeDataTargets();
		
		List<Object> properties = new ArrayList<Object>();
		
		if ( startPage == endPage && startPage != 0 )
			properties.add( startPage );
		else if ( startPage != 0 )
			properties.add( startPage );
		else if ( endPage != 0 )
			properties.add( endPage );
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, groupPolicy, name, relativeDataTargets );
		
			
		return properties;
	}

	public static List<Object> resolveConstructorParameters( PdfDataTarget pdfDataTarget ) {
		
		Object filter = null;
		List<? extends ContextFilter> filters = pdfDataTarget.getFilters();
		if ( filters != null && filters.size() == 1 )
			filter = filters.get(0);
		else 
			filter = filters;
		
		GroupPolicy groupPolicy = pdfDataTarget.getGroupPolicy();
		String key = pdfDataTarget.getName();
	
		DomainKeys domainkeys = null;
		if ( key != null )
			domainkeys = DomainKeyUtils.getInstance().getEnumConstantForString( key );
	
		List<? extends DataTarget> relativeDataTargets = pdfDataTarget.getRelativeDataTargets();
		
		List<Object> properties = new ArrayList<Object>();
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, filter, groupPolicy, domainkeys, relativeDataTargets );
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( ExpandablePdfPageDataTarget pdfPageDataTarget ) {
		
		int startPage = pdfPageDataTarget.getStartPage();
		int endPage = pdfPageDataTarget.getEndPage();
		GroupPolicy groupPolicy = pdfPageDataTarget.getGroupPolicy();
		String name = pdfPageDataTarget.getName();
		List<? extends DataTarget> relativeDataTargets = pdfPageDataTarget.getRelativeDataTargets();
		
		List<Object> properties = new ArrayList<Object>();
		
		if ( startPage == endPage && startPage != 0 )
			properties.add( startPage );
		else if ( startPage != 0 )
			properties.add( startPage );
		else if ( endPage != 0 )
			properties.add( endPage );
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, groupPolicy, name, relativeDataTargets );
		
			
		return properties;
	}

	public static List<Object> resolveConstructorParameters( ExpandablePdfDataTarget dataTarget ) {
		
		ContextKey expandableKey = dataTarget.getExpandableKey();
		List<? extends ContextFilter> filters = dataTarget.getFilters();
		GroupPolicy groupPolicy = dataTarget.getGroupPolicy();
		List<? extends DataTarget> relativeDataTargets = dataTarget.getRelativeDataTargets();
		
		List<Object> properties = new ArrayList<Object>();
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, expandableKey, filters, groupPolicy, relativeDataTargets );
		
		return properties;
	}

}
