package urjanet.hit.ui.view.attributes.contextKeys;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.TargetContextAttributes;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.PhraseTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.ContextKey;
import urjanet.pull.web.pdf.key.ContextKey.KeyIncludeBehavior;

public class ContextKeyAttributes implements Initializable, TemplateAttributesPane {

	public static final String resourcePath = "/ContextKeyAttributes.fxml";
	
	@FXML protected Pane targetContextPane;
	@FXML protected ComboBox includeBehaviorCombo;
	protected Property includeBehaviorProperty;
	@FXML protected ComboBox keyFormatCb;
	protected Property keyFormatProperty;
	@FXML protected TextField occuranceOfKeyTf;
	protected Property occuranceOfKeyProperty;
	
	private TargetContextAttributes targetContextAttributes;
	private ContextKey contextKey;
	public enum KeyFormat {LINE, PHRASE, SINGLEWORD};
	private TemplateTreeItem treeItem;
    private TreeView treeView;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		FXMLLoader loader = new FXMLUtils().loader(TargetContextAttributes.resourcePath);
		
		targetContextPane.getChildren().add(loader.getRoot());
		targetContextAttributes = loader.getController();
		
		includeBehaviorCombo.getItems().add(KeyIncludeBehavior.values());
		keyFormatCb.getItems().add(KeyFormat.values());
		
		keyFormatCb.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue ov, Object t, Object t1) {
            	if(t1 == KeyFormat.LINE)
            		contextKey.setKeyFormat(new LineTargetFormat());
            	else if(t1 == KeyFormat.PHRASE)
            		contextKey.setKeyFormat(new PhraseTargetFormat());
            	else if(t1 == KeyFormat.SINGLEWORD)
            		contextKey.setKeyFormat(new SingleWordTargetFormat());
            }
        });
	}
	
	private void setContextKey(ContextKey contextKey) {
		
		this.contextKey = contextKey;
        
        try {
        	//bind
        	if( includeBehaviorProperty != null ) FXMLUtils.unbindField( includeBehaviorCombo, includeBehaviorProperty );
        	includeBehaviorProperty = FXMLUtils.bindField(includeBehaviorCombo, contextKey, "includeBehavior");
        	
        	if( occuranceOfKeyProperty != null ) FXMLUtils.unbindField( occuranceOfKeyTf, occuranceOfKeyProperty );
        	occuranceOfKeyProperty = FXMLUtils.bindField(occuranceOfKeyTf, contextKey, "occuranceOfKey");
        	
        	TargetFormat keyFormat = contextKey.getKeyFormat();
        	if(keyFormat instanceof LineTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.LINE);
        	else if(keyFormat instanceof PhraseTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.PHRASE);
        	else if(keyFormat instanceof SingleWordTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.SINGLEWORD);
        	
        } catch(Exception ex) {
        	ex.printStackTrace();
        }
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {

		this.treeItem = item;

		targetContextAttributes.setTemplateItem(item);
		Object obj = item.getValue();
		if(obj != null)
			setContextKey((ContextKey) obj);
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
		targetContextAttributes.setTreeView(treeView);
	}

}
