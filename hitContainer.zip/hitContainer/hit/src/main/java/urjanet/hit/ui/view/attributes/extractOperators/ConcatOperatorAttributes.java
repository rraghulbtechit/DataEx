package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.ConcatOperator;

public class ConcatOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/ConcatOperatorAttributes.fxml";
	
	private ExtractOperatorAttributes extractOpAttr;
	@FXML private TextField delimiterText;
	@FXML Pane extractOperatorPane;
	private Property delimiterTextProperty;
	
	private ConcatOperator concatOperator ;
	
	public ConcatOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
		FXMLLoader loader = new FXMLUtils().loader(ExtractOperatorAttributes.resourcePath);
		
		extractOperatorPane.getChildren().add(loader.getRoot());
		extractOpAttr = loader.getController();
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof ConcatOperator))
            throw new HiTException("Could not create Form for ConcatOperator due to incompatible node. Received " + Obj.getClass());
        
        this.concatOperator = (ConcatOperator) Obj;
        
        if( delimiterTextProperty != null ) FXMLUtils.unbindField( delimiterText, delimiterTextProperty );
        delimiterTextProperty = FXMLUtils.bindField(delimiterText, concatOperator, "delimiter");

        extractOpAttr.setTemplateItem(treeItem);
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        extractOpAttr.setTreeView(treeView);
	}

}