package urjanet.hit.template.source.builder.constructor;

import java.util.List;

import urjanet.pull.web.DataTarget;

public class ListConstructorResolution {

	public static List<? extends DataTarget> resolveConstructorParameters( List objects ) {
	
		return objects;
	}

}
