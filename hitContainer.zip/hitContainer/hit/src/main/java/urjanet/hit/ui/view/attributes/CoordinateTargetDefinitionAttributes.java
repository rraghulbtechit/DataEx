package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.pull.web.coordinate.CoordinateKey;
import urjanet.pull.web.coordinate.CoordinateTargetDefinition;

import java.net.URL;
import java.util.ResourceBundle;

public class CoordinateTargetDefinitionAttributes implements Initializable {

    public static final String resourcePath = "/CoordinateTargetDefinitionAttributes.fxml";

    @FXML protected ComboBox        formattingCb;
    protected Property              formattingProperty;
    @FXML protected ComboBox        directionCb;
    protected Property              directionProperty;
    @FXML protected TextField       maxDistanceText;
    protected Property              maxDistanceProperty;
    @FXML protected TextField       regExQualifierText;
    protected Property              regExQualifierProperty;
    @FXML protected TextField       regExOutputApplicatorText;
    protected Property              regExOutputApplicatorProperty;
    @FXML protected VBox            searchKeyVBox;
    @FXML protected VBox            endKeyVBox;
    @FXML protected CoordinateKeyAttributes searchKeyVBoxController;
    @FXML protected CoordinateKeyAttributes endKeyVBoxController;

    private CoordinateTargetDefinition  coordinateTargetDefinition;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        formattingCb.getItems().addAll( CoordinateTargetDefinition.Formatting.values() );
        directionCb.getItems().addAll( CoordinateTargetDefinition.Direction.values() );

        try {
            formattingProperty = FXMLUtils.bindField( formattingCb, coordinateTargetDefinition, "formatting" );
            directionProperty = FXMLUtils.bindField( directionCb, coordinateTargetDefinition, "direction" );
            maxDistanceProperty = FXMLUtils.bindField( maxDistanceText, coordinateTargetDefinition, "maxDistance" );
            regExQualifierProperty = FXMLUtils.bindField( regExQualifierText, coordinateTargetDefinition, "regExQualifier" );
            regExOutputApplicatorProperty = FXMLUtils.bindField( regExOutputApplicatorText, coordinateTargetDefinition, "regExOutputApplicator" );
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    public void setCoordinateTargetDefinition( CoordinateTargetDefinition definition ) throws HiTException {

        this.coordinateTargetDefinition = definition;
        formattingProperty = FXMLUtils.rebindField( formattingCb, formattingProperty, coordinateTargetDefinition, "formatting" );
        directionProperty = FXMLUtils.rebindField( directionCb, directionProperty, coordinateTargetDefinition, "direction" );
        maxDistanceProperty = FXMLUtils.rebindField( maxDistanceText, maxDistanceProperty, coordinateTargetDefinition, "maxDistance" );
        regExQualifierProperty = FXMLUtils.rebindField( regExQualifierText, regExQualifierProperty, coordinateTargetDefinition, "regExQualifier" );
        regExOutputApplicatorProperty = FXMLUtils.rebindField( regExOutputApplicatorText, regExOutputApplicatorProperty, coordinateTargetDefinition, "regExOutputApplicator" );

        searchKeyVBoxController.setKey( definition.getSearchKey() == null ? new CoordinateKey("") : definition.getSearchKey() );
        endKeyVBoxController.setKey( definition.getEndKey() == null ? new CoordinateKey("") : definition.getEndKey() );
    }

    public CoordinateTargetDefinition getCoordinateTargetDefinition() {

        return coordinateTargetDefinition;
    }
}
