package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.HiTException;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.MethodDeclarationAndInvocation;
import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.template.content.PdfPageSpecProvider;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ContentType;

public class PageSpecBuilder implements TemplateItemBuilder {

	private static final PageSpecBuilder theInstance = new PageSpecBuilder();
	
	public static PageSpecBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private PageSpecBuilder() {}
	
	@Override
	public Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) {
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
		
	}
	
	@Override
	public Expression createTemplateItem( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) {
	
		if( ((BasePageSpec)object).getExpectedContentType().equals( ContentType.PDF ))

			return new MethodDeclarationAndInvocation( typeDeclaration, methodDeclaration, object, typeTracker)
				.setSuperInterfaces( Arrays.asList( PdfPageSpecProvider.class  ) )
				.setModifiers( Arrays.asList( 
						JavaElementBuilder.createOverrideMarker( typeDeclaration.getAST() ),
						JavaElementBuilder.createPublicModifier( typeDeclaration.getAST() )) )
				.setMethodName( "getPdfPageSpec" )
				.declareAndReturnInvocation();
		else 
			return new ClassInstantiation( typeDeclaration, methodDeclaration, object, typeTracker ).instantiate();
				
	}

}
