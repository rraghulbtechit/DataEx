package urjanet.hit.template.source;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.template.source.compile.TemplateClassCompiler;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.service.PullServiceOptions;
import urjanet.pull.service.PullServiceOptions.ServiceOption;
import urjanet.pull.web.WebPullJobTemplate;


public class TemplateBuilderTest {

	private static final String BILLS_DIRECTORY = "/opt/template_builder_test";

	public static void test(String args[]) throws Exception {
		
		File folder = new File(BILLS_DIRECTORY);
		for (final File fileEntry : folder.listFiles()) {
			if (!fileEntry.isDirectory()) {
				
				String templateId = FilenameUtils.getBaseName( fileEntry.getName() );
				
				File billDirectory = urjanet.hit.utils.FileUtils.getTemporaryBillStoreDirectory();
				FileUtils.copyFileToDirectory( fileEntry, billDirectory );
				
				recreateTemplateAndCompile( templateId );
			}
		}
	}

	public static void main( String[] args ) {
		
		System.out.println( recreateTemplateFromExisting( "TownAndCountryDisposalCOTemplateProvider" ).getSourceCode() );
	}
	private static void recreateTemplateAndCompile( String templateId ){
		
		TemplateSource generatedTemplateSource = recreateTemplateFromExisting( templateId );
		
		createTemplateFileInTemplateWorkspace( generatedTemplateSource );
		TemplateClassCompiler.compile( generatedTemplateSource );
		
	}
	private static void wootCompareTest( String templateId, File billDirectory ) {

		runTemplate( templateId, billDirectory );
		recreateTemplateAndRun( templateId, billDirectory );
	}

	private static String runTemplate( String templateId, File billDirectory ){
	
		PullServiceOptions pullServiceOptions = new PullServiceOptions();
		pullServiceOptions.setServiceOption( ServiceOption.USE_DIRECTORY_AS_SOURCE, billDirectory );
		
		return TemplateClassCompiler.runTemplate( templateId, billDirectory.getAbsolutePath() );
	}
	
	private static TemplateSource recreateTemplateFromExisting( String templateId ){
		
		PullJobTemplate actualTemplate = null;
		try {
			actualTemplate = PlatformAccessor.getTemplate( templateId );
		} catch( HiTException e ) {
			e.printStackTrace();
		}
		
		TemplateBuilder templateBuilder = new TemplateBuilder();
		TemplateSource generatedTemplateSource = templateBuilder.generateTemplate( templateId, ( WebPullJobTemplate )actualTemplate );
		
		return generatedTemplateSource;
		
	}
	
	private static String recreateTemplateAndRun( String templateId, File billDirectory ){
		
		recreateTemplateAndCompile( templateId );
		
		return runTemplate( templateId, billDirectory );
	}
	
	private static void createTemplateFileInTemplateWorkspace( TemplateSource generatedTemplateSource ) {

		String templateWorkspaceDirectoryPath = "/opt/platform2/pull/templateworkspace/src/main/java/urjanet/pull/template";
		
		File template = new File( templateWorkspaceDirectoryPath, generatedTemplateSource.getTemplateName() + ".java" );
		
		try {
			FileUtils.writeStringToFile( template, generatedTemplateSource.getSourceCode() );
		} catch( IOException e ) {
			e.printStackTrace();
		}
	}
}
