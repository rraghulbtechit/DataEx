package urjanet.hit.ui.view.attributes;

import javafx.scene.Node;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.tree.TemplateTreeItem;

/**
 * A Pane to display the template node's attributes. There will be one attribute pane for a type. Setting a new node
 * value would bind to the new object.
 */
public interface TemplateAttributesPane<T> {

    void setTemplateItem(TemplateTreeItem<T> item) throws HiTException;

    void setTreeView( TreeView treeView );

    /**
     * Delete the associated treeItem, the value object and null the parent's reference to the value object
     */
    default void delete() {}

    /**
     * A string representation of the node
     *
     * @return
     */
    default String getString() {
        return "";
    }

    /**
     * The graphic to display the node
     *
     * @return
     */
    default Node getGraphic() {
        return null;
    }

    /**
     * Gets the currently associated template object to this pane. A short cut to treeItem.getValue()
     * @return
     */
    default T getTemplateObject() {
        return null;
    }

    /**
     * Creates child treeItems for the currently associated treeItem
     */
    default void addChildren() {

    }

    /**
     * Called when the form is removed from view
     */
    default void onUnload() {

    }

    /**
     * Whether the object represented by this template node is in a valid state
     *
     * @return
     */
    default boolean isValid() {
        return false;
    }
}
