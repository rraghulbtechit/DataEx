package urjanet.hit.ast;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;

import urjanet.hit.utils.DefaultValue;
import urjanet.pull.web.DataTarget;

public class InlineMethodGeneration {

	public static List<Method> generate( Object object, List<String> inlineSetterProperties ){
		
		List<Method> inLineSetters = new ArrayList<Method>();
		Map<String, Object> properties = null;
		try {
			properties = PropertyUtils.describe( object );
		} catch( IllegalAccessException | InvocationTargetException | NoSuchMethodException e1 ) {
			e1.printStackTrace();
		}

		for( String key : inlineSetterProperties ) {
			
			Object value = properties.get( key );
			
			if( value != null && !( DefaultValue.doesContainDefaultValue( value )) )
				inLineSetters.add( new Setter( key, value ) );
		}
		
		return inLineSetters;
	}
}
