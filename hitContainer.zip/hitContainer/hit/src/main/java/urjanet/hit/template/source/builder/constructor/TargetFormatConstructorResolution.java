package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.PhraseTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;

public class TargetFormatConstructorResolution {

	public static List<Object> resolveConstructorParameters( TargetFormat object) throws UnresolvedConstructorException {
		
		if( object instanceof PhraseTargetFormat )
			return TargetFormatConstructorResolution.resolveConstructorParameters( (PhraseTargetFormat) object );
		else if( object instanceof LineTargetFormat )
			return TargetFormatConstructorResolution.resolveConstructorParameters( (LineTargetFormat) object );
		else if( object instanceof SingleWordTargetFormat )
			return TargetFormatConstructorResolution.resolveConstructorParameters( (SingleWordTargetFormat) object );
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( SingleWordTargetFormat singleWordTargetFormat ) {
		
		List<Object> properties = new ArrayList<Object>();
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( LineTargetFormat lineTargetFormat ) {
		
		List<Object> properties = new ArrayList<Object>();
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( PhraseTargetFormat phraseTargetFormat ) {
		
		double spacing = phraseTargetFormat.getSpacing();
	
		List<Object> properties = new ArrayList<Object>();
		
		if ( spacing != phraseTargetFormat.DEFAULT_SPACING)
			properties.add(spacing);
		
		return properties;
	}

}
