package urjanet.hit.template.source;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.PackageDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jface.text.IDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;
import urjanet.hit.template.source.formatter.DefaultTemplateFormatter;
import urjanet.hit.template.source.refactor.TemplateRefactor;
import urjanet.keys.InputKeys;
import urjanet.keys.MetaKeys;
import urjanet.keys.ProviderIds;
import urjanet.keys.ProviderKeys;
import urjanet.pull.conversion.document.DocConverterConfigurationParameters;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.ContentType;
import urjanet.pull.web.ExpandableNavTarget;
import urjanet.pull.web.InputElement;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.PdfExtractionHandlerType;
import urjanet.pull.web.VariableInputElement;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.XmlTargetGroup;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfPageDataTarget;

public class TemplateBuilder {
	
	private static final Logger log = LoggerFactory.getLogger(TemplateBuilder.class);
	
	private static final String TEMPLATES_PACKAGE_NAME = "urjanet.pull.template";
	
	private TypeTracker typeTracker;
	private AST ast;
	private CompilationUnit cu;
	
	public TemplateBuilder() {
		
		ast = AST.newAST( AST.JLS3 );
		cu = ast.newCompilationUnit();
		typeTracker = new TypeTracker( cu );
	}
	
	/**
	 * sets up compilation unit, creates template type and starts building individual template items.
	 * Starts with PullJobPageSpec which then creates all children template items.
	 * 
	 * 
	 * @param templateId
	 * @param wpjt
	 * @return
	 */
	public TemplateSource generateTemplate(  String templateId, WebPullJobTemplate wpjt ) {

		log.info( "Building template " + templateId );
		
		ast = AST.newAST( AST.JLS3 );
		cu = ast.newCompilationUnit();
		typeTracker = new TypeTracker( cu );
		
		// creating TemplateProvider Type and adding to compilation unit
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  templateId );
		cu.types().add(typeDeclaration);
		
		PackageDeclaration packageDeclaration = ast.newPackageDeclaration();
		packageDeclaration.setName( ast.newName( TEMPLATES_PACKAGE_NAME ) );
		cu.setPackage( packageDeclaration );
		
		MethodDeclaration parentMethodDeclaration = null;
		try {
			TemplateItemBuilderFactory.getBuilder( wpjt ).createTemplateItem( typeDeclaration, parentMethodDeclaration, wpjt, typeTracker );
		} catch( HiTException e ) {
			e.printStackTrace();
		}
		
		log.info( "Template build complete. Adding imports" );
		typeTracker.addImports();
		
		String code = cu.toString();

		log.info( "formatting code" );
		IDocument document = DefaultTemplateFormatter.format( code );

		return new TemplateSource( templateId, document.get() );
	}

	/**
	 * 
	 * generating template source code and returning source code as string
	 * @param templateId
	 * @param wpjt
	 * 
	 * @deprecated
	 */
	public String generateTemplate_old( String templateId, WebPullJobTemplate wpjt ) {

		
		
		
		// creating TemplateProvider Type and adding to compilation unit
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  templateId );
		cu.types().add(typeDeclaration);
		
		// creating WebPullJobTemplate object
		ClassInstanceCreation wpjtInstance = (ClassInstanceCreation) TemplateItemBuilderFactory.createTemplateItem_old( typeDeclaration, wpjt, typeTracker );
		
		TemplateRefactor.refactorTemplate(typeDeclaration, wpjtInstance );
		
		typeTracker.addImports();
		
		return cu.toString();
	}
	
	public static void main( String[] args ) {
		
		PdfPageDataTarget rootTarget =new PdfPageDataTarget(
			Arrays.asList(
				new PdfDataTarget( ProviderKeys.PROVIDER_NAME.getValue() ).setDefaultValue( ProviderIds.TownAndCountyDisposalLLC.getLongAlias() ),
				new PdfDataTarget( MetaKeys.PROVIDER_ID.getValue() ).setDefaultValue(ProviderIds.TownAndCountyDisposalLLC.getShortAlias())
		));
		
		ConfigOptions configOpts = new ConfigOptions();
		configOpts.addOption( DocConverterConfigurationParameters.HANDLER_TYPE.getParameterName(), PdfExtractionHandlerType.CONTEXT_HANDLER );
		configOpts.addOption( DocConverterConfigurationParameters.DUPLICATE_SOURCE_CHECK.getParameterName(), true );

		PageSpec pdfBillPageSpec = new BasePageSpec( ContentType.PDF, configOpts, new XmlTargetGroup( rootTarget) );
		ClickableNavTarget billsClick = new ExpandableNavTarget(pdfBillPageSpec, "//a[contains(text(),'view')]");
		
		BasePageSpec historySpec = new BasePageSpec(new XmlTargetGroup(billsClick));
		ClickableNavTarget historyClick = new ClickableNavTarget(historySpec, "//button[contains(text(),'history')]");
		
		BasePageSpec billingSpec = new BasePageSpec(new XmlTargetGroup(historyClick)); 
		ClickableNavTarget billingsClick = new ClickableNavTarget( billingSpec, "//button[contains(text(),'Billings')]" );
		
		BasePageSpec postLoginSpec = new BasePageSpec( new XmlTargetGroup( billingsClick ) ); 
		
		InputElement username = new VariableInputElement( "//input[contains(@name,'UserName')]", InputKeys.LOGIN_ID.getValue() );
		InputElement password = new VariableInputElement( "//input[contains(@name,'Password')]", InputKeys.LOGIN_PASS.getValue() );
		List<InputElement> loginInputElements = Arrays.asList( username, password );
		
		NavTarget loginSubmit = new ClickableNavTarget( postLoginSpec, "//input[contains(@name,'btLogin')]", loginInputElements);		
		
		BasePageSpec loginPageSpec = new BasePageSpec( new XmlTargetGroup( loginSubmit ) );
		

		WebPullJobTemplate wpjt = new WebPullJobTemplate( "google.com", 
				loginPageSpec, "TownAndCountyTemplateProvider", "$LastChangedBy: abc$", "$LastChangedRevision: 123$" );

		
		TemplateSource templateSource = new TemplateBuilder().generateTemplate( "TownAndCountyTemplateProvider", wpjt );
		System.out.println( templateSource.getSourceCode() );
		
	}
}
