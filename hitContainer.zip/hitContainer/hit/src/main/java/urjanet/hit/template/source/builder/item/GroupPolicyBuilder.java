package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.template.source.TypeTracker;

public class GroupPolicyBuilder implements TemplateItemBuilder{
	
	private static final GroupPolicyBuilder theInstance = new GroupPolicyBuilder();
	
	public static GroupPolicyBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private GroupPolicyBuilder() {}

	@Override
	public Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) {
		
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
		
	}

	@Override
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker) {
		
		return createClassInstance(typeDeclaration, methodDeclaration, object, typeTracker);
	}

}
