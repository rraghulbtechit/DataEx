package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.FilterKey;
import urjanet.pull.web.pdf.key.IndexedKey;
import urjanet.pull.web.pdf.key.KeyStructure;
import urjanet.pull.web.pdf.key.MultiStringKey;
import urjanet.pull.web.pdf.key.RectKey;
import urjanet.pull.web.pdf.key.RegExKey;
import urjanet.pull.web.pdf.key.StringKey;
import urjanet.pull.web.pdf.key.VariableStringKey;
import urjanet.pull.web.pdf.key.WordContextKey;

public class ContextKeyConstructorResolution {

	public static List<Object> resolveConstructorParameters( WordContextKey object) throws UnresolvedConstructorException {
		
		if( object instanceof StringKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (StringKey) object );
		else if( object instanceof VariableStringKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (VariableStringKey) object );
		else if( object instanceof MultiStringKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (MultiStringKey) object );
		else if( object instanceof IndexedKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (IndexedKey) object );
		else if( object instanceof FilterKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (FilterKey) object );
		else if( object instanceof RectKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (RectKey) object );
		else if( object instanceof RegExKey )
			return ContextKeyConstructorResolution.resolveConstructorParameters( (RegExKey) object );
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( IndexedKey indexedKey ) {
		
		int lineNumber = indexedKey.getLineNumber();
		int wordNumber = indexedKey.getWordNumber();
		TargetFormat targetFormat = indexedKey.getIndexStrategy();
		
		
		List<Object> properties = new ArrayList<Object>();
		properties.add(lineNumber);
	
		if ( ( wordNumber != 0 ))
			properties.add(wordNumber);
	
		if ( wordNumber == 0 ){
			if ( !(targetFormat instanceof LineTargetFormat))
				properties.add(targetFormat);
		} else {
			if ( !( targetFormat instanceof SingleWordTargetFormat ))
				properties.add(targetFormat);
		}
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( StringKey stringKey ) {
		
		String key = stringKey.getKey();
		KeyStructure keyStructure = stringKey.getStructure();
		int occurence = stringKey.getOccuranceOfKey();
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, key, keyStructure );
		
		if ( occurence != 0 ){
			properties.add(occurence);
		}
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( VariableStringKey variableStringKey) {
		
		List<? extends ContextFilter> filters = variableStringKey.getFilters();
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, filters.toArray(new ContextFilter[filters.size()]));
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( MultiStringKey multiStringKey) {
		
		List<String> keys = multiStringKey.getKeys();
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, keys.toArray(new String[keys.size()]));
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( FilterKey filterKey) {
		
		List<? extends ContextFilter> keys = filterKey.getFilters();
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, keys.toArray(new ContextFilter[keys.size()]));
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( RectKey rectKey ) {
		
		double x = rectKey.getX();
		double y = rectKey.getX();
		double width = rectKey.getX();
		double height = rectKey.getX();
		
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, x, y, width, height);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( RegExKey regExKey ) {
		
		String key = regExKey.getKey();
		int occurenceOfKey = regExKey.getOccuranceOfKey();
		
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, key);
		if ( occurenceOfKey != 0 )
			properties.add(occurenceOfKey);
		
		return properties;
	}

}
