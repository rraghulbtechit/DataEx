package urjanet.hit.ast;


import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.template.source.builder.item.TemplateItemBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;

public class MethodInvocationWrapper {

	private static final Logger log = LoggerFactory.getLogger(MethodInvocationWrapper.class);
	
	private String methodName;
	private Expression expression;
	private List<Object> parameters;
	
	private TypeDeclaration typeDeclaration;
	private MethodDeclaration methodDeclaration;
	private TypeTracker typeTracker;
	private AST ast;
	
	public MethodInvocationWrapper( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration,
		TypeTracker typeTracker ) {

		this.typeDeclaration = typeDeclaration;
		this.methodDeclaration = methodDeclaration;
		this.typeTracker = typeTracker;
		this.ast = typeDeclaration.getAST();
	}
	
	public MethodInvocationWrapper setMethodName( String methodName ) {

		this.methodName = methodName;
		return this;
	}
	
	public MethodInvocationWrapper setExpression( Expression expression ) {

		this.expression = expression;
		return this;
	}
	
	public MethodInvocationWrapper setParameters( List<Object> parameters ) {

		this.parameters = parameters;
		return this;
	}
	
	public MethodInvocation invoke(){
		
		List<Expression> parameterExpression = new ArrayList<Expression>();
		if ( parameters != null )
			for( Object parameter : parameters ) {
				log.info( parameter + "->" + parameter );
				try {
					TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( parameter );
//					log.info( "creating " + parameter );
					
					log.info( "builder for " + parameter + " in " + templateItemBuilder );
					parameterExpression.add( templateItemBuilder.createTemplateItem( typeDeclaration, methodDeclaration, parameter, typeTracker ) );
				} catch( HiTException e ) {
					e.printStackTrace();
				}
			}
//		log.info( parameterExpression );
		return JavaElementBuilder.createMethodInvocation(ast, expression, methodName, parameterExpression);
	}
	
}
