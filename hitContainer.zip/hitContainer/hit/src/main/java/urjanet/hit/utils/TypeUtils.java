package urjanet.hit.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.Type;


public class TypeUtils {

	private static final Set<Class<?>> WRAPPER_TYPES = getWrapperTypes();

	//  UnmodifiableCollection is package-private and it's not possible to check at compile time
	private static Class UNMODIFIABLE_LIST_CLASS = Collections.unmodifiableList( new ArrayList() ).getClass();
	
	//  Array.asList() returns an "Arrays$ArrayList" (ie an inner class of the Arrays class) rather than a java.util.ArrayList.
	private static Class ARRAYS_ARRAYLIST_CLASS = Arrays.asList().getClass();
	
	public static boolean isWrapperType(Class<?> clazz) {
		return WRAPPER_TYPES.contains(clazz);
	}

	private static Set<Class<?>> getWrapperTypes() {
		Set<Class<?>> ret = new HashSet<Class<?>>();
		ret.add(Boolean.class);
		ret.add(Character.class);
		ret.add(Byte.class);
		ret.add(Short.class);
		ret.add(Integer.class);
		ret.add(Long.class);
		ret.add(Float.class);
		ret.add(Double.class);
		ret.add(Void.class);
		return ret;
	}
	
	/**
	 * 
	 * @param type
	 * @param clazz
	 * @return
	 */
	public static boolean isEquivalentType( SimpleType type, Class clazz ){

		return type.getName().toString().equals(clazz.getSimpleName());
	}

	public static Class getConcreteType(Class anInterface) {
		if(List.class.isAssignableFrom(anInterface))
			return ArrayList.class;

		return anInterface;
	}

	public static boolean isBasicType( Object object ) {
	
		if( object instanceof String
			||	isWrapperType(object.getClass()) 
			||	object instanceof Enum<?> )
			return true;
		
		return false;
	}

	public static boolean isList( Object object ) {
		
		if ( object instanceof List )
			return true;
		else if ( isUnmodifiableList( object ) )
			return true;
		return false;
	}

	private static boolean isUnmodifiableList( Object object ) {

		if ( object.getClass().equals( UNMODIFIABLE_LIST_CLASS ))
			return true;
		else if ( object.getClass().equals( ARRAYS_ARRAYLIST_CLASS ))
			return true;
		else 
			return false;
	}
	

	public static <E> List<E> arrayToList(E... args ){
		
		return new ArrayList<E>( Arrays.asList( args  ) );
	}
	
	public static boolean isSameType( Object object1, Object object2 ){
		
		return object1.getClass().equals( object2.getClass() );
	}
	
	public static boolean isSameType( Type returnType1, Type returnType2 ) {

		if( returnType1 instanceof SimpleType )
			return isSameType( (SimpleType)returnType1, (SimpleType)returnType2 );

		return false;
	}

	private static boolean isSameType( SimpleType type1, SimpleType type2 ) {

		return type1.getName().toString().equals( type2.getName().toString() );
	}
}
