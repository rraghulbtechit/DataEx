package urjanet.hit.ui.view.attributes;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.JavaScriptNavTarget;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by shankerj on 6/27/2016.
 */
public class JavaScriptNavTargetAttributes<T>  implements Initializable, TemplateAttributesPane {

    static final String resourcePath = "/JavaScriptNavTargetAttributes.fxml";

    @FXML public TextArea                       javaScriptText;
    @FXML public VBox                           clickableNavTargetAttributesVBox;
    @FXML public ClickableNavTargetAttributes   clickableNavTargetAttributesVBoxController;

    protected TemplateTreeItem<T> treeItem;
    protected TreeView<T>                   treeView;

    public JavaScriptNavTargetAttributes( ) {
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        JavaScriptNavTarget javaScriptNavTarget = (JavaScriptNavTarget) item.getValue();

        FXMLUtils.unbindAll( this );
        FXMLUtils.bindField( javaScriptText, javaScriptNavTarget, "script" );

        clickableNavTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        clickableNavTargetAttributesVBoxController.setTreeView( treeView );
    }
}
