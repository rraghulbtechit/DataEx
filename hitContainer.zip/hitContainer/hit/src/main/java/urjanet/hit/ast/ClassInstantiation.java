package urjanet.hit.ast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.template.source.builder.constructor.ConstructorResolutionFactory;
import urjanet.hit.template.source.builder.item.BasicTypeBuilder;
import urjanet.hit.template.source.builder.item.PullJobTemplateBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;
import urjanet.hit.utils.TypeUtils;
import urjanet.pull.web.WebPullJobTemplate;

public class ClassInstantiation {

	private static final Logger log = LoggerFactory.getLogger(ClassInstantiation.class);

	private Object templateObject;
	private List<?> parameters;
	
	private TypeDeclaration typeDeclaration;
	private MethodDeclaration methodDeclaration;
	private TypeTracker typeTracker;
	private AST ast;
	
	private List<Method> inlineMethodChain = new ArrayList<Method>();
	
	private Map<String, Object> propertyMap = new HashMap<String, Object>();
	
	
	public ClassInstantiation( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object templateObject, TypeTracker typeTracker) {

		this.typeDeclaration = typeDeclaration;
		this.methodDeclaration = methodDeclaration;
		this.templateObject = templateObject;
		this.typeTracker = typeTracker;
		this.ast = typeDeclaration.getAST();
		
	}

	public ClassInstantiation setInlineMethodChain( List<Method> inlineMethodChain ) {

		this.inlineMethodChain = inlineMethodChain;
		return this;
	}
	
	public Expression instantiate() {

		Expression cic = JavaElementBuilder.createClassInstanceCreation( ast, typeTracker.getType(templateObject) );
		parameters = ConstructorResolutionFactory.getConstructorParamater(templateObject);
		
		log.trace( "constructing " + templateObject.getClass() + " of parameter " + parameters); 
		for( Object parameter : parameters ) {
			Expression parameterExpression ;
			
			try {
				TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( parameter );
				parameterExpression = templateItemBuilder.createTemplateItem( typeDeclaration, methodDeclaration, parameter, typeTracker );
				((ClassInstanceCreation)cic).arguments().add( parameterExpression );
				log.trace( templateObject.getClass().getSimpleName() + " being constructed");
			} catch( HiTException e ) {
				log.error( "Error creating parameter " + parameter );
				e.printStackTrace();
			}
		}
		
		log.trace( "constructed " + templateObject.getClass().getSimpleName()  + "  --->   " + cic );
		
		log.trace( "adding inline setters" );
		cic = addInlineMethods( cic );
		
		return cic;
	}

	private Expression addInlineMethods(Expression expression) {

		for( Method method : inlineMethodChain ) {
			
			expression = new MethodInvocationWrapper( typeDeclaration, methodDeclaration, typeTracker)
				.setMethodName( method.getMethodName() )
				.setExpression( expression )
				.setParameters( method.getParameters() )
				.invoke();
		}
		
		return expression;
	}
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		final AST ast = AST.newAST( AST.JLS3 );
		CompilationUnit cu = ast.newCompilationUnit();
		final TypeTracker typeTracker = new TypeTracker( cu );
		
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  "TemplateName" );
		cu.types().add(typeDeclaration);
		
//		try {
////			PullJobTemplateBuilder.createTemplateItem(typeDeclaration, null, (WebPullJobTemplate) PlatformAccessor.getTemplate("TownAndCountryDisposalCOTemplateProvider"), typeTracker);
//		} catch (HiTException e) {
//			e.printStackTrace();
//		}
//		log.info(cu);
	}
	
	
	public MethodDeclaration getMethodDeclaration() {

		return methodDeclaration;
	}
}
