package urjanet.hit.ui.view.attributes;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.utils.ReflectionUtils;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.DataTargetPageCondition;
import urjanet.pull.web.TrackLoginFailurePageSpec;
import urjanet.pull.web.XmlDataTarget;

public class TrackedLoginPageSpecAttributes extends BaseTemplateAttributes {

	private static final String resourcePath = "/TrackedLoginPageSpecAttributes.fxml";

	@FXML private CheckBox 			enforceExtractionHandlerCheck;
	@FXML private TemplateMenuItem	xmlDataTargetItem;
	@FXML private TemplateMenuItem	expandableDataTargetItem;
	@FXML private TemplateButton	pageSpecBtn;
	@FXML private TemplateMenuItem 	basePageSpecItem;
	@FXML private TemplateMenuItem 	conditionalPageSpecItem;

	private BooleanProperty 				dataTargetNotPresentProperty;
	private TrackLoginFailurePageSpec 		trackLoginFailurePageSpec;
	private TemplateTreeItem<XmlDataTarget> dataTargetItem = null;
	private TemplateTreeItem<PageSpec> 		pageSpecItem = null;

	public TrackedLoginPageSpecAttributes(TemplateTreeItem treeItem, TreeView treeView) {
		try {
			if( load(resourcePath) ) {
				initControls();
				this.treeView = treeView;
				setTemplateItem(treeItem);
			}
		} catch (HiTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initializes the required child objects and tree
	 */
	private void initControls() {

		//button handlers
		xmlDataTargetItem.setOnAction( dataTargetHandler );
		expandableDataTargetItem.setOnAction( dataTargetHandler );

		basePageSpecItem.setOnAction( pageSpecHandler );
		conditionalPageSpecItem.setOnAction( pageSpecHandler );

		//binding properties
		dataTargetNotPresentProperty = new SimpleBooleanProperty( true );
		pageSpecBtn.disableProperty().bind( dataTargetNotPresentProperty );

		//PageSpec tree items will be assigned in this order
		if( treeItem != null ) {
			ObservableList<TemplateTreeItem> childItems = treeItem.getChildren();
			for (TemplateTreeItem item : childItems) {
				if (item.getValue() instanceof XmlDataTarget)
					dataTargetItem = item;
				else if (item.getValue() instanceof PageSpec) {
					pageSpecItem = item;
				}
			}
		}
	}

	EventHandler dataTargetHandler = event -> {

		String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
		try {
			if( ((DataTargetPageCondition)trackLoginFailurePageSpec.getPageCondition()).getDataTargetRequirement() == null ) {
				XmlDataTarget targetRequirement = (XmlDataTarget) Class.forName( targetClassName ).newInstance();

				ReflectionUtils.setField( trackLoginFailurePageSpec, "pageCondition",
						new DataTargetPageCondition( targetRequirement,
								((DataTargetPageCondition)trackLoginFailurePageSpec.getPageCondition()).isEnforceExtractionHandler()) );
				dataTargetItem = new TemplateTreeItem<>( targetRequirement );
				addSelectNode( dataTargetItem );
			} else {
				XmlDataTarget targetRequirement = ((DataTargetPageCondition)trackLoginFailurePageSpec.getPageCondition()).getDataTargetRequirement();
				//TODO Alert if existing object is of a different type than selected

				dataTargetItem = getChildItem( treeItem, targetRequirement );

				if( dataTargetItem != null)
					selectNode( dataTargetItem );
				else
					addSelectNode( new TemplateTreeItem<>(targetRequirement) );
			}
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	};

	//TODO Move this block as TemplateTreeItem.getChildItem
	public <T, S> TemplateTreeItem<S> getChildItem( TemplateTreeItem<T> parentItem, S templateObj ) {

		TemplateTreeItem<S> childItem = null;
		ObservableList<TemplateTreeItem> children = parentItem.getChildren();
		for(TemplateTreeItem item: children ) {
			if( templateObj.equals( item.getValue() )) {
				childItem = item;
				break;
			}
		}

		return childItem;
	}

	EventHandler pageSpecHandler = event -> {

		try {

			String targetClassName = ((TemplateMenuItem) event.getSource()).getRepresentsClassName();

			if (trackLoginFailurePageSpec.getPageSpec() == null) {
				ReflectionUtils.setField( trackLoginFailurePageSpec, "pageSpec", (PageSpec) Class.forName(targetClassName).newInstance());
			} else {
				pageSpecItem = getChildItem(treeItem, trackLoginFailurePageSpec.getPageSpec());
			}
			if (pageSpecItem == null) {
				pageSpecItem = new TemplateTreeItem<>(trackLoginFailurePageSpec.getPageSpec());
				addChildNode(pageSpecItem, null);
			}

			selectNode( pageSpecItem );
		}catch(InstantiationException | ClassNotFoundException | IllegalAccessException e){
			e.printStackTrace();
		}
	};


	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		try {
			this.treeItem = item;
			trackLoginFailurePageSpec = (TrackLoginFailurePageSpec) item.getValue();
			dataTargetNotPresentProperty.setValue( false );

			if( trackLoginFailurePageSpec.getPageCondition() == null ) {
				ReflectionUtils.setField( trackLoginFailurePageSpec, "pageCondition", new DataTargetPageCondition() );
			}

			FXMLUtils.unbindAll( this );
			if( trackLoginFailurePageSpec != null && trackLoginFailurePageSpec.getPageCondition() != null ) {
				FXMLUtils.bindField(enforceExtractionHandlerCheck, trackLoginFailurePageSpec.getPageCondition(), "enforceExtractionHandler");
				dataTargetNotPresentProperty.setValue(trackLoginFailurePageSpec.getPageCondition() == null
						|| ((DataTargetPageCondition) trackLoginFailurePageSpec.getPageCondition()).getDataTargetRequirement() == null);
			}

			if( dataTargetItem != null)
				dataTargetItem.setValue( ((DataTargetPageCondition)trackLoginFailurePageSpec.getPageCondition()).getDataTargetRequirement() );
			if( pageSpecItem != null )
				pageSpecItem.setValue( trackLoginFailurePageSpec.getPageSpec() );
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}

	//TODO add delete Handler

}
