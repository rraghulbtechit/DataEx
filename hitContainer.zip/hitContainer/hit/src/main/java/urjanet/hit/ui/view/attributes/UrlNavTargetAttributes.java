package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.UrlNavTarget;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by shankerj on 6/27/2016.
 */
public class UrlNavTargetAttributes<T> implements Initializable, TemplateAttributesPane  {

    static final String resourcePath = "/UrlNavTargetAttributes.fxml";

    @FXML private TextField             urlText;
    private Property                    urlProperty;
    @FXML private VBox                  navTargetAttributesVBox;
    @FXML private NavTargetAttributes   navTargetAttributesVBoxController;

    protected TemplateTreeItem<T>       treeItem;
    protected TreeView<T>               treeView;
    protected UrlNavTarget              urlNavTarget = new UrlNavTarget();

    public UrlNavTargetAttributes(  ) {
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try {
            urlProperty = FXMLUtils.bindField( urlText, urlNavTarget, "url" );
            //TODO needed? navTargetAttributesVBoxController.initialize(location, resources);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        urlNavTarget = (UrlNavTarget) item.getValue();

        urlProperty = FXMLUtils.rebindField( urlText, urlProperty, urlNavTarget, "url" );

        navTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        navTargetAttributesVBoxController.setTreeView( treeView );
    }
}
