package urjanet.hit.ui.view.tree;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.utils.TemplateUtils;
import urjanet.pull.bool.AndDataTargetQualifier;
import urjanet.pull.bool.ComparisonDataTargetQualifier;
import urjanet.pull.bool.NotDataTargetQualifier;
import urjanet.pull.bool.OrDataTargetQualifier;
import urjanet.pull.core.PageSpec;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.operator.ConcatOperator;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.operator.SimpleOperatorChain;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.ConditionalPageSpec;
import urjanet.pull.web.CustomRequestNavTarget;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.ExpandableNavTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.UrlNavTarget;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.XmlDataTarget;
import urjanet.pull.web.XmlDataTargetQualifier;
import urjanet.pull.web.XmlTargetGroup;
import urjanet.pull.web.coordinate.CoordinateDataTargetQualifier;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfDataTargetQualifier;
import urjanet.pull.web.pdf.PdfPageDataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.filter.DirectionFilter;
import urjanet.pull.web.pdf.filter.HorizontalFilter;
import urjanet.pull.web.pdf.filter.RangeFilter;
import urjanet.pull.web.pdf.filter.VerticalFilter;
import urjanet.pull.web.pdf.key.ContextKey;
import urjanet.pull.web.pdf.key.FilterKey;
import urjanet.pull.web.pdf.key.VariableStringKey;
import urjanet.pull.web.reference.GroupReference;
import urjanet.pull.web.text.TextTargetGroup;

/**
 * A TreeItem for Template nodes for TreeView display
 */
public class TemplateTreeItem<T> extends TreeItem {

    private static final Logger log = LoggerFactory.getLogger(TemplateTreeItem.class);

    private boolean isChildrenAssigned = false;

    /** If enabled shows PdfDataTarget downwards */
    private boolean showPdfOnly = false;

    protected TemplateAttributesPane<T> attributesPane;

    /**
     * Gets a child TemplateTreeItem of the input parent that has the input templateObject as its Value
     * @param parentItem
     * @param templateObj
     * @param <T>
     * @param <S>
* @return
*/
    public static <T, S> TemplateTreeItem<S> getChildItem( TemplateTreeItem<T> parentItem, S templateObj ) {

        return parentItem.getChildItem( templateObj );
    }

    public <S> TemplateTreeItem<S> getChildItem( S templateObj ) {

        if( templateObj == null )
            return null;

        TemplateTreeItem<S> childItem = null;
        ObservableList<TemplateTreeItem> children = super.getChildren();
        for(TemplateTreeItem item: children ) {
            if(( item.getValue() != null ) && ( templateObj.hashCode() == item.getValue().hashCode() )) {
            //if( templateObj.equals( item.getValue() )) { //object equals on incomplete objects is not possible
                childItem = item;
                break;
            }
        }

        return childItem;
    }

    public TemplateAttributesPane<T> getAttributesPane() {
        return attributesPane;
    }

    public void setAttributesPane(TemplateAttributesPane<T> attributesPane) {
        this.attributesPane = attributesPane;
    }
    
    public TemplateTreeItem(T templateObj) {

        super(templateObj, getIcon(templateObj));
    }

    public boolean isShowPdfOnly() {
        return showPdfOnly;
    }

    public void setShowPdfOnly(boolean showPdfOnly) {
        this.showPdfOnly = showPdfOnly;
    }

    // TODO add menu items and corresponding actions
    @SuppressWarnings("unchecked")
	public ContextMenu getContextMenu() {

        ContextMenu contextMenu = new ContextMenu();
    	
    	MenuItem deleteNode = new MenuItem("Delete Node");
        contextMenu.getItems().add(deleteNode);

        deleteNode.setOnAction(event -> {

            if( this.getParent() == null ) return;

            try {
                deleteChild( );
            } catch (HiTException e) {
                e.printStackTrace();
            }
        });
        
        return contextMenu;
    }

    private boolean deleteChild() throws HiTException {

        boolean result = false;
        Object parentNode = getParent().getValue();
        Object templateNode = getValue();

        if( parentNode == null ) return false;
        else if( templateNode == null ) return true; //nothing to do

        if( PullJobTemplate.class.isAssignableFrom(parentNode.getClass()) ) {
            result = deleteChild( (PullJobTemplate) parentNode, templateNode );
        } else if( PageSpec.class.isAssignableFrom(parentNode.getClass()) ) {
            result = deleteChild( (PageSpec) parentNode, templateNode );
        } else if (TargetGroup.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((TargetGroup) parentNode, templateNode);
        } else if (NavTarget.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((NavTarget) parentNode, templateNode);
        } else if (DataTarget.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((DataTarget) parentNode, templateNode);
        } else if (GroupReference.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((GroupReference) parentNode, templateNode);
        } else if (DataTargetQualifier.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((DataTargetQualifier) parentNode, templateNode);
        } else if (ContextFilter.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((ContextFilter) parentNode, templateNode);
        } else if (ExtractOperator.class.isAssignableFrom(parentNode.getClass())) {
            result = deleteChild((ExtractOperator) parentNode, templateNode);
        }

        if( result ) {
            setChildrenAssigned(false);
            //TODO ensure all tree items and nodes are deleted for garbage collection
        }

        return result;
    }

	private boolean deleteChild(ContextFilter parentNode, Object templateNode) {
		
		boolean isChildRemoved = false;
        
        if(templateNode instanceof ContextFilter && parentNode instanceof FilterKey) {
        	
        	FilterKey parentFilter = (FilterKey)parentNode;
        	
	        if( parentFilter.getFilters() != null && parentFilter.getFilters().contains( templateNode ) ) {
	
	            List<ContextFilter> relativeOperators = new ArrayList<>( parentFilter.getFilters() );
	            relativeOperators.remove( templateNode );
	            parentFilter.setFilters( relativeOperators );
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof ContextFilter && parentNode instanceof VariableStringKey) {
        	
        	VariableStringKey parentFilter = (VariableStringKey)parentNode;
        	
	        if( parentFilter.getFilters() != null && parentFilter.getFilters().contains( templateNode ) ) {
	
	            List<ContextFilter> relativeOperators = new ArrayList<>( parentFilter.getFilters() );
	            relativeOperators.remove( templateNode );
	            parentFilter.setFilters( relativeOperators );
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof ContextKey && parentNode instanceof DirectionFilter) {
        	
    		((DirectionFilter)parentNode).setKey(null);
    		getParent().getChildren().remove( this );
            isChildRemoved = true;
    	} else if(templateNode instanceof ContextKey && parentNode instanceof VerticalFilter) {
    		
    		((VerticalFilter)parentNode).setStartKey(null);
    		getParent().getChildren().remove( this );
            isChildRemoved = true;
    	} else if(templateNode instanceof ContextKey && parentNode instanceof HorizontalFilter) {
    		
    		((HorizontalFilter)parentNode).setStartKey(null);
    		getParent().getChildren().remove( this );
            isChildRemoved = true;
    	} else if(templateNode instanceof ContextKey && parentNode instanceof RangeFilter) {
    		
    		RangeFilter parentFilter = (RangeFilter)parentNode;
    		
    		if(templateNode.equals(parentFilter.getStartKey())) {
    			parentFilter.setStartKey(null);
    			getParent().getChildren().remove( this );
    			isChildRemoved = true;
    		} else if(templateNode.equals(parentFilter.getEndKey())) {
    			parentFilter.setEndKey(null);
    			getParent().getChildren().remove( this );
    			isChildRemoved = true;
    		}
    	}
        
        return isChildRemoved;
	}
	
	private boolean deleteChild(ExtractOperator parentNode, Object templateNode) {
		
		boolean isChildRemoved = false;
        
        if(templateNode instanceof ExtractOperator && parentNode instanceof SimpleOperatorChain) {
        	
        	SimpleOperatorChain parentOperator = (SimpleOperatorChain)parentNode;
        	
	        if( parentOperator.getOperators() != null && parentOperator.getOperators().contains( templateNode ) ) {
	
	            List<ExtractOperator> relativeOperators = new ArrayList<>( parentOperator.getOperators() );
	            relativeOperators.remove( templateNode );
	            parentOperator.setOperators( relativeOperators );
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof ExtractOperator && parentNode instanceof ConcatOperator) {
        	
        	ConcatOperator parentOperator = (ConcatOperator)parentNode;
        	
	        if( parentOperator.getOperators() != null && parentOperator.getOperators().contains( templateNode ) ) {
	
	            List<ExtractOperator> relativeOperators = new ArrayList<>( parentOperator.getOperators() );
	            relativeOperators.remove( templateNode );
	            parentOperator.setOperators( relativeOperators );
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        }
        
        return isChildRemoved;
	}

	private boolean deleteChild(PullJobTemplate parentNode, Object templateNode) throws HiTException {

        //PageSpec cannot be nulled out. Reset values instead
        if( templateNode instanceof BasePageSpec ) {
            BasePageSpec pageSpec = (BasePageSpec)templateNode;
            pageSpec.setConfigOptions( null );
            pageSpec.setExpectedContentType( null );

            //Remove all children = TargetGroups
            pageSpec.setTargetGroups(null);
            List<TemplateTreeItem> children = getChildren();
            for( TemplateTreeItem child : children )
                getChildren().remove( child );

        } else if( templateNode instanceof ConditionalPageSpec ) {
            ConditionalPageSpec pageSpec = (ConditionalPageSpec)templateNode;
            pageSpec.setConditionFalseSpec( null );
            pageSpec.setConditionTrueSpec( null );
            pageSpec.setConfigOptions( null );
            pageSpec.setExpectedContentType( null );
            pageSpec.setPageCondition( null );

            TreeItem itemToRemove = null;
            for( TreeItem item : this.getChildren() )
                if( item.getValue().equals( pageSpec.getTargetSpec()) )
                    itemToRemove = item;
            if( itemToRemove != null ) {
                pageSpec.setTargetSpec(null);
                this.getChildren().remove( itemToRemove );
            }
        } else {
            throw new HiTException("Cannot handle child " + templateNode.getClass().getName() + " of parent " + parentNode.getClass().getName() );
        }

        return true;
    }

    private boolean deleteChild( PageSpec parentNode, Object templateNode ) throws HiTException {

        if(! (TargetGroup.class.isAssignableFrom( templateNode.getClass() )))
            throw new HiTException("Cannot handle child " + templateNode.getClass().getName() + " of parent " + parentNode.getClass().getName() );

        ((BasePageSpec)parentNode).setTargetGroups( null );
        getParent().getChildren().remove( this );

        return true;
    }

    /**
     * Delete a child of TargetGroup.NavTargets or DataTargets
     *
     * @param parentNode
     * @param templateNode
     * @return
     */
    private boolean deleteChild(TargetGroup<DataTarget, NavTarget> parentNode, Object templateNode) throws HiTException {

        if( templateNode instanceof DataTarget ) {

            List<DataTarget> dataTargets = parentNode.getDataTargets();
            if( dataTargets != null ) {
                dataTargets = new ArrayList<>(dataTargets);
                dataTargets.remove(templateNode);
                if( parentNode instanceof XmlTargetGroup )
                    ((XmlTargetGroup) parentNode).setDataTargets( dataTargets );
                else if( parentNode instanceof TextTargetGroup)
                    ((TextTargetGroup) parentNode).setDataTargets( dataTargets );
                getParent().getChildren().remove( this );
            }
        } else if( templateNode instanceof NavTarget ) {

            List<NavTarget> navTargets = parentNode.getNavTargets();
            if( navTargets != null ) {
                navTargets = new ArrayList<>(navTargets);
                navTargets.remove(templateNode);
                if( parentNode instanceof XmlTargetGroup )
                    ((XmlTargetGroup) parentNode).setNavTargets( navTargets );
                else if( parentNode instanceof TextTargetGroup)
                    ((TextTargetGroup) parentNode).setNavTargets( navTargets );
                getParent().getChildren().remove( this );
            }
        } else if(templateNode instanceof GroupPolicy) {
        	
        	if( parentNode.getGroupPolicy().equals(templateNode) ) {

        		((XmlTargetGroup)parentNode).setGroupPolicy(null);
	            getParent().getChildren().remove( this );
        	}
        } else
            throw new HiTException( "Cannot handle child " + templateNode.getClass().getName() + " of parent " + parentNode.getClass().getName() );

        return true;
    }


    private boolean deleteChild(NavTarget parentNode, Object templateNode) {

        boolean isChildRemoved = false;
        if( templateNode instanceof PageSpec ) {
            parentNode.setTargetPageSpec( null );
            isChildRemoved = true;
        }

        if( parentNode instanceof ClickableNavTarget ) {

            ClickableNavTarget node = (ClickableNavTarget)parentNode;

            //TODO inputElements
            if( templateNode.equals( node.getMetaDataTargets()) ) {
                node.setMetaDataTargets( null );
                isChildRemoved = true;
                getParent().getChildren().remove( this );
            } else if( templateNode instanceof DataTarget ) {
                parentNode.setXPathDataTarget(null);
                isChildRemoved = true;
                getParent().getChildren().remove( this );
            }
        }

        return isChildRemoved;
    }

    private boolean deleteChild(DataTarget parentNode, Object templateNode) {

        boolean isChildRemoved = false;
        
        if(templateNode instanceof DataTarget) {
	        if( parentNode.getRelativeDataTargets() != null && parentNode.getRelativeDataTargets().contains( templateNode ) ) {
	
	            List<DataTarget> relativeDataTargets = new ArrayList<>( parentNode.getRelativeDataTargets() );
	            relativeDataTargets.remove( templateNode );
	            parentNode.setRelativeDataTargets( relativeDataTargets );
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof GroupReference) {
        	
        	if( parentNode.getReferences() != null && parentNode.getReferences().contains( templateNode ) ) {
        		
        		List<GroupReference> groupReferences = new ArrayList<>( parentNode.getReferences() );
	            groupReferences.remove( templateNode );
	            GroupReference[] gr = new GroupReference[groupReferences.size()];
	            parentNode.addReference(groupReferences.toArray(gr));
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
        	}
        } else if(templateNode instanceof DataTargetQualifier) {
        	
        	if(parentNode instanceof ExpandablePdfDataTarget) {
        		
        		ExpandablePdfDataTarget expandablePdfDataTarget = (ExpandablePdfDataTarget)parentNode;
        		if(expandablePdfDataTarget.getStartQualifier().equals(templateNode)) {
            		expandablePdfDataTarget.setStartQualifier(null);
            		getParent().getChildren().remove( this );
    	            isChildRemoved = true;
            	} else {
            		expandablePdfDataTarget.setEndQualifier(null);
            		getParent().getChildren().remove( this );
    	            isChildRemoved = true;
            	}
        	} else {
	        	if( parentNode.getQualifier().equals(templateNode) ) {
	
	        		parentNode.setQualifier(null);
		            getParent().getChildren().remove( this );
		            isChildRemoved = true;
	        	}
        	}
        } else if(templateNode instanceof GroupPolicy) {
        	
        	if( parentNode.getGroupPolicy().equals(templateNode) ) {

        		parentNode.setGroupPolicy(null);
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
        	}
        } else if(templateNode instanceof ContextFilter && parentNode instanceof PdfDataTarget) {
        	PdfDataTarget parentTarget = (PdfDataTarget)parentNode;
        	if( parentTarget.getFilters() != null && parentTarget.getFilters().contains( templateNode ) ) {
        		
	            List<ContextFilter> filters = new ArrayList<>( parentTarget.getFilters() );
	            filters.remove( templateNode );
	            parentTarget.setFilters(filters);
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof ExtractOperator ) {
        	
        	if( parentNode.getOperator().equals(templateNode) ) {
        		
        		parentNode.setOperator(null);
	            getParent().getChildren().remove( this );
	            isChildRemoved = true;
	        }
        } else if(templateNode instanceof ContextKey && parentNode instanceof PdfPageDataTarget) {
        	
        	PdfPageDataTarget pdfPageDataTarget = (PdfPageDataTarget)parentNode;
        	if(pdfPageDataTarget.getStartQualifier().equals(templateNode)) {
        		pdfPageDataTarget.setStartQualifier(null);
        		getParent().getChildren().remove( this );
	            isChildRemoved = true;
        	} else { 
        		pdfPageDataTarget.setEndQualifier(null);
        		getParent().getChildren().remove( this );
	            isChildRemoved = true;
        	}
        } else if(templateNode instanceof ContextKey && parentNode instanceof ExpandablePdfDataTarget) {
        	
        	ExpandablePdfDataTarget expandablePdfDataTarget = (ExpandablePdfDataTarget)parentNode;
        	if(expandablePdfDataTarget.getExpandableKey().equals(templateNode)) {
        		expandablePdfDataTarget.setExpandableKey(null);
        		getParent().getChildren().remove( this );
	            isChildRemoved = true;
        	}
        }

        return isChildRemoved;
    }
    
    private boolean deleteChild(GroupReference parentNode, Object templateNode) {

        boolean isChildRemoved = false;
        if( parentNode.getTargets() != null && parentNode.getTargets().contains( templateNode ) ) {

            List<DataTarget> relativeDataTargets = new ArrayList<>( parentNode.getTargets() );
            relativeDataTargets.remove( templateNode );
            parentNode.setTargets( relativeDataTargets );
            getParent().getChildren().remove( this );
            isChildRemoved = true;
        }

        return isChildRemoved;
    }
    
    private boolean deleteChild(DataTargetQualifier parentNode, Object templateNode) {

        boolean isChildRemoved = false;
        
        if( parentNode instanceof CoordinateDataTargetQualifier && templateNode instanceof DataTarget) {
        	
           ((CoordinateDataTargetQualifier) parentNode).setQualifyingTarget(null);
            getParent().getChildren().remove( this );
            isChildRemoved = true;
        }
        else if( parentNode instanceof ComparisonDataTargetQualifier  && templateNode instanceof DataTarget) {
        	
        	ComparisonDataTargetQualifier qualifier = (ComparisonDataTargetQualifier) parentNode;
        	
        	if(templateNode.equals(qualifier.getQualifyingTarget1())) {
        		qualifier.setQualifyingTarget1(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	} else if(templateNode.equals(qualifier.getQualifyingTarget2())) {
        		qualifier.setQualifyingTarget2(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	}
        } else if(parentNode instanceof AndDataTargetQualifier && templateNode instanceof DataTargetQualifier) {
        	
        	AndDataTargetQualifier qualifier = (AndDataTargetQualifier) parentNode;
        	
        	if(templateNode.equals(qualifier.getC1())) {
        		qualifier.setC1(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	} else if(templateNode.equals(qualifier.getC2())) {
        		qualifier.setC2(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	}
        } else if(parentNode instanceof OrDataTargetQualifier && templateNode instanceof DataTargetQualifier) {
        	
        	OrDataTargetQualifier qualifier = (OrDataTargetQualifier) parentNode;
        	
        	if(templateNode.equals(qualifier.getC1())) {
        		qualifier.setC1(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	} else if(templateNode.equals(qualifier.getC2())) {
        		qualifier.setC2(null);
        		getParent().getChildren().remove( this );
        		isChildRemoved = true;
        	}
        } else if(parentNode instanceof NotDataTargetQualifier && templateNode instanceof DataTargetQualifier) {
        	
        	((NotDataTargetQualifier)parentNode).setTarget(null);
        	getParent().getChildren().remove( this );
            isChildRemoved = true;
        } else if(parentNode instanceof PdfDataTargetQualifier && templateNode instanceof PdfDataTarget) {
        	
        	((PdfDataTargetQualifier) parentNode).setQualifyingTarget(null);
        	getParent().getChildren().remove( this );
            isChildRemoved = true;
        } else if(parentNode instanceof XmlDataTargetQualifier && templateNode instanceof XmlDataTarget) {
        	
        	((XmlDataTargetQualifier)parentNode).setQualifyingTarget(null);
        	getParent().getChildren().remove( this );
            isChildRemoved = true;
        }

        return isChildRemoved;
    }

    /**
     * 
     * @return true, if the template tree item is a dataTarget and it takes key value pair.
     * false, if the template tree item is a dataTarget with GroupPolicy or a dataTarget with relative dataTargets.
     */
    public  boolean isKeyDataTarget() {
        Object item = this.getValue();
    	if ( item instanceof PdfDataTarget ){
    		if( !( 															// not 
    			((PdfDataTarget) item).getGroupPolicy() != null || 			// containing groupPolicy or   
    			((PdfDataTarget) item).getRelativeDataTargets() != null )) 	// relativeDataTargets
    		return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreeItem is a dataTarget with groupPolicy
     */
    public  boolean isGroupDataTarget() {
        Object item = this.getValue();
    	if ( item instanceof PdfDataTarget ){
    		if ( ((PdfDataTarget) item).getGroupPolicy() != null ) 
    			return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreeItem is dataTarget with baseFilter and some collection of other datatargets
     */
    public  boolean isContainerDataTarget() {
        Object item = this.getValue();
    	if ( item instanceof PdfDataTarget ){
    		if ( /*((PdfDataTarget) item).getGroupPolicy() == null ||*/
    			((PdfDataTarget) item).getRelativeDataTargets() != null )
    			return true;
    	}
    	
		return false;
	}

    /** Call this with false when children list changes */
    public void setChildrenAssigned(boolean childrenAssigned) {
        isChildrenAssigned = childrenAssigned;
    }

    @Override
    public ObservableList<TemplateTreeItem> getChildren() {

        if (isChildrenAssigned) return super.getChildren();

        Object value = this.getValue();
        //System.out.println(value.getClass()); //--
        createChildren(value);

        return super.getChildren();
    }

    @Override
    public boolean isLeaf() {

        if( !isChildrenAssigned ) {
            Object value = this.getValue();
            createChildren( value );
        }
        return super.getChildren().isEmpty();
    }

    private void createChildren(Object templateObj) {
        if( templateObj == null) return;

        if (PullJobTemplate.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((PullJobTemplate) templateObj);
        } else if (PageSpec.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((PageSpec) templateObj);
        } else if (TargetGroup.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((TargetGroup) templateObj);
        } else if (NavTarget.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((NavTarget) templateObj);
        } else if (DataTarget.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((DataTarget) templateObj);
        } else if (GroupReference.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((GroupReference) templateObj);
        } else if (DataTargetQualifier.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((DataTargetQualifier) templateObj);
        } else if (ContextFilter.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((ContextFilter) templateObj);
        } else if (ExtractOperator.class.isAssignableFrom(templateObj.getClass())) {
            addChildren((ExtractOperator) templateObj);
        } else {
        	//System.err.println("Unhandled method : createChildren() : " + templateObj.getClass());
        }

        setChildrenAssigned(true);
    }
    
    private void addChildren(ExtractOperator extractOperator) {

    	if(extractOperator != null) {
    		ObservableList<TreeItem> children = super.getChildren();
	    	if(extractOperator instanceof SimpleOperatorChain) {
                List<? extends ExtractOperator> operators = ((SimpleOperatorChain)extractOperator).getOperators();
                if( operators != null && operators.size() > 0 ) {
                    for (ExtractOperator operator : operators) {
                        children.add(new TemplateTreeItem<>(operator));
                    }
                }
	    	} else if(extractOperator instanceof ConcatOperator) {
	    		List<? extends ExtractOperator> operators = ((ConcatOperator)extractOperator).getOperators();
                if( operators != null && operators.size() > 0 ) {
                    for (ExtractOperator operator : operators) {
                        children.add(new TemplateTreeItem<>(operator));
                    }
                }
	    	} else {
	        	//System.err.println("Unhandled Filter : createChildren() : " + extractOperator.getClass());
	        }
    	}
	}

    private void addChildren(ContextFilter contextFilter) {

    	if(contextFilter != null) {
    		ObservableList<TreeItem> children = super.getChildren();
	    	if(contextFilter instanceof FilterKey) {
                List<? extends ContextFilter> filters = ((FilterKey)contextFilter).getFilters();
                if( filters != null && filters.size() > 0 ) {
                    for (ContextFilter filter : filters) {
                        children.add(new TemplateTreeItem<>(filter));
                    }
                }
	    	} else if(contextFilter instanceof VariableStringKey) {
	    		List<? extends ContextFilter> filters = ((VariableStringKey)contextFilter).getFilters();
                if( filters != null && filters.size() > 0 ) {
                    for (ContextFilter filter : filters) {
                        children.add(new TemplateTreeItem<>(filter));
                    }
                }
	    	} else if(contextFilter instanceof DirectionFilter) {
	    		children.add(new TemplateTreeItem<>(((DirectionFilter)contextFilter).getKey()));
	    	} else if(contextFilter instanceof VerticalFilter) {
	    		children.add(new TemplateTreeItem<>(((VerticalFilter)contextFilter).getStartKey()));
	    	} else if(contextFilter instanceof HorizontalFilter) {
	    		children.add(new TemplateTreeItem<>(((HorizontalFilter)contextFilter).getStartKey()));
	    	} else if(contextFilter instanceof RangeFilter) {
	    		children.add(new TemplateTreeItem<>(((RangeFilter)contextFilter).getStartKey()));
	    		children.add(new TemplateTreeItem<>(((RangeFilter)contextFilter).getEndKey()));
	    	} else {
	        	//System.err.println("Unhandled Filter : createChildren() : " + contextFilter.getClass());
	        }
    	}
	}

	private void addChildren(PullJobTemplate template) {

        if(template == null)
            return;

        ObservableList<TreeItem> children = super.getChildren();
        PageSpec pageSpec = null;
		if( showPdfOnly )
		    pageSpec = TemplateUtils.getPdfPageSpec((WebPullJobTemplate) template);
		else
		    pageSpec = template.getPageSpec();
        if(pageSpec != null)
            children.setAll(new TemplateTreeItem(pageSpec));
    }

    private void addChildren(PageSpec spec) {

        if(spec == null)
            return;

        ObservableList<TreeItem> children = super.getChildren();
        List<TargetGroup> targetGroups;
        /* Left other cases commented out in case we need specialized behavior */
        if(spec instanceof BasePageSpec) {
        	targetGroups = (List<TargetGroup>) ((BasePageSpec)spec).getTargetGroups();
        
        } else {
        	targetGroups = ((PageSpec)spec).getAllTargetGroups();
        	
        }
        /*else if(spec instanceof ConditionalPageSpec) {
        	
        }
        else if(spec instanceof TrackLoginFailurePageSpec) {
        	
        }*/
        
        if(targetGroups != null) {
            for (TargetGroup group : targetGroups) {
                children.add(new TemplateTreeItem(group));
            }
        }
    }

    private void addChildren(TargetGroup targetGroup) {

        if(targetGroup == null)
            return;

        ObservableList<TreeItem> children = super.getChildren();
        
        GroupPolicy grpPolicy = targetGroup.getGroupPolicy();
        if( grpPolicy != null ) {
              children.add(new TemplateTreeItem<>(grpPolicy));
        }
        
        List<DataTarget> dataTargets = targetGroup.getDataTargets();
        if (dataTargets != null) {

            for (DataTarget target : dataTargets) {
                if(target != null) {
                    children.add( new TemplateTreeItem( target ));
                }
            }
        }

        List<NavTarget> navTargets = targetGroup.getNavTargets();
        if (navTargets != null) {

            for (NavTarget target : navTargets) {
                children.add( new TemplateTreeItem<>( target ) );
            }
        }
    }

    private void addChildren(NavTarget navTarget) {

        if(navTarget == null)
            return;

        PageSpec pageSpec = navTarget.getTargetPageSpec();
        if( pageSpec != null) {
            ObservableList<TreeItem> children = super.getChildren();
            children.add(new TemplateTreeItem<>(pageSpec));
        }
    }


    private void addChildren( DataTarget dataTarget ) {
        if(dataTarget == null)
            return;

        ObservableList<TreeItem> children = super.getChildren();

        if( dataTarget.getQualifier() != null ) {
            children.add(new TemplateTreeItem<>(dataTarget.getQualifier()));
        }
        
        if( dataTarget.getOperator() != null ) {
            children.add(new TemplateTreeItem<>(dataTarget.getOperator()));
        }

        if( dataTarget instanceof PdfDataTarget ) {
            List<? extends ContextFilter> filters = ((PdfDataTarget) dataTarget).getFilters();
            if( filters != null && filters.size() > 0 ) {
                for (ContextFilter filter : filters) {
                    children.add(new TemplateTreeItem<>(filter));
                }
            }
        }
        
        if(dataTarget instanceof PdfPageDataTarget) {
        	
        	PdfPageDataTarget pdfPageDataTarget = (PdfPageDataTarget)dataTarget;
        	if(pdfPageDataTarget.getStartQualifier() != null)
        		children.add(new TemplateTreeItem<>(pdfPageDataTarget.getStartQualifier()));
        	if(pdfPageDataTarget.getEndQualifier() != null)
        		children.add(new TemplateTreeItem<>(pdfPageDataTarget.getEndQualifier()));
        } else if(dataTarget instanceof ExpandablePdfDataTarget) {
        	
        	ExpandablePdfDataTarget expandablePdfDataTarget = (ExpandablePdfDataTarget)dataTarget;
        	
        	if(expandablePdfDataTarget.getStartQualifier() != null)
        		children.add(new TemplateTreeItem<>(expandablePdfDataTarget.getStartQualifier()));
        	if(expandablePdfDataTarget.getEndQualifier() != null)
        	children.add(new TemplateTreeItem<>(expandablePdfDataTarget.getEndQualifier()));
        	
        	if(expandablePdfDataTarget.getExpandableKey() != null)
        	children.add(new TemplateTreeItem<>(expandablePdfDataTarget.getExpandableKey()));
        }
        
        GroupPolicy grpPolicy = dataTarget.getGroupPolicy();
        if( grpPolicy != null ) {
              children.add(new TemplateTreeItem<>(grpPolicy));
        }

        if(dataTarget.getRelativeDataTargets() != null) {
	        for(DataTarget childTarget : dataTarget.getRelativeDataTargets()) {
	            children.add( new TemplateTreeItem<>(childTarget) );
	        }
        }
        
        if(dataTarget.getReferences() != null) {
        	for(GroupReference childTarget : dataTarget.getReferences()) {
	            children.add(new TemplateTreeItem<>(childTarget));
	        }
        }
    }

    private void addChildren( DataTargetQualifier qualifier ) {
        if( qualifier == null )
            return;

        ObservableList<TreeItem> children = super.getChildren();

        if( qualifier instanceof CoordinateDataTargetQualifier ) {
            children.add( new TemplateTreeItem<>( ((CoordinateDataTargetQualifier) qualifier).getQualifyingTarget()) );
        }
        else if( qualifier instanceof ComparisonDataTargetQualifier ) {
            children.add( new TemplateTreeItem<>( ((ComparisonDataTargetQualifier) qualifier).getQualifyingTarget1()) );
            children.add( new TemplateTreeItem<>( ((ComparisonDataTargetQualifier) qualifier).getQualifyingTarget2()) );
        } else if(qualifier instanceof AndDataTargetQualifier) {
        	children.add( new TemplateTreeItem<>( ((AndDataTargetQualifier) qualifier).getC1()) );
            children.add( new TemplateTreeItem<>( ((AndDataTargetQualifier) qualifier).getC2()) );
        } else if(qualifier instanceof OrDataTargetQualifier) {
        	children.add( new TemplateTreeItem<>( ((OrDataTargetQualifier) qualifier).getC1()) );
            children.add( new TemplateTreeItem<>( ((OrDataTargetQualifier) qualifier).getC2()) );
        } else if(qualifier instanceof NotDataTargetQualifier) {
        	children.add( new TemplateTreeItem<>( ((NotDataTargetQualifier) qualifier).getTarget()) );
        } else if(qualifier instanceof PdfDataTargetQualifier) {
        	children.add( new TemplateTreeItem<>( ((PdfDataTargetQualifier) qualifier).getQualifyingTarget()) );
        } else if(qualifier instanceof XmlDataTargetQualifier) {
        	children.add( new TemplateTreeItem<>( ((XmlDataTargetQualifier) qualifier).getQualifyingTarget()) );
        }
    }
    
    private void addChildren(GroupReference groupReference) {
        if(groupReference == null || groupReference.getTargets() == null)
            return;

        ObservableList<TreeItem> children = super.getChildren();

        for(DataTarget childTarget : groupReference.getTargets()) {
            children.add(new TemplateTreeItem<>(childTarget));
        }
    }

    private static Node getIcon( Object templateObj ) {

        if( templateObj == null) return null;


        String image = null;
        if( PageSpec.class.isAssignableFrom(templateObj.getClass()) )
            image = "page.png";
        else if( TargetGroup.class.isAssignableFrom(templateObj.getClass()) )
            image = "list.png";
        else if( DataTarget.class.isAssignableFrom(templateObj.getClass()) ) {
            if (((DataTarget) templateObj).getGroupPolicy() != null)
                image = "group.png";
            else if (((DataTarget) templateObj).getRelativeDataTargets() != null)
                image = "list.png";
            else if (((DataTarget) templateObj).getQualifier() != null)
                image = "qualify.png";
            else
                image = "key.png";
        } else if(NavTarget.class.isAssignableFrom(templateObj.getClass()) )
            image = "target.png";
        else if( ContextFilter.class.isAssignableFrom( templateObj.getClass() ))
            image = "filter.png";
        else if( DataTargetQualifier.class.isAssignableFrom( templateObj.getClass() ))
            image = "qualifier.png";

        Node icon =  null;
        if(image != null) {
            InputStream is = TemplateTreeItem.class.getResourceAsStream("/icons/"+image);
            if(is != null) {
                icon = new ImageView(new Image(is));
            }
        }
        return icon;
    }

    @Override
    public String toString() {

        Object value = this.getValue();

        String displayString = "";
        if (value == null) {
            displayString = "ERROR - no template node";
        } else if (List.class.isAssignableFrom(value.getClass())) {
            List valueList = (List)value;
            displayString = (valueList.size()) > 0 ? (valueList.get(0).getClass().getSimpleName() + " (" + valueList.size() + ")")
                    : "List of " + value.getClass().getSimpleName();
        } else if (!value.getClass().getPackage().getName().startsWith("urjanet")) {
            displayString = super.toString();
        } else if(PullJobTemplate.class.isAssignableFrom(value.getClass())) {
            displayString = (getAttributesPane() != null) ? getAttributesPane().getString() : "Template"; //((PullJobTemplate)value).getId();
        } else if (PageSpec.class.isAssignableFrom(value.getClass())) {
            displayString = toString((PageSpec)value);
        } else if(TargetGroup.class.isAssignableFrom(value.getClass())) {
            GroupPolicy policy = ((TargetGroup)value).getGroupPolicy();
            if(policy != null) {
                displayString = policy.getGroupName() + "-" + policy.getAction();
            }
        } else if(NavTarget.class.isAssignableFrom(value.getClass())) {
            displayString = toString((NavTarget)value);
        } else if(DataTarget.class.isAssignableFrom(value.getClass())) {
            displayString = toString((DataTarget)value);
        } else if(GroupReference.class.isAssignableFrom(value.getClass())) {
            displayString = toString((GroupReference)value);
        } else if(DataTargetQualifier.class.isAssignableFrom(value.getClass())) {
            displayString = toString((DataTargetQualifier)value);
        }

        displayString = (displayString == null || displayString.isEmpty()) ? value.getClass().getSimpleName() : displayString;
        return displayString;
    }

    private String toString(PageSpec pgSpec) {
        if(pgSpec instanceof BasePageSpec) {
            return "BasePageSpec";
        }
        else if(pgSpec instanceof ConditionalPageSpec) {
            return "ConditionalPageSpec";
        }
        else
            return "PageSpec";
    }
    
    private String toString(GroupReference value) {
        return value.getClass().getSimpleName();
    }
    
    private String toString(DataTargetQualifier value) {
        return value.getClass().getSimpleName();
    }

    private String toString(NavTarget value) {
        String displayString = value.getClass().getSimpleName();
        if (value.getGroupPolicy() != null)
            displayString += " " + value.getGroupPolicy().getGroupName() + "-" + value.getGroupPolicy().getAction();

        if (value instanceof UrlNavTarget && ((UrlNavTarget)value).getUrl() != null)
            displayString += " " + ((UrlNavTarget)value).getUrl();
        else if (value instanceof ClickableNavTarget && ((ClickableNavTarget)value).getXpathTarget() != null)
            displayString += " " + ((ClickableNavTarget)value).getXpathTarget();
        else if (value instanceof CustomRequestNavTarget && ((CustomRequestNavTarget)value).getUrl() != null)
            displayString += " " + ((CustomRequestNavTarget)value).getUrl();
        else if (value instanceof ExpandableNavTarget && ((ExpandableNavTarget)value).getXpathTarget() != null)
            displayString += ((ExpandableNavTarget)value).getXpathTarget();

        return displayString;
    }

    private String toString(DataTarget value) {
        String displayString;
        if(value.getGroupPolicy() != null)
            displayString = (value.getGroupPolicy().getGroupName() + "-" + value.getGroupPolicy().getAction());
        else
            displayString = "";

        displayString = displayString
                + (value.getName() != null ? ("-"+value.getName()) : "")
                + (value.getDefaultValue() != null ? ("-"+value.getDefaultValue()) : ""); //TODO

        return displayString;
    }

    /**
     * When getChildren() is called, child nodes are created from the template node in <i>value</i> object. For user edits,
     * the template object will not be changed. Instead the different scenarios are handled as follows:
     *
     *   - Add new child node
     *      - validate if child can be created; error message if invalid - we can skip this since the form should have only allowed nodes to add
     *      - if valid,
     *          - if node being added is a list, or element to add to a list
     *              - create child element and TemplateTreeItem for it
     *              - if a child List exists containing the given containedType, add child element to list
     *              - else create List with TemplateTreeItem and add one child element
     *          - else
     *              - if already exists select
     *              - else create child TemplateTreeItem with default values
     *      - on Apply, parent is recreated with child nodes
     *   - Delete node
     *      if doesn't exist in parent node, delete
     *      else, Set parent node's child to null - TODO create a new parent node by cloneWithout
     *      -
     *   -
     *
     * @param nodeClass
     */
    public TemplateTreeItem addNode(Class nodeClass) {

        TemplateTreeItem newNode = null;
        foreachChild: for(TemplateTreeItem<T> child : this.getChildren()) {

            if( child == null || child.getValue() == null)
                continue;

            //is child assignable to the node's class?
            /*System.out.println("Adding node " + arg.getName() + "; checking child type: " + child.getValue().getClass().getTypeName()
                    + " child type parameters: " + child.getValue().getClass().getTypeParameters());*/
            //is child a list of given type?
            if(List.class.isAssignableFrom(child.getValue().getClass())) {
                Object element = ((List)child.getValue()).get(0);
                /*if(arg.isContainer()) {
                    if(element.getClass().isAssignableFrom(arg.getContainedType()) ) {
                        newNode = child;
                        break foreachChild;
                    }
                } else */if(element.getClass().isAssignableFrom(nodeClass)) {
                    newNode = child;
                    break foreachChild;
                }
            }

            if(nodeClass.isAssignableFrom(child.getValue().getClass())) {
                newNode = child;
                break;
            }

            //is child assignable to interface?
            for(Class classInterface : nodeClass.getInterfaces()) {
                System.out.println("Checking interfaces now.." + classInterface.getName());
                if(classInterface.isAssignableFrom(child.getValue().getClass())) {
                    newNode = child;
                    break foreachChild;
                }
            }
        }

        if(newNode == null) {
            try {
                Object newValue = nodeClass.newInstance();
                newNode = new TemplateTreeItem<>(newValue);
                this.getChildren().add(newNode);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        return newNode;
    }
}
