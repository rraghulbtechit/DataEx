package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ContentType;

public class PageSpecConstructorResolution {

	public static List<Object> resolveConstructorParameters( BasePageSpec basePageSpec ) {
		
		ContentType contentType = basePageSpec.getExpectedContentType();
		ConfigOptions configOptions = basePageSpec.getConfigOptions();
		List<TargetGroup> targetGroups = basePageSpec.getAllTargetGroups();
		List<Object> properties = new ArrayList<Object>();
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, contentType, configOptions, targetGroups);
		return properties;
	}

}
