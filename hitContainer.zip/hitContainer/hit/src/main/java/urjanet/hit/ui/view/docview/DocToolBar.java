package urjanet.hit.ui.view.docview;

import javafx.scene.control.ToolBar;

/**
 * Document view's tool bar
 */
public class DocToolBar extends ToolBar {
}
