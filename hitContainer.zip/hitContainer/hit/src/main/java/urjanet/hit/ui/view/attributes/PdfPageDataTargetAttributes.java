package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.PdfPageDataTarget;

public class PdfPageDataTargetAttributes<T> extends BaseTemplateAttributes<T> {

	private static final String resourcePath = "/PdfPageDataTargetAttributes.fxml";
	
	@FXML protected Pane dataTargetPane;
	@FXML protected Pane contextKeysPane;
	
	@FXML protected CheckBox inversePagesCB;
	protected Property inversePagesProperty;
	@FXML protected TextField startPageText;
	protected Property startPageProperty;
	@FXML protected TextField endPageText;
	protected Property endPageProperty;
	
	private PdfPageDataTarget pdfPageDataTarget = new PdfPageDataTarget();
	private DataTargetAttributes dataTargetAttributes;
	private KeysAttributes keyAttributes;
	
	public PdfPageDataTargetAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(DataTargetAttributes.resourcePath);
		dataTargetPane.getChildren().add(loader.getRoot());
		dataTargetAttributes = loader.getController();
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		contextKeysPane.getChildren().add(loaderContextKey.getRoot());
		keyAttributes = loaderContextKey.getController();

		inversePagesProperty = FXMLUtils.bindField( inversePagesCB, pdfPageDataTarget, "inversePages" );
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }


	@Override
	public void setTreeView(TreeView treeView) {
        super.setTreeView( treeView );
        dataTargetAttributes.setTreeView(treeView);
        
        keyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		super.setTreeItem( item );
		dataTargetAttributes.setTemplateItem(treeItem);

        Object Obj = item.getValue();
        if(! (Obj instanceof PdfPageDataTarget))
            throw new HiTException("Could not create Form for PdfPageDataTarget due to incompatible node. Received " + Obj.getClass());
        
        this.pdfPageDataTarget = (PdfPageDataTarget) Obj;

        //bind
		FXMLUtils.rebindField(inversePagesCB, inversePagesProperty, pdfPageDataTarget, "inversePages");
		FXMLUtils.rebindField(startPageText, startPageProperty, pdfPageDataTarget, "startPage");
		FXMLUtils.rebindField(endPageText, endPageProperty, pdfPageDataTarget, "endPage");
		
		keyAttributes.setTemplateItem(item);
	}
	
	@Override
    protected void onHide() {
		
		dataTargetAttributes.onHide();
    }
}
