package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.TypeTracker;

public class EnumConstantBuilder implements TemplateItemBuilder{

	private static final EnumConstantBuilder theInstance = new EnumConstantBuilder();
	
	public static EnumConstantBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private EnumConstantBuilder() {}
	
	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		AST ast = typeDeclaration.getAST();

		EnumConstant castObject = ( EnumConstant )object;
		Expression enumExpression = ast.newQualifiedName( 
			ast.newSimpleName( castObject.getEnumType().getSimpleName() ), 
			ast.newSimpleName( ((Enum)castObject.getValue()).name() ) );
		enumExpression = JavaElementBuilder.createMethodInvocation(ast, 
			enumExpression, castObject.getMethod().getName());
		return enumExpression;
	}

	@Override
	public Expression createTemplateItem( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		return createClassInstance( typeDeclaration, methodDeclaration, object, typeTracker );
	}

}
