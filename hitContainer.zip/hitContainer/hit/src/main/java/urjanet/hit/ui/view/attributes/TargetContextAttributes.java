package urjanet.hit.ui.view.attributes;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.context.TargetContext;
import urjanet.pull.web.pdf.context.TargetContext.TargetContextDirection;
import urjanet.pull.web.pdf.key.ContextKey;

public class TargetContextAttributes implements Initializable, TemplateAttributesPane {

	public static final String resourcePath = "/TargetContextAttributes.fxml";
	@FXML protected TextField depthTf;
    @FXML protected ComboBox targetContextCombo;
    @FXML protected CheckBox restrictedContextDeltaCb;
    
    private TargetContext targetContext;
    private TemplateTreeItem treeItem;
    private TreeView treeView;
    
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
        targetContextCombo.getItems().addAll(TargetContextDirection.values());
	}
	
	private void setTargetContext(TargetContext targetContext) {

		this.targetContext = targetContext;
        FXMLUtils.unbindAll(this);
        
        if(targetContext == null) {
        	targetContext = new TargetContext();
        }
        
        try {
        	//bind
        	FXMLUtils.bindField(depthTf, targetContext, "depth");
        	FXMLUtils.bindField(targetContextCombo, targetContext, "targetContext");
        	FXMLUtils.bindField(restrictedContextDeltaCb, targetContext, "restrictedContextDelta");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {

		this.treeItem = treeItem;
		
		Object obj = item.getValue();
		
		if(obj != null) {
			ContextKey key = (ContextKey) obj;
			setTargetContext(key.getSearchContext());
		}
	}

	@Override
	public void setTreeView(TreeView treeView) {

		this.treeView = treeView;
	}

}