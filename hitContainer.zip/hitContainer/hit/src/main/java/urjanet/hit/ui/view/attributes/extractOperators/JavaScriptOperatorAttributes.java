package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.JavaScriptOperator;

public class JavaScriptOperatorAttributes extends BaseTemplateAttributes<T> {
	
	public static final String resourcePath = "/JavaScriptOperatorAttributes.fxml";

	@FXML private TextArea scriptText;
	private Property scriptTextProperty;
	
	private JavaScriptOperator javaScriptOperator;
	
	public JavaScriptOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof JavaScriptOperator))
            throw new HiTException("Could not create Form for JavaScriptOperator due to incompatible node. Received " + Obj.getClass());
        
        this.javaScriptOperator = (JavaScriptOperator) Obj;
        
        if( scriptTextProperty != null ) FXMLUtils.unbindField( scriptText, scriptTextProperty );
		scriptTextProperty = FXMLUtils.bindField(scriptText, javaScriptOperator, "script");
		
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}
