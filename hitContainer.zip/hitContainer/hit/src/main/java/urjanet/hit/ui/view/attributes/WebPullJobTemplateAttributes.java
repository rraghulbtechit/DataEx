package urjanet.hit.ui.view.attributes;

import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.property.adapter.JavaBeanIntegerPropertyBuilder;
import javafx.beans.property.adapter.JavaBeanLongPropertyBuilder;
import javafx.beans.property.adapter.JavaBeanStringProperty;
import javafx.beans.property.adapter.JavaBeanStringPropertyBuilder;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.TreeView;
import javafx.util.converter.NumberStringConverter;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.NavigationOptions;
import urjanet.pull.web.WebPullJobTemplate;

/**
 * Attributes of WebPullJobTemplates that will be shown in a form
 */
public class WebPullJobTemplateAttributes<T> extends BaseTemplateAttributes<T> {

    private static final String resourcePath = "/WebPullJobTemplateAttributes.fxml";

    @FXML private TextField         urlText;
    @FXML private Label             templateNameLabel;
    @FXML private TextField         templateNameText;
    @FXML private TextField         threadsText;
    @FXML private TextField         delayText;
    @FXML private TemplateButton    pageSpecBtn;
    @FXML private TemplateMenuItem  basePageSpecItem;
    @FXML private TemplateMenuItem  conditionalPageSpecItem;
    @FXML private TitledPane        navOptionsPane;
    @FXML private NavigationOptionsPane navOptionsPaneController;

    private WebPullJobTemplate      template;
    private JavaBeanStringProperty  idProperty; //template name
    private StringProperty          urlProperty;

    public WebPullJobTemplateAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        setTemplateItem(treeItem);

        basePageSpecItem.setOnAction( pgSpecHandler );
        conditionalPageSpecItem.setOnAction( pgSpecHandler );
    }

    EventHandler pgSpecHandler =  event -> {

        TemplateTreeItem pgSpecItem = null;
        if( template.getPageSpec() == null ) {
            //create PageSpec
            PageSpec pgSpec = null;
            try {
                String pgSpecClass = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
                pgSpec = (PageSpec)Class.forName(pgSpecClass).newInstance();
                //set it to template
                template.getEntryPointNavTarget().setTargetPageSpec(pgSpec);
                pgSpecItem = new TemplateTreeItem<>( pgSpec );
                addSelectNode(pgSpecItem);
            } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            for( TemplateTreeItem item : treeItem.getChildren() ) {
                if (item.getValue() instanceof PageSpec) {
                    pgSpecItem = item;
                    break;
                }
            }
            selectNode(pgSpecItem);
            //TODO when type is changed
        }
    };

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        if(item == null)
            throw new HiTException( "Could not create Form. No object present in tree item." );
        else if( ! (item.getValue() instanceof WebPullJobTemplate) )
            throw new HiTException("Could not create Form for WebPullJobTemplate due to incompatible node. Received " + item.getValue().getClass());

        this.template = (WebPullJobTemplate) item.getValue();

        templateNameText.textProperty().unbind();
        try {
            idProperty = JavaBeanStringPropertyBuilder.create().bean(template).name("id").build();//TODO store property with node
            templateNameText.textProperty().bindBidirectional(idProperty);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        urlText.textProperty().unbind();
        try {
            urlProperty = JavaBeanStringPropertyBuilder.create().bean(template.getEntryPointNavTarget()).name("url").build();
            urlText.textProperty().bindBidirectional(urlProperty);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        threadsText.textProperty().unbind();
        try {
            Bindings.bindBidirectional( threadsText.textProperty(),
                    JavaBeanIntegerPropertyBuilder.create().bean(template).name("threads").build(),
                    new NumberStringConverter());
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        delayText.textProperty().unbind();
        try {
            Bindings.bindBidirectional( delayText.textProperty(),
                    JavaBeanLongPropertyBuilder.create().bean(template).name("delay").build(),
                    new NumberStringConverter());
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        if( template.getDefaultNavOptionOverrides() == null )
            template.setDefaultNavOptionOverrides( NavigationOptions.getDefaultOptions() );
        navOptionsPaneController.setNavigationOptions( template.getDefaultNavOptionOverrides() );
    }

    @Override
    public String getString() {
        return template.getId();
    }
    
    @Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}