package urjanet.hit.template.source.compile;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

import urjanet.hit.utils.FileUtils;
import urjanet.regex.RegExHandler;

public class Javac {

	private static final Pattern REGX_PATTERN_PUBLIC_CLASS_FILE = Pattern.compile("public +(?:class|interface) +(\\w+)");
	private static final Pattern REGX_PATTERN_CLASS_NAME = Pattern.compile("(?:class|interface) +(\\w+)");
	private static final Pattern REGX_PATTERN_PACKAGE_NAME = Pattern.compile("package\\s+([a-zA_Z_][\\.\\w]*);");
	
	public static Class compile(String srcCodes) {

		SourceInfo sourceInfo = getSourceInfo(srcCodes);

		File workspaceDirectory = null;
		try {
			workspaceDirectory = FileUtils.getTemporaryWorkspaceDirectory();
		} catch( IOException e ) {
			e.printStackTrace();
		}

		File classDirectory = new File(workspaceDirectory.getAbsolutePath() + File.separatorChar + "classes");
		classDirectory.mkdir();
		
		String options[] = { "-d", classDirectory.getAbsolutePath() };

		String args[] = new String[options.length + 1];
		System.arraycopy(options, 0, args, 0, options.length);

		String sourceFileName = workspaceDirectory.getAbsolutePath() + File.separatorChar + sourceInfo.className + ".java";
		FileUtils.writeFile(new File(sourceFileName), sourceInfo.sourceCode.getBytes());
		args[options.length] = sourceFileName;

		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		compiler.run(null, null, null, args);

		try {
			addToClasspath( classDirectory.getAbsolutePath() );
		} catch( Exception e1 ) {
			e1.printStackTrace();
		}

		return sourceInfo.getClassType();
	}

	private static List<SourceInfo> getSourceInfos(List<String> srcCodes) {
		
		List<SourceInfo> srcInfos = new ArrayList<SourceInfo>(srcCodes.size());
		for (String srcCode : srcCodes) {
			srcInfos.add(getSourceInfo(srcCode));
		}
		
		return srcInfos;
	}

	private static SourceInfo getSourceInfo(String sourceCode) {
		
		Matcher m = REGX_PATTERN_PUBLIC_CLASS_FILE.matcher(sourceCode);
		if (m.find())
			return new SourceInfo(m.group(1), sourceCode);
		else {
			m = REGX_PATTERN_CLASS_NAME.matcher(sourceCode);
			if (m.find())
				return new SourceInfo(m.group(1), sourceCode);
			else
				throw new IllegalArgumentException( "No class or interface definition found in src: \n'" + sourceCode + "'");
		}
	}

	public static void addToClasspath(String s) throws Exception {
		
		File f = new File(s);
		URL u = f.toURL();
		URLClassLoader urlClassLoader = (URLClassLoader) ClassLoader.getSystemClassLoader();
		Class urlClass = URLClassLoader.class;
		Method method = urlClass.getDeclaredMethod("addURL", new Class[]{URL.class});
		method.setAccessible(true);
		method.invoke(urlClassLoader, new Object[]{u});
		
	}

	private static class SourceInfo {
		
		public String fullyQualifiedName;
		public String packageName;
		public String className;
		public String sourceCode;
		
		public SourceInfo(String className, String sourceCode) {
			this.className = className;
			this.sourceCode = sourceCode;
			this.packageName = RegExHandler.extract( sourceCode, REGX_PATTERN_PACKAGE_NAME, 1 );
			this.fullyQualifiedName = packageName + "." + className;
			
		}
		

		
		public Class getClassType() {

			Class clazz = null;
			try {
				clazz = Class.forName( fullyQualifiedName );
			} catch( ClassNotFoundException e ) {
				e.printStackTrace();
			}
			
			return clazz;
		}
	}
}
