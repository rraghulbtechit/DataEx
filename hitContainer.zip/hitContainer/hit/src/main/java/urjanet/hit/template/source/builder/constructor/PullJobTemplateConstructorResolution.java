package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.clean.validation.ValidationException;
import urjanet.hit.utils.TemplateUtils;
import urjanet.pull.core.PageSpec;
import urjanet.pull.web.UrlNavTarget;
import urjanet.pull.web.WebPullJobTemplate;

public class PullJobTemplateConstructorResolution {

	public static List<Object> resolveConstructorParameters( WebPullJobTemplate wpjt ) {
		
		String url = ((UrlNavTarget)wpjt.getEntryPointNavTarget()).getUrl();
		PageSpec pageSpec = null;
		pageSpec = wpjt.getPageSpec();
		//		pageSpec = TemplateUtils.getPdfPageSpec(wpjt);
		String id = wpjt.getId();
		String author = "$LastChangedBy$";
		String revision = "$LastChangedRevision$";
		
		List<Object> properties = new ArrayList<Object>();
		ConstructorResolutionFactory.checkNullAndAddAll( properties, url, pageSpec, id, author, revision );
		
		try {
			ConstructorResolutionFactory.doesSuchConstructorExist( wpjt.getClass(), properties );
		} catch( UnresolvedConstructorException e ) {
			e.printStackTrace();
		}
		
		return properties;
	}
}

