package urjanet.hit.ui.view.source;

import com.kenai.jaffl.struct.Struct;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebView;
import urjanet.hit.template.source.SourceHandler;
import urjanet.hit.ui.control.AlertDialog;
import urjanet.pull.core.PullJobTemplate;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller for Source tab
 */
public class TemplateSourceView implements Initializable {

    @FXML private StackPane         sourceCodePane;

    protected TreeView              templateTreeView;
    protected SourceHandler         sourceHandler;
    protected SourceCodeEditor      sourceCodeEditor;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        sourceCodeEditor = new SourceCodeEditor( "" );
        WebView webView = sourceCodeEditor.getWebview();
        webView.setMaxHeight( Double.MAX_VALUE );
        sourceCodePane.getChildren().add( webView );
    }

    public TreeView getTemplateTreeView() {
        return templateTreeView;
    }

    public void setTemplateTreeView(TreeView templateTreeView) {
        this.templateTreeView = templateTreeView;
        refreshSourceHandler();
    }


    private void refreshSourceHandler() {

        sourceHandler = new SourceHandler();
        if( templateTreeView != null )
            sourceHandler.setTemplateRoot((PullJobTemplate) templateTreeView.getRoot().getValue());
    }



    public void updateSourceAndWoot() {

//		PreCodeGenerationProcessingResult result = PreCodeGenerationProcessor.process( tree );
        // TODO get and set template name
        String sourceCode = "";
        if( sourceHandler != null && templateTreeView.getRoot().getValue() != null )
            sourceCode = sourceHandler.getTemplateSource().getSourceCode();
        sourceCodeEditor.setCode( sourceCode );
    }

    public void onShowDiff(ActionEvent actionEvent) {
        AlertDialog.create("Source Display", "Diff doesn't work yet" );
    }
}
