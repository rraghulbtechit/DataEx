package urjanet.hit.ui.view.attributes;

import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TreeView;
import urjanet.hit.ui.view.tree.TemplateTreeItem;

import java.io.IOException;

/**
 *
 */
public abstract class BaseTemplateAttributes<T> extends ScrollPane implements TemplateAttributesPane {

    protected TemplateTreeItem<T> treeItem;
    protected TreeView             treeView;

    public BaseTemplateAttributes() {

        baseInit();
    }

    protected void baseInit() {

        this.visibleProperty().addListener((observable, wasShowing, isShowing) -> {
            if(!isShowing)
                onHide();
        });
    }

    public TemplateTreeItem<T> getTreeItem() {
        return treeItem;
    }

    public void setTreeItem(TemplateTreeItem<T> treeItem) {
        this.treeItem = treeItem;
    }

    public TreeView getTreeView() {
        return treeView;
    }

    public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
    }

    /**
     * The template object class this attributes pane represents
     *
     * @return
     */
    public Class getClazz() {

        Object templateObject = treeItem.getValue();
        return templateObject.getClass();
    }

    protected boolean load(String resourcePath) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource(resourcePath));
        loader.setRoot(this);
        loader.setController(this);

        try {
            Object load = loader.load();
            System.out.println("Loaded " + load.getClass().getName());
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Override the method for actions to take such as save state etc.
     */
    protected void onHide() {

    }


    protected void addSelectNode(TemplateTreeItem templateTreeItem) {

        addSelectNode( templateTreeItem, null );
    }

    protected void addSelectNode(TemplateTreeItem templateTreeItem, Object afterTemplateObject) {

        addChildNode(templateTreeItem, afterTemplateObject);
        selectNode( templateTreeItem );
    }

    public void addChildNode( TemplateTreeItem childItem ) {
        addChildNode( childItem, null );
    }

    public void addChildNode( TemplateTreeItem childItem, Object afterTemplateObject) {
        ObservableList<TemplateTreeItem> children = treeItem.getChildren();
        if( afterTemplateObject == null )
            children.add(childItem);
        else {
            TemplateTreeItem insertAfter = null;
            for( int i = 0; i < children.size(); ++i ) {
                TemplateTreeItem item = children.get( i );
                if(afterTemplateObject.equals( item.getValue() )) {
                    children.add(i+1, childItem);
                    break;
                }
            }

        }
    }

    public void addChildNode( TemplateTreeItem childItem, TemplateTreeItem afterItem ) {
        ObservableList<TemplateTreeItem> children = treeItem.getChildren();
        if( afterItem == null )
            children.add(childItem);
        else {
            int idx = children.indexOf( afterItem );
            children.add( idx+1, childItem );
        }
    }

    protected void selectNode(TemplateTreeItem templateTreeItem) {
        //select treeItem's child PageSPec node
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }
}
