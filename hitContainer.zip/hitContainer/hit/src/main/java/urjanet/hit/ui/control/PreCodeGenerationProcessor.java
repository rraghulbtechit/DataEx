package urjanet.hit.ui.control;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javafx.scene.control.TreeItem;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.model.TemplateTree;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.web.WebPullJobTemplate;

public class PreCodeGenerationProcessor {

	public static PreCodeGenerationProcessingResult process( TemplateTree tree ){
		
		reconstructTemplate();
		TreeItem root = tree.getRoot();
		
		Map<String, List<TreeItem>> similarGroups = tree.getItemsWithSameGroupName();
		
		for( Entry<String, List<TreeItem>> entry : similarGroups.entrySet() ) {
			
			List<TreeItem> listOfSimilarGroups = entry.getValue();
			
			for (int i = 0; i < listOfSimilarGroups.size(); i++) {
				for (int j = i+1; j < listOfSimilarGroups.size(); j++) {
					
					findDifference( listOfSimilarGroups.get( i ), listOfSimilarGroups.get( j ) );
				}
			}
		}
		Set<Entry<String, List<TreeItem>>> setOfSimilarGroups = similarGroups.entrySet();
		List<Entry<String, List<TreeItem>>> listOfSimilarGroups = new ArrayList<>( setOfSimilarGroups );

		

		return new PreCodeGenerationProcessingResult();
	}

	
	private static void findDifference( TreeItem treeItem, TreeItem treeItem2 ) {

		
	}


	// TODO implement
	private static void reconstructTemplate() {

		
	}
	
	public static void main( String[] args ) throws Exception{
		
        String template = "TownAndCountryDisposalCOTemplateProvider";
        PullJobTemplate t = PlatformAccessor.getTemplate(template);
        TemplateTree tree = TemplateTree.getTemplateTree(t);
        
		PreCodeGenerationProcessor.process( tree );
	}
}

class PreCodeGenerationProcessingResult{
	
	private WebPullJobTemplate template;
	
	public WebPullJobTemplate getTemplate() {

		return template;
	}
}
