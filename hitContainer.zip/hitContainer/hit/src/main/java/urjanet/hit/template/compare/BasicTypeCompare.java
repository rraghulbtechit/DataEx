package urjanet.hit.template.compare;

import java.util.ArrayList;
import java.util.List;

import urjanet.hit.utils.TypeUtils;

public class BasicTypeCompare {

	public static List<Object> diff( Object object1, Object object2 ) throws UnsupportedComparisonException{
		
		if( object1 instanceof String )
			return diff( (String) object1, (String) object2 );
		
		if( object1 instanceof Boolean )
			return diff( (Boolean) object1, (Boolean) object2 );
		
		throw new UnsupportedComparisonException( "Comparison not implemented for " + object1.getClass() );
	}
	
	public static List<Object> diff( String string1, String string2 ){
		
		if( string1 != string2 ){
			return TypeUtils.arrayToList( string1 );
		}
		
		return new ArrayList<Object>();
	}
	
	public static List<Object> diff( Boolean boolean1, Boolean boolean2 ){
		
		if( boolean1 != boolean2 ){
			return TypeUtils.arrayToList( boolean1 );
		}
		
		return new ArrayList<Object>();
	}
	
	public static List<Object> diff( Class clazz1, Class clazz2 ){
		
		if( !clazz1.equals( clazz2 ))
			return TypeUtils.arrayToList( clazz1 );
		
		return new ArrayList<Object>();
	}
}
