package urjanet.hit.ui.view.attributes;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.Property;
import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.GroupPolicyButton;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.XmlTargetGroup;

/**
 * 
 */
public class XmlTargetGroupAttributes extends BaseTemplateAttributes {

    Logger log = LoggerFactory.getLogger( XmlTargetGroupAttributes.class );

    protected static final String resourcePath = "/XmlTargetGroupAttributes.fxml";

    @FXML protected TextField           baseXPathText;
    protected Property                  baseXPathProperty;
    @FXML protected TemplateButton      dataTargetsBtn;
    @FXML protected TemplateButton      navTargetsBtn;
    @FXML protected GroupPolicyButton   groupPolicyBtn;

    protected XmlTargetGroup            xmlTargetGroup = new XmlTargetGroup();

    public XmlTargetGroupAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        groupPolicyBtn.setEventFilter( groupPolicyFilter );
        
        for(MenuItem item : dataTargetsBtn.getItems()) {
            item.setOnAction( dataTargetHandler );
        }
        for(MenuItem item : navTargetsBtn.getItems()) {
            item.setOnAction( navTargetHandler );
        }

        baseXPathProperty = FXMLUtils.bindField(baseXPathText, xmlTargetGroup, "baseXPath");

        setTreeView( treeView );
        setTemplateItem( treeItem );
    }

    @Override
    public void setTreeView(TreeView treeView) {
        super.setTreeView( treeView );
        groupPolicyBtn.setTreeView( treeView );
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        super.setTreeItem( item );
        try {
            this.xmlTargetGroup = (XmlTargetGroup) item.getValue();
            baseXPathProperty = FXMLUtils.rebindField( baseXPathText, baseXPathProperty, xmlTargetGroup, "baseXPath" );
        } catch(ClassCastException e) {
            log.error("Incompatible object type received for XmlTargetGroup: " + item.getValue().getClass().getName());
        }
        //initialize groupPolicy button with current values.
        //groupPolicyFilter will set a new object if null when button is clicked
        groupPolicyBtn.setParentTreeItem( treeItem );
        groupPolicyBtn.setGroupPolicy( xmlTargetGroup.getGroupPolicy() );
        groupPolicyBtn.setTemplateTreeItem( treeItem.getChildItem( xmlTargetGroup.getGroupPolicy() ));
    }
    
    private EventHandler groupPolicyFilter = event -> {

        if( xmlTargetGroup.getGroupPolicy() == null ) {
            xmlTargetGroup.setGroupPolicy( new GroupPolicy() );
        }
        groupPolicyBtn.setGroupPolicy( xmlTargetGroup.getGroupPolicy() );
    };

    EventHandler dataTargetHandler = event -> {

        try {
        	TemplateTreeItem<T> dataTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTarget newTarget = ((DataTarget)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor
            List<DataTarget> list = xmlTargetGroup.getDataTargets();
            DataTarget insertAfter;
            if( list != null && list.size() > 0 ) {
                if(! (newTarget.getClass().isAssignableFrom(list.get(0).getClass())))
                    throw new HiTException("Cannot add incompatible types to list of DataTargets" );
                list = new ArrayList<>( list );
                insertAfter = list.get( list.size()-1 );
                list.add( newTarget );
            } else {
                list = new ArrayList<>();
                insertAfter = null;
                list.add(newTarget);
            }

            //this.treeItem.getChildren().clear();
            xmlTargetGroup.setDataTargets(list);
            
            dataTargetItem = new TemplateTreeItem( newTarget );
            addSelectNode(dataTargetItem, insertAfter);
            
            //this.treeItem.setChildrenAssigned( false );
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch( HiTException e ) {
            System.out.println( e );
        }
    };

    EventHandler navTargetHandler = event -> {

        try {
        	TemplateTreeItem<T> navTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            NavTarget newTarget = (NavTarget)(Class.forName(targetClassName).newInstance()); //TODO handle classes without no arg c'tor eg CustomRequestNavTarget
            List<NavTarget> list = xmlTargetGroup.getNavTargets();
            NavTarget insertAfter;
            if( list != null && list.size() > 0 ) {
                if(! (newTarget.getClass().isAssignableFrom(list.get(0).getClass())))
                    throw new HiTException("Cannot add incompatible types to list of NavTargets.");
                list = new ArrayList<>( list );
                insertAfter = list.get( list.size()-1 );
                list.add( newTarget );
            } else {
                list = new ArrayList<>();
                insertAfter = null;
                list.add(newTarget);
            }

            //this.treeItem.getChildren().clear();
            xmlTargetGroup.setNavTargets( list );
            //this.treeItem.setChildrenAssigned( false );
            navTargetItem = new TemplateTreeItem( newTarget );
            addSelectNode(navTargetItem, insertAfter);
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch( HiTException e ) {
            System.out.println(e);
        }
    };


    @Override
    protected void onHide() {

    	/*GroupPolicy policy = xmlTargetGroup.getGroupPolicy();
        policy = groupPolicyAttributes.getGroupPolicy(policy);
        if(policy != null) {
            xmlTargetGroup.setGroupPolicy(policy);
        }*/
    }

}
