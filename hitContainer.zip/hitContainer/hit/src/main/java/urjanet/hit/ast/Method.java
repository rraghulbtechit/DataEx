package urjanet.hit.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class Method {

	protected String methodName;
	protected List<Object> parameters = new ArrayList<Object>();
	
	public Method( String methodName ) {
		
		this.methodName = methodName;
	}
	public Method setMethodName( String methodName ){
		
		this.methodName = methodName;
		return this;
	}
	
	public String getMethodName(){
	
		return methodName;
	}
	
	public Method addParameter( Object... object ){
	
		return addParameter( Arrays.asList( object ) );
	}
	
	public Method addParameter( List object ){
		
		parameters.addAll( object );
		
		return this;
	}
	
		
	public List<Object> getParameters(){
		return parameters;
	}
}
