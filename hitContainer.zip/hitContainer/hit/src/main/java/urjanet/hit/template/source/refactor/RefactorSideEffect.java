package urjanet.hit.template.source.refactor;

import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

@Deprecated
public abstract class RefactorSideEffect {
	
	public abstract void apply( TypeDeclaration typeDeclaration, BodyDeclaration bodyDeclaration );

}
