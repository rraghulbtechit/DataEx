package urjanet.hit.template.source.refactor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.internal.compiler.ast.Argument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;
import urjanet.hit.utils.TypeUtils;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.pdf.PdfDataTarget;


@Deprecated
public class TemplateRefactor {

	private static final Logger log = LoggerFactory.getLogger(TemplateItemBuilderFactory.class);
	
	private static List<String> listOfTypeArgumentOnWhichExtractMethod = Arrays.asList( "GroupPolicy" );

	private static Map<Expression, RefactorInfo> refactorMarkupMap = new HashMap<>();
	
	public static void refactorTemplate( TypeDeclaration typeDeclaration, ClassInstanceCreation templateItem ){
		
		traverseArgumentsAndRefactor(typeDeclaration, templateItem, null);
	}

	private static RefactorResult traverseArgumentsAndRefactor(TypeDeclaration typeDeclaration, Expression templateItem, List siblingArguments) {

		RefactorInfo refactorInfo = resolveRefactor(templateItem);
		
		
		List<Expression> arguments = null;
		arguments = getArguments( templateItem );
		
		for (int i = 0; i < arguments.size(); i++) {
			RefactorResult refactorResult2 = traverseArgumentsAndRefactor(typeDeclaration, arguments.get(i), arguments);
			if( refactorResult2 != null)
				arguments.set(i, refactorResult2.getExtractInvocation());
		}
		
		RefactorResult refactorResult = refactor(typeDeclaration, refactorInfo, templateItem);
		return refactorResult;
	}

	
	private static RefactorResult refactor( TypeDeclaration typeDeclaration, RefactorInfo refactorInfo, Expression expression ){
		
		RefactorResult refactorResult = null;
		
		List<RefactorAction> refactorActions = refactorInfo.getRefactorActions();
		List<RefactorSideEffect> refactorSideEffects = refactorInfo.getRefactorSideEffects();
		
		for (RefactorAction refactorAction : refactorActions) {
			refactorResult = refactorAction.refactor(typeDeclaration, expression);
		}
		
		for (RefactorSideEffect refactorSideEffect : refactorSideEffects) {
			refactorSideEffect.apply(typeDeclaration, refactorResult.getExtract());
		}
		return refactorResult;
	}
	
	private static List<Expression> getArguments(Expression expression) {

		if( expression instanceof ClassInstanceCreation )
			return ((ClassInstanceCreation) expression).arguments();
		else if( expression instanceof MethodInvocation )
			return ((MethodInvocation) expression).arguments();
		
		return new ArrayList<>();
	}

	private static String getIdentifierForMethodReturning(Expression returnType) {
		
		if( TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) returnType).getType(), WebPullJobTemplate.class))
			return "getTemplate";
		else if(TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) returnType).getType(), BasePageSpec.class))
			return "getPdfPageSpec";
		else if(TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) returnType).getType(), PdfDataTarget.class)){
			
			// TODO dirty..too dirty
			List<Expression> arguments = ((ClassInstanceCreation) returnType).arguments();
			for (Expression expression : arguments) {
				if ( expression instanceof ClassInstanceCreation && 
					((ClassInstanceCreation)expression ).getType().toString().equals("GroupPolicy")){
					return ((ClassInstanceCreation)expression ).arguments().get(0).toString().replace("\"", "");
				}
			}
		}
			
		
		return "MISSING_METHOD_NAME";
	}

	private static RefactorInfo resolveRefactor(Expression expression){
		
//		RefactorInfo refactorInfo = null;
		RefactorInfo refactorInfo = new RefactorInfo( expression );
		AST ast = expression.getAST();
		
		if( expression instanceof ClassInstanceCreation){
			if ( TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) expression).getType(), WebPullJobTemplate.class)){
				
				refactorInfo = new RefactorInfo( expression );
				ExtractMethod extractMethod = new ExtractMethod();
				extractMethod.setMethodName( getIdentifierForMethodReturning(expression));
				extractMethod.addModifier( JavaElementBuilder.createPublicModifier(ast));
				refactorInfo.addRefactorAction(extractMethod);
				
				AddSuperInterfaceToTypeDeclaration addSuperInterfaceToTypeDeclaration = new AddSuperInterfaceToTypeDeclaration();
				addSuperInterfaceToTypeDeclaration.addSuperInterface( JavaElementBuilder.createSimpleType(ast, "TemplateProvider"));
				refactorInfo.addRefactorSideEffect( addSuperInterfaceToTypeDeclaration );
			
			} else if (TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) expression).getType(), BasePageSpec.class)){
				
				refactorInfo = new RefactorInfo( expression );
				ExtractMethod extractMethod = new ExtractMethod();
				extractMethod.setMethodName( getIdentifierForMethodReturning(expression));
				extractMethod.addModifier( JavaElementBuilder.createPublicModifier(ast));
				refactorInfo.addRefactorAction(extractMethod);
				
				AddSuperInterfaceToTypeDeclaration addSuperInterfaceToTypeDeclaration = new AddSuperInterfaceToTypeDeclaration();
				addSuperInterfaceToTypeDeclaration.addSuperInterface( JavaElementBuilder.createSimpleType(ast, "PdfPageSpecProvider"));
				refactorInfo.addRefactorSideEffect( addSuperInterfaceToTypeDeclaration );
				
			} else if (TypeUtils.isEquivalentType((SimpleType) ((ClassInstanceCreation) expression).getType(), PdfDataTarget.class)){
				
				if ( doesTypeContainsMethodExtractableTypeArgument( (ClassInstanceCreation) expression )){
					ExtractMethod extractMethod = new ExtractMethod();
					extractMethod.setMethodName( getIdentifierForMethodReturning(expression));
					
					extractMethod.addModifier( JavaElementBuilder.createPublicModifier(ast));
					
					refactorInfo = new RefactorInfo( expression );
					refactorInfo.addRefactorAction(extractMethod);
				}
			}
			
		}
		return refactorInfo;
		
	}
	
	private static boolean doesTypeContainsMethodExtractableTypeArgument( ClassInstanceCreation classInstanceCreation ) {
		
		
		List<Expression> arguments = classInstanceCreation.arguments();
		for (Expression expression : arguments) {
			if ( expression instanceof ClassInstanceCreation &&
				listOfTypeArgumentOnWhichExtractMethod.contains(((ClassInstanceCreation)expression ).getType().toString()))
				return true;
		}
		return false;
	}
}