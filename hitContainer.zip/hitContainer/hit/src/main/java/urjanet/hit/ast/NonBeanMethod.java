package urjanet.hit.ast;

public class NonBeanMethod extends Method{


	public NonBeanMethod( String methodName ) {
		
		super( methodName );
	}
}
