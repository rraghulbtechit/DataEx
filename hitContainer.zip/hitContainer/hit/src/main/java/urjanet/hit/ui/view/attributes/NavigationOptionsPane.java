package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.pull.web.AgentVersion;
import urjanet.pull.web.AjaxProcessing;
import urjanet.pull.web.NavigationOptions;
import urjanet.pull.web.WebClientInstance;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * NavigationOptions embeddable TitledPane component. @fx:include the fxml to embed the component.
 */
public class NavigationOptionsPane implements Initializable {

    private static final String resourcePath = "/NavigationOptions.fxml";

    @FXML private ComboBox  agentVersionCb;
    private Property agentVersionProperty;
    @FXML private ComboBox  webclientInstanceCb;
    private Property webclientInstanceProperty;
    @FXML private CheckBox  clearCookiesCheck;
    private Property  clearCookiesProperty;
    @FXML private CheckBox  concurrentAccessOkCheck;
    private Property  concurrentAccessOkProperty;
    @FXML private CheckBox  ignoreSubsequentRefreshCheck;
    private Property  ignoreSubsequentRefreshProperty;
    @FXML private CheckBox  needsReinitializationCheck;
    private Property  needsReinitializationProperty;
    @FXML private CheckBox  retryOnScriptExceptionCheck;
    private Property  retryOnScriptExceptionProperty;
    @FXML private CheckBox  clearCacheCheck;
    private Property  clearCacheProperty;
    @FXML private CheckBox  refreshResponseFromServerCheck;
    private Property  refreshResponseFromServerProperty;
    @FXML private TextField  waitForJavascriptText;
    private Property  waitForJavascriptProperty;
    @FXML private TextField  waitForJavascriptBeforeText;
    private Property  waitForJavascriptBeforeProperty;
    @FXML private CheckBox  tryHandleExceptionCheck;
    private Property  tryHandleExceptionProperty;
    @FXML private CheckBox  forceJavascriptProcessingCheck;
    private Property  forceJavascriptProcessingProperty;
    @FXML private CheckBox  disableJavascriptCheck;
    private Property  disableJavascriptProperty;
    @FXML private CheckBox  rerenderAjaxCheck;
    private Property  rerenderAjaxProperty;
    @FXML private CheckBox  disableAjaxControllerCheck;
    private Property  disableAjaxControllerProperty;
    @FXML private CheckBox  waitForJavascriptOnOriginalPageCheck;
    private Property  waitForJavascriptOnOriginalPageProperty;
    @FXML private CheckBox  disableExceptionOnScriptErrorCheck;
    private Property  disableExceptionOnScriptErrorProperty;
    @FXML private CheckBox  doNotCloseWindowsCheck;
    private Property  doNotCloseWindowsProperty;
    @FXML private CheckBox  doNotApplyPageHistoryCheck;
    private Property  doNotApplyPageHistoryProperty;
    @FXML private CheckBox  clearHtmlUnitTemporaryFilesCheck;
    private Property  clearHtmlUnitTemporaryFilesProperty;
    @FXML private CheckBox  useBasicAuthCheck;
    private Property  useBasicAuthProperty;
    @FXML private TextField interceptorNameText;
    private Property interceptorNameProperty;
    @FXML private TextField timeoutText;
    private Property timeoutProperty;
    @FXML private TextField handleRefreshesUnderSecondsText;
    private Property handleRefreshesUnderSecondsProperty;
    @FXML private TextField numberOfRetriesText;
    private Property numberOfRetriesProperty;
    @FXML private TextField allowedStatusCodesText;
    private Property allowedStatusCodesProperty;
    @FXML private TextField handleJavascriptAlertsText;
    private Property handleJavascriptAlertsProperty;
    @FXML private TextField sslProtocolText;
    private Property sslProtocolProperty;
    @FXML private CheckBox  useInsecureSslCheck;
    private Property  useInsecureSslProperty;
    @FXML private ComboBox  ajaxProcessingCb;
    private Property  ajaxProcessingProperty;
    @FXML private CheckBox  doNotReloadOriginalPageCheck;
    private Property  doNotReloadOriginalPageProperty;

    private NavigationOptions navOptions = NavigationOptions.getDefaultOptions();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            agentVersionCb.getItems().addAll(AgentVersion.values());
            webclientInstanceCb.getItems().addAll(WebClientInstance.values());
            ajaxProcessingCb.getItems().addAll(AjaxProcessing.values());

            agentVersionProperty = FXMLUtils.bindField(agentVersionCb, navOptions, "agentVersion");
            webclientInstanceProperty = FXMLUtils.bindField(webclientInstanceCb, navOptions, "webClientInstance");
            clearCookiesProperty = FXMLUtils.bindField(clearCookiesCheck, navOptions, "clearCookies");
            concurrentAccessOkProperty = FXMLUtils.bindField(concurrentAccessOkCheck, navOptions, "concurrentAccessOk");
            ignoreSubsequentRefreshProperty = FXMLUtils.bindField(ignoreSubsequentRefreshCheck, navOptions, "ignoreSubsequentRefresh");
            needsReinitializationProperty = FXMLUtils.bindField(needsReinitializationCheck, navOptions, "needsReinitialization");
            retryOnScriptExceptionProperty = FXMLUtils.bindField(retryOnScriptExceptionCheck, navOptions, "retryOnScriptException");
            clearCacheProperty = FXMLUtils.bindField(clearCacheCheck, navOptions, "clearCache");
            refreshResponseFromServerProperty = FXMLUtils.bindField(refreshResponseFromServerCheck, navOptions, "refreshResponseFromServer");
            waitForJavascriptBeforeProperty = FXMLUtils.bindField(waitForJavascriptBeforeText, navOptions, "waitForJavascriptBefore");
            tryHandleExceptionProperty = FXMLUtils.bindField(tryHandleExceptionCheck, navOptions, "tryHandleException");
            forceJavascriptProcessingProperty = FXMLUtils.bindField(forceJavascriptProcessingCheck, navOptions, "forceJavaScriptProcessing");
            disableJavascriptProperty = FXMLUtils.bindField(disableJavascriptCheck, navOptions, "disableJavaScript");
            rerenderAjaxProperty = FXMLUtils.bindField(rerenderAjaxCheck, navOptions, "rerenderAjax");
            //TODO FXMLUtils.bindField(disableAjaxControllerCheck, navOptions, "disableAjaxController");
            waitForJavascriptOnOriginalPageProperty = FXMLUtils.bindField(waitForJavascriptOnOriginalPageCheck, navOptions, "waitForJavascriptOnOriginalPage");
            disableAjaxControllerProperty = FXMLUtils.bindField(disableExceptionOnScriptErrorCheck, navOptions, "disableExceptionOnScriptError");
            doNotCloseWindowsProperty = FXMLUtils.bindField(doNotCloseWindowsCheck, navOptions, "doNotCloseAllWindows");
            doNotApplyPageHistoryProperty = FXMLUtils.bindField(doNotApplyPageHistoryCheck, navOptions, "doNotApplyPageHistory");
            clearHtmlUnitTemporaryFilesProperty = FXMLUtils.bindField(clearHtmlUnitTemporaryFilesCheck, navOptions, "clearHtmlUnitTemporaryFiles");
            useBasicAuthProperty = FXMLUtils.bindField(useBasicAuthCheck, navOptions, "useBasicAuth");

            interceptorNameProperty = FXMLUtils.bindField(interceptorNameText, navOptions, "interceptorName");
            waitForJavascriptProperty = FXMLUtils.bindField(waitForJavascriptText, navOptions, "waitForJavascript");
            timeoutProperty = FXMLUtils.bindField(timeoutText, navOptions, "timeout");
            handleRefreshesUnderSecondsProperty = FXMLUtils.bindField(handleRefreshesUnderSecondsText, navOptions, "handleRefreshesUnderSeconds");
            numberOfRetriesProperty = FXMLUtils.bindField(numberOfRetriesText, navOptions, "numberOfRetries");
            allowedStatusCodesProperty = FXMLUtils.bindField(allowedStatusCodesText, navOptions, "allowedStatusCodes"); //TODO List<Integer> <-> Text
            handleJavascriptAlertsProperty = FXMLUtils.bindField(handleJavascriptAlertsText, navOptions, "handleJavascriptAlerts"); //TODO List<String> <-> Text

            sslProtocolProperty = FXMLUtils.bindField(sslProtocolText, navOptions, "sslProtocol");
            useInsecureSslProperty = FXMLUtils.bindField(useInsecureSslCheck, navOptions, "useInsecureSSL");
            ajaxProcessingProperty = FXMLUtils.bindField(ajaxProcessingCb, navOptions, "ajaxProcessing");
            doNotReloadOriginalPageProperty = FXMLUtils.bindField(doNotReloadOriginalPageCheck, navOptions, "doNotReloadOriginalPage");
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    public void setNavigationOptions( NavigationOptions options ) throws HiTException {

        this.navOptions = options;

        //bind
        agentVersionProperty = FXMLUtils.rebindField(agentVersionCb, agentVersionProperty, navOptions, "agentVersion");
        webclientInstanceProperty = FXMLUtils.rebindField(webclientInstanceCb, webclientInstanceProperty, navOptions, "webClientInstance");
        clearCookiesProperty = FXMLUtils.rebindField(clearCookiesCheck, clearCookiesProperty, navOptions, "clearCookies");
        concurrentAccessOkProperty = FXMLUtils.rebindField(concurrentAccessOkCheck, concurrentAccessOkProperty, navOptions, "concurrentAccessOk");
        ignoreSubsequentRefreshProperty = FXMLUtils.rebindField(ignoreSubsequentRefreshCheck, ignoreSubsequentRefreshProperty, navOptions, "ignoreSubsequentRefresh");
        needsReinitializationProperty = FXMLUtils.rebindField(needsReinitializationCheck, needsReinitializationProperty, navOptions, "needsReinitialization");
        retryOnScriptExceptionProperty = FXMLUtils.rebindField(retryOnScriptExceptionCheck, retryOnScriptExceptionProperty, navOptions, "retryOnScriptException");
        clearCacheProperty = FXMLUtils.rebindField(clearCacheCheck, clearCacheProperty, navOptions, "clearCache");
        refreshResponseFromServerProperty = FXMLUtils.rebindField(refreshResponseFromServerCheck, refreshResponseFromServerProperty,navOptions, "refreshResponseFromServer");
        waitForJavascriptBeforeProperty = FXMLUtils.rebindField(waitForJavascriptBeforeText, waitForJavascriptBeforeProperty, navOptions, "waitForJavascriptBefore");
        tryHandleExceptionProperty = FXMLUtils.rebindField(tryHandleExceptionCheck, tryHandleExceptionProperty, navOptions, "tryHandleException");
        forceJavascriptProcessingProperty = FXMLUtils.rebindField(forceJavascriptProcessingCheck, forceJavascriptProcessingProperty, navOptions, "forceJavaScriptProcessing");
        disableJavascriptProperty = FXMLUtils.rebindField(disableJavascriptCheck, disableJavascriptProperty, navOptions, "disableJavaScript");
        rerenderAjaxProperty = FXMLUtils.rebindField(rerenderAjaxCheck, rerenderAjaxProperty, navOptions, "rerenderAjax");
        //TODO FXMLUtils.rebindField(disableAjaxControllerCheck, navOptions, "disableAjaxController");
        waitForJavascriptOnOriginalPageProperty = FXMLUtils.rebindField(waitForJavascriptOnOriginalPageCheck, waitForJavascriptOnOriginalPageProperty, navOptions, "waitForJavascriptOnOriginalPage");
        disableExceptionOnScriptErrorProperty = FXMLUtils.rebindField(disableExceptionOnScriptErrorCheck, disableExceptionOnScriptErrorProperty, navOptions, "disableExceptionOnScriptError");
        doNotCloseWindowsProperty = FXMLUtils.rebindField(doNotCloseWindowsCheck, doNotCloseWindowsProperty, navOptions, "doNotCloseAllWindows");
        doNotApplyPageHistoryProperty = FXMLUtils.rebindField(doNotApplyPageHistoryCheck, doNotApplyPageHistoryProperty, navOptions, "doNotApplyPageHistory");
        clearHtmlUnitTemporaryFilesProperty = FXMLUtils.rebindField(clearHtmlUnitTemporaryFilesCheck, clearHtmlUnitTemporaryFilesProperty, navOptions, "clearHtmlUnitTemporaryFiles");
        useBasicAuthProperty = FXMLUtils.rebindField(useBasicAuthCheck, useBasicAuthProperty, navOptions, "useBasicAuth");

        interceptorNameProperty = FXMLUtils.rebindField(interceptorNameText, interceptorNameProperty, navOptions, "interceptorName");
        waitForJavascriptProperty = FXMLUtils.rebindField(waitForJavascriptText, waitForJavascriptProperty, navOptions, "waitForJavascript");
        timeoutProperty = FXMLUtils.rebindField(timeoutText, timeoutProperty, navOptions, "timeout");
        handleRefreshesUnderSecondsProperty = FXMLUtils.rebindField(handleRefreshesUnderSecondsText, handleRefreshesUnderSecondsProperty, navOptions, "handleRefreshesUnderSeconds");
        numberOfRetriesProperty = FXMLUtils.rebindField(numberOfRetriesText, numberOfRetriesProperty, navOptions, "numberOfRetries");
        allowedStatusCodesProperty = FXMLUtils.rebindField(allowedStatusCodesText, allowedStatusCodesProperty, navOptions, "allowedStatusCodes"); //TODO List<Integer> <-> Text
        handleJavascriptAlertsProperty = FXMLUtils.rebindField(handleJavascriptAlertsText, handleJavascriptAlertsProperty, navOptions, "handleJavascriptAlerts"); //TODO List<String> <-> Text

        sslProtocolProperty = FXMLUtils.rebindField(sslProtocolText, sslProtocolProperty, navOptions, "sslProtocol");
        useInsecureSslProperty = FXMLUtils.rebindField(useInsecureSslCheck, useInsecureSslProperty, navOptions, "useInsecureSSL");
        ajaxProcessingProperty = FXMLUtils.rebindField(ajaxProcessingCb, ajaxProcessingProperty, navOptions, "ajaxProcessing");
        doNotReloadOriginalPageProperty = FXMLUtils.rebindField(doNotReloadOriginalPageCheck, doNotReloadOriginalPageProperty, navOptions, "doNotReloadOriginalPage");
    }
}
