package urjanet.hit.template.source.builder.item;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.InlineMethodGeneration;
import urjanet.hit.ast.Method;
import urjanet.hit.ast.MethodDeclarationAndInvocation;
import urjanet.hit.ast.Setter;
import urjanet.hit.ast.VariableDeclarationAndSubstitution;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.utils.DefaultValue;
import urjanet.hit.utils.StringOperations;
import urjanet.keys.AddressKeys;
import urjanet.keys.DataValues;
import urjanet.keys.MeterKeys;
import urjanet.keys.uds.GroupingKeys;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfPageDataTarget;

public class DataTargetBuilder implements TemplateItemBuilder {

	private static final Logger log = LoggerFactory.getLogger(DataTargetBuilder.class);
	
	private static final DataTargetBuilder theInstance = new DataTargetBuilder();
	
	public static DataTargetBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private DataTargetBuilder() {}
	
	/////////////////////////////////////////////// Resolve Type of DataTarget //////////////////////////////////////////////////////
	
	@Override
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, final Object object, final TypeTracker typeTracker) {

		if( object instanceof PdfDataTarget )
			return createTemplateItem( typeDeclaration, methodDeclaration, (PdfDataTarget)object, typeTracker );
		else if( object instanceof PdfPageDataTarget )
			return createTemplateItem( typeDeclaration, methodDeclaration, (PdfPageDataTarget)object, typeTracker );
		
		return null;
	}
	
	@Override
	public Expression createClassInstance(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker) {
		
		if( object instanceof PdfDataTarget )
			return createClassInstance( typeDeclaration, methodDeclaration, (PdfDataTarget)object, typeTracker );
		else if( object instanceof PdfPageDataTarget )
			return createClassInstance( typeDeclaration, methodDeclaration, (PdfPageDataTarget)object, typeTracker );
		
		return null;

	}

	//////////////////////////////////////////// Pdf Data Target Specific code ///////////////////////////////////////////////////////
	
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, final PdfDataTarget pdfDataTarget, final TypeTracker typeTracker) {

		if( pdfDataTarget.getGroupPolicy() == null ) {
			return createClassInstance( typeDeclaration, methodDeclaration, pdfDataTarget, typeTracker );
		} else{
			return new MethodDeclarationAndInvocation(typeDeclaration, methodDeclaration, pdfDataTarget, typeTracker)
				.setMethodName( getMethodName( pdfDataTarget ) )
				.declareAndReturnInvocation();
		}	
	}
	
	public Expression createClassInstance(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, PdfDataTarget object, final TypeTracker typeTracker) {
		
		List<String> inlineSetterProperties = Arrays.asList( "qualifier", "defaultValue"  );

		List<Method> inLineSetters = InlineMethodGeneration.generate( object, inlineSetterProperties );

		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker)
			.setInlineMethodChain(
				inLineSetters)
			.instantiate();
	}
	
	public String getMethodName( PdfDataTarget incomingParameter ){
		
		String methodName = null;
		if ( incomingParameter.getGroupPolicy() != null)
			methodName = getMethodNameForGroupDataTarget(incomingParameter);
		log.trace("creating method with name " + methodName + " for object " + incomingParameter);
		
		return methodName;
	}
	
	////////////////////////////////////////// PDF Page Data Target Specific code /////////////////////////////////////////////////////
	
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, PdfPageDataTarget object, final TypeTracker typeTracker) {
	
		if ( isPdfPageDataTargetWithStatementGroup( object ) ){
			
			Expression classInstantiation = new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker)
				.instantiate();
			
			return new VariableDeclarationAndSubstitution(typeDeclaration, methodDeclaration, classInstantiation, typeTracker)
				.setIdentifier( "rootTarget" )
				.declareAndSubstitute();
		} else {
			
			return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
		}
	}

	public Expression createClassInstance(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, PdfPageDataTarget object, final TypeTracker typeTracker) {
		
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
	}
	
	private static boolean isPdfPageDataTargetWithStatementGroup( PdfPageDataTarget pdfPageDataTarget) {

		List<? extends DataTarget> relativeDataTargets = pdfPageDataTarget.getRelativeDataTargets();
	
		for (DataTarget dataTarget : relativeDataTargets) {
			GroupPolicy groupPolicy = dataTarget.getGroupPolicy();
			if ( groupPolicy != null ){
				if ( groupPolicy.getGroupName().equals( GroupingKeys.STATEMENT_GROUP.getValue()) )
					return true;
			}
		}

		return false;
	}


	///////////////////////////////////// Common Data Target code //////////////////////////////////////////////////////////////////////////

	
	
	
	private static String getMethodNameForGroupDataTarget(final PdfDataTarget incomingParameter ) {

		String groupName = incomingParameter.getGroupPolicy().getGroupName();
		List<? extends DataTarget> relativeDataTaget = incomingParameter.getRelativeDataTargets();
		String methodName = null;
		try {
			if ( groupName.equals( GroupingKeys.ADDRESS_GROUP.getValue())) {
				if (relativeDataTaget != null) {
					String addressTypeId = null;
					for (DataTarget dataTarget : relativeDataTaget) {
						if( dataTarget.getName().equals( AddressKeys.ADDRESS_TYPE_ID.getValue())){
							addressTypeId = dataTarget.getDefaultValue();
						}
					}
					if ( addressTypeId != null){
						addressTypeId = StringOperations.capitalizeFirstLetter(addressTypeId.split("_")[0]);
						groupName = StringOperations.capitalizeFirstLetter(groupName);
						methodName = "get" + addressTypeId + groupName;
					} else {
						throw new HiTException("Address group with no ADDRESS_TYPE_ID. That don't seem right" );
					}
				} else {
					throw new HiTException("A PdfDataTarget with a groupPolicy but no relative dataTargets. You sure your template is right?");
				} 
			} else {
				return "get" + StringOperations.capitalizeFirstLetter(groupName);
			}
		} catch (HiTException e) {

			e.printStackTrace();
		}
		
		return methodName;
	}
	
	public static void main( String[] args ) {

		AST ast = AST.newAST( AST.JLS3 );
		CompilationUnit cu = ast.newCompilationUnit();
		TypeTracker typeTracker = new TypeTracker( cu );
		
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  "Sample" );
		cu.types().add(typeDeclaration);
		
		MethodDeclaration methodDeclaration = null;
		methodDeclaration = JavaElementBuilder.createMethodDeclaration(ast, "Test");

		PdfDataTarget meterGroup = new PdfDataTarget(
			new GroupPolicy( GroupingKeys.METER_GROUP.getValue() ),
		Arrays.asList(
			new PdfDataTarget(MeterKeys.RATE_OR_TARIFF_ACTUAL_NAME.getValue()).setDefaultValue(DataValues.UNKNOWN_TARIFF.getValue()),
			new PdfDataTarget(MeterKeys.DEREGULATION_STATUS_ID.getValue()).setDefaultValue(DataValues.FULL_SERVICE.getValue()),
			new PdfDataTarget(MeterKeys.SERVICE_TYPE_ID.getValue()).setDefaultValue(DataValues.SANITATION.getValue()),
			new PdfDataTarget( MeterKeys.POD_NUMBER.getValue() )
			));
					
		System.out.println( new DataTargetBuilder().createTemplateItem( typeDeclaration, methodDeclaration, meterGroup, typeTracker ) );
		System.out.println( typeDeclaration );
	}

}
