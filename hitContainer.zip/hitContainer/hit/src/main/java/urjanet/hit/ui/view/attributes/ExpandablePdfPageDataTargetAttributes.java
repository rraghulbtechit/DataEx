package urjanet.hit.ui.view.attributes;

import javafx.scene.control.TreeView;
import urjanet.hit.ui.view.tree.TemplateTreeItem;

public class ExpandablePdfPageDataTargetAttributes extends PdfPageDataTargetAttributes {
	
	public ExpandablePdfPageDataTargetAttributes(TemplateTreeItem treeItem, TreeView treeView) {
		super(treeItem, treeView);
	}

}
