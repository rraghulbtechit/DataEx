package urjanet.hit.ui.view.attributes.contextKeys;

import java.net.URL;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.PdfPageDataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.filter.DirectionFilter;
import urjanet.pull.web.pdf.filter.HorizontalFilter;
import urjanet.pull.web.pdf.filter.RangeFilter;
import urjanet.pull.web.pdf.filter.VerticalFilter;
import urjanet.pull.web.pdf.key.ContextKey;

public class KeysAttributes implements Initializable, TemplateAttributesPane {
	
	public static final String resourcePath = "/KeysAttributes.fxml";
	
	@FXML protected TemplateButton contextKeysBtn;
	
	private TemplateTreeItem treeItem;
    private TreeView treeView;
    
    private ContextFilter contextFilter;
    private PdfPageDataTarget pdfPageDataTarget;
    private ExpandablePdfDataTarget expandablePdfDataTarget;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		for(MenuItem item : contextKeysBtn.getItems()) {
            item.setOnAction( contextKeyItemHandler );
        }
	}
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		
		if(item.getValue() instanceof ContextFilter)
			this.contextFilter = (ContextFilter) item.getValue();
		else if(item.getValue() instanceof PdfPageDataTarget) {
			this.contextFilter = null;
			this.pdfPageDataTarget = (PdfPageDataTarget) item.getValue();
		} else {
			this.contextFilter = null;
			this.pdfPageDataTarget = null;
			this.expandablePdfDataTarget = (ExpandablePdfDataTarget) item.getValue();
		}
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
	}

	private EventHandler<ActionEvent> contextKeyItemHandler = event -> {
		try {
        	
        	TemplateTreeItem<T> keyItem;
        	
            String filterClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            ContextKey contextKey = ((ContextKey)Class.forName(filterClassName).newInstance()); //TODO handle classes without arg-less c'tor
            
            if(contextFilter != null) {
	            if(contextFilter instanceof DirectionFilter) {
	            	this.treeItem.getChildren().clear();
	            	((DirectionFilter)contextFilter).setKey(contextKey);
	            } else if(contextFilter instanceof HorizontalFilter) {
	            	this.treeItem.getChildren().clear();
	            	((HorizontalFilter)contextFilter).setStartKey(contextKey);
	            } else if(contextFilter instanceof VerticalFilter) {
	            	this.treeItem.getChildren().clear();
	            	((VerticalFilter)contextFilter).setStartKey(contextKey);
	            } else if(contextFilter instanceof RangeFilter) {
	            	
	            	RangeFilter rangeFilter = ((RangeFilter)contextFilter);
	            	if(rangeFilter.getStartKey() == null)
	            		rangeFilter.setStartKey(contextKey);
	            	else 
	            		rangeFilter.setEndKey(contextKey);
	            }
            } else if(pdfPageDataTarget != null){
            	
            	if(pdfPageDataTarget.getStartQualifier() == null)
            		pdfPageDataTarget.setStartQualifier(contextKey);
            	else 
            		pdfPageDataTarget.setEndQualifier(contextKey);
            } else {
            	
            	expandablePdfDataTarget.setExpandableKey(contextKey);
            }
            
            keyItem = new TemplateTreeItem( contextKey );
            addSelectNode(keyItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
    
    private void addSelectNode(TemplateTreeItem templateTreeItem) {
        treeItem.getChildren().add(templateTreeItem);
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }
}