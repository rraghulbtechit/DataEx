package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.SimpleOperatorChain;

public class SimpleOperatorChainAttributes extends BaseTemplateAttributes<T> {
	
	public static final String resourcePath = "/SimpleOperatorChainAttributes.fxml";
	@FXML Pane extractOperatorPane;
	private ExtractOperatorAttributes extractOpAttr;
	
	private SimpleOperatorChain simpleOperatorChain ;
	
	public SimpleOperatorChainAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
		FXMLLoader loader = new FXMLUtils().loader(ExtractOperatorAttributes.resourcePath);
		
		extractOperatorPane.getChildren().add(loader.getRoot());
		extractOpAttr = loader.getController();
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof SimpleOperatorChain))
            throw new HiTException("Could not create Form for SimpleOperatorChain due to incompatible node. Received " + Obj.getClass());
        
        this.simpleOperatorChain = (SimpleOperatorChain) Obj;
        
        extractOpAttr.setTemplateItem(treeItem);
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        extractOpAttr.setTreeView(treeView);
	}

}
