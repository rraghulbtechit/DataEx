package urjanet.hit.ui.view.attributes.qualifier;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.StringQualifier;

public class StringQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/StringQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane;
	@FXML Pane comparisonDataTargetPane;
	
	@FXML CheckBox ignoreCaseCB;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private ComparisonDataTargetQualifierAttributes comparisonDataTargetAttr;
	private StringQualifier stringQualifier;
	
	public StringQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		FXMLLoader loaderComparisonQualifiers = new FXMLUtils().loader(ComparisonDataTargetQualifierAttributes.resourcePath);
		
        comparisonDataTargetPane.getChildren().add(loaderComparisonQualifiers.getRoot());
		comparisonDataTargetAttr = loaderComparisonQualifiers.getController();
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		comparisonDataTargetAttr.setTemplateItem(item);
		comparisonDataTargetAttr.setTreeView(treeView);
		
		stringQualifier = ((StringQualifier)item.getValue());
		
		FXMLUtils.unbindAll(this);
        //bind
        try {
            FXMLUtils.bindField(ignoreCaseCB, stringQualifier, "ignoreCase");
        } catch( Exception e ) {
            e.printStackTrace();
        }
	}
}