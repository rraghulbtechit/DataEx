package urjanet.hit.ui.view.attributes;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.beans.property.Property;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.DataTargetType;
import urjanet.hit.HiTException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.GroupPolicyButton;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.extractOperators.ExtractOperatorAttributes;
import urjanet.hit.ui.view.attributes.qualifier.DataTargetQualifierAttributes;
import urjanet.keys.Charges;
import urjanet.keys.DataValues;
import urjanet.keys.DomainKeys;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetOperationType;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.XmlDataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.reference.GroupReference;

public class DataTargetAttributes implements Initializable, TemplateAttributesPane {
	
	public static final String resourcePath = "/DataTargetAttributes.fxml";

	public static Logger log = LoggerFactory.getLogger( DataTargetAttributes.class );
	
	@FXML Pane extractOperatorPane;
	@FXML Pane qualifiersPane;
	
	@FXML protected ComboBox 			nameKeysCb;
	protected Property 					nameKeysProperty;
	@FXML protected ComboBox<DataTargetType> dataTargetTypeCb;
	protected Property 					dataTargetTypeProperty;
	@FXML protected ComboBox 			defaultValueCb;
	protected Property 					defaultValueProperty;
	@FXML protected CheckBox 			groupingTargetCB;
	protected Property 					groupingTargetProperty;
	@FXML protected TextField 			variableNameText;
	protected Property 					variableNameProperty;
	@FXML protected TextField 			formatHintText;
	protected Property 					formatHintProperty;
	@FXML protected TextField 			framePathText;
	protected Property 					framePathProperty;
	@FXML protected ComboBox<DataTargetOperationType> operationTypeCombo;
	protected Property 					operationTypeProperty;
	@FXML protected CheckBox 			isCorruptedPdfCheck;
	protected Property 					isCorruptedPdfProperty;

	@FXML protected GroupPolicyButton 	groupPolicyBtn;
	@FXML protected Button 				groupReferenceBtn;
	@FXML protected TemplateButton 		dataTargetsBtn;
	
	@FXML protected TemplateMenuItem    xmlDataTargetItem;
    @FXML protected TemplateMenuItem    expandableDataTargetItem;
    @FXML protected TemplateMenuItem    coordinateDataTargetItem;
    @FXML protected TemplateMenuItem    pdfDataTargetItem;
    @FXML protected TemplateMenuItem    expandablePdfDataTargetItem;
    @FXML protected TemplateMenuItem    pdfPageDataTargetItem;
    @FXML protected TemplateMenuItem    expandablePdfPageDataTargetItem;
    @FXML protected TemplateMenuItem    textDataTargetItem;
    @FXML protected TemplateMenuItem    expandableTextDataTargetItem;
	
    private ExtractOperatorAttributes 	extractOp;
    private DataTargetQualifierAttributes qualifierAttr;
	private DataTarget 					dataTarget;
    private TemplateTreeItem 			treeItem;
    private TreeView 					treeView;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		FXMLLoader loader = new FXMLUtils().loader(ExtractOperatorAttributes.resourcePath);
		extractOperatorPane.getChildren().add(loader.getRoot());
		extractOp = loader.getController();
		
		FXMLLoader loaderQualifiers = new FXMLUtils().loader(DataTargetQualifierAttributes.resourcePath);
		qualifiersPane.getChildren().add(loaderQualifiers.getRoot());
		qualifierAttr = loaderQualifiers.getController();
		
		for(MenuItem item : dataTargetsBtn.getItems()) {
            item.setOnAction( dataTargetHandler );
        }
		
		groupReferenceBtn.setOnAction( groupReferenceEventHandler );
		
		dataTargetTypeCb.getItems().addAll(FXCollections.observableArrayList(DataTargetType.values()));
		operationTypeCombo.getItems().addAll(FXCollections.observableArrayList(DataTargetOperationType.values()));

		defaultValueCb.getItems().addAll(DataValues.values());
		defaultValueCb.getItems().addAll(Charges.values());
		defaultValueCb.setEditable(true);

		groupPolicyBtn.setEventFilter( groupPolicyFilter );
	}


	public String getVariable() {
		if(variableNameText.getText() != null)
			return variableNameText.getText();
		else
			return null;
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;

		groupPolicyBtn.setTreeView( treeView );
		extractOp.setTreeView( treeView );
		qualifierAttr.setTreeView( treeView );
	}

	/*
	NOTE: For binding you cannot use FXMLUtils.rebind as DataTarget is an abstract class and will be null initially.
	*/
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        this.dataTarget = (DataTarget)item.getValue();
        
        if( dataTarget instanceof XmlDataTarget ) {
		    coordinateDataTargetItem.setVisible(false);
		    pdfDataTargetItem.setVisible(false);
		    expandablePdfDataTargetItem.setVisible(false);
		    pdfPageDataTargetItem.setVisible(false);
		    expandablePdfPageDataTargetItem.setVisible(false);
		    textDataTargetItem.setVisible(false);
		    expandableTextDataTargetItem.setVisible(false);
		} else if(dataTarget instanceof PdfDataTarget ) {
			xmlDataTargetItem.setVisible(false);
			expandableDataTargetItem.setVisible(false);
		}

		extractOp.setTemplateItem(treeItem);
		qualifierAttr.setTemplateItem(treeItem);
		/*DataTarget parentDataTarget = dataTarget.getParentDataTarget();
		if((parentDataTarget != null) && (parentDataTarget.getGroupPolicy() != null)) {
			groupName = parentDataTarget.getGroupPolicy().getGroupName();
		}*/
		//initialize groupPolicy button with current values.
		//groupPolicyFilter will set a new object if null when button is clicked
		groupPolicyBtn.setParentTreeItem( treeItem );
		groupPolicyBtn.setGroupPolicy( dataTarget.getGroupPolicy() );
		groupPolicyBtn.setTemplateTreeItem( treeItem.getChildItem( dataTarget.getGroupPolicy() ));

		if( nameKeysProperty != null ) FXMLUtils.unbindField( nameKeysCb, nameKeysProperty );
		nameKeysCb.getItems().clear();

        GroupPolicy grpPolicy = ( dataTarget.getGroupPolicy() == null )
				? GroupPolicyAttributes.findParentGroupPolicy( treeItem ) : dataTarget.getGroupPolicy();
		String groupName = ( grpPolicy != null ) ? grpPolicy.getGroupName() : PlatformAccessor.getRootGroup();
		Map<String, DomainKeys> allowedKeys = PlatformAccessor.getAllowedKeysForGroup(groupName);
		Collection<DomainKeys> keys = allowedKeys.values();
		keys.forEach( key -> nameKeysCb.getItems().add(key.getValue()));

        //bind
		nameKeysProperty = FXMLUtils.bindField( nameKeysCb, dataTarget, "name" );

		dataTargetTypeProperty = FXMLUtils.rebindField( dataTargetTypeCb, dataTargetTypeProperty, dataTarget, "type" );
		defaultValueProperty = FXMLUtils.rebindField( defaultValueCb, defaultValueProperty, dataTarget, "defaultValue" );
		groupingTargetProperty = FXMLUtils.rebindField( groupingTargetCB, groupingTargetProperty, dataTarget, "groupingTarget" );
		variableNameProperty = FXMLUtils.rebindField( variableNameText, variableNameProperty, dataTarget, "variableName", "getVariableName", "setVariable" );
		formatHintProperty = FXMLUtils.rebindField( formatHintText, formatHintProperty, dataTarget, "formatHint" );
		framePathProperty = FXMLUtils.rebindField( framePathText, framePathProperty, dataTarget, "framePath", "getFramePath", "setFrameNumber" );
		operationTypeProperty = FXMLUtils.rebindField(operationTypeCombo, operationTypeProperty, dataTarget, "operationType", "getDataTargetOperationType", "setDataTargetOperationType");
		isCorruptedPdfProperty = FXMLUtils.rebindField(isCorruptedPdfCheck, isCorruptedPdfProperty, dataTarget, "isCorruptedPdf", "isCorruptedPdf", "setCorruptedPdf");
    }


	private EventHandler groupPolicyFilter = event -> {

		if( dataTarget.getGroupPolicy() == null ) {
			dataTarget.setGroupPolicy( new GroupPolicy() );
		}
		groupPolicyBtn.setGroupPolicy( dataTarget.getGroupPolicy() );
	};
	
	private EventHandler dataTargetHandler = event -> {
        try {
        	TemplateTreeItem<T> dataTargetItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTarget newTarget = ((DataTarget)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor
            List<DataTarget> list = (List<DataTarget>) dataTarget.getRelativeDataTargets();
            if( list != null && list.size() > 0 ) {
                if(! (newTarget.getClass().isAssignableFrom(list.get(0).getClass())))
                    throw new HiTException("Cannot add incompatible types to list of DataTargets" );
                list = new ArrayList<>( list );
                list.add( newTarget );
            } else {
                list = new ArrayList<>();
                list.add(newTarget);
            }

            //this.treeItem.getChildren().clear();
            dataTarget.setRelativeDataTargets(list);
            
            dataTargetItem = new TemplateTreeItem( newTarget );
            addSelectNode(dataTargetItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch( HiTException e ) {
            System.out.println( e );
        }
    };

	//TODO Move this to TemplateTreeItem from here and other classes
    private void addSelectNode( TemplateTreeItem newItem ) {
        treeItem.getChildren().add(newItem);
        if( newItem != null )
            treeView.getSelectionModel().select(newItem);
    }
    
    private EventHandler groupReferenceEventHandler = event -> {
		
        GroupReference grpRef = new GroupReference();
        List<GroupReference> grpRefList = dataTarget.getReferences();
        List<GroupReference> grpRefFinalList;
        if( grpRefList == null ) {
            grpRefFinalList = new ArrayList<>();
        } else {
            grpRefFinalList = new ArrayList<>( grpRefList );
        }

        grpRefFinalList.add( grpRef );
        GroupReference[] gr = new GroupReference[grpRefFinalList.size()];
        dataTarget.addReference(grpRefFinalList.toArray(gr));
        TemplateTreeItem<GroupReference> targetGroupItem = new TemplateTreeItem<>(grpRef);
        addSelectNode(targetGroupItem);
	};

	public void onHide() {

		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}
}