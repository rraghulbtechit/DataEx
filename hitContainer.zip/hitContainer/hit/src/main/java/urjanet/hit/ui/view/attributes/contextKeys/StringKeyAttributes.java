package urjanet.hit.ui.view.attributes.contextKeys;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.key.KeyStructure;
import urjanet.pull.web.pdf.key.StringKey;

public class StringKeyAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/StringKeyAttributes.fxml";
	
	@FXML protected TitledPane stringKeyPane;
	@FXML protected Pane contextKeyPane;
	
	@FXML protected TextField keyTf;
	protected Property keyProperty;
	@FXML protected TextField fontRegExTf;
	protected Property fontRegExProperty;
	@FXML protected ComboBox structureCombo;
	protected Property structureProperty;
	@FXML protected CheckBox inverseSearchDirectionCb;
	protected Property inverseSearchDirectionProperty;
	
	private StringKey stringKey;
	private ContextKeyAttributes contextKeyAttributes;
	
	public StringKeyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(contextKeyAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loaderContextKey.getRoot());
		contextKeyAttributes = loaderContextKey.getController();
		
		structureCombo.getItems().addAll(KeyStructure.values());
		
		setTemplateItem(treeItem);
        setTreeView(treeView);
	}
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        contextKeyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof StringKey))
            throw new HiTException("Could not create Form for StringKey due to incompatible node. Received " + Obj.getClass());
        
        this.stringKey = (StringKey) Obj;
        
        addBinding();
        
        contextKeyAttributes.setTemplateItem(item);
	}
	
	private void addBinding() {

		try {
        	//bind
			if( keyProperty != null ) FXMLUtils.unbindField( keyTf, keyProperty );
			keyProperty = FXMLUtils.bindField(keyTf, stringKey, "key");
			
			if( fontRegExProperty != null ) FXMLUtils.unbindField( fontRegExTf, fontRegExProperty );
			fontRegExProperty = FXMLUtils.bindField(fontRegExTf, stringKey, "fontRegEx");
        	
        	if( structureProperty != null ) FXMLUtils.unbindField( structureCombo, structureProperty );
        	structureProperty = FXMLUtils.bindField(structureCombo, stringKey, "structure");
        	
        	if( inverseSearchDirectionProperty != null ) FXMLUtils.unbindField( inverseSearchDirectionCb, inverseSearchDirectionProperty );
        	inverseSearchDirectionProperty = FXMLUtils.bindField(inverseSearchDirectionCb, stringKey, "inverseSearchDirection");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }
	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}
