package urjanet.hit.ui.view.attributes.contextKeys;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextFilters.ContextFilterAttributes;
import urjanet.pull.web.pdf.key.FilterKey;

public class FilterKeyAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/FilterKeyAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;
	@FXML protected Pane contextFilterPane;
	
	private FilterKey filterKey;
	private ContextKeyAttributes contextKeyAttributes;
	private ContextFilterAttributes contextFilterAttributes;
	
	public FilterKeyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(ContextKeyAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loaderContextKey.getRoot());
		contextKeyAttributes = loaderContextKey.getController();
		
		FXMLLoader loader = new FXMLUtils().loader(ContextFilterAttributes.resourcePath);
		
		contextFilterPane.getChildren().add(loader.getRoot());
		contextFilterAttributes = loader.getController();
		
		setTemplateItem(treeItem);
        setTreeView(treeView);
	}
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        contextKeyAttributes.setTreeView(treeView);
        contextFilterAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof FilterKey))
            throw new HiTException("Could not create Form for FilterKey due to incompatible node. Received " + Obj.getClass());
        
        this.filterKey = (FilterKey) Obj;
        
        contextKeyAttributes.setTemplateItem(item);
        contextFilterAttributes.setTemplateItem(item);
	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}
