package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.RegExOperator;

public class RegEXOperatorAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/RegEXOperatorAttributes.fxml";
	
	@FXML private TextField regExText;
	private Property regExTextProperty;
	@FXML private TextField groupCountText;
	private Property groupCountTextProperty;
	
	private RegExOperator regExOperator;
	
	public RegEXOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof RegExOperator))
            throw new HiTException("Could not create Form for RegExOperator due to incompatible node. Received " + Obj.getClass());
        
        this.regExOperator = (RegExOperator) Obj;
        
        if( regExTextProperty != null ) FXMLUtils.unbindField( regExText, regExTextProperty );
		regExTextProperty = FXMLUtils.bindField(regExText, regExOperator, "regEx");
		
		if( groupCountTextProperty != null ) FXMLUtils.unbindField( groupCountText, groupCountTextProperty );
		groupCountTextProperty = FXMLUtils.bindField(groupCountText, regExOperator, "groupCount");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}
