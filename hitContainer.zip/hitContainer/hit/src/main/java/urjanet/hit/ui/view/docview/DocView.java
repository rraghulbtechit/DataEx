package urjanet.hit.ui.view.docview;

import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import org.jpedal.examples.viewer.Commands;
import org.jpedal.examples.viewer.OpenViewerFX;

import java.io.File;

/**
 * Component for document view to show and interact with bills
 */
public class DocView {

    private String          docRoot = "C:\\Users\\shankerj\\Desktop";
    private WebView         webView;
    private OpenViewerFX    openViewer;

    protected VBox          docViewVBox;

    public DocView( ) {
        init();
    }

    protected void init() {
        docViewVBox = new VBox(5.0);
        docViewVBox.getChildren().add( 0, new DocToolBar() );
    }

    public Pane getDocView() {
        return docViewVBox;
    }
/*
    public WebView getWebView() {
        return webView;
    }*/

    public void show( String fileName ) {

        if( fileName.toLowerCase().endsWith(".pdf") )
            showPdf( fileName );

        if( webView == null ) webView = new javafx.scene.web.WebView();

        final java.net.URI uri = java.nio.file.Paths.get(docRoot+ File.separator + fileName).toAbsolutePath().toUri();
        String filePath = uri.toString();
        //System.out.println( "Showing "+filePath );
        webView.getEngine().load( filePath );
        webView.setZoom(javafx.stage.Screen.getPrimary().getDpi() / 96);
        docViewVBox.getChildren().remove( 1 );
        docViewVBox.getChildren().add( 1, webView );
    }

    protected void showPdf( String fileName) {
        if( openViewer == null ) {
            openViewer = new OpenViewerFX(docViewVBox, "null" );
            openViewer.setupViewer();
            String[] scalingOption = {"Fit Width"};
            openViewer.executeCommand(Commands.SCALING, scalingOption);
            docViewVBox.getChildren().remove( 1 );
            docViewVBox.getChildren().add( 1, openViewer.getRoot() );
        }

        openViewer.openDefaultFile( docRoot+ File.separator + fileName );
    }
}
