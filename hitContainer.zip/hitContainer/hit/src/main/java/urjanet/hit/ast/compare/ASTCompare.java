package urjanet.hit.ast.compare;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.Type;

import urjanet.hit.template.compare.UnsupportedComparisonException;
import urjanet.hit.utils.TypeUtils;
import urjanet.pull.web.pdf.key.ContextKey;

public class ASTCompare {

	public static List<Expression> compare( Object object1, Object object2 ) throws UnsupportedComparisonException{
		
		if ( ! TypeUtils.isSameType( object1, object2 )){
			throw new UnsupportedComparisonException( "Could not compare type " + object1.getClass() + " and " + object2.getClass() );
		}

		if( object1 instanceof Type )
			return compare ( (Type) object1, (Type)object2 );
		if( object1 instanceof Statement )
			return StatementCompare.compare ( (Statement) object1, (Statement)object2 );
		if( object1 instanceof Expression )
			return ExpressionCompare.compare ( (Expression)object1, (Expression)object2 );
		
		throw new UnsupportedComparisonException( "No implementation found to compare " + object1.getClass() + " and " + object2.getClass() );
	}
	
	/**
	 * 
	 * @param body
	 * @param body2
	 * @return
	 *  a list of varying expressions.
	 *  an empty list if both blocks are equal.
	 *  null if they are structurally different.
	 *  Structurally different covers 
	 *  	1. unequal  number of statements in body
	 *  	2. unequal number of parameters in a classInstantiation or method invocation
	 * @throws UnsupportedComparisonException 
	 * 
	 */
	public static List<Expression> compare( Block body, Block body2 ) throws UnsupportedComparisonException {

		List<Expression> differences = new ArrayList<Expression>();
		
		int numberOfBodyStatements1 = body.getLength();
		int numberOfBodyStatements2 = body2.getLength();
		
		if( numberOfBodyStatements1 != numberOfBodyStatements2 )
			return null;
		List<Statement> statements1 = body.statements();
		List<Statement> statements2 = body2.statements();
		
		for( int i = 0; i < statements1.size(); i ++ ) {
			if( ! TypeUtils.isSameType( statements1.get( i ), statements2.get( i )) ){
				return null;
			}
			
			System.out.println( "comparing " + statements1.get( i ).getClass() + " and " + statements2.get( i ).getClass() );
			compare( statements1.get( i ), statements2.get( i ));
		}
		
		return differences;
	}

	private static List<Object> compare( ContextKey startKey, ContextKey startKey2 ) {

		// TODO Auto-generated method stub
		return null;
	}

	public static void main( String[] args ) {
		AST ast = AST.newAST( AST.JLS3 );
		System.out.println( new String( "euseo").getClass().equals( new String( "ueodnu").getClass() ));
	}
}

