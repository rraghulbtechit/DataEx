package urjanet.hit.ui.view.attributes.contextFilters;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.pull.web.pdf.filter.OverlapPosition;
import urjanet.pull.web.pdf.filter.RangeFilter;

public class RangeFilterAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/RangeFilterAttributes.fxml";
	
	@FXML protected Pane startContextKeyPane;
	@FXML protected Pane endContextKeyPane;

	@FXML protected ComboBox overlapTextPositionCombo;
	protected Property overlapTextPositionProperty;
	
	private RangeFilter rangeFilter;
	private KeysAttributes startKeyAttributes;
	private KeysAttributes endKeyAttributes;
	
	public RangeFilterAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
     
    	FXMLLoader loaderStartKey = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		startContextKeyPane.getChildren().add(loaderStartKey.getRoot());
		startKeyAttributes = loaderStartKey.getController();
		
		FXMLLoader loaderEndKey = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		endContextKeyPane.getChildren().add(loaderEndKey.getRoot());
		endKeyAttributes = loaderEndKey.getController();
		
		overlapTextPositionCombo.getItems().addAll(OverlapPosition.values());
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        startKeyAttributes.setTreeView(treeView);
        endKeyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof RangeFilter))
            throw new HiTException("Could not create Form for RangeFilter due to incompatible node. Received " + Obj.getClass());
        
        this.rangeFilter = (RangeFilter) Obj;
        
        addBinding();
        
        startKeyAttributes.setTemplateItem(item);
        endKeyAttributes.setTemplateItem(item);
	}
	
	public void addBinding() {
		
		try {
        	//bind
			if( overlapTextPositionProperty != null ) FXMLUtils.unbindField( overlapTextPositionCombo, overlapTextPositionProperty );
			overlapTextPositionProperty = FXMLUtils.bindField(overlapTextPositionCombo, rangeFilter, "overlapTextPosition");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }

	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}