package urjanet.hit.ui.view.attributes;

import java.util.Arrays;
import java.util.List;

import javafx.beans.property.Property;
import javafx.scene.layout.VBox;
import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.XmlDataTarget;

public class XmlDataTargetAttributes extends BaseTemplateAttributes<T> {
	
	private static final String resourcePath = "/XmlDataTargetAttributes.fxml";

	private static Logger log = LoggerFactory.getLogger( XmlDataTargetAttributes.class );
	
	@FXML protected TextField 		xPathText;
	protected Property 				xPathProperty;
	@FXML protected TextArea 		altXPathListText;
	protected Property 				alternateXPathsProperty;
	@FXML protected TextField 		indexText; //TODO This may not be needed. Should be for sdk only. SJ
	@FXML protected CheckBox 		variableSubstitutionCheck;
	protected Property 				variableSubstitutionProperty;
	@FXML protected CheckBox 		reinitializeVariableCheck;
	@FXML protected VBox 			dataTargetVBox;
	@FXML private DataTargetAttributes dataTargetVBoxController;

	private XmlDataTarget 			xmldatatarget;

	
	public XmlDataTargetAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
			init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init( TemplateTreeItem treeItem, TreeView treeView ) throws HiTException {

		FXMLUtils.loader( this.resourcePath, this, this );
		setTreeView(treeView);
		setTemplateItem(treeItem);
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        super.setTreeView( treeView );
        dataTargetVBoxController.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		super.setTreeItem( item );
		dataTargetVBoxController.setTemplateItem(treeItem);
		
        Object obj = item.getValue();
        if(! (obj instanceof XmlDataTarget))
            throw new HiTException("Could not create Form for XmlDataTarget due to incompatible node. Received " + obj.getClass());
        
        this.xmldatatarget = (XmlDataTarget) obj;

		try {
			xPathProperty = ( xPathProperty == null )
					? FXMLUtils.bindField( xPathText, xmldatatarget, "xPath" )
					: FXMLUtils.rebindField(xPathText, xPathProperty, xmldatatarget, "xPath");
			//TODO alternateXPathsProperty = (alternateXPathsProperty == null )
				// ? FXMLUtils.bindField( altXPathListText, xmldatatarget, "alternateXPaths" ); //-- TODO list<->string
				// 	: FXMLUtils.rebindField( altXPathListText, alternateXPathsProperty, xmldatatarget, "alternateXPaths" );
			List<String> alternateXpaths = xmldatatarget.getAlternateXPaths();
			if(alternateXpaths != null) {
				StringBuilder strb = new StringBuilder();
				for(String xpath : alternateXpaths) {
					strb.append(xpath + ",");
				}
				altXPathListText.setText(strb.toString());
			}
			variableSubstitutionProperty = ( variableSubstitutionProperty == null )
				? FXMLUtils.bindField( variableSubstitutionCheck, xmldatatarget, "variableSubstitution",
					"isVariableSubstitution", "setVariableSubstitution" )
				: FXMLUtils.rebindField( variableSubstitutionCheck, variableSubstitutionProperty, xmldatatarget, "variableSubstitution" );
			reinitializeVariableCheck.selectedProperty().set( xmldatatarget.isReinitializeVariable() ); //reinitializeVariable is not a bean attribute
		} catch( HiTException e ) {
			log.error( "Error in binding", e );
			throw e;
		}
	}
	
	@Override
    protected void onHide() {
		
		dataTargetVBoxController.onHide();
		
		String xpaths = altXPathListText.getText();
		if(xpaths != "") {
			
			xmldatatarget.setAlternateXPaths(Arrays.asList(xpaths.split("\\,")));
		}

		if( reinitializeVariableCheck.isSelected() != xmldatatarget.isReinitializeVariable() ) {
			xmldatatarget.setVariable(dataTargetVBoxController.getVariable(), reinitializeVariableCheck.isSelected());
		}
    }
}