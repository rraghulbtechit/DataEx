package urjanet.hit.ui.view;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.TreeView;
import urjanet.hit.ui.view.tree.TemplateTreeItem;

/**
 * Created by shankerj on 5/30/2016.
 */
public class GenericButtonActionHandler implements EventHandler {

    private TemplateTreeItem selectedItem;
    private TreeView template_tree;
    private Class    nodeClass;

    public GenericButtonActionHandler(TemplateTreeItem selectedItem, TreeView template_tree, Class nodeClass) {

        this.nodeClass = nodeClass;
        this.selectedItem = selectedItem;
        this.template_tree = template_tree;
    }

    public TemplateTreeItem getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(TemplateTreeItem selectedItem) {
        this.selectedItem = selectedItem;
    }

    @Override
    public void handle(Event event) {

        template_tree.getSelectionModel().select(selectedItem.addNode(nodeClass));
    }
}
