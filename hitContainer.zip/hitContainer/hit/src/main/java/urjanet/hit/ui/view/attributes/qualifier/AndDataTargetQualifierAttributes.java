package urjanet.hit.ui.view.attributes.qualifier;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.AndDataTargetQualifier;
import urjanet.pull.web.DataTargetQualifier;

public class AndDataTargetQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/AndDataTargetQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane; 
	
	@FXML protected TemplateButton dataTargetQualifierBtn;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private AndDataTargetQualifier andDataTargetQualifier;
	
	public AndDataTargetQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		andDataTargetQualifier = ((AndDataTargetQualifier)item.getValue());
		
		for(MenuItem menuItem : dataTargetQualifierBtn.getItems()) {
			menuItem.setOnAction( dataTargetQualifierHandler );
        }
		
	}
	
	private EventHandler dataTargetQualifierHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetQualifierItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTargetQualifier newTargetQualifier = ((DataTargetQualifier)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor

            if(andDataTargetQualifier.getC1() == null) {
            	
            	andDataTargetQualifier.setC1(newTargetQualifier);
            } else if(andDataTargetQualifier.getC2() == null) {
            	
            	andDataTargetQualifier.setC2(newTargetQualifier);
            } else {
            	
            	newTargetQualifier = new AndDataTargetQualifier(andDataTargetQualifier.getC2(), newTargetQualifier);
            }
            
            dataTargetQualifierItem = new TemplateTreeItem( newTargetQualifier );
            addSelectNode(dataTargetQualifierItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
}