package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.core.PageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.InputElement;

public class NavTargetConstructorResolution {
	
	public static List<Object> resolveConstructorParameters( ClickableNavTarget navTarget ) {
		
		PageSpec targetPageSpec = navTarget.getTargetPageSpec();
		String XpathTarget = navTarget.getXpathTarget();
		List<InputElement> inputElements = navTarget.getInputElements();
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties,targetPageSpec,XpathTarget,inputElements);
		return properties;
	}

}
