package urjanet.hit.template.source.builder.item;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.template.source.builder.constructor.ConstructorResolutionFactory;
import urjanet.hit.utils.TypeUtils;
import urjanet.keys.DomainKeys;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.InputElement;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.VariableInputElement;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.ContextKey;

// actually uses multiton pattern
public class TemplateItemBuilderFactory {
	
	private static final Logger log = LoggerFactory.getLogger(TemplateItemBuilderFactory.class);
	
	private static Map<Class, TemplateItemBuilder> multitonInstances = new HashMap<Class, TemplateItemBuilder>();
	public static Map <Object, Expression> map = new HashMap<>();
	
//	public static Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) throws HiTException {
//		
//		if( object instanceof WebPullJobTemplate )
//			return PullJobTemplateBuilder.createClassInstance(typeDeclaration, methodDeclaration, (WebPullJobTemplate)object, typeTracker);
//		else if( object instanceof BasePageSpec )
//			return PageSpecBuilder.createClassInstance(typeDeclaration, methodDeclaration, (BasePageSpec)object, typeTracker);
//		else if( object instanceof List<?> )
//			return ListBuilder.createClassInstance(typeDeclaration, methodDeclaration, (List<?>)object, typeTracker);
//		else if( object instanceof GroupPolicy )
//			return GroupPolicyBuilder.createClassInstance(typeDeclaration, methodDeclaration, (GroupPolicy)object, typeTracker);
//		else if( object instanceof PdfDataTarget )
//			return DataTargetBuilder.createClassInstance(typeDeclaration, methodDeclaration, (PdfDataTarget)object, typeTracker);
//		else if( object instanceof PdfPageDataTarget )
//			return DataTargetBuilder.createClassInstance(typeDeclaration, methodDeclaration, (PdfPageDataTarget)object, typeTracker);
//		throw new HiTException("unhandled template item creation: " + object.getClass() ) ;
//		
//		return PullJobTemplateBuilder;
//	}
	
	public static TemplateItemBuilder getBuilder( Object object ) throws HiTException {

		if( object instanceof WebPullJobTemplate )
			return PullJobTemplateBuilder.getInstance();
		else if( object instanceof DataTarget )
			return DataTargetBuilder.getInstance();
		else if( object instanceof NavTarget )
			return NavTargetBuilder.getInstance();
		else if( object instanceof InputElement )
			return InputElementBuilder.getInstance();
		else if( TypeUtils.isBasicType( object ) )
			return BasicTypeBuilder.getInstance();
		else if( object instanceof BasePageSpec )
			return PageSpecBuilder.getInstance();
		else if( object instanceof List<?> )
			return ListBuilder.getInstance();
		else if( object instanceof ConfigOptions )
			return ConfigOptionsBuilder.getInstance();
		else if( object instanceof ContextKey )
			return ContextKeyBuilder.getInstance();
		else if( object instanceof EnumConstant )
			return EnumConstantBuilder.getInstance();
		else if( 
			   object instanceof ContextFilter
			|| object instanceof TargetGroup 
			|| object instanceof DataTargetQualifier 
			|| object instanceof GroupPolicy
			|| object instanceof TargetFormat )
			return CommonTemplateItemBuilder.getInstance();
		
		throw new HiTException( "Error creating builder for " + object.getClass() );
		
	}
//	public static Expression createTemplateItem( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) throws HiTException {
//		
//		if ( TypeUtils.isBasicType( object ))
//			return BasicTypeBuilder.createTemplateItem(typeDeclaration, methodDeclaration, object, typeTracker);
//		else if( object instanceof XmlTargetGroup )
//			return TargetGroupBuilder.createTemplateItem(typeDeclaration, methodDeclaration, (XmlTargetGroup)object, typeTracker);
//		else if( object instanceof PdfDataTarget )
//			return DataTargetBuilder.createTemplateItem(typeDeclaration, methodDeclaration, (PdfDataTarget)object, typeTracker);
//		else if( object instanceof ContextFilter )
//			return ContextFilterBuilder.createTemplateItem(typeDeclaration, methodDeclaration, (ContextFilter)object, typeTracker);
//		throw new HiTException("unhandled template item creation: " + object.getClass() ) ;
//	}
	
	@Deprecated
	public static Expression createTemplateItem_old( ASTNode typeDeclaration, Object object, TypeTracker typeManager ) {
		
		AST ast = typeDeclaration.getAST();

		List<?> parameters = ConstructorResolutionFactory.getConstructorParamater(object);
		
		ClassInstanceCreation cic= null;
		MethodInvocation methodInvocation = null;
		
		if( (object instanceof List<?> )){
			List<Expression> parametersExpression = new ArrayList<Expression>();
			for( Object parameter : parameters ) {
				Expression parameterExpression = null;
				if( parameter instanceof String )
					parameterExpression = JavaElementBuilder.getValueLiteralForType( ast, typeManager.getType(parameter), ( String )parameter);
				else if (parameter instanceof Enum<?>) {
					String enumDeclaringClassName = ((Enum)parameter).getDeclaringClass().getSimpleName();
					parameterExpression = ast.newQualifiedName( ast.newSimpleName(  enumDeclaringClassName ), ast.newSimpleName( ((Enum)parameter).name() ) );
					if ( parameter instanceof DomainKeys )
						parameterExpression = JavaElementBuilder.createMethodInvocation(ast, parameterExpression, "getValue");
				} else {
					parameterExpression = createTemplateItem_old( typeDeclaration, parameter, typeManager );
				}
				
				parametersExpression.add( parameterExpression );
//				map.put(parameter, parameterExpression);
			}
			methodInvocation = JavaElementBuilder.createMethodInvocation(ast, ast.newSimpleName("Arrays"), "asList", parametersExpression);
			map.put(object, methodInvocation);
			return methodInvocation;
		} else {

			 cic = JavaElementBuilder.createClassInstanceCreation( ast, typeManager.getType(object) );
			 
			 for( Object parameter : parameters ) {
				 Expression parameterExpression = null;
					if( parameter instanceof String )
						parameterExpression = JavaElementBuilder.getValueLiteralForType( ast, typeManager.getType(parameter), ( String )parameter);
					else if( TypeUtils.isWrapperType(parameter.getClass()) ){
						parameterExpression = JavaElementBuilder.getValueLiteralForType( ast, typeManager.getType(parameter), parameter) ;
					}
					else if (parameter instanceof Enum<?>) {
						String enumDeclaringClassName = ((Enum)parameter).getDeclaringClass().getSimpleName();
						parameterExpression = ast.newQualifiedName( ast.newSimpleName(  enumDeclaringClassName ), ast.newSimpleName( ((Enum)parameter).name() ) );
						if ( parameter instanceof DomainKeys )
							parameterExpression = JavaElementBuilder.createMethodInvocation(ast, parameterExpression, "getValue");
					} else {
						parameterExpression = createTemplateItem_old( typeDeclaration, parameter, typeManager );
					}
					cic.arguments().add(parameterExpression);
//					map.put(parameter, parameterExpression);
				}
			log.info( "constructed " + object.getClass().getName()  + "  --->   " + cic );
			map.put(object, cic);
			return cic;
		}
	}
}