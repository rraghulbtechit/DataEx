package urjanet.hit.template.source.builder.item;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;

public class DataTargetWrapper {

	DataTarget dataTarget;
	
	public DataTargetWrapper( DataTarget dataTarget ){
		
		
	}
	
	/**
     * 
     * @return true, if the template tree dataTarget is a dataTarget and it takes key value pair.
     * false, if the template tree dataTarget is a dataTarget with GroupPolicy or a dataTarget with relative dataTargets.
     */
    public  boolean isKeyDataTarget() {

    	if ( dataTarget instanceof PdfDataTarget ){
    		if( !( 															// not 
    			((PdfDataTarget) dataTarget).getGroupPolicy() != null || 			// containing groupPolicy or   
    			((PdfDataTarget) dataTarget).getRelativeDataTargets() != null )) 	// relativeDataTargets
    		return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreedataTarget is a dataTarget with groupPolicy
     */
    public  boolean isGroupDataTarget() {

    	if ( dataTarget instanceof PdfDataTarget ){
    		if ( ((PdfDataTarget) dataTarget).getGroupPolicy() != null ) 
    			return true;
    	}
    	
		return false;
	}
    
    /**
     * 
     * @return true, if the templateTreedataTarget is dataTarget with baseFilter and some collection of other datatargets
     */
    public  boolean isContainerDataTarget() {

    	if ( dataTarget instanceof PdfDataTarget ){
    		if ( /*((PdfDataTarget) dataTarget).getGroupPolicy() == null ||*/
    			((PdfDataTarget) dataTarget).getRelativeDataTargets() != null )
    			return true;
    	}
    	
		return false;
	}
}

