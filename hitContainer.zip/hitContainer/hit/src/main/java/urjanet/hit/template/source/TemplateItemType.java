package urjanet.hit.template.source;


public class TemplateItemType {
	
	private String qualifiedName;
	private String simpleName;
	private String packageName;
	
	
	public TemplateItemType( String qualifiedName, String simpleName, String packageName) {
		
		this.qualifiedName = qualifiedName;
		this.simpleName = simpleName;
		this.packageName = packageName;
	}

	public TemplateItemType ( Class clazz ){
		
		this.qualifiedName = clazz.getName();
		/*
		 * Get fully-qualified name as used in binding. Binding name differs from the standard fully-qualified name in that it uses
		 * '$' rather than '.' to delimit inner class names.
		 */
		this.qualifiedName = this.qualifiedName.replace("$", ".");
		this.simpleName = clazz.getSimpleName();
		this.packageName = clazz.getPackage().getName();
	}
	
	
	public String getQualifiedName() {

		return qualifiedName;
	}
	
	public String getSimpleName() {

		return simpleName;
	}
	
	
	public String getPackageName() {

		return packageName;
	}
}
