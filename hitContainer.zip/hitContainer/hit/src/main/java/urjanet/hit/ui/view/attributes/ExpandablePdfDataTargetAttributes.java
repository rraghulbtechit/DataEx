package urjanet.hit.ui.view.attributes;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.contextFilters.ContextFilterAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.key.ContextKey;

public class ExpandablePdfDataTargetAttributes extends BaseTemplateAttributes<T> {

	private static final String resourcePath = "/ExpandablePdfDataTargetAttributes.fxml";
	
	@FXML protected Pane dataTargetPane;
	@FXML protected Pane filtersPane;
	@FXML protected Pane contextKeysPane;
	
	@FXML protected CheckBox endExpansionOnKeyChk;
	protected Property endExpansionOnKeyProperty;
	@FXML protected CheckBox uniqueExpansionOnKeyChk;
	protected Property uniqueExpansionOnKeyProperty;
	
	private ExpandablePdfDataTarget expandablePdfdatatarget;
	private DataTargetAttributes dataTargetAttributes;
	private ContextFilterAttributes contextFilterAttr;
	
	private boolean endExpansionOnKey = false;
	private boolean uniqueExpansionOnKey = false;
	private ContextKey expandableKey;
	private KeysAttributes keyAttributes;
	
	public ExpandablePdfDataTargetAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(DataTargetAttributes.resourcePath);
		dataTargetPane.getChildren().add(loader.getRoot());
		dataTargetAttributes = loader.getController();
		
		FXMLLoader loaderFilters = new FXMLUtils().loader(ContextFilterAttributes.resourcePath);
		
		filtersPane.getChildren().add(loaderFilters.getRoot());
		contextFilterAttr = loaderFilters.getController();
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		contextKeysPane.getChildren().add(loaderContextKey.getRoot());
		keyAttributes = loaderContextKey.getController();
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
			
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        dataTargetAttributes.setTreeView(treeView);
        contextFilterAttr.setTreeView(treeView);
        
        keyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
		dataTargetAttributes.setTemplateItem(treeItem);
        Object Obj = item.getValue();
        if(! (Obj instanceof ExpandablePdfDataTarget))
            throw new HiTException("Could not create Form for ExpandablePdfDataTarget due to incompatible node. Received " + Obj.getClass());
        
        this.expandablePdfdatatarget = (ExpandablePdfDataTarget) Obj;

        contextFilterAttr.setTemplateItem(treeItem);
        keyAttributes.setTemplateItem(item);
        
        if( endExpansionOnKeyProperty != null ) FXMLUtils.unbindField( endExpansionOnKeyChk, endExpansionOnKeyProperty );
        endExpansionOnKeyProperty = FXMLUtils.bindField(endExpansionOnKeyChk, expandablePdfdatatarget, "endExpansionOnKey");
    	
    	if( uniqueExpansionOnKeyProperty != null ) FXMLUtils.unbindField( uniqueExpansionOnKeyChk, uniqueExpansionOnKeyProperty );
    	uniqueExpansionOnKeyProperty = FXMLUtils.bindField(uniqueExpansionOnKeyChk, expandablePdfdatatarget, "uniqueExpansionOnKey");
	}
	
	@Override
    protected void onHide() {
		
		dataTargetAttributes.onHide();
    }
}
