package urjanet.hit.template.source;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ImportDeclaration;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.SimpleName;

public class ImportManager {
	
	private AST ast;
	private CompilationUnit cu;

	private Set<TemplateItemType> importedTypes;
	
	
	public ImportManager( CompilationUnit cu ) {
		this.cu = cu;
		this.ast = cu.getAST();
		importedTypes = new HashSet<TemplateItemType>();
	}
	
	public void addimport( TemplateItemType templateItemType ) {
		
		importedTypes.add( templateItemType );
	}
	
	public void addimport( Object object ) {
		
		importedTypes.add( new TemplateItemType(object.getClass()));
	}
	
	
	public Set<TemplateItemType> getImportedTypes() {

		return importedTypes;
	}
	
	
	public void resolveImports() {
		
		for (TemplateItemType importedType : importedTypes) {
			ImportDeclaration importDeclaration = ast.newImportDeclaration();
			importDeclaration.setName( ast.newName(importedType.getQualifiedName()) ); 
			cu.imports().add(importDeclaration);
		}
	}
}
