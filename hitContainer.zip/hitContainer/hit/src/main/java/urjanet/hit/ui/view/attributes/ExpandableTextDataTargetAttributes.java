package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.text.ExpandableTextDataTarget;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Created by shankerj on 7/14/2016.
 */
public class ExpandableTextDataTargetAttributes implements Initializable, TemplateAttributesPane {

    public static final String resourcePath = "/ExpandableTextDataTargetAttributes.fxml";

    @FXML private TextField                     indexText;
    private Property                            indexProperty;
    @FXML private TextField                     endLabelText;
    private Property                            endLabelProperty;
    @FXML private VBox                          textDataTargetVBox;
    @FXML private TextDataTargetAttributes      textDataTargetVBoxController;

    protected TemplateTreeItem      treeItem;
    protected TreeView              treeView;
    protected ExpandableTextDataTarget expandableTextDataTarget;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        expandableTextDataTarget = (ExpandableTextDataTarget) item.getValue();

        if( indexProperty != null ) FXMLUtils.unbindField( indexText, indexProperty );
        indexProperty = FXMLUtils.bindField( indexText, expandableTextDataTarget, "index" );
        if( endLabelProperty != null ) FXMLUtils.unbindField( endLabelText, endLabelProperty );
        endLabelProperty = FXMLUtils.bindField( endLabelText, expandableTextDataTarget, "endLabel" );

        textDataTargetVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        textDataTargetVBoxController.setTreeView( treeView );
    }
}
