package urjanet.hit.ui.view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TreeView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import urjanet.hit.ui.control.AlertDialog;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.GroupPolicy;

public class GroupPolicyButton extends Button {

    Logger log = LoggerFactory.getLogger( GroupPolicyButton.class );

    private EventHandler            groupPolicyFilter;

    protected TreeView              treeView;
    protected TemplateTreeItem parentTreeItem;
    protected TemplateTreeItem      treeItem;

    protected GroupPolicy           groupPolicy;

    public GroupPolicyButton() {
        init();
    }

    protected void init() {
        this.getStyleClass().add( "group-policy-button" );
        if( this.getText().isEmpty() )
            this.setText( "Group Policy" );
        this.setOnAction( eventHandler );
    }

    EventHandler eventHandler = event -> {
        boolean bailOut = false;
        if( groupPolicy == null ) {
            AlertDialog.create( AlertDialog.TITLE.ERROR.name(), AlertDialog.HEADER.INVALID_STATE.text(), "Group Policy is null! Click OK and retry" );
            bailOut = true;
        } else if(( parentTreeItem == null ) || ( treeView == null )) {
            AlertDialog.create( AlertDialog.TITLE.ERROR.name(), AlertDialog.HEADER.INVALID_STATE.text(), "Parent's tree item and tree view are required" );
            log.debug( "Invalid state with parent tree item:"+parentTreeItem+" or tree view: "+treeView );
            bailOut = true;
        } else if( groupPolicyFilter == null ) {
            AlertDialog.create( AlertDialog.TITLE.ERROR.name(), AlertDialog.HEADER.INVALID_STATE.text(), "GroupPolicy filter is not assigned. This is needed to set values." );
            bailOut = true;
        }

        if( bailOut ) return;

        if( treeItem == null ) {
            treeItem = new TemplateTreeItem<>( groupPolicy );
            parentTreeItem.getChildren().add( treeItem );
        }
        treeView.getSelectionModel().select( treeItem );
    };

    public void setEventFilter( EventHandler groupPolicyFilter ) {
        this.groupPolicyFilter = groupPolicyFilter;
        this.addEventFilter( ActionEvent.ACTION, groupPolicyFilter );
    }

    /**
     * Mandatory field
     * @param item
     */
    public void setTemplateTreeItem( TemplateTreeItem item ) { this.treeItem = item; }

    /**
     * Mandatory field
     * @param parentItem
     */
    public void setParentTreeItem( TemplateTreeItem parentItem ) {
        this.parentTreeItem = parentItem;
    }

    /**
     * Mandatory field
     * @param treeView
     */
    public void setTreeView( TreeView treeView ) {
        this.treeView = treeView;
    }

    public GroupPolicy getGroupPolicy() {
        return groupPolicy;
    }

    public void setGroupPolicy(GroupPolicy groupPolicy) {
        this.groupPolicy = groupPolicy;
    }
}
