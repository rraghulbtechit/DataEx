package urjanet.hit.template.compare;

import java.util.List;

import urjanet.hit.utils.TypeUtils;
import urjanet.pull.web.DataTarget;

public class TemplateItemCompare {
	
	public static List<Object> diff( Object object1, Object object2 ) throws UnsupportedComparisonException{
		
		if( object1 instanceof DataTarget )
			return DataTargetCompare.diff( (DataTarget) object1, (DataTarget) object2 );
	
		if( TypeUtils.isList( object1 ))
			return ListCompare.diff( (List)object1, (List)object2 );
		
		if( TypeUtils.isBasicType( object1 ))
			return BasicTypeCompare.diff( object1, object2 );

		if( object1 instanceof Class )
			return BasicTypeCompare.diff( (Class) object1, (Class) object2 );
		throw new UnsupportedComparisonException( "Comparison not implemented for " + object1.getClass() + " : " + object1 );
	}

}
