package urjanet.hit.ui.control;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public class ConfirmDialog {

    Alert dialog;

    private ConfirmDialog() {
        dialog = new Alert(Alert.AlertType.CONFIRMATION);
    }

    public static boolean create() {
        return create( "Please confirm", "Click OK or Cancel" );
    }

    public static boolean create(String headerText, String contentText) {
        return create("Confirm Dialog", headerText, contentText);
    }

    public static boolean create(String title, String headerText, String contentText) {
        ConfirmDialog confirmDialog = new ConfirmDialog();
        Alert dialog = confirmDialog.getDialog();
        dialog.setTitle( title );
        dialog.setHeaderText( headerText );
        dialog.setContentText( contentText );

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.get() == ButtonType.OK){
            return true;
        } else {
            return false;
        }
    }

    public Alert getDialog() {
        return dialog;
    }
}
