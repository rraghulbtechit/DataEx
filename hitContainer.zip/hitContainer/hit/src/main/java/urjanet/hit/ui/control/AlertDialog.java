package urjanet.hit.ui.control;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

/**
 * Created by shankerj on 9/5/2016.
 */
public class AlertDialog {

	public enum TITLE {ERROR, WARNING, INFORMATION}

	public enum HEADER {
		INVALID_STATE("Invalid State"), ALERT("Alert!");
		private final String text;

		private HEADER(String text) {
			this.text = text;
		}

		public String text() {
			return text;
		}
	}

	Alert dialog;

	private AlertDialog() {
		dialog = new Alert(Alert.AlertType.ERROR);
	}

	public static boolean create() {
		return create(HEADER.ALERT.text(), "Click OK");
	}

	public static boolean create(String headerText, String contentText) {
		return create("Alert Dialog", headerText, contentText);
	}

	public static boolean create(String title, String headerText, String contentText) {
		AlertDialog alertDialog = new AlertDialog();
		Alert dialog = alertDialog.getDialog();
		dialog.setTitle(title);
		dialog.setHeaderText(headerText);
		dialog.setContentText(contentText);

		Optional<ButtonType> result = dialog.showAndWait();
		return true;
	}

	public Alert getDialog() {
		return dialog;
	}
}
