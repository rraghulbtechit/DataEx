package urjanet.hit.ast.compare;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.StringLiteral;

import urjanet.hit.template.compare.UnsupportedComparisonException;
import urjanet.hit.utils.TypeUtils;

public class ExpressionCompare {

	static List<Expression> compare( Expression expression1, Expression expression2 ) throws UnsupportedComparisonException {
	
		if( expression1 instanceof ClassInstanceCreation )
			return ExpressionCompare.compare( (ClassInstanceCreation)expression1, (ClassInstanceCreation)expression2 );
		if( expression1 instanceof NumberLiteral )
			return ExpressionCompare.compare( (NumberLiteral)expression1, (NumberLiteral)expression2 );
		if( expression1 instanceof StringLiteral )
			return ExpressionCompare.compare( (StringLiteral)expression1, (StringLiteral)expression2 );
		if( expression1 instanceof BooleanLiteral )
			return ExpressionCompare.compare( (BooleanLiteral)expression1, (BooleanLiteral)expression2 );
		if( expression1 instanceof QualifiedName )
			return ExpressionCompare.compare( (QualifiedName)expression1, (QualifiedName)expression2 );
		if( expression1 instanceof MethodInvocation )
			return ExpressionCompare.compare( (MethodInvocation)expression1, (MethodInvocation)expression2);
		
		throw new UnsupportedComparisonException( "Could not compare type " + expression1.getClass() + " and " + expression2.getClass() );
	}

	public static List<Expression> compare( ClassInstanceCreation classInstanceCreation1, ClassInstanceCreation classInstanceCreation2 ) throws UnsupportedComparisonException {
		
		List<Expression> differences = new ArrayList<Expression>();
		
		if ( ! TypeUtils.isSameType( classInstanceCreation1.getType(), classInstanceCreation2.getType() ) ){
			return null;
		}
		
		List parameter1 = classInstanceCreation1.arguments();
		List parameter2 = classInstanceCreation2.arguments();
		
		if( parameter1.size() != parameter2.size() )
			return null;
		for( int i = 0; i < parameter1.size(); i ++ ) {
			
			List<Expression> difference = ASTCompare.compare( parameter1.get( i ), parameter2.get( i ) );
			if( difference != null )
				differences.addAll( difference );
		}
		
		return differences;
	}
	
	public static List<Expression> compare( NumberLiteral numberLiteral1, NumberLiteral numberLiteral2 ){
		
		if ( numberLiteral1.getToken().equals( numberLiteral2.getToken() ))
			return new ArrayList<>();
		
		return null;
	}

	public static List<Expression> compare( StringLiteral numberLiteral1, StringLiteral numberLiteral2 ){
		
		if ( numberLiteral1.getLiteralValue().equals( numberLiteral2.getLiteralValue() ))
			return new ArrayList<>();
		
		return null;
	}
	

	public static List<Expression> compare( BooleanLiteral booleanLiteral1, BooleanLiteral booleanLiteral2 ){
		
		if ( booleanLiteral1.booleanValue() == booleanLiteral2.booleanValue() )
			return new ArrayList<>();
		
		return null;
	}
	
	public static List<Expression> compare( QualifiedName qualifiedName1, QualifiedName qualifiedName2 ){
		
		if ( qualifiedName1.getFullyQualifiedName().equals( qualifiedName2.getFullyQualifiedName() ))
			return new ArrayList<>();
		
		return null;
	}
	
	public static List<Expression> compare( SimpleName simpleName1, SimpleName simpleName2 ){
		
		if ( simpleName1.getFullyQualifiedName().equals( simpleName2.getFullyQualifiedName() ))
			return new ArrayList<>();
		
		return null;
	}

	public static List<Expression> compare( MethodInvocation methodInvocation1, MethodInvocation methodInvocation2 ) throws UnsupportedComparisonException{
		
		SimpleName name1 = methodInvocation1.getName();
		SimpleName name2 = methodInvocation2.getName();
		
		
		if( compare( name1, name2 ) == null ){
			return null;
		}
		
		List parameters1 = methodInvocation1.arguments();
		List parameters2 = methodInvocation1.arguments();
		
		if( parameters1.size() != parameters2.size() )
			return null;
		
		List<Expression> differences = new ArrayList<Expression>();
		for( int i = 0; i < parameters1.size(); i ++ ) {
			differences.addAll( ASTCompare.compare( parameters1.get( i ), parameters2.get( i ) ) );
			
		}
		
		return differences;
	}

}
