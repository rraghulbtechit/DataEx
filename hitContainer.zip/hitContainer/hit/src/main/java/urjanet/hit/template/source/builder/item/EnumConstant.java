package urjanet.hit.template.source.builder.item;

import java.lang.reflect.Method;

import urjanet.pull.conversion.document.DocConverterConfigurationParameters;

public class EnumConstant {

	Class enumType;
	Object constant;
	Method method;
	
	public EnumConstant( Class class1, Object value, Method method ) {
		super();
		this.enumType = class1;
		this.constant = value;
		this.method = method;
	}
	
	
	public Class getEnumType() {
	
		return enumType;
	}


	public void setEnumType( Class enumType ) {
	
		this.enumType = enumType;
	}


	public Object getValue() {
	
		return constant;
	}


	public void setValue( Object value ) {
	
		this.constant = value;
	}


	public Method getMethod() {
	
		return method;
	}


	public void setMethod( Method method ) {
	
		this.method = method;
	}


	public static void main( String[] args ) {
		try {
			new EnumConstant( DocConverterConfigurationParameters.class, 
				DocConverterConfigurationParameters.HANDLER_TYPE,
				DocConverterConfigurationParameters.class.getMethod( "getParameterName" )
				);
		} catch( NoSuchMethodException | SecurityException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
