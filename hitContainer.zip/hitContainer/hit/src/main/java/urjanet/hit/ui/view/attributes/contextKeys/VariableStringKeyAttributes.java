package urjanet.hit.ui.view.attributes.contextKeys;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextFilters.ContextFilterAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.ExtractOperatorAttributes;
import urjanet.pull.web.pdf.key.VariableStringKey;

public class VariableStringKeyAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/VariableStringKeyAttributes.fxml";
	
	@FXML protected Pane contextFilterPane;
	@FXML protected Pane stringKeyPane;
	@FXML protected Pane extractOperatorPane;
	
	private VariableStringKey variableStringKey;
	private ContextFilterAttributes contextFilterAttributes;
	private StringKeyAttributes stringKeyAttributes;
	private ExtractOperatorAttributes extractOperatorAttributes;
	
	public VariableStringKeyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
		
		FXMLLoader loaderExtractOperator = new FXMLUtils().loader(ExtractOperatorAttributes.resourcePath);
		
		extractOperatorPane.getChildren().add(loaderExtractOperator.getRoot());
		extractOperatorAttributes = loaderExtractOperator.getController();
		
		FXMLLoader loaderStringKey = new FXMLUtils().loader(StringKeyAttributes.resourcePath);
		
		stringKeyPane.getChildren().add(loaderStringKey.getRoot());
		stringKeyAttributes = loaderStringKey.getController();
		
		FXMLLoader loader = new FXMLUtils().loader(contextFilterAttributes.resourcePath);
		
		contextFilterPane.getChildren().add(loader.getRoot());
		contextFilterAttributes = loader.getController();
		
		setTemplateItem(treeItem);
        setTreeView(treeView);
	}
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        extractOperatorAttributes.setTreeView(treeView);
        stringKeyAttributes.setTreeView(treeView);
        contextFilterAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof VariableStringKey))
            throw new HiTException("Could not create Form for VariableStringKey due to incompatible node. Received " + Obj.getClass());
        
        this.variableStringKey = (VariableStringKey) Obj;
        
        extractOperatorAttributes.setTemplateItem(item);
        stringKeyAttributes.setTemplateItem(item);
        contextFilterAttributes.setTemplateItem(item);
	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}
