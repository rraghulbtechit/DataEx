package urjanet.hit.template.compare;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;

public class ListCompare {
	
	public static List<Object> diff( List list1, List list2 ) throws UnsupportedComparisonException{

		if( list1.size() != list2.size() )
			return null;
		
		List differences = new ArrayList<>();
		
		for( int i = 0; i < list1.size(); i ++ ) {
			differences.addAll( TemplateItemCompare.diff( list1.get( i ), list2.get( i ) ) );
		}
		
		return differences;
	}

}
