package urjanet.hit.ui.view.attributes.contextFilters;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.pull.web.pdf.filter.HorizontalFilter;
import urjanet.pull.web.pdf.filter.OverlapPosition;

public class HorizontalFilterAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/HorizontalFilterAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;

	@FXML protected TextField topBufferTf;
	protected Property topBufferProperty;
	@FXML protected TextField bottomBufferTf;
	protected Property bottomBufferProperty;
	@FXML protected TextField offsetTf;
	protected Property offsetProperty;
	@FXML protected TextField maxDistanceTf;
	protected Property maxDistanceProperty;
	@FXML protected CheckBox forwardCb;
	protected Property forwardProperty;
	@FXML protected ComboBox overlapTextPositionCombo;
	protected Property overlapTextPositionProperty;
	
	private HorizontalFilter horizontalFilter;
	private KeysAttributes keyAttributes;
	
	public HorizontalFilterAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loader.getRoot());
		keyAttributes = loader.getController();
		
		overlapTextPositionCombo.getItems().addAll(OverlapPosition.values());
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        keyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof HorizontalFilter))
            throw new HiTException("Could not create Form for HorizontalFilter due to incompatible node. Received " + Obj.getClass());
        
        this.horizontalFilter = (HorizontalFilter) Obj;
        
        addBinding();
        
        keyAttributes.setTemplateItem(item);
	}
	
	public void addBinding() {
		
		try {
        	//bind
			if( topBufferProperty != null ) FXMLUtils.unbindField( topBufferTf, topBufferProperty );
			topBufferProperty = FXMLUtils.bindField(topBufferTf, horizontalFilter, "topBuffer");
        	
        	if( bottomBufferProperty != null ) FXMLUtils.unbindField( bottomBufferTf, bottomBufferProperty );
        	bottomBufferProperty = FXMLUtils.bindField(bottomBufferTf, horizontalFilter, "bottomBuffer");
        	
        	if( offsetProperty != null ) FXMLUtils.unbindField( offsetTf, offsetProperty );
        	offsetProperty = FXMLUtils.bindField(offsetTf, horizontalFilter, "offset");
        	
        	if( forwardProperty != null ) FXMLUtils.unbindField( forwardCb, forwardProperty );
        	forwardProperty = FXMLUtils.bindField(forwardCb, horizontalFilter, "forward");
        	
        	if( maxDistanceProperty != null ) FXMLUtils.unbindField( maxDistanceTf, maxDistanceProperty );
        	maxDistanceProperty = FXMLUtils.bindField(maxDistanceTf, horizontalFilter, "maxDistance");
        	
        	if( overlapTextPositionProperty != null ) FXMLUtils.unbindField( overlapTextPositionCombo, overlapTextPositionProperty );
        	overlapTextPositionProperty = FXMLUtils.bindField(overlapTextPositionCombo, horizontalFilter, "overlapTextPosition");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }

	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}