package urjanet.hit.ui.model;

import java.util.Iterator;
import java.util.Stack;

import javafx.scene.control.TreeItem;
import urjanet.clean.validation.ValidationException;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.model.TemplateTree.TemplateTreeTraversalListenerImpl;
import urjanet.hit.utils.TemplateUtils;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.web.DataTarget;

public class TemplateTreeTraversal {
	
	Stack<TreeItem> stack = new Stack<>();

	/**
	 *  Iterative function for postorder tree traversal 
	 *  
	 */
	public void preOrderTraverse(TreeItem treeItem, TemplateTreeTraversalListener listener) throws ValidationException {

		listener.beginTraversal( treeItem );

		TreeIterator<String> iterator = new TreeIterator<>(treeItem);
		while (iterator.hasNext()) {
			TreeItem currentTreeItem = iterator.next();
			Object currentValue = currentTreeItem.getValue();
			
			if ( currentValue instanceof DataTarget ){
				listener.fireDataTargetEncountered( currentTreeItem, listener );
				DataTarget dataTarget = ( DataTarget )currentValue;
				if( TemplateUtils.isGroupDataTarget( dataTarget )){
					
					listener.fireGroupEncountered( 
						dataTarget.getGroupPolicy().getGroupName(), 
						dataTarget.getGroupPolicy().getAction(), 
						currentTreeItem);
				}
			}
		}
		
		listener.endTraversal( treeItem );

	}
	
	public static void main( String[] args ) throws Exception {
		
        String template = "TownAndCountryDisposalCOTemplateProvider";
        PullJobTemplate t = PlatformAccessor.getTemplate(template);
        TemplateTree tree = TemplateTree.getTemplateTree(t);
        
        TemplateTreeTraversalListenerImpl listener = new TemplateTreeTraversalListenerImpl();
        new TemplateTreeTraversal().preOrderTraverse( tree.getRoot(), listener );
	}
}


class TreeIterator<T> implements Iterator<TreeItem<T>> {
    private Stack<TreeItem<T>> stack = new Stack<>();

    public TreeIterator(TreeItem<T> root) {
        stack.push(root);
    }

    @Override
    public boolean hasNext() {
        return !stack.isEmpty();
    }

    @Override
    public TreeItem<T> next() {
        TreeItem<T> nextItem = stack.pop();
        nextItem.getChildren().forEach(stack::push);

        return nextItem;
    }
}
