package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.core.ConfigOptions;

public class ConfigOptionsConstructorResolution {

	public static List<Object> resolveConstructorParameters( ConfigOptions configOptions ) {
		
		List<Object> properties = new ArrayList<Object>();
	
		return properties;
	}

}
