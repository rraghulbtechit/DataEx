package urjanet.hit.ast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.template.content.PdfPageSpecProvider;

public class VariableDeclarationAndSubstitution {


	private static final Logger log = LoggerFactory.getLogger(ClassInstantiation.class);

	private Expression expression;
	private List<?> parameters = new ArrayList<>();
	
	private TypeDeclaration typeDeclaration;
	private MethodDeclaration methodDeclaration;
	private TypeTracker typeTracker;
	private AST ast;

	private String identifier;

	private List<Method> methodInvocation = new ArrayList<>();
	
	
	public VariableDeclarationAndSubstitution( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Expression expression, TypeTracker typeTracker) {

		this.typeDeclaration = typeDeclaration;
		this.methodDeclaration = methodDeclaration;
		this.expression = expression;
		this.typeTracker = typeTracker;
		this.ast = typeDeclaration.getAST();
	}
	
	public VariableDeclarationAndSubstitution setIdentifier( String identifier ){
		
		this.identifier = identifier;
		return this;
	}
	
	public VariableDeclarationAndSubstitution addMethodInvocation( List methodInvocation ) {

		this.methodInvocation = methodInvocation;
		return this;
	}
	
	public VariableDeclarationAndSubstitution addMethodInvocation( Method methodInvocation ) {

		this.methodInvocation.add( methodInvocation );
		return this;
	}
	
	public SimpleName declareAndSubstitute(){
		
		VariableDeclarationStatement variableDeclarationStatement = null;
			try {
				variableDeclarationStatement = JavaElementBuilder.createVariableDeclarationStatement(
					ast, getTypeName(), 
					JavaElementBuilder.createVariableDeclarationFragment(
						ast, identifier, 
						expression
						));
			} catch( HiTException e ) {
				e.printStackTrace();
			}
		
		Block block = (Block) ASTNode.copySubtree(ast, methodDeclaration.getBody());
			
		if( block == null )
			block = ast.newBlock();
		block.statements().add(variableDeclarationStatement);
		for( Method method : methodInvocation ) {
			
			MethodInvocation invocation = createMethodInvocation( method );
//			invocation = ( MethodInvocation )ASTNode.copySubtree(ast, invocation);
			block.statements().add( ast.newExpressionStatement( invocation ));
		}
		
		
		
		methodDeclaration.setBody(block);
		return ast.newSimpleName( identifier );
	}

	private MethodInvocation createMethodInvocation(Method method) {

		return new MethodInvocationWrapper( typeDeclaration, methodDeclaration, typeTracker)
			.setMethodName( method.getMethodName() )
			.setExpression( ast.newSimpleName( identifier ) )
			.setParameters( method.getParameters() )
			.invoke();
	}

	private String getTypeName() throws HiTException {

		Type type = null;
		if( expression instanceof ClassInstanceCreation )
			return ((ClassInstanceCreation) expression).getType().toString();
		
//		return type.toString();
		throw new HiTException( "You're trying to creating a variable for non-class instance" );
	}
}
