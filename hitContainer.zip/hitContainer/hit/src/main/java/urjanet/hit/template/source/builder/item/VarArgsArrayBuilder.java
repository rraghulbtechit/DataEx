package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.template.source.TypeTracker;

public class VarArgsArrayBuilder implements TemplateItemBuilder{

	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Expression createTemplateItem( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		// TODO Auto-generated method stub
		return null;
	}
	
	
}
