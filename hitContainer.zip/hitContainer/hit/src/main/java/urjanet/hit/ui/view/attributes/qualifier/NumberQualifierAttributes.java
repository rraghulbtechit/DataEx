package urjanet.hit.ui.view.attributes.qualifier;

import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.NumberQualifier;

public class NumberQualifierAttributes extends BaseTemplateAttributes<T> {

	protected static final String resourcePath = "/NumberQualifierAttributes.fxml";
	
	@FXML Pane baseDataTargetPane;
	@FXML Pane comparisonDataTargetPane;
	
	private BaseDataTargetQualifierAttributes baseDataTargetAttr;
	private ComparisonDataTargetQualifierAttributes comparisonDataTargetAttr;
	private NumberQualifier numberQualifier;
	
	public NumberQualifierAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

        this.treeView = treeView;
        
        FXMLLoader loaderQualifiers = new FXMLUtils().loader(BaseDataTargetQualifierAttributes.resourcePath);
		
        baseDataTargetPane.getChildren().add(loaderQualifiers.getRoot());
		baseDataTargetAttr = loaderQualifiers.getController();
		
		FXMLLoader loaderComparisonQualifiers = new FXMLUtils().loader(ComparisonDataTargetQualifierAttributes.resourcePath);
		
        comparisonDataTargetPane.getChildren().add(loaderComparisonQualifiers.getRoot());
		comparisonDataTargetAttr = loaderComparisonQualifiers.getController();
		
		setTemplateItem(treeItem);
    }
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		baseDataTargetAttr.setTemplateItem(item);
		baseDataTargetAttr.setTreeView(treeView);
		
		comparisonDataTargetAttr.setTemplateItem(item);
		comparisonDataTargetAttr.setTreeView(treeView);
		
		numberQualifier = ((NumberQualifier)item.getValue());
		
	}
}