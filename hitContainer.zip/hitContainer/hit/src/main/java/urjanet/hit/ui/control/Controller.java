package urjanet.hit.ui.control;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.Event;
import javafx.scene.control.*;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import urjanet.hit.platform.PlatformAccessor;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.source.TemplateSourceView;
import urjanet.hit.ui.view.docview.DocView;


public class Controller implements Initializable {

	@FXML protected ComboBox<String> 	template_list;
	@FXML protected TreeViewController 	templateTreeViewController;
	@FXML protected TemplateButton		newTemplateBtn;
	@FXML protected TemplateMenuItem 	webPullJobTemplateButton;
	@FXML protected TabPane 			templateViewPane;
	@FXML protected VBox				templateTreeView;
	@FXML protected VBox				wootView;
	@FXML protected Tab					sourceTab;
	@FXML protected VBox				sourceView;
	@FXML protected TemplateSourceView sourceViewController;
	@FXML protected SplitPane 			bill_tree_split_pane;
	@FXML protected Pane 				billPane;

	protected DocView					billView;
	
	// TODO move this element to FXML

	@Override 
	public void initialize(URL fxmlFileLocation, ResourceBundle resources) {

		loadPDFViewer();
		initTemplates();
		initTreeTabs();
	}

	private void loadPDFViewer() {
		billView = new DocView( );
	}

	//TODO separate this out from tree view
	private void initTemplates() {
		List<String> templates = PlatformAccessor.getAllTemplates();
		template_list.setItems(FXCollections.observableArrayList(templates));
		new AutoCompleteComboBoxListener(template_list);

		addNewTemplateListener();
	}

	private void initTreeTabs() {
		templateViewPane.getSelectionModel().selectedItemProperty().addListener((observable, oldTab, newTab) -> {
			//if source is selected, generate and show source

			//if woot is selected, run template and show woot and events

			//else if tree is selected, show tree
        });
	}

	public void addNewTemplateListener() {

		ChangeListener listener = (observable, oldValue, newValue) -> template_list.valueProperty().setValue(null);
		newTemplateBtn.getItems().forEach( menuItem -> {
			menuItem.onActionProperty().addListener(listener);
		});
	}

	public void newTemplate(ActionEvent actionEvent) {

		template_list.setValue( null );
		try {
			if( canLoad() )
				templateTreeViewController.loadTreeItems(null, Class.forName((( TemplateMenuItem) actionEvent.getSource()).getRepresentsClassName() ));

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void onTemplateSelect(ActionEvent actionEvent) {
		String template = (String) ((ComboBox)actionEvent.getSource()).getValue();
		if( template != null && canLoad() )
			templateTreeViewController.loadTreeItems(template);
	}

	private boolean canLoad() {
		if( templateTreeViewController.tree == null
				|| templateTreeViewController.tree.getRoot() == null
				|| ConfirmDialog.create("Load another template?",
				"Select OK to lose changes and edit another template. Click Cancel to close this dialog and Save changes." ))
			return true;

		return false;
	}
	
	public void onExit(ActionEvent actionEvent) {

		Platform.exit();
	}

	public void onSourceSelect(Event event) {
		if( sourceTab.isSelected() ) {
			sourceViewController.setTemplateTreeView( templateTreeViewController.getTemplateTreeView() );
			sourceViewController.updateSourceAndWoot();
		}
	}
}