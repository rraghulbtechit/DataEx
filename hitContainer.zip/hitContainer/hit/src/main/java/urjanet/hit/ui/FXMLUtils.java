package urjanet.hit.ui;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.Property;
import javafx.beans.property.adapter.JavaBeanBooleanPropertyBuilder;
import javafx.beans.property.adapter.JavaBeanDoublePropertyBuilder;
import javafx.beans.property.adapter.JavaBeanIntegerPropertyBuilder;
import javafx.beans.property.adapter.JavaBeanObjectProperty;
import javafx.beans.property.adapter.JavaBeanObjectPropertyBuilder;
import javafx.beans.property.adapter.JavaBeanStringPropertyBuilder;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.util.converter.NumberStringConverter;
import urjanet.hit.HiTException;
import urjanet.hit.utils.ReflectionUtils;

public class FXMLUtils {
	
	public static FXMLLoader loader(String resourcePath) {
		
		return loader( resourcePath, null, null );
	}

    public static FXMLLoader loader(String resourcePath, Object root, Object controller) {

        FXMLLoader loader = new FXMLLoader(FXMLUtils.class.getResource(resourcePath));

        try {
            if(root != null )
                loader.setRoot( root );
            if( controller != null )
                loader.setController( controller );
                Object load = loader.load();
            System.out.println("Loaded " + load.getClass().getName());
            return loader;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Property bindField(TextField field, Object bean, String name) throws HiTException {

        return bindField( field, bean, name, null, null );
    }

    public static Property bindField( TextField field, Object bean, String name, String getter, String setter ) throws HiTException {

        Property property = null;
        try {
            Field f = ReflectionUtils.getField( bean.getClass(), name );//bean.getClass().getDeclaredField(name);
            f.setAccessible( true );

            Class fieldType = f.getType();
            if( String.class.equals( fieldType )) {

                if( null == f.get( bean )) f.set( bean, "" );
                property = (getter == null || setter == null)
                        ? JavaBeanStringPropertyBuilder.create().bean( bean ).name( name ).build()
                        : JavaBeanStringPropertyBuilder.create().bean( bean ).name( name ).getter( getter ).setter( setter ).build();
                field.textProperty().bindBidirectional( property );
            } else if( Integer.class.equals( fieldType ) || Integer.TYPE.equals( fieldType )) {

                if( null == f.get( bean )) f.set( bean, new Integer(0) );
                property = (getter == null || setter == null)
                        ? JavaBeanIntegerPropertyBuilder.create().bean( bean ).name( name ).build()
                        : JavaBeanIntegerPropertyBuilder.create().bean( bean ).name( name ).getter( getter ).setter( setter ).build();
                Bindings.bindBidirectional( field.textProperty(), property, new NumberStringConverter() );
            } else if( Long.class.equals( fieldType ) || Long.TYPE.equals( fieldType )) {

                if( null == f.get( bean )) f.set( bean, new Long(0) );
                property = (getter == null || setter == null)
                        ? JavaBeanIntegerPropertyBuilder.create().bean( bean ).name( name ).build()
                        : JavaBeanIntegerPropertyBuilder.create().bean( bean ).name( name ).getter( getter ).setter( setter ).build();
                Bindings.bindBidirectional( field.textProperty(), property, new NumberStringConverter() );
            } else if( Double.class.equals( fieldType ) || Double.TYPE.equals( fieldType )) {

                if( null == f.get( bean )) f.set( bean, new Double(0.0) );
                property = (getter == null || setter == null)
                        ? JavaBeanDoublePropertyBuilder.create().bean( bean ).name( name ).build()
                        : JavaBeanDoublePropertyBuilder.create().bean( bean ).name( name ).getter( getter ).setter( setter ).build();
                Bindings.bindBidirectional( field.textProperty(), property, new NumberStringConverter());
            } else if( List.class.equals( fieldType )) {

                List<String> list = new ArrayList<>();
                if( null != f.get( bean )) {
                    field.setText( "Unsupported field type: " +fieldType);
                    field.setDisable( true );
                    throw new HiTException( "Unhandled bean field type in TextField: "+fieldType+" in "+bean.getClass().getName()+"."+"name" );
                }
            } else {
                throw new HiTException( "Unhandled bean field type in TextField: "+fieldType+" in "+bean.getClass().getName()+"."+"name" );
            }
        } catch (NoSuchMethodException | IllegalAccessException e) {
            throw new HiTException( e );
        }
        return property;
    }

    public static void unbindField( TextField field, Property property ) {

        field.textProperty().unbindBidirectional( property );
    }

    public static Property rebindField( TextField field, Property property, Object bean, String name ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name );
    }

    public static Property rebindField( TextField field, Property property, Object bean, String name, String getter, String setter ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name, getter, setter );
    }

    private static String listToText( List list ) {
        return list.toString();
    }

    private static List textToList( String text ) {
        return new ArrayList<>();
    }

    public static Property bindField( TextArea field, Object bean, String name ) {
        try {
            Property property = JavaBeanStringPropertyBuilder.create().bean(bean).name(name).build();
            field.textProperty().bindBidirectional( property );
            return property;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void unbindField(TextArea field, Property property) {

        field.textProperty().unbindBidirectional( property );
    }

    public static Property rebindField( TextArea field, Property property, Object bean, String name ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name );
    }

    public static Property bindField(ComboBox field, Object bean, String name) throws HiTException {

        return bindField( field, bean, name, null, null );
    }

    public static Property bindField(ComboBox field, Object bean, String name, String getter, String setter) throws HiTException {
        try {
            JavaBeanObjectProperty property = ( getter == null || setter == null )
                ? JavaBeanObjectPropertyBuilder.create().bean(bean).name(name).build()
                    : JavaBeanObjectPropertyBuilder.create().bean(bean).name(name).getter(getter).setter(setter).build();
            field.valueProperty().bindBidirectional( property );
            return property;
        } catch (NoSuchMethodException e) {
            throw new HiTException( e );
        }
    }

    public static void unbindField( ComboBox field, Property property ) {

        field.valueProperty().unbindBidirectional( property );
    }

    public static Property rebindField( ComboBox field, Property property, Object bean, String name ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name );
    }

    public static Property rebindField( ComboBox field, Property property, Object bean, String name, String getter, String setter ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name, getter, setter );
    }

    public static Property bindField( CheckBox field, Object bean, String name ) throws HiTException {

        return bindField( field, bean, name, null, null );
    }

    public static Property bindField( CheckBox field, Object bean, String name, String getter, String setter ) throws HiTException {
        try {
            Property property = ( getter == null || setter == null )
                    ? JavaBeanBooleanPropertyBuilder.create().bean( bean ).name( name ).build()
                    : JavaBeanBooleanPropertyBuilder.create().bean( bean ).name( name ).getter( getter ).setter( setter ).build();
            Field f = ReflectionUtils.getField( bean.getClass(), name );
            f.setAccessible( true );

            if( null == f.get( bean )) f.set( bean, false );
            field.selectedProperty().bindBidirectional( property );
            return property;
        } catch (NoSuchMethodException | IllegalAccessException e) {
            throw new HiTException( e );
        }
    }

    public static void unbindField( CheckBox field, Property property ) {

        field.selectedProperty().unbindBidirectional( property );
    }

    public static Property rebindField( CheckBox field, Property property, Object bean, String name ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name );
    }

    public static Property rebindField( CheckBox field, Property property, Object bean, String name, String getter, String setter ) throws HiTException {

        if( property != null ) unbindField( field, property );
        return bindField( field, bean, name, getter, setter );
    }
    
    public static void checkMandatoryFields(Object view, TreeView treeView, TreeItem treeItem) {
    	Node node = isMandatoryFieldsValid(view);
    	
    	if(node != null) {
			Platform.runLater(() -> {
				if(treeView.getRow(treeItem) >= 0 && treeView.getSelectionModel().getSelectedItem() != treeItem.getParent())
					treeView.getSelectionModel().select(treeItem);
                node.requestFocus();
            });
    	}
    }
    
    private static Node isMandatoryFieldsValid(Object view) {

        forField: for( Field field : view.getClass().getDeclaredFields() ) {
            try {
                field.setAccessible( true );
                Object formField = field.get( view );
                if( formField == null ) continue forField;

                if( formField instanceof Node ) {
                    Node node = (Node)formField;
                    String nodeId = node.getId();
                    
                    if(nodeId != null) {
                    
	                    if(nodeId.equals("mandatoryField")) {
	                    	if( formField instanceof TextField) {
	                            TextField textField = (TextField)formField;
	                            if(textField.getText().isEmpty()) {
	                            	return node;
	                            }
	                    	} else if(formField instanceof TextArea) {
	                    		TextArea textArea = (TextArea)formField;
	                            if(textArea.getText().isEmpty()) {
	                            	return node;
	                            }
	                    	} else if(formField instanceof ComboBox) {
	                    		ComboBox comboBox = (ComboBox)formField;
	                            if(comboBox.getSelectionModel().isEmpty()) {
	                            	return node;
	                            }
	                    	}
	                    }
                    }
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    	
    	return null;
    }

    @Deprecated /** unsafe to use */
    public static void unbindField( Node formField ) {
        if( formField instanceof ComboBox)
            ((ComboBox)formField).valueProperty().unbind();
        else if(formField instanceof CheckBox)
            ((CheckBox)formField).selectedProperty().unbind();
        else if( formField instanceof TextField)
            ((TextField)formField).textProperty().unbind();
        else if(formField instanceof TextArea)
            ((TextArea)formField).textProperty().unbind();
    }

    @Deprecated /** unsafe to use */
    public static void unbindAll(Object view) {

        forField: for( Field field : view.getClass().getDeclaredFields() ) {
            try {
                field.setAccessible( true );
                Object formField = field.get( view );
                if( formField == null ) continue forField;

                if( formField instanceof Node )
                    unbindField( (Node)formField );
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }
}
