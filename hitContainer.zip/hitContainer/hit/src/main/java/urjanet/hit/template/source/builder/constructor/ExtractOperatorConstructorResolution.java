package urjanet.hit.template.source.builder.constructor;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import urjanet.pull.operator.ConcatOperator;
import urjanet.pull.operator.DateOperator;
import urjanet.pull.operator.DateOperator.DateOperation;
import urjanet.pull.operator.DecimalFormatOperator;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.operator.JavaScriptOperator;
import urjanet.pull.operator.MathOperator;
import urjanet.pull.operator.MathOperator.MathOperation;
import urjanet.pull.operator.RegExOperator;
import urjanet.pull.operator.ReplaceOperator;
import urjanet.pull.operator.SimpleOperatorChain;
import urjanet.pull.operator.SplitGetOperator;
import urjanet.pull.operator.StringOperator;
import urjanet.pull.operator.StringOperator.StringOperation;

public class ExtractOperatorConstructorResolution {

	public static List<Object> resolveConstructorParameters( ExtractOperator object) throws UnresolvedConstructorException {
		
		if( object instanceof ConcatOperator )
			return resolveConstructorParameters( (ConcatOperator) object );
		else if( object instanceof DateOperator )
			return resolveConstructorParameters( (DateOperator) object );
		else if( object instanceof DecimalFormatOperator )
			return resolveConstructorParameters( (DecimalFormatOperator) object );
		else if( object instanceof DecimalFormatOperator )
			return resolveConstructorParameters( (DecimalFormatOperator) object );
		else if( object instanceof JavaScriptOperator )
			return resolveConstructorParameters( (JavaScriptOperator) object );
		else if( object instanceof MathOperator )
			return resolveConstructorParameters( (MathOperator) object );
		else if( object instanceof RegExOperator)
			return resolveConstructorParameters( (RegExOperator) object );
		else if( object instanceof ReplaceOperator )
			return resolveConstructorParameters( (ReplaceOperator) object );
		else if( object instanceof SimpleOperatorChain )
			return resolveConstructorParameters( (SimpleOperatorChain) object );
		else if( object instanceof SplitGetOperator)
			return resolveConstructorParameters( (SplitGetOperator) object );
		else if( object instanceof StringOperator)
			return resolveConstructorParameters( (StringOperator) object );
		
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( ConcatOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String delimiter = operator.getDelimiter();
		List<? extends ExtractOperator> operators = operator.getOperators();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, delimiter, operators);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( DateOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
	
		DateOperation operation = operator.getOperation();
		int value = operator.getValue();
		DateFormat inputFormat = operator.getInputFormat();
		DateFormat outputFormat = operator.getOutputFormat();
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, operation);
		if( value != 0 )
			properties.add(value);
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, inputFormat, outputFormat);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( DecimalFormatOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		DecimalFormat formatter = operator.getFormatter();
		RoundingMode mode = operator.getMode();
		// TODO is toPattern correct?
		ConstructorResolutionFactory.checkNullAndAddAll(properties, formatter.toPattern(), mode);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( JavaScriptOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String script = operator.getScript();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, script);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( MathOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		MathOperation operation = operator.getOperation();
		double number = operator.getNumber();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, operation);
		properties.add( number );
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( RegExOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String regEx = operator.getRegEx();
		int groupCount = operator.getGroupCount();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, regEx );
		properties.add( groupCount );
		
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( ReplaceOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String regEx = operator.getRegEx();
		String replaceWith = operator.getReplaceWith();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, regEx, replaceWith );
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( SimpleOperatorChain operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		List<? extends ExtractOperator> operators = operator.getOperators();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, operators );
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( SplitGetOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String regExDelim = operator.getRegExDelim();
		int index = operator.getIndex();
		int limit = operator.getLimit();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, regExDelim);
		properties.add(index);
		if ( limit != 0 )
			properties.add(limit);
		
		return properties;
	}

	public static List<Object> resolveConstructorParameters( StringOperator operator) {
		
		List<Object> properties = new ArrayList<Object>();
	
		StringOperation operation = operator.getOperation();
		String value = operator.getValue();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, operation, value);
		
		return properties;
	}

}
