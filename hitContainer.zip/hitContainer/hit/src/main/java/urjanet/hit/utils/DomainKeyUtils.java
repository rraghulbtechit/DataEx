package urjanet.hit.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.keys.AccountKeys;
import urjanet.keys.AccountSearchKeys;
import urjanet.keys.AddressKeys;
import urjanet.keys.ChargeKeys;
import urjanet.keys.Charges;
import urjanet.keys.DataValues;
import urjanet.keys.DomainKeys;
import urjanet.keys.IntervalKeys;
import urjanet.keys.MessageKeys;
import urjanet.keys.MetaKeys;
import urjanet.keys.MeterKeys;
import urjanet.keys.ProviderKeys;
import urjanet.keys.RecentPaymentKeys;
import urjanet.keys.SmartMeterKeys;
import urjanet.keys.StatKeys;
import urjanet.keys.StatementKeys;
import urjanet.keys.SummaryKeys;
import urjanet.keys.TemporalKeys;
import urjanet.keys.UnrelatedChargeKeys;
import urjanet.keys.UsageKeys;
import urjanet.keys.uds.GroupingKeys;

public class DomainKeyUtils {

	private static final Logger log = LoggerFactory.getLogger(DomainKeyUtils.class);
	
	private static Map <String, DomainKeys> domainKeyMap = new HashMap<String, DomainKeys>();
	private static DomainKeyUtils theInstance = null;
	
	private DomainKeyUtils() {

		initialize();
		log.trace( "initializing domain keys..." );
	}
	
	private void initialize() {

		Set<Class<? extends DomainKeys>> matchingTypes = ReflectionUtils.findAllMatchingTypes(DomainKeys.class);
		for (Class<? extends DomainKeys> clazz : matchingTypes) {
			Enum[] e=(Enum[]) clazz.getEnumConstants();
			if( e!= null ) {
				for (Enum enum1 : e) {
					DomainKeys domainKey = null;
					if( enum1 instanceof AccountKeys ){
						domainKey = AccountKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MetaKeys ){
						domainKey = MetaKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof UsageKeys ){
						domainKey = UsageKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MessageKeys ){
						domainKey = MessageKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof Charges){
						domainKey = Charges.valueOf( enum1.name() );
					} else if ( enum1 instanceof UnrelatedChargeKeys ){
						domainKey = UnrelatedChargeKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof RecentPaymentKeys ){
						domainKey = RecentPaymentKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof MeterKeys){
						domainKey = MeterKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof IntervalKeys ){
						domainKey = IntervalKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof GroupingKeys ){
						domainKey = GroupingKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof StatementKeys ){
						domainKey = StatementKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof AddressKeys ){
						domainKey = AddressKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof TemporalKeys ){
						domainKey = TemporalKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof SmartMeterKeys ){
						domainKey = SmartMeterKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof SummaryKeys ){
						domainKey = SummaryKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof AccountSearchKeys ){
						domainKey = AccountSearchKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof StatKeys ){
						domainKey = StatKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof ProviderKeys ){
						domainKey = ProviderKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof ChargeKeys ){
						domainKey = ChargeKeys.valueOf( enum1.name() );
					} else if ( enum1 instanceof DataValues ){
						domainKey = DataValues.valueOf( enum1.name() );
					}
					
					domainKeyMap.put( domainKey.getValue(), domainKey );
				}
			}
		}
	}

	public static DomainKeyUtils getInstance(){
		
		if ( theInstance == null )
			theInstance = new DomainKeyUtils();
		
		return theInstance; 
		
	}
	
	public DomainKeys getEnumConstantForString( String key ) {
		
		return domainKeyMap.get( key );
	}
	
	public static void main( String[] args ) {
		System.out.println( DomainKeyUtils.getInstance().domainKeyMap );
	}
}
