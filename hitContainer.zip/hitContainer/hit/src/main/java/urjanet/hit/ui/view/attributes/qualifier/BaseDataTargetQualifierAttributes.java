package urjanet.hit.ui.view.attributes.qualifier;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.property.Property;
import org.apache.poi.ss.formula.functions.T;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.BaseDataTargetQualifier;

public class BaseDataTargetQualifierAttributes implements Initializable, TemplateAttributesPane {

	public static final String resourcePath = "/BaseDataTargetQualifierAttributes.fxml";

	@FXML protected TextField nameText;
	protected Property nameProperty;

	protected TreeView<T>  treeView;
	protected TemplateTreeItem<T>           treeItem;
	private BaseDataTargetQualifier baseDataTargetQualifier = new BaseDataTargetQualifier();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			nameProperty = FXMLUtils.bindField( nameText, baseDataTargetQualifier, "name" );
		} catch (HiTException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof BaseDataTargetQualifier))
            throw new HiTException("Could not create Form for BaseDataTargetQualifier due to incompatible node. Received " + Obj.getClass());
        
        this.baseDataTargetQualifier = (BaseDataTargetQualifier) Obj;
        
        //bind
        nameProperty = FXMLUtils.rebindField(nameText, nameProperty, baseDataTargetQualifier, "name");
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
		
	}
}