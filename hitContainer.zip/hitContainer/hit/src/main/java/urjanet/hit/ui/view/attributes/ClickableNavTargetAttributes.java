package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.*;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.keys.InputKeys;
import urjanet.pull.web.*;

import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;

public class ClickableNavTargetAttributes<T> implements Initializable, TemplateAttributesPane {

    static final String resourcePath = "/ClickableNavTargetAttributes.fxml";

    @FXML private TextField                 xPathTargetText;
    private Property                        xPathTargetTextProperty;
    @FXML private TextField                 userNameInput;
    private Property                        userNameInputProperty;
    @FXML private TextField                 passwordInput;
    private Property                        passwordInputProperty;
    @FXML private TextField                 framePathText;
    private Property                        framePathTextProperty;
    @FXML private TextField                 returnWindowNumberText;
    private Property                        returnWindowNumberTextProperty;
    @FXML private TextField                 waitForXPathBeforeClickText;
    private Property                        waitForXPathBeforeClickTextProperty;
    @FXML private TextField                 searchKeyForResponseUrlText;
    private Property                        searchKeyForResponseUrlTextProperty;
    @FXML private ComboBox                  navActionCb;
    private Property                        navActionCbProperty;
    @FXML private CheckBox                  searchForBinaryStreamCheck;
    private Property                        searchForBinaryStreamCheckProperty;
    @FXML private CheckBox                  doNotReloadOriginalPageCheck;
    private Property                        doNotReloadOriginalPageCheckProperty;
    @FXML private CheckBox                  clearWebResponseSetCheck;
    private Property                        clearWebResponseSetCheckProperty;
    @FXML private CheckBox                  variableSubstitutionCheck;
    private Property                        variableSubstitutionCheckProperty;
    @FXML private CheckBox                  notAlwaysPresentCheck;
    private Property                        notAlwaysPresentCheckProperty;
    @FXML private TemplateButton            metaDataTargetsBtn;
    @FXML private VBox                      navTargetAttributesVBox;
    @FXML protected NavTargetAttributes     navTargetAttributesVBoxController;

    protected TemplateTreeItem<T> treeItem;
    protected TreeView<T>                   treeView;

    private ClickableNavTarget              clickableNavTarget = new ClickableNavTarget();

    public ClickableNavTargetAttributes( ) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        navActionCb.getItems().addAll(NavAction.values() );
        //TODO this either adds a new target or edits one. Should allow for multiple datatargets
        metaDataTargetsBtn.getItems().forEach( item -> {
            item.setOnAction(event -> {
                try {
                    DataTarget metaDataTargets = ((ClickableNavTarget)treeItem.getValue()).getMetaDataTargets();
                    if( metaDataTargets != null) {
                        for( TemplateTreeItem dataTargetItem : treeItem.getChildren() ) {
                            if( dataTargetItem.getValue() instanceof DataTarget ) {
                                treeView.getSelectionModel().select(dataTargetItem);
                            }
                        }
                    } else {
                        String clazzName = ((TemplateMenuItem)item).getRepresentsClassName();
                        metaDataTargets = (DataTarget) Class.forName( clazzName ).newInstance();
                        ((ClickableNavTarget)treeItem.getValue()).setMetaDataTargets( metaDataTargets );
                        TemplateTreeItem dataTargetItem = new TemplateTreeItem( metaDataTargets );
                        treeItem.getChildren().add( dataTargetItem );
                        treeView.getSelectionModel().select( dataTargetItem );
                    }
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            });
        });

        try {
            initProperties();
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    //TODO test inputelements, doNotReload...
    protected void initProperties() throws HiTException {
        xPathTargetTextProperty = FXMLUtils.bindField( xPathTargetText, clickableNavTarget, "xpathTarget" );
        if( clickableNavTarget.getInputElements() != null ) {
            if (clickableNavTarget.getInputElements().size() > 0) {
                userNameInputProperty = FXMLUtils.bindField(userNameInput, clickableNavTarget.getInputElements().get(0), "valueRegEx");
            }
            if (clickableNavTarget.getInputElements().size() > 1) {
                passwordInputProperty = FXMLUtils.bindField(passwordInput, clickableNavTarget.getInputElements().get(1), "valueRegEx");
            }
        }
        framePathTextProperty = FXMLUtils.bindField( framePathText, clickableNavTarget, "framePath" );
        returnWindowNumberTextProperty = FXMLUtils.bindField( returnWindowNumberText, clickableNavTarget, "returnWindowNumber" );
        waitForXPathBeforeClickTextProperty = FXMLUtils.bindField( waitForXPathBeforeClickText, clickableNavTarget, "waitForXPathBeforeClick" );
        searchKeyForResponseUrlTextProperty = FXMLUtils.bindField( searchKeyForResponseUrlText, clickableNavTarget,
                "searchKeyForResponseUrl", "getSearchKeyOfResponseUrl", "setSearchForResponseUrl" );
        navActionCbProperty = FXMLUtils.bindField( navActionCb, clickableNavTarget, "action" );
        searchForBinaryStreamCheckProperty = FXMLUtils.bindField( searchForBinaryStreamCheck, clickableNavTarget, "searchForBinaryStream" );
        doNotReloadOriginalPageCheckProperty = FXMLUtils.bindField( doNotReloadOriginalPageCheck, clickableNavTarget.getNavigationOptions(), "doNotReloadOriginalPage" );
        clearWebResponseSetCheckProperty = FXMLUtils.bindField( clearWebResponseSetCheck, clickableNavTarget, "isClearWebResponseSet",
                "isClearWebResponseSet", "clearWebResponseSet" );
        variableSubstitutionCheckProperty = FXMLUtils.bindField( variableSubstitutionCheck, clickableNavTarget, "variableSubstitution" );
        notAlwaysPresentCheckProperty = FXMLUtils.bindField( notAlwaysPresentCheck, clickableNavTarget, "notAlwaysPresent" );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        navTargetAttributesVBoxController.setTreeView( treeView );
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        navTargetAttributesVBoxController.setTemplateItem( item );
        clickableNavTarget = (ClickableNavTarget)treeItem.getValue();

        xPathTargetTextProperty = FXMLUtils.rebindField( xPathTargetText, xPathTargetTextProperty, clickableNavTarget, "xpathTarget" );
        if( clickableNavTarget.getInputElements() != null ) {
            if( clickableNavTarget.getInputElements().size() > 0 ) {
                userNameInputProperty = FXMLUtils.rebindField(userNameInput, userNameInputProperty, clickableNavTarget.getInputElements().get(0), "elementXPath");
            }
            if( clickableNavTarget.getInputElements().size() > 1 ) {
                passwordInputProperty = FXMLUtils.rebindField(passwordInput, passwordInputProperty, clickableNavTarget.getInputElements().get(1), "elementXPath" );
            }
        }

        framePathTextProperty = FXMLUtils.rebindField( framePathText, framePathTextProperty, clickableNavTarget, "framePath" );
        returnWindowNumberTextProperty = FXMLUtils.rebindField( returnWindowNumberText, returnWindowNumberTextProperty, clickableNavTarget, "returnWindowNumber" );
        waitForXPathBeforeClickTextProperty = FXMLUtils.rebindField( waitForXPathBeforeClickText, waitForXPathBeforeClickTextProperty,
                clickableNavTarget, "waitForXPathBeforeClick" );
        searchKeyForResponseUrlTextProperty = FXMLUtils.rebindField( searchKeyForResponseUrlText, searchKeyForResponseUrlTextProperty, clickableNavTarget,
                "searchKeyForResponseUrl", "getSearchKeyOfResponseUrl", "setSearchForResponseUrl" );
        navActionCbProperty = FXMLUtils.rebindField( navActionCb, navActionCbProperty, clickableNavTarget, "action" );
        searchForBinaryStreamCheckProperty = FXMLUtils.rebindField( searchForBinaryStreamCheck, searchForBinaryStreamCheckProperty,
                clickableNavTarget, "searchForBinaryStream" );
        if( clickableNavTarget.getNavigationOptions() != null ) {
            if (clickableNavTarget.getNavigationOptions().getDoNotReloadOriginalPage() == null) {
                clickableNavTarget.setDoNotReloadOriginalPage(false);
            }
            doNotReloadOriginalPageCheckProperty = FXMLUtils.rebindField( doNotReloadOriginalPageCheck, doNotReloadOriginalPageCheckProperty,
                    clickableNavTarget.getNavigationOptions(), "doNotReloadOriginalPage" );
        }
        clearWebResponseSetCheckProperty = FXMLUtils.rebindField( clearWebResponseSetCheck, clearWebResponseSetCheckProperty, clickableNavTarget, "isClearWebResponseSet",
                "isClearWebResponseSet", "clearWebResponseSet" );
        variableSubstitutionCheckProperty = FXMLUtils.rebindField( variableSubstitutionCheck, variableSubstitutionCheckProperty, clickableNavTarget, "variableSubstitution" );
        notAlwaysPresentCheckProperty = FXMLUtils.rebindField( notAlwaysPresentCheck, notAlwaysPresentCheckProperty, clickableNavTarget, "notAlwaysPresent" );
    }

    @Override
    public void onUnload() {
        if( ( clickableNavTarget.getInputElements() == null || clickableNavTarget.getInputElements().size() < 1 )
                && (userNameInput.getText() != null || passwordInput.getText() != null )) {
            InputElement userName =  new VariableInputElement( userNameInput.getText(), InputKeys.LOGIN_ID.getValue());;
            InputElement password = new VariableInputElement( passwordInput.getText(), InputKeys.LOGIN_PASS.getValue());
            clickableNavTarget.setInputElements(Arrays.asList( userName, password ));
        }
    }
}
