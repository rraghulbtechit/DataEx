package urjanet.hit.ui.view.attributes.contextFilters;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;

public class ContextFilterAttributes implements Initializable, TemplateAttributesPane {
	
	public static final String resourcePath = "/ContextFilterAttributes.fxml";
	
	@FXML protected TemplateButton contextFiltersBtn;
	
	private TemplateTreeItem treeItem;
    private TreeView treeView;
    
    private PdfDataTarget pdfDataTarget;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		for(MenuItem item : contextFiltersBtn.getItems()) {
            item.setOnAction( filterItemHandler );
        }
	}
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		
		this.pdfDataTarget = (PdfDataTarget) item.getValue();
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
		
	}

	private EventHandler<ActionEvent> filterItemHandler = event -> {
		try {
        	
        	TemplateTreeItem<T> filterItem;
        	
            String filterClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            ContextFilter contextFilter = ((ContextFilter)Class.forName(filterClassName).newInstance()); //TODO handle classes without arg-less c'tor
            List<ContextFilter> list = (List<ContextFilter>) pdfDataTarget.getFilters();
            if( list != null && list.size() > 0 ) {
                list = new ArrayList<>( list );
                list.add( contextFilter );
            } else {
                list = new ArrayList<>();
                list.add(contextFilter);
            }

            //this.treeItem.getChildren().clear();
            pdfDataTarget.setFilters(list);
            
            filterItem = new TemplateTreeItem( contextFilter );
            addSelectNode(filterItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
    
    private void addSelectNode(TemplateTreeItem templateTreeItem) {
        treeItem.getChildren().add(templateTreeItem);
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }    
}
