package urjanet.hit.ui.view.attributes.contextFilters;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.pdf.context.TargetContext.TargetContextDirection;
import urjanet.pull.web.pdf.filter.PreviousFilter;

public class PreviousFilterAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/PreviousFilterAttributes.fxml";
	
	@FXML protected TextField depthOfPreviousContextsTf;
	protected Property depthOfPreviousContextsProperty;
	@FXML protected ComboBox targetContextDirectionCombo;
	protected Property targetContextDirectionProperty;
	
	private PreviousFilter previousFilter;
	
	public PreviousFilterAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	targetContextDirectionCombo.getItems().addAll(TargetContextDirection.values());
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof PreviousFilter))
            throw new HiTException("Could not create Form for PreviousFilter due to incompatible node. Received " + Obj.getClass());
        
        this.previousFilter = (PreviousFilter) Obj;
        
        addBinding();
	}
	
	public void addBinding() {
		
		try {
        	//bind
			if( depthOfPreviousContextsProperty != null ) FXMLUtils.unbindField( depthOfPreviousContextsTf, depthOfPreviousContextsProperty );
			depthOfPreviousContextsProperty = FXMLUtils.bindField(depthOfPreviousContextsTf, previousFilter, "depthOfPreviousContexts");
        	
        	if( targetContextDirectionProperty != null ) FXMLUtils.unbindField( targetContextDirectionCombo, targetContextDirectionProperty );
        	targetContextDirectionProperty = FXMLUtils.bindField(targetContextDirectionCombo, previousFilter, "targetContextDirection");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }

	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}