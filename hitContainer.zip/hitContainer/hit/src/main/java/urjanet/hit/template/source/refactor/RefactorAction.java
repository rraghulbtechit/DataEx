package urjanet.hit.template.source.refactor;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.TypeDeclaration;

@Deprecated
public abstract class RefactorAction {

	public abstract RefactorResult refactor( TypeDeclaration typeDeclaration, Expression expression );

}
