package urjanet.hit.template.source.builder.constructor;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import urjanet.pull.bool.AndDataTargetQualifier;
import urjanet.pull.bool.ComparisonDataTargetQualifier;
import urjanet.pull.bool.DateQualifier;
import urjanet.pull.bool.NotDataTargetQualifier;
import urjanet.pull.bool.NumberQualifier;
import urjanet.pull.bool.OrDataTargetQualifier;
import urjanet.pull.bool.StringQualifier;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.pdf.PdfDataTargetQualifier;

public class DataTargetQualifierConstructorResolution {

	public static List<Object> resolveConstructorParameters( DataTargetQualifier object) throws UnresolvedConstructorException {
		
		if( object instanceof AndDataTargetQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (AndDataTargetQualifier) object );
		else if( object instanceof OrDataTargetQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (OrDataTargetQualifier) object );
		else if( object instanceof PdfDataTargetQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (PdfDataTargetQualifier) object );
		else if( object instanceof NotDataTargetQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (NotDataTargetQualifier) object );
		else if( object instanceof StringQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (StringQualifier) object );
		else if( object instanceof NumberQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (NumberQualifier) object );
		else if( object instanceof DateQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (DateQualifier) object );
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
	}

	public static List<Object> resolveConstructorParameters( AndDataTargetQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String name = qualifier.getName();
		DataTargetQualifier c1 = qualifier.getC1();
		DataTargetQualifier c2 = qualifier.getC2();
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, name, c1, c2);
		return properties;
		
	}

	public static List<Object> resolveConstructorParameters( OrDataTargetQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String name = qualifier.getName();
		DataTargetQualifier c1 = qualifier.getC1();
		DataTargetQualifier c2 = qualifier.getC2();
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, name, c1, c2);
		return properties;
		
	}
	
	public static List<Object> resolveConstructorParameters( PdfDataTargetQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		DataTarget dataTarget = qualifier.getQualifyingTarget();
		ConstructorResolutionFactory.checkNullAndAddAll(properties, dataTarget);
		return properties;
		
	}

	public static List<Object> resolveConstructorParameters( NotDataTargetQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		String name = qualifier.getName();
		DataTargetQualifier target = qualifier.getTarget();
		
		ConstructorResolutionFactory.checkNullAndAddAll(properties, name, target);
		return properties;
		
	}

	public static List<Object> resolveConstructorParameters( StringQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		ComparisonDataTargetQualifier.ComparisonOperator comparisonOperator = qualifier.getComparisonOperator();
		if( !comparisonOperator.equals(ComparisonDataTargetQualifier.ComparisonOperator.EQUAL_TO ))
			properties.add(comparisonOperator);
		// TODO and getter for ignore case
		// qualifier.isIgnoreCase();
		
		DataTarget target1 = qualifier.getQualifyingTarget1();
		DataTarget target2 = qualifier.getQualifyingTarget2();
		
		properties.add(target1);
		properties.add(target2);
		
		return properties;
		
	}

	public static List<Object> resolveConstructorParameters( NumberQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		ComparisonDataTargetQualifier.ComparisonOperator comparisonOperator = qualifier.getComparisonOperator();
		if( !comparisonOperator.equals(ComparisonDataTargetQualifier.ComparisonOperator.EQUAL_TO ))
			properties.add(comparisonOperator);
		
		DataTarget target1 = qualifier.getQualifyingTarget1();
		DataTarget target2 = qualifier.getQualifyingTarget2();
		
		properties.add(target1);
		properties.add(target2);
		
		return properties;
		
	}

	public static List<Object> resolveConstructorParameters( DateQualifier qualifier) {
		
		List<Object> properties = new ArrayList<Object>();
	
		ComparisonDataTargetQualifier.ComparisonOperator comparisonOperator = qualifier.getComparisonOperator();
		if( !comparisonOperator.equals(ComparisonDataTargetQualifier.ComparisonOperator.EQUAL_TO ))
			properties.add(comparisonOperator);
		
		DateFormat dataFormat = qualifier.getDateFormat();
		
		DataTarget target1 = qualifier.getQualifyingTarget1();
		DataTarget target2 = qualifier.getQualifyingTarget2();
		
		properties.add(target1);
		properties.add(target2);
		
		return properties;
		
	}

}
