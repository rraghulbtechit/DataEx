package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.template.source.TypeTracker;

public class CommonTemplateItemBuilder implements TemplateItemBuilder{

	private static final CommonTemplateItemBuilder theInstance = new CommonTemplateItemBuilder();
	
	public static CommonTemplateItemBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private CommonTemplateItemBuilder() {}
	
	@Override
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker) {
	
		return createClassInstance( typeDeclaration, methodDeclaration, object, typeTracker );
	}

	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
	}

}


