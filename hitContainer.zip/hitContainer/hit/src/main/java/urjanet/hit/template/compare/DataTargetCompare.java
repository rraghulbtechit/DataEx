package urjanet.hit.template.compare;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.beanutils.BeanMap;

import com.sun.xml.txw2.output.DataWriter;

import urjanet.pull.web.DataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;

public class DataTargetCompare {

	public static List<Object> diff( DataTarget dataTarget1, DataTarget dataTarget2 ) throws UnsupportedComparisonException{
		
		if( dataTarget1 instanceof PdfDataTarget )
			return diff( (PdfDataTarget) dataTarget1, (PdfDataTarget) dataTarget2 );
		
		throw new UnsupportedComparisonException( "Comparison not implemented for " + dataTarget1.getClass() );
	}
	
	public static List<Object> diff( PdfDataTarget pdfDataTarget, PdfDataTarget pdfDataTarget2 ) throws UnsupportedComparisonException{
		
		if ( ! pdfDataTarget.getClass().equals( pdfDataTarget2.getClass()) )
			return null;
		
		List<Object> differences = new ArrayList<>();

		Map<Object, Object> propertyMap1 = new BeanMap(pdfDataTarget); 
		Map<Object, Object> propertyMap2 = new BeanMap(pdfDataTarget2); 
		
		for( Entry<Object, Object> entry : propertyMap1.entrySet() ) {
			
			System.out.println( "comparing " + entry.getKey() );
			Object value1 = entry.getValue();
			Object value2 = propertyMap2.get( entry.getKey() );
			if( value1 != null && value2 != null ){
				List difference = TemplateItemCompare.diff( value1, value2 );
				if( difference != null )
					differences.addAll( difference );
			}
		}
		
		return differences;
	}
	
	public static void main( String[] args ) {
		
		try {
			System.out.println( diff( 
				new PdfDataTarget( "ee" ).setDefaultValue( "abc" ), 
				new PdfDataTarget( "ee" ).setDefaultValue("che") ));
		} catch( UnsupportedComparisonException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
