package urjanet.hit.platform;

import java.io.File;
import java.io.FilenameFilter;
import java.util.*;

import urjanet.hit.HiTException;
import urjanet.hit.utils.HiTProperties;
import urjanet.hit.utils.ReflectionUtils;
import urjanet.keys.AccountKeys;
import urjanet.keys.AccountSearchKeys;
import urjanet.keys.AddressKeys;
import urjanet.keys.ChargeKeys;
import urjanet.keys.DomainKeys;
import urjanet.keys.IntervalKeys;
import urjanet.keys.KeyManager;
import urjanet.keys.MessageKeys;
import urjanet.keys.MeterKeys;
import urjanet.keys.ProviderKeys;
import urjanet.keys.RecentPaymentKeys;
import urjanet.keys.SmartMeterKeys;
import urjanet.keys.StatKeys;
import urjanet.keys.StatementKeys;
import urjanet.keys.UnrelatedChargeKeys;
import urjanet.keys.UsageKeys;
import urjanet.keys.uds.GroupingKeys;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.template.TemplateProvider;

/**
 * Created by shankerj on 4/18/2016.
 */
public class PlatformAccessor {

    //TODO List type
    public static List<String> getProviders() {
        return null;
    }

    //TODO List type
    public static List<String> getTemplates(String providerAlias) {
        return null;
    }

    /**
     * Get all template class simple names in system
     *
     * TODO
     * @return
     */
    public static List<String> getAllTemplates() {
        List<String> templates = new ArrayList<>();

        Set<Class<? extends Object>> templateClasses = ReflectionUtils.getClassesInPackage(TemplateProvider.class.getPackage().getName());
        for (Class<? extends Object> templateClass : templateClasses) {
            templates.add( templateClass.getSimpleName() );
        }
        if(templates.size() > 0)
            return templates;

        /* This is a workaround for some environments */
        String templatesSrcPath = HiTProperties.getProperty( "templatePath" );
        File templatesDir = new File(templatesSrcPath);
        File[] files = templatesDir.listFiles((dir, name) -> {
            return name.endsWith("TemplateProvider.java");
        });

        for(File f : files) {
            String template = f.getName().substring(0, f.getName().lastIndexOf("."));
            templates.add(template);
        }
        return templates;
    }

    //TODO List type
    public static List<?> getExemplars(String template) {
        return null;
    }

    /**
     * Given a template name, instantiate the template from classpath
     *
     * TODO When source is created, what should be the path?
     *
     * @param template
     * @return
     */
    public static PullJobTemplate getTemplate(String template) throws HiTException{

        try {
            Class clazz = Class.forName("urjanet.pull.template." + template);

            if (! urjanet.pull.template.TemplateProvider.class.isAssignableFrom(clazz))
                throw new HiTException("Given template " + template + " is not of type PullJobTemplate. It is " + clazz.getTypeName());

            TemplateProvider t = (TemplateProvider) clazz.newInstance();
            return t.getTemplate();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e){
            throw new HiTException(e + ":" + e.getMessage());
        }
    }

    public static String getRootGroup() {
        return "providerGroup";
    }

    public static List<String> getGroupingKeyNames() {

        List<String> groups = new ArrayList();
        for(GroupingKeys key : GroupingKeys.values()) {
            groups.add(key.getValue());
        }
        return groups;
    }

    public static List<String> getValidChildGroupNames(String parentGroupName) throws HiTException {

        if(parentGroupName == null) {
            return null;
        }

        List<String> childGroupNames = new ArrayList<>();
        Collection<GroupingKeys> childGroups = KeyManager.getInstance().getValidChildGroupsFor(parentGroupName);
        if( childGroups != null ) {
            for(GroupingKeys groupKey : childGroups) {
                childGroupNames.add(groupKey.getValue());
            }
            Collections.sort(childGroupNames);
        }

        return childGroupNames;
    }

    private static Map<String, Map<String, DomainKeys>> keySetsById;
    public static Map<String, DomainKeys> getDomainKeys(String groupName) {
        if(keySetsById == null)
            keySetsById = KeyManager.getInstance().getKeySetsById();

        if("providerGroup".equals(groupName))
            return keySetsById.get(ProviderKeys.KEYSET_ID);
        else if("statementGroup".equals(groupName))
            return keySetsById.get(StatementKeys.KEYSET_ID);
        else if("accountGroup".equals(groupName))
            return keySetsById.get(AccountKeys.KEYSET_ID);
        else if("meterGroup".equals(groupName))
            return keySetsById.get(MeterKeys.KEYSET_ID);
        else if("usageGroup".equals(groupName))
            return keySetsById.get(UsageKeys.KEYSET_ID);
        else if("chargeGroup".equals(groupName))
            return keySetsById.get(ChargeKeys.KEYSET_ID);
        else if("unrelatedChargesGroup".equals(groupName))
            return keySetsById.get(UnrelatedChargeKeys.KEYSET_ID);
        else if("additionalProvider".equals(groupName))
            return keySetsById.get(ProviderKeys.KEYSET_ID);
        else if("messageGroup".equals(groupName))
            return keySetsById.get(MessageKeys.KEYSET_ID);
        else if("statisticsGroup".equals(groupName))
            return keySetsById.get(StatKeys.KEYSET_ID);
        else if("addressGroup".equals(groupName))
            return keySetsById.get(AddressKeys.KEYSET_ID);
        else if("accountSearchGroup".equals(groupName))
            return keySetsById.get(AccountSearchKeys.KEYSET_ID);
        else if("smartMeterGroup".equals(groupName))
            return keySetsById.get(SmartMeterKeys.KEYSET_ID);
        else if("recentPaymentGroup".equals(groupName))
            return keySetsById.get(RecentPaymentKeys.KEYSET_ID);
        else if("intervalGroup".equals(groupName))
            return keySetsById.get(IntervalKeys.KEYSET_ID);

        return null;
    }

    /**
     * List all allowed keys for a group.
     *
     * @param groupName
     * @return
     */
    public static Map<String, DomainKeys> getAllowedKeysForGroup(String groupName) {

        return KeyManager.getInstance().getAllowedKeysForGroup(groupName);
        //return getDomainKeys(groupName);
    }
    /*
        Test code
     */
    public static void main(String[] args) throws HiTException {
        /* //Get a PullJobTemplate
        if (args.length < 1) throw new HiTException("Need <template> as argument");
        String template = args[0];
        PullJobTemplate t = getTemplate(template);*/
        //get grouping keys
        System.out.println(getGroupingKeyNames());
        System.out.println(getValidChildGroupNames(getRootGroup()));

        System.out.println(getDomainKeys(getRootGroup()));
        System.out.println(getValidChildGroupNames("accountSearchGroup"));
        /*KeyManager keyManager = KeyManager.getInstance();
        System.out.println(keyManager.getGroupForName(getRootGroup()));*/
        //System.out.print(keyManager.getGroupForName("providerGroup"));
/*        System.out.println(getValidChildGroupNames("providerGroup"));
        Map<String, Map<String, DomainKeys>> keySetsById = keyManager.getKeySetsById();
        System.out.println(keySetsById.keySet());
        System.out.println(keySetsById.values());*/
    }
}
