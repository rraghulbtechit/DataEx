package urjanet.hit.template.source.refactor;

import java.util.List;

import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.ast.compare.ASTCompare;
import urjanet.hit.template.compare.UnsupportedComparisonException;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;
import urjanet.hit.utils.TypeUtils;

public class MergeMethods {

	private static final Logger log = LoggerFactory.getLogger(MergeMethods.class);
	
	public static void merge( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration ){
		
		getSimilarMethods( typeDeclaration, methodDeclaration );
		
		typeDeclaration.bodyDeclarations().add( methodDeclaration );
	}

	private static void getSimilarMethods( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration ) {

		List<BodyDeclaration> bodyDeclarations = typeDeclaration.bodyDeclarations();
		
		for( BodyDeclaration bodyDeclaration : bodyDeclarations ) {
			
			if( bodyDeclaration instanceof MethodDeclaration ){
				MergeMethods.isMergable( methodDeclaration, ( MethodDeclaration )bodyDeclaration );
			}
		}
		
	}

	public static boolean isMergable( MethodDeclaration methodDeclaration1, MethodDeclaration methodDeclaration2 ){
	
		
		log.info( "Checking whether methods {} and {} are mergable", methodDeclaration1.getName().getIdentifier(), methodDeclaration2.getName().getIdentifier() );
			Type returnType1 = methodDeclaration1.getReturnType2();
			Type returnType2 = methodDeclaration2.getReturnType2();
			
			if(! TypeUtils.isSameType( returnType1, returnType2 ) ){
				return false;
			}
			
			try {
				
				System.out.println( "****" + ASTCompare.compare(methodDeclaration1.getBody(), methodDeclaration2.getBody()) );
			} catch( UnsupportedComparisonException e ) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	//		Block block1 = methodDeclaration1.getBody().
			
			return false;
		}

	public static boolean isVariablizableType( Object object ) {
		
		return false;
	}
	public static void main( String[] args ) {
		String c = new String("abcd").intern();
		String d = new String("abcd").intern();
		System.out.println(c == d);  // False
		System.out.println(c.equals(d)); // True
	}
	
}
