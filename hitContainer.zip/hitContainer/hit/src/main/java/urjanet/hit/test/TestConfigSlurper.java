package urjanet.hit.test;

import groovy.util.ConfigObject;
import groovy.util.ConfigSlurper;

import java.net.URL;
import java.util.List;
import java.util.Map;

/**
 * Created by shankerj on 9/5/2016.
 */
public class TestConfigSlurper {

    public static void main( String[] args ) {

        URL url = TestConfigSlurper.class.getClassLoader().getResource("conf/properties.groovy");
        ConfigObject config = new ConfigSlurper("win").parse( url );
        System.out.println(config.getConfigFile());
        System.out.println(config.entrySet());
        Map props = config.flatten();
        System.out.println( props.keySet() );
        System.out.println( props.get("templatePath") );
        System.out.println( props.get("section.key") );
        List list = (List)props.get("section.subsection.subarray");
        System.out.println( list.size() +""+ list.get(2));
        System.out.println( props.get("section.subsection.aMap.a"));
    }
}
