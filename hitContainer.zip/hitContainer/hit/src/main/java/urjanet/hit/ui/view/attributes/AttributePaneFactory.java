package urjanet.hit.ui.view.attributes;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;

import javafx.fxml.FXMLLoader;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TreeView;
import javafx.util.Pair;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.contextFilters.DirectionFilterAttributes;
import urjanet.hit.ui.view.attributes.contextFilters.HorizontalFilterAttributes;
import urjanet.hit.ui.view.attributes.contextFilters.PreviousFilterAttributes;
import urjanet.hit.ui.view.attributes.contextFilters.RangeFilterAttributes;
import urjanet.hit.ui.view.attributes.contextFilters.VerticalFilterAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.FilterKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.IndexedKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.MultiStringKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.RectKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.RegExKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.StringKeyAttributes;
import urjanet.hit.ui.view.attributes.contextKeys.VariableStringKeyAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.ConcatOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.DateOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.DecimalFormatOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.JavaScriptOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.MathOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.RegEXOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.ReplaceOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.SimpleOperatorChainAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.SplitGetOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.StringOperatorAttributes;
import urjanet.hit.ui.view.attributes.extractOperators.TextNodeConcatOperatorAttributes;
import urjanet.hit.ui.view.attributes.qualifier.AndDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.BaseDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.CoordinateDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.DateQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.NotDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.NumberQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.OrDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.PdfDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.StringQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.TextDataTargetQualifierAttributes;
import urjanet.hit.ui.view.attributes.qualifier.XmlDataTargetQualifierAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.bool.AndDataTargetQualifier;
import urjanet.pull.bool.DateQualifier;
import urjanet.pull.bool.NotDataTargetQualifier;
import urjanet.pull.bool.NumberQualifier;
import urjanet.pull.bool.OrDataTargetQualifier;
import urjanet.pull.bool.StringQualifier;
import urjanet.pull.core.PageSpec;
import urjanet.pull.operator.ConcatOperator;
import urjanet.pull.operator.DateOperator;
import urjanet.pull.operator.DecimalFormatOperator;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.operator.JavaScriptOperator;
import urjanet.pull.operator.MathOperator;
import urjanet.pull.operator.RegExOperator;
import urjanet.pull.operator.ReplaceOperator;
import urjanet.pull.operator.SimpleOperatorChain;
import urjanet.pull.operator.SplitGetOperator;
import urjanet.pull.operator.StringOperator;
import urjanet.pull.operator.TextNodeConcatOperator;
import urjanet.pull.web.BaseDataTargetQualifier;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.ConditionalPageSpec;
import urjanet.pull.web.CustomRequestNavTarget;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.ExpandableDataTarget;
import urjanet.pull.web.ExpandableNavTarget;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.JavaScriptNavTarget;
import urjanet.pull.web.NavTarget;
import urjanet.pull.web.TrackLoginFailurePageSpec;
import urjanet.pull.web.UrlNavTarget;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.XmlDataTarget;
import urjanet.pull.web.XmlDataTargetQualifier;
import urjanet.pull.web.XmlTargetGroup;
import urjanet.pull.web.coordinate.CoordinateDataTarget;
import urjanet.pull.web.coordinate.CoordinateDataTargetQualifier;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.ExpandablePdfPageDataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfDataTargetQualifier;
import urjanet.pull.web.pdf.PdfPageDataTarget;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.filter.DirectionFilter;
import urjanet.pull.web.pdf.filter.HorizontalFilter;
import urjanet.pull.web.pdf.filter.PreviousFilter;
import urjanet.pull.web.pdf.filter.RangeFilter;
import urjanet.pull.web.pdf.filter.VerticalFilter;
import urjanet.pull.web.pdf.key.ContextKey;
import urjanet.pull.web.pdf.key.FilterKey;
import urjanet.pull.web.pdf.key.IndexedKey;
import urjanet.pull.web.pdf.key.MultiStringKey;
import urjanet.pull.web.pdf.key.RectKey;
import urjanet.pull.web.pdf.key.RegExKey;
import urjanet.pull.web.pdf.key.StringKey;
import urjanet.pull.web.pdf.key.VariableStringKey;
import urjanet.pull.web.reference.GroupReference;
import urjanet.pull.web.text.ExpandableTextDataTarget;
import urjanet.pull.web.text.TextDataTarget;
import urjanet.pull.web.text.TextDataTargetQualifier;

/**
 * Returns a form for AttributePane depending on the node type.
 */
public class AttributePaneFactory {

    private static Map<Object, Pair<ScrollPane, TemplateAttributesPane>> attributes = new HashMap<>();

    private AttributePaneFactory() {
    }

    private static TemplateAttributesPane getController( Object templateObj ) {
        Pair<ScrollPane, TemplateAttributesPane> pane = attributes.get(templateObj.getClass());
        if( pane != null ) {
            return pane.getValue();
        }

        return null;
    }

    public static TemplateAttributesPane getController( TemplateTreeItem treeItem ) {
        Object templateObj = treeItem.getValue();
        return getController( templateObj );
    }

    private static ScrollPane getAttributePane( Object templateObj ) {
        Pair<ScrollPane, TemplateAttributesPane> pane = attributes.get(templateObj.getClass());
        if( pane != null ) {
            return pane.getKey();
        }

        return null;
    }

    public static ScrollPane getAttributePane(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {

    	//this is for existng templates case
        Object templateObj = treeItem.getValue();
        TemplateAttributesPane attributeController = getController(templateObj);
        if( attributeController != null ) {
            attributeController.setTemplateItem( treeItem );
            attributeController.setTreeView( treeView );
            return getAttributePane( templateObj );
        }

        //this is for a new template object
        Pair<ScrollPane, TemplateAttributesPane> pane;

        if (templateObj instanceof WebPullJobTemplate)
            pane = wrapPane(new WebPullJobTemplateAttributes(treeItem, treeView));
        else if( templateObj instanceof PageSpec )
            pane = getPageSpecPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof XmlTargetGroup )
            pane = wrapPane(new XmlTargetGroupAttributes(treeItem, treeView));
        else if( templateObj instanceof  DataTarget )
            pane = getDataTargetPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof DataTargetQualifier )
            pane = getDataTargetQualifierPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof ContextKey )
            pane = getContextKeyPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof ContextFilter )
            pane = getContextFilterPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof GroupPolicy )
        	pane = wrapPane(new GroupPolicyAttributes(treeItem, treeView));
        else if( templateObj instanceof BaseDataTargetQualifier )
            pane = wrapPane( BaseDataTargetQualifierAttributes.resourcePath);
        else if( templateObj instanceof NavTarget )
            pane = getNavTargetPane(templateObj);
        else if(templateObj instanceof ExtractOperator)
        	pane = getExtractOperatorPane(treeItem, treeView, templateObj);
        else if( templateObj instanceof GroupReference)
            pane = wrapPane(new GroupReferenceAttributes(treeItem, treeView));
        else
            pane = wrapPane(new NodeAttributes(treeItem, treeView));

      //  System.out.println("Class Name : " + templateObj.getClass());
        attributeController = pane.getValue();
        attributeController.setTemplateItem( treeItem );
        attributeController.setTreeView( treeView );
        treeItem.setAttributesPane( attributeController );

        ScrollPane  attributePane = pane.getKey();
        attributes.put( templateObj.getClass(), pane );

        return attributePane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getDataTargetPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) throws HiTException {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if( templateObj instanceof CoordinateDataTarget)
            pane = wrapPane( CoordinateDataTargetAttributes.resourcePath);
        else if( templateObj instanceof ExpandableTextDataTarget)
            pane = wrapPane( ExpandableTextDataTargetAttributes.resourcePath);
        else if( templateObj instanceof TextDataTarget)
            pane = wrapPane( TextDataTargetAttributes.resourcePath);
        else if( templateObj instanceof ExpandableDataTarget)
            pane = wrapPane(new ExpandableDataTargetAttributes(treeItem, treeView));
        else if( templateObj instanceof XmlDataTarget)
            pane = wrapPane(new XmlDataTargetAttributes(treeItem, treeView));
        else if( templateObj instanceof ExpandablePdfPageDataTarget)
            pane = wrapPane(new ExpandablePdfPageDataTargetAttributes(treeItem, treeView));
        else if( templateObj instanceof PdfPageDataTarget)
            pane = wrapPane(new PdfPageDataTargetAttributes(treeItem, treeView));
        else if( templateObj instanceof ExpandablePdfDataTarget)
            pane = wrapPane(new ExpandablePdfDataTargetAttributes(treeItem, treeView));
        else if( templateObj instanceof PdfDataTarget)
            pane = wrapPane(new PdfDataTargetAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getPageSpecPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if (templateObj instanceof BasePageSpec)
            pane = wrapPane(new BasePageSpecAttributes(treeItem, treeView));
        else if(templateObj instanceof ConditionalPageSpec)
            pane = wrapPane(new ConditionalPageSpecAttributes(treeItem, treeView));
        else if( templateObj instanceof TrackLoginFailurePageSpec )
            pane = wrapPane( new TrackedLoginPageSpecAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getNavTargetPane(Object templateObj) throws HiTException {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if( templateObj instanceof JavaScriptNavTarget) {
            pane = wrapPane( JavaScriptNavTargetAttributes.resourcePath);
        }
        else if( templateObj instanceof CustomRequestNavTarget) {
            pane = wrapPane( CustomRequestNavTargetAttributes.resourcePath);
        }
        else if( templateObj instanceof ExpandableNavTarget) {
            pane = wrapPane( ExpandableNavTargetAttributes.resourcePath );
        }
        else if( templateObj instanceof ClickableNavTarget) {
            pane = wrapPane( ClickableNavTargetAttributes.resourcePath );
        }
        else if( templateObj instanceof UrlNavTarget) {
            pane = wrapPane( UrlNavTargetAttributes.resourcePath );
        }
        else
            pane = null;
        return pane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getContextKeyPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if( templateObj instanceof StringKey)
            pane = wrapPane(new StringKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof FilterKey)
            pane = wrapPane(new FilterKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof IndexedKey)
            pane = wrapPane(new IndexedKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof MultiStringKey)
            pane = wrapPane(new MultiStringKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof RectKey)
            pane = wrapPane(new RectKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof RegExKey )
            pane = wrapPane(new RegExKeyAttributes(treeItem, treeView));
        else if( templateObj instanceof VariableStringKey )
            pane = wrapPane(new VariableStringKeyAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getContextFilterPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if (templateObj instanceof DirectionFilter)
            pane = wrapPane(new DirectionFilterAttributes(treeItem, treeView));
        else if (templateObj instanceof HorizontalFilter)
            pane = wrapPane(new HorizontalFilterAttributes(treeItem, treeView));
        else if (templateObj instanceof PreviousFilter)
            pane = wrapPane(new PreviousFilterAttributes(treeItem, treeView));
        else if (templateObj instanceof RangeFilter)
            pane = wrapPane(new RangeFilterAttributes(treeItem, treeView));
        else if (templateObj instanceof VerticalFilter)
            pane = wrapPane(new VerticalFilterAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> getDataTargetQualifierPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if (templateObj instanceof AndDataTargetQualifier)
            pane = wrapPane(new AndDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof OrDataTargetQualifier)
            pane = wrapPane(new OrDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof NotDataTargetQualifier)
            pane = wrapPane(new NotDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof PdfDataTargetQualifier)
            pane = wrapPane(new PdfDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof XmlDataTargetQualifier)
            pane = wrapPane(new XmlDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof TextDataTargetQualifier)
            pane = wrapPane(new TextDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof CoordinateDataTargetQualifier)
            pane = wrapPane(new CoordinateDataTargetQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof DateQualifier)
            pane = wrapPane(new DateQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof NumberQualifier)
            pane = wrapPane(new NumberQualifierAttributes(treeItem, treeView));
        else if (templateObj instanceof StringQualifier)
            pane = wrapPane(new StringQualifierAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }
    
    protected static Pair<ScrollPane, TemplateAttributesPane> getExtractOperatorPane(TemplateTreeItem treeItem, TreeView treeView, Object templateObj) {
        Pair<ScrollPane, TemplateAttributesPane> pane;
        if (templateObj instanceof ConcatOperator)
            pane = wrapPane(new ConcatOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof MathOperator)
            pane = wrapPane(new MathOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof ReplaceOperator)
            pane = wrapPane(new ReplaceOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof StringOperator)
            pane = wrapPane(new StringOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof DateOperator)
            pane = wrapPane(new DateOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof TextNodeConcatOperator)
            pane = wrapPane(new TextNodeConcatOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof DecimalFormatOperator)
            pane = wrapPane(new DecimalFormatOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof JavaScriptOperator)
            pane = wrapPane(new JavaScriptOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof RegExOperator)
            pane = wrapPane(new RegEXOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof SplitGetOperator)
            pane = wrapPane(new SplitGetOperatorAttributes(treeItem, treeView));
        else if (templateObj instanceof SimpleOperatorChain)
            pane = wrapPane(new SimpleOperatorChainAttributes(treeItem, treeView));
        else
            pane = null;
        return pane;
    }
    
    protected static Pair<ScrollPane, TemplateAttributesPane> wrapPane( String resourcePath )
            throws HiTException {
        ScrollPane attributePane;
        FXMLLoader loader = FXMLUtils.loader( resourcePath );
        if( ! (loader.getRoot() instanceof ScrollPane )) {
            attributePane = new ScrollPane();
            attributePane.setContent(loader.getRoot());
        } else {
            attributePane = loader.getRoot();
        }
        return new Pair<>(attributePane, loader.getController());
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> wrapPane( ScrollPane pane ) {
        if( pane instanceof TemplateAttributesPane)
            return wrapPane( pane, (TemplateAttributesPane)pane );
        else
            try {
                throw new HiTException("Attribute Pane controller needs to be "+TemplateAttributesPane.class.getName());
            } catch (HiTException e) {
                e.printStackTrace();
            }

        return null;
    }

    protected static Pair<ScrollPane, TemplateAttributesPane> wrapPane(@Nonnull ScrollPane pane, @Nonnull TemplateAttributesPane controller ) {
        return new Pair<>( pane, controller );
    }
}
