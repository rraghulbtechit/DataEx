package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.GroupPolicy.GroupAction;

public class GroupPolicyConstructorResolution {

	public static List<Object> resolveConstructorParameters( GroupPolicy groupPolicy ) {
		
		String groupName = groupPolicy.getGroupName();
		GroupAction groupAction = groupPolicy.getAction();
		
		List<Object> properties = new ArrayList<Object>();
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties, groupName, groupAction);
		
		return properties;
	}

}
