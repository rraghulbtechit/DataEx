package urjanet.hit.template.source.builder.constructor;

import java.util.Arrays;
import java.util.List;

import urjanet.pull.core.TargetGroup;

public class ArrayConstructorResolution {

	public static List<?> resolveConstructorParameters( TargetGroup[] nodeList ) {
		
		
		return Arrays.asList( nodeList );
	}

}
