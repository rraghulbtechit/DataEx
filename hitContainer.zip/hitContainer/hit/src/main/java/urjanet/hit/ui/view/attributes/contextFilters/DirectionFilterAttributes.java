package urjanet.hit.ui.view.attributes.contextFilters;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextKeys.ContextKeyAttributes.KeyFormat;
import urjanet.hit.ui.view.attributes.contextKeys.KeysAttributes;
import urjanet.pull.web.coordinate.CoordinateTargetDefinition.Direction;
import urjanet.pull.web.pdf.filter.DirectionFilter;
import urjanet.pull.web.pdf.filter.OverlapPosition;
import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.PhraseTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.TargetFormat;

public class DirectionFilterAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/DirectionFilterAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;
	@FXML protected ComboBox directionCombo;
	protected Property directionProperty;
	@FXML protected ComboBox keyFormatCb;
	protected Property keyFormatProperty;
	@FXML protected TextField maxDistanceTf;
	protected Property maxDistanceProperty;
	@FXML protected ComboBox overlapTextPositionCombo;
	protected Property overlapTextPositionProperty;
	
	private DirectionFilter directionFilter;
	private KeysAttributes keyAttributes;
	
	public DirectionFilterAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	FXMLLoader loader = new FXMLUtils().loader(KeysAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loader.getRoot());
		keyAttributes = loader.getController();
		
    	setTemplateItem(treeItem);
        setTreeView(treeView);
		
        directionCombo.getItems().addAll(Direction.values());
		overlapTextPositionCombo.getItems().addAll(OverlapPosition.values());
		keyFormatCb.getItems().addAll(KeyFormat.values());
		
		keyFormatCb.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue ov, Object t, Object t1) {
            	if(t1 == KeyFormat.LINE)
            		directionFilter.setTargetFormat(new LineTargetFormat());
            	else if(t1 == KeyFormat.PHRASE)
            		directionFilter.setTargetFormat(new PhraseTargetFormat());
            	else if(t1 == KeyFormat.SINGLEWORD)
            		directionFilter.setTargetFormat(new SingleWordTargetFormat());
            }
        });
    }
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        keyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof DirectionFilter))
            throw new HiTException("Could not create Form for DirectionFilter due to incompatible node. Received " + Obj.getClass());
        
        this.directionFilter = (DirectionFilter) Obj;
        
        addBinding();
        
        keyAttributes.setTemplateItem(item);
	}
	
	private void addBinding() {
		
		try {
        	//bind
			if( directionProperty != null ) FXMLUtils.unbindField( directionCombo, directionProperty );
			directionProperty = FXMLUtils.bindField(directionCombo, directionFilter, "direction");
			
			if( maxDistanceProperty != null ) FXMLUtils.unbindField( maxDistanceTf, maxDistanceProperty );
			maxDistanceProperty = FXMLUtils.bindField(maxDistanceTf, directionFilter, "maxDistance");
        	
        	if( overlapTextPositionProperty != null ) FXMLUtils.unbindField( overlapTextPositionCombo, overlapTextPositionProperty );
        	overlapTextPositionProperty = FXMLUtils.bindField(overlapTextPositionCombo, directionFilter, "overlapTextPosition");
        	
        	TargetFormat keyFormat = directionFilter.getTargetFormat();
        	if(keyFormat instanceof LineTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.LINE);
        	else if(keyFormat instanceof PhraseTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.PHRASE);
        	else if(keyFormat instanceof SingleWordTargetFormat)
        		keyFormatCb.getSelectionModel().select(KeyFormat.SINGLEWORD);
        	
        } catch(Exception ex) {
        	ex.printStackTrace();
        }

	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }

}