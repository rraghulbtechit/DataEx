package urjanet.hit.template.compare;

public class UnsupportedComparisonException extends Exception
{

	private static final long serialVersionUID = 1997753363232807009L;

		public UnsupportedComparisonException()
		{
		}

		public UnsupportedComparisonException(String message)
		{
			super(message);
		}

		public UnsupportedComparisonException(Throwable cause)
		{
			super(cause);
		}

		public UnsupportedComparisonException(String message, Throwable cause)
		{
			super(message, cause);
		}

		public UnsupportedComparisonException(String message, Throwable cause, 
									boolean enableSuppression, boolean writableStackTrace)
		{
			super(message, cause, enableSuppression, writableStackTrace);
		}

}
