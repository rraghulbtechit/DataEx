package urjanet.hit.ui.view.attributes.contextKeys;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.coordinate.CoordinateTargetDefinition.Direction;
import urjanet.pull.web.pdf.key.RectKey;

public class RectKeyAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/RectKeyAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;
	
	@FXML protected TextField xTf;
	protected Property xProperty;
	@FXML protected TextField yTf;
	protected Property yProperty;
	@FXML protected TextField widthTf;
	protected Property widthProperty;
	@FXML protected TextField heightTf;
	protected Property heightProperty;
	@FXML protected ComboBox expandingDirectionCombo;
	protected Property expandingDirectionProperty;
	
	private RectKey rectKey;
	private ContextKeyAttributes contextKeyAttributes;
	
	public RectKeyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(contextKeyAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loaderContextKey.getRoot());
		contextKeyAttributes = loaderContextKey.getController();
		
		expandingDirectionCombo.getItems().addAll(Direction.values());
		
		setTemplateItem(treeItem);
        setTreeView(treeView);
	}
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        contextKeyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof RectKey))
            throw new HiTException("Could not create Form for RectKey due to incompatible node. Received " + Obj.getClass());
        
        this.rectKey = (RectKey) Obj;
        
        addBinding();
        
        contextKeyAttributes.setTemplateItem(item);
	}

	private void addBinding() {

		try {
        	//bind
			if( xProperty != null ) FXMLUtils.unbindField( xTf, xProperty );
        	xProperty = FXMLUtils.bindField(xTf, rectKey, "x");
        	
        	if( yProperty != null ) FXMLUtils.unbindField( yTf, yProperty );
        	yProperty = FXMLUtils.bindField(yTf, rectKey, "y");
        	
        	if( widthProperty != null ) FXMLUtils.unbindField( widthTf, widthProperty );
        	widthProperty = FXMLUtils.bindField(widthTf, rectKey, "width");
        	
        	if( heightProperty != null ) FXMLUtils.unbindField( heightTf, heightProperty );
        	heightProperty = FXMLUtils.bindField(heightTf, rectKey, "height");
        	
        	if( expandingDirectionProperty != null ) FXMLUtils.unbindField( expandingDirectionCombo, expandingDirectionProperty );
        	expandingDirectionProperty = FXMLUtils.bindField(expandingDirectionCombo, rectKey, "expandingDirection");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }
	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}
