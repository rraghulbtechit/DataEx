package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.DateOperator;
import urjanet.pull.operator.DateOperator.DateOperation;

public class DateOperatorAttributes extends BaseTemplateAttributes<T> {
	
	public static final String resourcePath = "/DateOperatorAttributes.fxml";

	@FXML private TextField inputFormatText;
	private Property inputFormatTextProperty;
	@FXML private TextField outputFormatText;
	private Property outputFormatTextProperty;
	@FXML private TextField valueText;
	private Property valueTextProperty;
	@FXML private ComboBox<DateOperation> operationCombo;
	private Property operationComboProperty;
	
	private DateOperator dateOperator;
	
	public DateOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
            operationCombo.getItems().addAll(DateOperation.values());
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }

	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof DateOperator))
            throw new HiTException("Could not create Form for DateOperator due to incompatible node. Received " + Obj.getClass());
        
        this.dateOperator = (DateOperator) Obj;
        
        if( inputFormatTextProperty != null ) FXMLUtils.unbindField( inputFormatText, inputFormatTextProperty );
        inputFormatTextProperty = FXMLUtils.bindField(inputFormatText, dateOperator, "inputFormat");
		
		if( outputFormatTextProperty != null ) FXMLUtils.unbindField( outputFormatText, outputFormatTextProperty );
		outputFormatTextProperty = FXMLUtils.bindField(outputFormatText, dateOperator, "outputFormat");
		
		if( valueTextProperty != null ) FXMLUtils.unbindField( valueText, valueTextProperty );
		valueTextProperty = FXMLUtils.bindField(valueText, dateOperator, "value");
		
		if( operationComboProperty != null ) FXMLUtils.unbindField( operationCombo, operationComboProperty );
		operationComboProperty = FXMLUtils.bindField(operationCombo, dateOperator, "operation");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}