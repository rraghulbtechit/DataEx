package urjanet.hit.template.source.builder.constructor;

import java.util.ArrayList;
import java.util.List;

import urjanet.pull.web.VariableInputElement;

public class InputElementConstructorResolution {

	public static List<Object> resolveConstructorParameters( VariableInputElement inputElement ) {
		
		String inputElementName = inputElement.getInputName();
		String XpathTarget = inputElement.getElementXPath();
		List<Object> properties = new ArrayList<Object>();
		
		properties = ConstructorResolutionFactory.checkNullAndAddAll(properties,XpathTarget,inputElementName);
		return properties;
	}
	
}
