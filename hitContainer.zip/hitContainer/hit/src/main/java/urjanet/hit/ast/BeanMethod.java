package urjanet.hit.ast;

public abstract class BeanMethod extends Method{

	private static String beanType;
	protected String property;
	
	public BeanMethod( String methodName ) {
		
		super( methodName );
	}
	public static String getBeanType() {

		return beanType;
	}
	
}
