package urjanet.hit.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;

public class FileUtils {

	public static File getTemporaryBillStoreDirectory() throws IOException {
		String tmpDirName = System.getProperty("java.io.tmpdir");
		if (tmpDirName == null) {
			tmpDirName = "";
		} else {
			tmpDirName += File.separator;
		}
	
		String name = tmpDirName + "HiT$BillStore$" + UUID.randomUUID().toString();
		File rootDir = new File(name);
		if (!rootDir.mkdir()) {
			throw new IOException("Unable to make tmp directory " + rootDir.getAbsolutePath());
		}
		
		rootDir.deleteOnExit();
		return rootDir;
	}

	public static void deleteDir(File rootDir) {
		for (File f : rootDir.listFiles()) {
			if (f.isDirectory()) {
				deleteDir(f);
			} else {
				if (!f.delete()) {
					System.err.println("Unable to delete " + f.getAbsolutePath());
				}
			}
		}
		if (!rootDir.delete()) {
			System.err.println("Unable to delete " + rootDir.getAbsolutePath());
		}
	}

	public static void writeFile(File f, byte[] srcCode) {
		try {
			FileOutputStream fos = new FileOutputStream(f);
			fos.write(srcCode);
			fos.close();
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	public static byte[] readFile(File f) {
		
		int len = (int) f.length();
		byte[] buf = new byte[len];
		try {
			
			FileInputStream fis = new FileInputStream(f);
			int off = 0;
			while (len > 0) {
				int n = fis.read(buf, off, len);
				if (n == -1)
					throw new IOException("Unexpected EOF reading " + f.getAbsolutePath());
				off += n;
				len -= n;
			}
			return buf;
		} catch (Exception e){
			e.printStackTrace();
		}
		return buf;
	}

	public static File getTemporaryWorkspaceDirectory() throws IOException {
		
		String tmpDirName = System.getProperty("java.io.tmpdir");
		if (tmpDirName == null) {
			tmpDirName = "";
		} else {
			tmpDirName += File.separator;
		}
	
		String name = tmpDirName + "HiT$templateworkspace";
		File tmpDirectory = new File(name);
		
		if( tmpDirectory.exists() ){
			org.apache.commons.io.FileUtils.cleanDirectory( tmpDirectory ); //clean out directory (this is optional -- but good know)
			org.apache.commons.io.FileUtils.forceDelete( tmpDirectory ); //delete directory
		}
		org.apache.commons.io.FileUtils.forceMkdir( tmpDirectory ); //create directory
		
		tmpDirectory.deleteOnExit();
		return tmpDirectory;
	}
	
	public static File getTemporaryLogFile() throws IOException {
		
		String tmpDirName = System.getProperty("java.io.tmpdir");
		if (tmpDirName == null) {
			tmpDirName = "";
		} else {
			tmpDirName += File.separator;
		}
	
		String name = tmpDirName + "HiT$LogFile" + UUID.randomUUID().toString();
		File tmpLogFile = new File(name);

		tmpLogFile.deleteOnExit();
		return tmpLogFile;
	}
	
	
	
	

}
