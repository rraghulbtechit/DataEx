package urjanet.hit.ui.view.attributes;

import javafx.beans.property.adapter.JavaBeanObjectProperty;
import javafx.beans.property.adapter.JavaBeanObjectPropertyBuilder;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.StringConverter;
import urjanet.hit.HiTException;
import urjanet.hit.ui.model.TemplateObjectMapper;
import urjanet.hit.ui.view.GenericButtonActionHandler;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.utils.StringOperations;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.*;

/**
 * Base class and a generic Pane to show properties for template objects. Strings, primitives and enums are shown for
 * edit. Objects are displayed as buttons (to select them in tree and bring up their form)
 *
 */
public class NodeAttributes extends BaseTemplateAttributes {

    private static final String resourcePath = "/NodeAttributes.fxml";

    @FXML protected Label       attributesTitle;
    @FXML protected GridPane    attributesForm;
    @FXML protected FlowPane    addObjectsPane;

    private List<TemplateObjectMapper.Arg>  fieldArgs = new ArrayList<>();

    private List<TemplateObjectMapper.Arg>  objectArgs = new ArrayList<>();

    private int fieldRows = 0;

    public NodeAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        this.treeView = treeView;
        this.treeItem = treeItem;

        if( load(resourcePath) )
            init(treeItem, treeView);
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) {

        Object templateObject = treeItem.getValue();
        if (templateObject != null) {
            createFields();
            display();
            bindAll();
        }
    }

    /**
     * Sets the TemplateTreeItem with the template object for this pane
     *
     * @param treeItem
     */
    public void setTemplateItem(TemplateTreeItem treeItem) {

        this.treeItem = treeItem;
        bindAll();
    }

    /**
     * Gathers the primitive and string fields for edit, and object field for buttons.
     *
     */
    protected void createFields() {

        List<TemplateObjectMapper.Arg> args = TemplateObjectMapper.getGetterArgs(treeItem.getValue());
        for(TemplateObjectMapper.Arg arg : args) {

            //Display label field for primitives, String, Enums
            if(arg.getType().isPrimitive() || arg.getType().isEnum() || String.class.isAssignableFrom(arg.getType())) {
                fieldArgs.add(arg);
            } else if(arg.getType().getPackage().getName().contains("urjanet")
                    || List.class.isAssignableFrom(arg.getType())) {
                objectArgs.add(arg);
            }
        }
    }

    public List<TemplateObjectMapper.Arg> getFieldArgs() { return fieldArgs; }

    public List<TemplateObjectMapper.Arg> getObjectArgs() { return objectArgs; }

    /**
     * Creates display in a vertical grid for fields and a flow layout of buttons for objects
     */
    protected void display() {

        this.attributesTitle.setText(getClazz().getName());

        displayFields();
        //Display buttons for contained objects
        displayObjectButtons();
    }

    /**
     * ids an Arg to make the field unique for the node
     *
     *
     * @param name@return
     */
    private String id(String name) {
        return name + "-" + this.hashCode();
    }

    protected void displayFields() {

        for( TemplateObjectMapper.Arg arg : fieldArgs ) {
            addField(arg.getType(), arg.getName());
        }
    }

    private void addField(Class type, String name) {
        Label label = new Label(name);
        Node field = createField( type, name );
        System.out.println("Adding field: " + label.getText());
        this.attributesForm.addRow(fieldRows++, label, field);
    }

    private Node createField(Class type, String name) {
        Node field;
        if( type.isEnum()) {

            ComboBox combo = new ComboBox<>();
            combo.setId(id(name));
            combo.getItems().setAll(Arrays.asList(type.getEnumConstants()));
            field = combo;
        } else {

            TextField textField = new TextField();
            textField.setId(id(name));
            textField.setEditable(true);
            field = textField;
        }
        return field;
    }


    protected void bindAll() {
        bindFields();
        bindButtons();
    }

    Map<Node, JavaBeanObjectProperty> comboPropertyMap = new HashMap<>();
    Map<Node, JavaBeanObjectProperty> textPropertyMap = new HashMap<>();
    protected void bindFields() {

        Object templateObj = this.treeItem.getValue();

        for(TemplateObjectMapper.Arg arg : fieldArgs) {

            Node node = this.getContent().lookup("#"+id(arg.getName()));
            System.out.println("Binding node " + node.getId());

            if(node instanceof ComboBox) {
                try {
                    JavaBeanObjectProperty property = comboPropertyMap.get(node);
                    if(property != null)
                        ((ComboBox)node).valueProperty().unbindBidirectional(property);
                    property = JavaBeanObjectPropertyBuilder.create().bean(templateObj).name(arg.getName()).build();
                    ((ComboBox)node).valueProperty().bindBidirectional(property);
                    comboPropertyMap.put(node, property);
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                }
            } else if(node instanceof TextField) {
                try {
                    JavaBeanObjectProperty property = textPropertyMap.get(node);
                    if(property != null)
                        ((TextField)node).textProperty().unbindBidirectional(property);
                    StringConverter converter = StringOperations.getConverter(arg.getType());
                    System.out.println(arg + ((converter != null) ? converter.getClass().getSimpleName() : "NULL Converter"));
                    System.out.println(templateObj.getClass().getMethod("get" + arg.getName()).invoke(templateObj) + " ");
                    property = JavaBeanObjectPropertyBuilder.create().bean(templateObj).name(arg.getName()).build();
                    ((TextField)node).textProperty().bindBidirectional(property, converter);
                    textPropertyMap.put(node, property);
                } catch (HiTException e) {
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    //e.printStackTrace();
                    System.out.println(e);
                } catch (UndeclaredThrowableException e) {
                    System.out.println(e.getCause());
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    //e.printStackTrace();
                    System.out.println(e);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected void displayObjectButtons() {

        for(TemplateObjectMapper.Arg arg : objectArgs) {

            System.out.println("Creating button for: " + arg);
            Button btn = new Button(arg.getName());
            btn.setId(id(arg.getName()));
            //btn.setOnAction(new GenericButtonActionHandler(this.templateItem, this.treeView, arg.getType()));
            addObjectsPane.getChildren().add(btn);
        }
    }

    protected void bindButtons() {

        for(TemplateObjectMapper.Arg arg : objectArgs) {
            Node node = this.getContent().lookup("#"+id(arg.getName()));
            setActionHandler(node, arg);
        }
    }

    protected void setActionHandler(Node button, TemplateObjectMapper.Arg arg) {

        ((Button)button).setOnAction(new GenericButtonActionHandler(this.getTreeItem(), this.getTreeView(), arg.getType()));
    }
}
