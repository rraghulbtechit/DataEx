package urjanet.hit.ui.view.attributes.extractOperators;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.pull.operator.ConcatOperator;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.operator.SimpleOperatorChain;
import urjanet.pull.web.DataTarget;

public class ExtractOperatorAttributes implements Initializable, TemplateAttributesPane {
	
	public static final String resourcePath = "/ExtractOperatorAttributes.fxml";
	
	@FXML protected TemplateButton extractOperatorBtn;

	private TreeView treeView;
	private TemplateTreeItem treeItem;
	
	private DataTarget dataTarget;
	private ExtractOperator parentExtractOperator;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		for(MenuItem item : extractOperatorBtn.getItems()) {
            item.setOnAction( filterItemHandler );
        }
	}
	
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		
		if(item.getValue() instanceof DataTarget)
			dataTarget = ((DataTarget)item.getValue());
		else if(item.getValue() instanceof ExtractOperator) {
			dataTarget = null;
			parentExtractOperator = ((ExtractOperator)item.getValue());
		}
		
	}

	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
	}
	
	private EventHandler<ActionEvent> filterItemHandler = event -> {
		try {
        	
        	TemplateTreeItem<T> extractOperatorItem;
        	
            String extractOperatorClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            ExtractOperator extractOperator = ((ExtractOperator)Class.forName(extractOperatorClassName).newInstance()); //TODO handle classes without arg-less c'tor

            //this.treeItem.getChildren().clear();
            if(dataTarget != null)
            	dataTarget.setOperator(extractOperator);
            else {

            	if(parentExtractOperator instanceof SimpleOperatorChain) {
            		SimpleOperatorChain soc = (SimpleOperatorChain)parentExtractOperator;
            		List<ExtractOperator> operators = (List<ExtractOperator>) soc.getOperators();
            		if(operators == null) {
            			operators = new ArrayList<>();
            		}
            		operators.add(extractOperator);
            		soc.setOperators(operators);
            	} else if(parentExtractOperator instanceof ConcatOperator) {
            		ConcatOperator concatOperator = (ConcatOperator)parentExtractOperator;
            		List<ExtractOperator> operators = (List<ExtractOperator>) concatOperator.getOperators();
            		if(operators == null) {
            			operators = new ArrayList<>();
            		}
            		operators.add(extractOperator);
            		concatOperator.setOperators(operators);
            	}
            }
            	
            extractOperatorItem = new TemplateTreeItem( extractOperator );
            addSelectNode(extractOperatorItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
    
    private void addSelectNode(TemplateTreeItem templateTreeItem) {
        treeItem.getChildren().add(templateTreeItem);
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }

}