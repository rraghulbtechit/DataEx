package urjanet.hit.ui.view.attributes.qualifier;

import java.net.URL;
import java.util.ResourceBundle;

import org.apache.poi.ss.formula.functions.T;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeView;
import javassist.expr.Instanceof;
import urjanet.hit.HiTException;
import urjanet.hit.ui.view.attributes.TemplateAttributesPane;
import urjanet.hit.ui.view.TemplateButton;
import urjanet.hit.ui.view.TemplateMenuItem;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;

public class DataTargetQualifierAttributes implements Initializable, TemplateAttributesPane {

	public static final String resourcePath = "/DataTargetQualifierAttributes.fxml";
	
	@FXML protected TemplateButton dataTargetQualifierBtn;
	
	private TemplateTreeItem treeItem;
    private TreeView treeView;
    private DataTarget dataTarget;
    private DataTargetQualifier dataTargetQualifier;
    
	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		this.treeItem = item;
		DataTarget dataTarget = ((DataTarget)item.getValue());
        this.dataTarget = dataTarget;
        this.dataTargetQualifier = dataTarget.getQualifier();
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
		this.treeView = treeView;
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		for(MenuItem item : dataTargetQualifierBtn.getItems()) {
            item.setOnAction( dataTargetQualifierHandler );
        }
	}
	
	private EventHandler dataTargetQualifierHandler = event -> {

        try {
        	
        	TemplateTreeItem<T> dataTargetQualifierItem;
        	
            String targetClassName = ((TemplateMenuItem)event.getSource()).getRepresentsClassName();
            DataTargetQualifier newTargetQualifier = ((DataTargetQualifier)Class.forName(targetClassName).newInstance()); //TODO handle classes without arg-less c'tor

            if(dataTarget instanceof ExpandablePdfDataTarget) {
            	
            	ExpandablePdfDataTarget expandablePdfDataTarget = (ExpandablePdfDataTarget)dataTarget;
            	if(expandablePdfDataTarget.getStartQualifier() == null) {
            		expandablePdfDataTarget.setStartQualifier(newTargetQualifier);
            	} else {
            		expandablePdfDataTarget.setEndQualifier(newTargetQualifier);
            	}
            	
            } else
            	dataTarget.setQualifier(newTargetQualifier);
            
            dataTargetQualifierItem = new TemplateTreeItem( newTargetQualifier );
            addSelectNode(dataTargetQualifierItem);
            
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    };
    
    private void addSelectNode(TemplateTreeItem templateTreeItem) {
        treeItem.getChildren().add(templateTreeItem);
        if( templateTreeItem != null )
            treeView.getSelectionModel().select(templateTreeItem);
    }
}