package urjanet.hit.template.source.builder.item;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.web.WebPullJobTemplate;

public interface TemplateItemBuilder {

	public Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker );
	
	public  Expression createTemplateItem( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker );
}
