package urjanet.hit.ast;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.HiTException;
import urjanet.hit.template.source.TypeTracker;
import urjanet.hit.template.source.builder.constructor.ConstructorResolutionFactory;
import urjanet.hit.template.source.builder.item.TemplateItemBuilder;
import urjanet.hit.template.source.builder.item.TemplateItemBuilderFactory;

public class MethodDeclarationAndInvocation {

	private static final Logger log = LoggerFactory.getLogger(ClassInstantiation.class);

	private Object templateObject;
	private List<?> parameters;
	
	private TypeDeclaration typeDeclaration;
	private MethodDeclaration parentMethodDeclaration;
	private TypeTracker typeTracker;
	private AST ast;
	
	private String methodName;
	private List<? extends ASTNode> modifiers;
	private List<Class> superInterfaces;
	private Expression expression;
	
	public MethodDeclarationAndInvocation( TypeDeclaration typeDeclaration, MethodDeclaration parentMethodDeclaration, Object templateObject, TypeTracker typeTracker) {

		this.typeDeclaration = typeDeclaration;
		this.parentMethodDeclaration = parentMethodDeclaration;
		this.templateObject = templateObject;
		this.typeTracker = typeTracker;
		this.ast = typeDeclaration.getAST();
		
	}
	
	public MethodDeclarationAndInvocation setExpression( Expression expression ) {

		this.expression = expression;
		return this;
	}
	
	public MethodDeclarationAndInvocation setSuperInterfaces( List<Class> superInterfaces ) {

		this.superInterfaces = superInterfaces;
		return this;
	}
	
	public MethodDeclarationAndInvocation setModifiers( List<? extends ASTNode> modifiers ) {

		this.modifiers = modifiers;
		return this;
	}
	public MethodDeclarationAndInvocation setMethodName( String methodName ) {

		this.methodName = methodName;
		return this;
	}

	
	public void declare() {
		
		try {
			AST ast = typeDeclaration.getAST();

			methodName = typeTracker.resolveMethodName( methodName );
			MethodDeclaration methodDeclaration = null;
			if( methodName != null )
				methodDeclaration = JavaElementBuilder.createMethodDeclaration(ast, methodName);
			else
				throw new HiTException("null or empty methodName");
			
			Expression expression = null;
			
//			System.out.println( templateObject );
			TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( templateObject );
			expression =  templateItemBuilder.createClassInstance( typeDeclaration, methodDeclaration, templateObject, typeTracker );
			
			ReturnStatement returnStatement = ast.newReturnStatement();
			returnStatement.setExpression(expression );
			
			Block block = (Block) ASTNode.copySubtree(ast, methodDeclaration.getBody());
			
			if( block == null )
				block = ast.newBlock();
			block.statements().add(returnStatement);
			
			Type type = typeTracker.getType(templateObject);
			
			methodDeclaration.setReturnType2( type );
			methodDeclaration.setBody( block );
			if( modifiers != null )
				methodDeclaration.modifiers().addAll( modifiers );
			
			List bodyDeclarations = ((TypeDeclaration)typeDeclaration).bodyDeclarations();
			bodyDeclarations.add(methodDeclaration);
			
			resolveSuperTypes();
			
		} catch ( Exception e ){
			e.printStackTrace();
		}
		
	}
	
	private void resolveSuperTypes() {

		if( superInterfaces != null ){
			for( Class superInterface : superInterfaces ) {
				typeDeclaration.superInterfaceTypes().add( typeTracker.getType( superInterface ) );
			}
		}
	}

	public MethodInvocation declareAndReturnInvocation(){
		
		declare();
		return JavaElementBuilder.createMethodInvocation(ast, null, methodName);
	}
	
	public MethodInvocation invoke(){
		
		return JavaElementBuilder.createMethodInvocation(ast, expression, methodName);
	}
	
	public MethodInvocation invokeWithParameter(){
		
		List<Expression> listOfParameterExpression = new ArrayList<Expression>();
		parameters = ConstructorResolutionFactory.getConstructorParamater( templateObject );
		for (Object parameter : parameters) {
			try {
				TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( parameter );
				Expression parameterExpression = templateItemBuilder.createTemplateItem( typeDeclaration, parentMethodDeclaration, parameter, typeTracker );
				
				listOfParameterExpression.add( parameterExpression );
			} catch( HiTException e ) {
				e.printStackTrace();
			}
		}
		
		log.trace( "adding invocation " + methodName + " on " + expression + " with parameter " + listOfParameterExpression);
		return JavaElementBuilder.createMethodInvocation(ast, expression, methodName, listOfParameterExpression);
	}
	
	public MethodInvocation invokeWithParameter(Object ... parameters){
		
		List<Expression> listOfParameterExpression = new ArrayList<Expression>();
		for (Object parameter : parameters) {
			try {
				TemplateItemBuilder templateItemBuilder = TemplateItemBuilderFactory.getBuilder( parameter );
				Expression parameterExpression = templateItemBuilder.createTemplateItem( typeDeclaration, parentMethodDeclaration, parameter, typeTracker );
				
				listOfParameterExpression.add( parameterExpression );
			} catch( HiTException e ) {
				e.printStackTrace();
			}
		}
		MethodInvocation methodInvocation = JavaElementBuilder.createMethodInvocation(ast, expression, methodName, listOfParameterExpression);
		
		log.trace( "creating method invocation " + methodInvocation );
		return methodInvocation;
	}

}
