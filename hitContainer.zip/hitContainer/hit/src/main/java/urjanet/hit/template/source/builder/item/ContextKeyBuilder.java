package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.InlineMethodGeneration;
import urjanet.hit.ast.Method;
import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.web.pdf.key.StringKey;

public class ContextKeyBuilder implements TemplateItemBuilder {
	

	private static final Logger log = LoggerFactory.getLogger(DataTargetBuilder.class);
	
	private static final ContextKeyBuilder theInstance = new ContextKeyBuilder();
	
	public static ContextKeyBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private ContextKeyBuilder() {}

	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Expression createTemplateItem( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		if( object instanceof StringKey )
			return createTemplateItem( typeDeclaration, methodDeclaration, (StringKey) object, typeTracker );
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
	}
	
	public Expression createTemplateItem( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, StringKey object,
		TypeTracker typeTracker ) {

		List<Method> inlineSetters = InlineMethodGeneration.generate( object, Arrays.asList( "inverseSearchDirection"  ) );
		
		return new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker)
			.setInlineMethodChain( inlineSetters )
			.instantiate();
	}

}
