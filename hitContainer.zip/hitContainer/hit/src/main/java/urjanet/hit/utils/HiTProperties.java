package urjanet.hit.utils;

import groovy.util.ConfigObject;
import groovy.util.ConfigSlurper;

import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Properties for HiTBuilder
 */
public class HiTProperties {

    private static final String propsPath = "conf/properties.groovy";

    private static HiTProperties instance;

    protected Map       props;

    private HiTProperties() {
        this( null );
    }

    private HiTProperties( String env ) {
        init( env );
    }

    private void init( String env ) {
        URL url = this.getClass().getClassLoader().getResource( propsPath );
        ConfigObject config = new ConfigSlurper( env ).parse( url );
        Map configProps = config.flatten();
        props = new HashMap( configProps );
    }

    public static void load() {
        load( null );
    }

    public static void load( String env ) {
        if( instance == null ) {
            instance = new HiTProperties( env );
        }
    }

    public static Map getPropertyMap( ) {

        return instance.props;
    }

    public static String getProperty( String key ) {
        Object value = instance.props.get( key );
        return (value == null) ? "" : value.toString();
    }
    //test code
    public static void main(String[] args) {
        Map props = HiTProperties.getPropertyMap();
        System.out.println( props.keySet() );
        System.out.println( props.get("templatePath") );
        System.out.println( props.get("section.key") );
        List list = (List)props.get("section.subsection.subarray");
        System.out.println( list.size() +""+ list.get(2));
        Map m = (Map)props.get( "section.subsection.aMap" );
        System.out.println(m.get("a"));
        System.out.println( props.get("section.subsection.aMap.a"));
    }
}
