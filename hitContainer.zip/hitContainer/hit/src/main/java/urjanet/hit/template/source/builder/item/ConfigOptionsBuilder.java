package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.Map;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.HiTException;
import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.ast.NonBeanMethod;
import urjanet.hit.ast.VariableDeclarationAndSubstitution;
import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.conversion.document.DocConverterConfigurationParameters;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.web.PdfExtractionHandlerType;

public class ConfigOptionsBuilder implements TemplateItemBuilder{

	private static final ConfigOptionsBuilder theInstance = new ConfigOptionsBuilder();
	
	public static ConfigOptionsBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private ConfigOptionsBuilder() {}
	
	public Expression createTemplateItem(final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker) {
	
		ConfigOptions configOptions = ( ConfigOptions )object;
		Expression classInstantiation = new ClassInstantiation(typeDeclaration, methodDeclaration, object, typeTracker).instantiate();
		Map<String, Object> options = configOptions.getOptions();
		
		
		VariableDeclarationAndSubstitution variableDeclarationAndSubstitution = 
			new VariableDeclarationAndSubstitution(typeDeclaration, methodDeclaration, classInstantiation, typeTracker)
			.setIdentifier( "configOptions" );

		for( String optionName : options.keySet() ) {
		
			NonBeanMethod addOptionMethod = new NonBeanMethod( "addOption" );

			DocConverterConfigurationParameters docConverterConfigurationParameterConstant = null;
			try {
				docConverterConfigurationParameterConstant = getDocConverterConfigurationParameterConstantForString( optionName );
				addOptionMethod.addParameter( 
					Arrays.asList(  
						new EnumConstant( DocConverterConfigurationParameters.class, 
							docConverterConfigurationParameterConstant,
							DocConverterConfigurationParameters.class.getMethod( "getParameterName" )
							),
						PdfExtractionHandlerType.CONTEXT_HANDLER 
						));
				variableDeclarationAndSubstitution.addMethodInvocation( addOptionMethod );
			} catch( HiTException e ) {
				e.printStackTrace();
			} catch( NoSuchMethodException e ) {
				e.printStackTrace();
			} catch( SecurityException e ) {
				e.printStackTrace();
			}
			
		}
		
		return variableDeclarationAndSubstitution
			.declareAndSubstitute();
		
	}

	private DocConverterConfigurationParameters getDocConverterConfigurationParameterConstantForString( String optionName ) throws HiTException {

		for( DocConverterConfigurationParameters parameter : DocConverterConfigurationParameters.values() ) {
			
			if( parameter.getParameterName().equals( optionName ))
				return parameter;
		}
		
		throw new HiTException( "No DocConverterConfigurationParameter found with value " + optionName );
	}

	public static void main( String[] args ) {

		AST ast = AST.newAST( AST.JLS3 );
		CompilationUnit cu = ast.newCompilationUnit();
		TypeTracker typeTracker = new TypeTracker( cu );
		
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  "Sample" );
		cu.types().add(typeDeclaration);
		
		MethodDeclaration methodDeclaration = null;
		methodDeclaration = JavaElementBuilder.createMethodDeclaration(ast, "Test");
		ConfigOptions configOpts = new ConfigOptions();
		configOpts.addOption( DocConverterConfigurationParameters.HANDLER_TYPE.getParameterName(), PdfExtractionHandlerType.CONTEXT_HANDLER );
		configOpts.addOption( DocConverterConfigurationParameters.DUPLICATE_SOURCE_CHECK.getParameterName(), true );
				
					
		System.out.println( new ConfigOptionsBuilder().createTemplateItem( typeDeclaration, methodDeclaration, configOpts, typeTracker ) );
		System.out.println( methodDeclaration );
	}

	@Override
	public Expression createClassInstance( TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object,
		TypeTracker typeTracker ) {

		// TODO Auto-generated method stub
		return null;
	}
}
