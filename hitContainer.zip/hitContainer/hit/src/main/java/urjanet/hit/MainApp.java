package urjanet.hit;

import javafx.stage.StageStyle;
import urjanet.hit.ui.view.dockfx.DockPane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import urjanet.hit.utils.HiTProperties;

import java.util.Map;

public class MainApp extends Application
{
	private static final Logger log = LoggerFactory.getLogger(MainApp.class);
	
	@Override
	public void start(Stage stage) throws Exception {
		//log.info("Loading fxml resource...");
		final FXMLLoader loader = new FXMLLoader(getClass().getResource("/mainDesign.fxml"));
		final Parent root = loader.load();

		Scene scene = new Scene(root, 1024, 700);
		scene.getStylesheets().add( getClass().getResource("/css/mainCSS.css").toURI().toString() );
		
		stage.setTitle("HiT Builder");
		//stage.initStyle(StageStyle.UNDECORATED);
		stage.setScene(scene);
		stage.setMaximized(true);
		stage.show();
		
		Application.setUserAgentStylesheet(Application.STYLESHEET_MODENA);
		
		DockPane.initializeDefaultUserAgentStylesheet();
	}

	@Override
	public void init() throws Exception {
		Map<String, String> parameters = getParameters().getNamed();
		HiTProperties.load( parameters.get("env") );
		System.out.println( HiTProperties.getPropertyMap().get( "templatePath" ) );
	}

	public static void main(String[] args) {
		
		log.info("Launching HiT Builder App...");
		
		Application.launch(MainApp.class, args);
	}
}