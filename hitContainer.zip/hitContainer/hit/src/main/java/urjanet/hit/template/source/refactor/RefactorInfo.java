package urjanet.hit.template.source.refactor;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.Expression;

@Deprecated
public class RefactorInfo {
	
	private Expression refactoredExpression;
	private List<RefactorAction> refactorActions = new ArrayList<RefactorAction>();
		
	private List<RefactorSideEffect> refactorSideEffects = new ArrayList<RefactorSideEffect>() ; 
	

	
	public RefactorInfo( Expression refactoredExpression ) {
		
		this.refactoredExpression = refactoredExpression;
	}
	
	public void addRefactorSideEffect( RefactorSideEffect refactorSideEffect ){
		
		refactorSideEffects.add(refactorSideEffect);
	}
	
	public void addRefactorAction( RefactorAction refactorAction){
		
		refactorActions.add(refactorAction);
	}
	
	public List<RefactorAction> getRefactorActions(){
		
		return refactorActions;
	}
	
	public List<RefactorSideEffect> getRefactorSideEffects(){
		
		return refactorSideEffects;
	}
	
	
	public Expression getRefactoredExpression() {

		return refactoredExpression;
	}

	@Override
	public String toString() {

		return "RefactorInfo [refactorActions=" + refactorActions + ", refactorSideEffects=" + refactorSideEffects + "]";
	}

}
