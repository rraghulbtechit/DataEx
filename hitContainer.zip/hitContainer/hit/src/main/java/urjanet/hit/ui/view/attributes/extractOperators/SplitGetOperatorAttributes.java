package urjanet.hit.ui.view.attributes.extractOperators;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.pull.operator.SplitGetOperator;

public class SplitGetOperatorAttributes extends BaseTemplateAttributes<T> {
	
	public static final String resourcePath = "/SplitGetOperatorAttributes.fxml";

	@FXML private TextField regExDelimText;
	private Property regExDelimTextProperty;
	@FXML private TextField indexText;
	private Property indexTextProperty;
	@FXML private TextField limitText;
	private Property limitTextProperty;
	
	private SplitGetOperator splitGetOperator;
	
	public SplitGetOperatorAttributes(TemplateTreeItem treeItem, TreeView treeView) {

		try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }
	
	protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
        
    	setTemplateItem(treeItem);
        setTreeView(treeView);
    }
	
	@Override
	public void onHide() {
		FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof SplitGetOperator))
            throw new HiTException("Could not create Form for splitGetOperator due to incompatible node. Received " + Obj.getClass());
        
        this.splitGetOperator = (SplitGetOperator) Obj;
        
        if( regExDelimTextProperty != null ) FXMLUtils.unbindField( regExDelimText, regExDelimTextProperty );
		regExDelimTextProperty = FXMLUtils.bindField(regExDelimText, splitGetOperator, "regExDelim");
		
		if( indexTextProperty != null ) FXMLUtils.unbindField( indexText, indexTextProperty );
		indexTextProperty = FXMLUtils.bindField(indexText, splitGetOperator, "index");
		
		if( limitTextProperty != null ) FXMLUtils.unbindField( limitText, limitTextProperty );
		limitTextProperty = FXMLUtils.bindField(limitText, splitGetOperator, "limit");
        
	}
	
	@Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
	}
}