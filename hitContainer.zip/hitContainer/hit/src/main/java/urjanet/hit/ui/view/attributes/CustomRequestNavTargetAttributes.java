package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.CustomRequestNavTarget;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomRequestNavTargetAttributes<T> implements Initializable, TemplateAttributesPane {

    static final String resourcePath = "/CustomRequestNavTargetAttributes.fxml";

    @FXML private TextField urlText;
    private Property        urlProperty;
    @FXML private ComboBox  requestTypeCb;
    private Property        requestTypeProperty;
    @FXML private CheckBox  closeAllWindowsCheck;
    private Property        closeAllWindowsProperty;
    @FXML private CheckBox  escapeVariablesCheck;
    private Property        escapeVariableProperty;
    @FXML private CheckBox  isLoginTargetCheck;
    private Property        isLoginTargetProperty;
    @FXML private TextArea  bodyText;
    private Property        bodyProperty;
    @FXML public VBox       expandableNavTargetAttributesVBox;
    @FXML public ExpandableNavTargetAttributes  expandableNavTargetAttributesVBoxController;

    protected TemplateTreeItem<T>           treeItem;
    protected TreeView<T>                   treeView;
    private CustomRequestNavTarget customRequestNavTarget = new CustomRequestNavTarget();

    public CustomRequestNavTargetAttributes( ) {
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        requestTypeCb.getItems().addAll(CustomRequestNavTarget.RequestType.values());

        try {
            urlProperty = FXMLUtils.bindField( urlText, customRequestNavTarget, "url");
            requestTypeProperty = FXMLUtils.bindField( requestTypeCb, customRequestNavTarget, "requestType" );
            closeAllWindowsProperty = FXMLUtils.bindField( closeAllWindowsCheck, customRequestNavTarget, "closeAllWindows" );
            escapeVariableProperty = FXMLUtils.bindField( escapeVariablesCheck, customRequestNavTarget, "escapeVariables" );
            isLoginTargetProperty = FXMLUtils.bindField( isLoginTargetCheck, customRequestNavTarget, "isLoginTarget", "isLoginTarget", "setLoginTarget" );
            bodyProperty = FXMLUtils.bindField( bodyText, customRequestNavTarget, "body" );
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        customRequestNavTarget = (CustomRequestNavTarget) item.getValue();

        urlProperty = FXMLUtils.rebindField( urlText, urlProperty, customRequestNavTarget, "url" );
        requestTypeProperty = FXMLUtils.rebindField( requestTypeCb, requestTypeProperty, customRequestNavTarget, "requestType" );
        closeAllWindowsProperty = FXMLUtils.rebindField( closeAllWindowsCheck, closeAllWindowsProperty, customRequestNavTarget, "closeAllWindows" );
        escapeVariableProperty = FXMLUtils.rebindField( escapeVariablesCheck, escapeVariableProperty, customRequestNavTarget, "escapeVariables" );
        isLoginTargetProperty = FXMLUtils.rebindField( isLoginTargetCheck, isLoginTargetProperty, customRequestNavTarget, "isLoginTarget", "isLoginTarget", "setLoginTarget" );
        bodyProperty = FXMLUtils.rebindField( bodyText, bodyProperty, customRequestNavTarget, "body" );

        expandableNavTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
        expandableNavTargetAttributesVBoxController.setTreeView( treeView );
    }
}
