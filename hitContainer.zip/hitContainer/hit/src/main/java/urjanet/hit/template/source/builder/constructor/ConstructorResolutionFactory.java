package urjanet.hit.template.source.builder.constructor;

import java.lang.reflect.Constructor;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import urjanet.hit.utils.ReflectionUtils;
import urjanet.hit.utils.TypeUtils;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.core.TargetGroup;
import urjanet.pull.operator.ExtractOperator;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.ClickableNavTarget;
import urjanet.pull.web.DataTarget;
import urjanet.pull.web.DataTargetQualifier;
import urjanet.pull.web.GroupPolicy;
import urjanet.pull.web.VariableInputElement;
import urjanet.pull.web.WebPullJobTemplate;
import urjanet.pull.web.XmlTargetGroup;
import urjanet.pull.web.pdf.ExpandablePdfDataTarget;
import urjanet.pull.web.pdf.ExpandablePdfPageDataTarget;
import urjanet.pull.web.pdf.PdfDataTarget;
import urjanet.pull.web.pdf.PdfPageDataTarget;
import urjanet.pull.web.pdf.context.TargetContext;
import urjanet.pull.web.pdf.filter.ContextFilter;
import urjanet.pull.web.pdf.format.TargetFormat;
import urjanet.pull.web.pdf.key.WordContextKey;

public class ConstructorResolutionFactory {
	
	private static final Logger log = LoggerFactory.getLogger(ConstructorResolutionFactory.class);

	
	public static List<?> resolveConstructorParameters( Object object ) throws Exception {
		
		if( object instanceof WebPullJobTemplate )
			return PullJobTemplateConstructorResolution.resolveConstructorParameters( (WebPullJobTemplate) object );
		else if( object instanceof BasePageSpec )
			return PageSpecConstructorResolution.resolveConstructorParameters( (BasePageSpec) object );
		else if( object instanceof ClickableNavTarget )
			return NavTargetConstructorResolution.resolveConstructorParameters( (ClickableNavTarget) object );
		else if( object instanceof VariableInputElement )
			return InputElementConstructorResolution.resolveConstructorParameters( (VariableInputElement) object );
		else if( object instanceof ConfigOptions )
			return ConfigOptionsConstructorResolution.resolveConstructorParameters( (ConfigOptions) object );
		else if( object.getClass().isArray() )
			return ArrayConstructorResolution.resolveConstructorParameters( (TargetGroup[]) object );
		else if( object instanceof XmlTargetGroup )
			return TargetGroupConstructorResolution.resolveConstructorParameters( (XmlTargetGroup) object );
		
		else if( object instanceof DataTarget )
			return DataTargetConstructorResolution.resolveConstructorParameters( (DataTarget) object );
		
		else if( object instanceof GroupPolicy )
			return GroupPolicyConstructorResolution.resolveConstructorParameters( (GroupPolicy) object );
		else if( object instanceof TargetContext )
			return TargetContextConstructorResolution.resolveConstructorParameters((TargetContext) object );
		
		else if( object instanceof ExtractOperator )
			return ExtractOperatorConstructorResolution.resolveConstructorParameters((ExtractOperator) object );
		
		else if( object instanceof WordContextKey)
			return ContextKeyConstructorResolution.resolveConstructorParameters((WordContextKey)object );
		
		else if( object instanceof ContextFilter)
			return ContextFilterConstructorResolution.resolveConstructorParameters((ContextFilter)object );
		
		else if( object instanceof TargetFormat )
			return TargetFormatConstructorResolution.resolveConstructorParameters( (TargetFormat) object );
		
		else if( object instanceof DataTargetQualifier )
			return DataTargetQualifierConstructorResolution.resolveConstructorParameters( (DataTargetQualifier) object );

		else if( TypeUtils.isList( object ) )
			return ListConstructorResolution.resolveConstructorParameters( (List<PdfDataTarget>) object );
		else
			throw new UnresolvedConstructorException( "could not resolve constructor signature for class " + object.getClass().getName());
		
	}
	
	static List<Object> checkNullAndAddAll( List<Object> properties, Object...objects) {

		for( Object object : objects ) {
			if ( object != null ){
				if ( object.getClass().isArray() ){
					for (Object b : (Object[])object) {
						properties.add(b);
					}
				} else {
					properties.add( object );
				}
			}
		}
		
		return properties;
	}

	static void doesSuchConstructorExist( Class c, List<?> parameters ) throws UnresolvedConstructorException {

		Class[] params = new Class[parameters.size()];
		for( int i = 0; i < parameters.size(); i ++ ) {
			params[i] = parameters.get(i).getClass();
		}
		
		boolean isConstructorFound = false;
		Constructor [] constructors = c.getConstructors();
		
		// Class#getConstructor(Class...c) just  looks for exact match. Does not resolves super class/ sub class. 
		// So had to implement that looking for all available constructor signature. :|
		for( Constructor constructor : constructors ) {
			
			Class[] parameterTypes = constructor.getParameterTypes();
			if ( parameterTypes.length != parameters.size() ){
				continue;
			} else {
				
				for( int i = 0; i < parameterTypes.length; i ++ ) {
					if(parameterTypes[i].isAssignableFrom(parameters.get( i ).getClass())) 
						isConstructorFound = true;
					else {
						isConstructorFound = false;
					}
				}
			}
		}
		
		if ( !isConstructorFound )
			throw new UnresolvedConstructorException( "no constructor with signature " + parameters + " exist for class " + c.getSimpleName() );
	}
	
	public static List<?> getConstructorParamater( Object object ) {

		log.trace( "Resolving parameters for " + object.getClass() );
		List<?> parameters = null;
		try {
			parameters = ConstructorResolutionFactory.resolveConstructorParameters( object );
		} catch( Exception e ) {
			e.printStackTrace();
		}

		StringBuilder constructorSignature = new StringBuilder();
		
		for (Object parameter : parameters) {
			constructorSignature.append(parameter.getClass().getSimpleName() + " ");
		}

		log.trace( "Parameters for " + object.getClass().getName() + " : " + parameters + "; Signature = " + constructorSignature.toString());
		
//		try {
//			doesSuchConstructorExist( object.getClass(), parameters );
//		} catch( UnresolvedConstructorException e ) {
//			e.printStackTrace();
//		}
		
		return parameters;
	}
}
