package urjanet.hit.template.source.builder.item;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import urjanet.hit.HiTException;
import urjanet.hit.ast.JavaElementBuilder;
import urjanet.hit.ast.ClassInstantiation;
import urjanet.hit.ast.Method;
import urjanet.hit.ast.MethodDeclarationAndInvocation;
import urjanet.hit.ast.Setter;
import urjanet.hit.template.source.TypeTracker;
import urjanet.pull.conversion.document.DocConverterConfigurationParameters;
import urjanet.pull.core.ConfigOptions;
import urjanet.pull.template.TemplateProvider;
import urjanet.pull.web.BasePageSpec;
import urjanet.pull.web.PdfExtractionHandlerType;
import urjanet.pull.web.WebPullJobTemplate;

public class PullJobTemplateBuilder implements TemplateItemBuilder{

	private static final PullJobTemplateBuilder theInstance = new PullJobTemplateBuilder();
	
	public static PullJobTemplateBuilder getInstance(){
		
		return theInstance; 
		
	}
	
	private PullJobTemplateBuilder() {}
	
	@Override
	public Expression createTemplateItem( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) {
	
		AST ast = typeDeclaration.getAST();
		return new MethodDeclarationAndInvocation(typeDeclaration, methodDeclaration, object, typeTracker)
			.setSuperInterfaces( Arrays.asList( TemplateProvider.class  ) )
			.setModifiers( Arrays.asList( 
					JavaElementBuilder.createOverrideMarker( ast ),
					JavaElementBuilder.createPublicModifier(ast)) )
			.setMethodName( "getTemplate" )
			.declareAndReturnInvocation();
	}

	public Expression createClassInstance( final TypeDeclaration typeDeclaration, MethodDeclaration methodDeclaration, Object object, final TypeTracker typeTracker ) {
		
		return new ClassInstantiation(typeDeclaration,methodDeclaration, object, typeTracker).instantiate();
	}
	
	public static void main( String[] args ) {

		AST ast = AST.newAST( AST.JLS3 );
		CompilationUnit cu = ast.newCompilationUnit();
		TypeTracker typeTracker = new TypeTracker( cu );
		
		TypeDeclaration typeDeclaration = JavaElementBuilder.createTypeDecelaration(ast, true, false,  "Sample" );
		cu.types().add(typeDeclaration);
		
		MethodDeclaration methodDeclaration = null;
		methodDeclaration = JavaElementBuilder.createMethodDeclaration(ast, "Test");

		WebPullJobTemplate wpjt = new WebPullJobTemplate("eu", null, "etuse", "$LastChangedBy$", "$LastChangedRevision$");
					
		new PullJobTemplateBuilder().createTemplateItem( typeDeclaration, null, wpjt, typeTracker );
		System.out.println(  typeDeclaration);
	}


}
