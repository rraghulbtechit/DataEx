package urjanet.hit.utils;

import org.apache.commons.lang.ObjectUtils.Null;

import com.google.common.base.Defaults;

public class DefaultValue{

	// These gets initialized to their default values
	private static boolean DEFAULT_BOOLEAN;
	private static byte DEFAULT_BYTE;
	private static short DEFAULT_SHORT;
	private static int DEFAULT_INT;
	private static long DEFAULT_LONG;
	private static float DEFAULT_FLOAT;
	private static double DEFAULT_DOUBLE;
	
	public static <T> boolean doesContainDefaultValue( T object ){
		
		T defaultValue = ( T )getDefaultValue( object.getClass() );
		if ( object.equals( defaultValue )){
			return true;
		}
		return false;
		
	}
	
	public static Object getDefaultValue(Class clazz) {
		
		if( clazz.isPrimitive() ){
			return Defaults.defaultValue( clazz );
		} else if ( TypeUtils.isWrapperType( clazz )){
			
			Object defaultValue = null;
			if( clazz.getName() == Boolean.class.getName() )
				defaultValue = new Boolean( DEFAULT_BOOLEAN );
			else if( clazz.getName() == Byte.class.getName() )
				defaultValue = new Byte( DEFAULT_BYTE );
			else if( clazz.getName() == Short.class.getName() )
				defaultValue = new Short( DEFAULT_SHORT);
			else if( clazz.getName() == Integer.class.getName() )
				defaultValue = new Integer( DEFAULT_INT );
			else if( clazz.getName() == Long.class.getName() )
				defaultValue = new Long( DEFAULT_LONG );
			else if( clazz.getName() == Float.class.getName() )
				defaultValue = new Float( DEFAULT_FLOAT );
			else if( clazz.getName() == Double.class.getName() )
				defaultValue = new Double( DEFAULT_DOUBLE );
			
			return defaultValue;
		} else {
			return null;
		}
	}
	
}
