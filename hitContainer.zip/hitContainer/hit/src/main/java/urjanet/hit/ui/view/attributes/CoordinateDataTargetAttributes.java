package urjanet.hit.ui.view.attributes;

import javafx.beans.property.Property;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.pull.web.coordinate.CoordinateDataTarget;
import urjanet.pull.web.coordinate.CoordinateTargetDefinition;

import java.net.URL;
import java.util.ResourceBundle;

public class CoordinateDataTargetAttributes<T> implements Initializable, TemplateAttributesPane {

    public static final String resourcePath = "/CoordinateDataTargetAttributes.fxml";

    @FXML protected TextField                               pageNumberText;
    protected Property                                      pageNumberProperty;
    @FXML protected VBox                               coordinateTargetDefinitionVBox;
    @FXML protected CoordinateTargetDefinitionAttributes    coordinateTargetDefinitionVBoxController;
    @FXML protected VBox                                    dataTargetAttributesVBox;
    @FXML protected DataTargetAttributes                    dataTargetAttributesVBoxController;

    private TreeView                treeView;
    private TemplateTreeItem<T> treeItem;
    private CoordinateDataTarget coordinateDataTarget = new CoordinateDataTarget();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try {
            pageNumberProperty = FXMLUtils.bindField( pageNumberText, coordinateDataTarget, "pageNumber" );
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setTemplateItem(TemplateTreeItem item) throws HiTException {

        this.treeItem = item;
        coordinateDataTarget = (CoordinateDataTarget) item.getValue();
        //bind
        pageNumberProperty = FXMLUtils.rebindField( pageNumberText, pageNumberProperty, coordinateDataTarget, "pageNumber" );

        CoordinateTargetDefinition coordinateTargetDefinition = coordinateDataTarget.getCoordinateTargetDefinition() == null
            ? new CoordinateTargetDefinition() : coordinateDataTarget.getCoordinateTargetDefinition();
        coordinateTargetDefinitionVBoxController.setCoordinateTargetDefinition( coordinateTargetDefinition );

        dataTargetAttributesVBoxController.setTemplateItem( item );
    }

    @Override
    public void setTreeView(TreeView treeView) {

        this.treeView = treeView;
    }
}
