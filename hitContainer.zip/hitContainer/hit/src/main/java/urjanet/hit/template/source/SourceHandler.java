package urjanet.hit.template.source;

import javafx.scene.control.TreeView;
import urjanet.pull.core.PullJobTemplate;
import urjanet.pull.web.WebPullJobTemplate;

/**
 * This class is a repository of tree actions to generate source on objects that have changed. The current implementation
 * is very limited in the sense it builds source for the tree each time instead of doing it incrementally.
 * It should support undo, redo functions.
 */
public class SourceHandler {

	protected PullJobTemplate	templateRoot;

	public PullJobTemplate getTemplateRoot() {
		return templateRoot;
	}

	public void setTemplateRoot(PullJobTemplate templateRoot) {
		this.templateRoot = templateRoot;
	}

	public TemplateSource getTemplateSource(){
		if( templateRoot != null )
			return new TemplateBuilder().generateTemplate( "TemplateProvider", (WebPullJobTemplate) templateRoot );

		return null;
	}

}
