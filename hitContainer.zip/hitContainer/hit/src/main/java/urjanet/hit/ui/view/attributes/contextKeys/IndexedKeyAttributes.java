package urjanet.hit.ui.view.attributes.contextKeys;

import org.apache.poi.ss.formula.functions.T;

import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import urjanet.hit.HiTException;
import urjanet.hit.ui.FXMLUtils;
import urjanet.hit.ui.view.attributes.BaseTemplateAttributes;
import urjanet.hit.ui.view.tree.TemplateTreeItem;
import urjanet.hit.ui.view.attributes.contextKeys.ContextKeyAttributes.KeyFormat;
import urjanet.pull.web.pdf.format.LineTargetFormat;
import urjanet.pull.web.pdf.format.PhraseTargetFormat;
import urjanet.pull.web.pdf.format.SingleWordTargetFormat;
import urjanet.pull.web.pdf.format.WordTargetFormat;
import urjanet.pull.web.pdf.key.IndexedKey;

public class IndexedKeyAttributes extends BaseTemplateAttributes<T> {

	public static final String resourcePath = "/IndexedKeyAttributes.fxml";
	
	@FXML protected Pane contextKeyPane;
	
	@FXML protected TextField lineNumberTf;
	protected Property lineNumberProperty;
	@FXML protected TextField wordNumberTf;
	protected Property wordNumberProperty;
	@FXML protected ComboBox indexStrategyCombo;
	protected Property indexStrategyProperty;
	@FXML protected CheckBox inverseLineSearchDirectionCb;
	protected Property inverseLineSearchDirectionProperty;
	@FXML protected CheckBox inverseWordSearchDirectionCb;
	protected Property inverseWordSearchDirectionProperty;
	
	private IndexedKey indexedKey;
	private ContextKeyAttributes contextKeyAttributes;
	private WordTargetFormat indexStrategy;
	
	public IndexedKeyAttributes(TemplateTreeItem treeItem, TreeView treeView) {

        try {
            if( load(resourcePath) )
                init(treeItem, treeView);
        } catch (HiTException e) {
            e.printStackTrace();
        }
    }

    protected void init(TemplateTreeItem treeItem, TreeView treeView) throws HiTException {
		
		FXMLLoader loaderContextKey = new FXMLUtils().loader(contextKeyAttributes.resourcePath);
		
		contextKeyPane.getChildren().add(loaderContextKey.getRoot());
		contextKeyAttributes = loaderContextKey.getController();
		
		indexStrategyCombo.getItems().addAll(KeyFormat.values());
		
		indexStrategyCombo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue ov, Object t, Object t1) {
            	if(t1 == KeyFormat.LINE)
            		indexStrategy = new LineTargetFormat();
            	else if(t1 == KeyFormat.PHRASE)
            		indexStrategy = new PhraseTargetFormat();
            	else if(t1 == KeyFormat.SINGLEWORD)
            		indexStrategy = new SingleWordTargetFormat();
            }
        });
		
		setTemplateItem(treeItem);
        setTreeView(treeView);
	}
    
    @Override
	public void setTreeView(TreeView treeView) {
        this.treeView = treeView;
        
        contextKeyAttributes.setTreeView(treeView);
	}

	@Override
	public void setTemplateItem(TemplateTreeItem item) throws HiTException {
		
		this.treeItem = item;
        Object Obj = item.getValue();
        if(! (Obj instanceof IndexedKey))
            throw new HiTException("Could not create Form for indexedKey due to incompatible node. Received " + Obj.getClass());
        
        this.indexedKey = (IndexedKey) Obj;
        
        addBinding();
        
        contextKeyAttributes.setTemplateItem(item);
	}
	
	private void addBinding() {

		indexStrategy = indexedKey.getIndexStrategy();
		
		if(indexStrategy != null) {
	    	if(indexStrategy instanceof LineTargetFormat)
	    		indexStrategyCombo.getSelectionModel().select(KeyFormat.LINE);
	    	else if(indexStrategy instanceof PhraseTargetFormat)
	    		indexStrategyCombo.getSelectionModel().select(KeyFormat.PHRASE);
	    	else if(indexStrategy instanceof SingleWordTargetFormat)
	    		indexStrategyCombo.getSelectionModel().select(KeyFormat.SINGLEWORD);
		}
		
		try {
        	//bind
			if( lineNumberProperty != null ) FXMLUtils.unbindField( lineNumberTf, lineNumberProperty );
			lineNumberProperty = FXMLUtils.bindField(lineNumberTf, indexedKey, "lineNumber");
        	
        	if( wordNumberProperty != null ) FXMLUtils.unbindField( wordNumberTf, wordNumberProperty );
        	wordNumberProperty = FXMLUtils.bindField(wordNumberTf, indexedKey, "wordNumber");
        	
        	if( inverseLineSearchDirectionProperty != null ) FXMLUtils.unbindField( inverseLineSearchDirectionCb, inverseLineSearchDirectionProperty );
        	inverseLineSearchDirectionProperty = FXMLUtils.bindField(inverseLineSearchDirectionCb, indexedKey, "inverseLineSearchDirection");
        	
        	if( inverseWordSearchDirectionProperty != null ) FXMLUtils.unbindField( inverseWordSearchDirectionCb, inverseWordSearchDirectionProperty );
        	inverseWordSearchDirectionProperty = FXMLUtils.bindField(inverseWordSearchDirectionCb, indexedKey, "inverseWordSearchDirection");
        } catch(Exception ex) {
        	ex.printStackTrace();
        }
	}
	
	@Override
    public void onHide() {
    	FXMLUtils.checkMandatoryFields(this, treeView, treeItem);
    }
}
