HiT stands for Help in Templating. It is an umbrella for utilities and tools to ease development and maintenance of templates. The motivation for this came from a codeathon to automate certain aspects of template development. Prior to the codeathon, an app was developed by Abdul Rehman for a UI based template code generator. Much, much prior to that a Javascript based template visualizer was prototyped by SJ to visually maintain the common template fixes. It was however  dropped adopting Java as the language for templates.

Contributors for this project:
Aravinthasamy S
Balaji
Raghul R
Santhosh T
Venkatesh S
with SJ acting as the product owner and benevolent dictator!

SJ
Apr 21, 2016
