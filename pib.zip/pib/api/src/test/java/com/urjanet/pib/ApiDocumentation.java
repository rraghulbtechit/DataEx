package com.urjanet.pib;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.restdocs.headers.HeaderDocumentation.headerWithName;
import static org.springframework.restdocs.headers.HeaderDocumentation.responseHeaders;
import static org.springframework.restdocs.hypermedia.HypermediaDocumentation.linkWithRel;
import static org.springframework.restdocs.hypermedia.HypermediaDocumentation.links;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders.get;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.servlet.RequestDispatcher;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.mockmvc.RestDocumentationResultHandler;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
@ActiveProfiles(profiles = "test")
public class ApiDocumentation {

    @Rule
    public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("build/generated-snippets");

    private RestDocumentationResultHandler document;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    WebApplicationContext context;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        this.document = document("{method-name}",
                preprocessRequest(prettyPrint()),
                preprocessResponse(prettyPrint()));

        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context)
                .apply(documentationConfiguration(this.restDocumentation))
                .alwaysDo(this.document)
                .build();
    }

    @Test
    @SuppressWarnings("deprecation")
    public void headersExample() throws Exception {
        this.document.snippets(responseHeaders(
                headerWithName("Content-Type").description("The Content-Type of the payload, e.g. `application/hal+json`")));

        this.mockMvc.perform(get("/"))
                .andExpect(status().isOk());
    }
    
    @Test
    public void indexExample() throws Exception {
        this.mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andDo(this.document.document(
                links(
                        linkWithRel("providers").description("The <<resources-providers,Providers resource>>"),
                        linkWithRel("serviceTypes").description("The <<resources-serviceTypes,ServiceTypes resource>>")),
                responseFields(
                        fieldWithPath("_links").description("<<resources-index-links,Links>> to other resources"))));
    }

    @Test
    public void errorExample() throws Exception {
        this.mockMvc
                .perform(get("/error")
                        .requestAttr(RequestDispatcher.ERROR_STATUS_CODE, 400)
                        .requestAttr(RequestDispatcher.ERROR_REQUEST_URI,
                                "/providers")
                        .requestAttr(RequestDispatcher.ERROR_MESSAGE,
                                "Validation failed for object='providerRequest'. Error count: 1"))
                .andDo(print()).andExpect(status().isBadRequest())
                .andExpect(jsonPath("error", is("Bad Request")))
                .andExpect(jsonPath("timestamp", is(notNullValue())))
                .andExpect(jsonPath("status", is(400)))
                .andExpect(jsonPath("path", is(notNullValue())))
                .andDo(this.document.document(
                    responseFields(
                        fieldWithPath("error").description("The HTTP error that occurred, e.g. `Bad Request`"),
                        fieldWithPath("message").description("A description of the cause of the error"),
                        fieldWithPath("path").description("The path to which the request was made"),
                        fieldWithPath("status").description("The HTTP status code, e.g. `400`"),
                        fieldWithPath("timestamp").description("The time, in milliseconds, at which the error occurred"))));
    }

    @Test
    public void providersListExample() throws Exception {        
        this.mockMvc.perform(get("/providers?size=3&history=true&all=true"))
                .andExpect(status().isOk())
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("This <<resources-providers,Providers>>"),
                        linkWithRel("next").description("Next page of <<resources-providers,Providers>>"),
                        linkWithRel("last").description("Last page of <<resources-providers,Providers>>"),
                        linkWithRel("first").description("First page of <<resources-providers,Providers>>")
                ),
                responseFields(
                        fieldWithPath("_embedded.providers").description("An array of <<resources-provider, Provider resources>>"),
                        fieldWithPath("page").description("The <<paging, Paging resource>>"),
                        fieldWithPath("_links").description("<<resources-providers-links,Links>> to other resources")
                ),
                pathParameters(
                        parameterWithName("history").description("Filter by history availability").optional(),
                        parameterWithName("alias").description("Filter by alias (containing)").optional(),
                        parameterWithName("name").description("Filter by provider name (containing)").optional(),
                        parameterWithName("all").description("If true, removes all default filters from listing").optional(),
                        parameterWithName("size").description("Page size for the returned list").optional(),
                        parameterWithName("page").description("Page number for the returned list").optional()
                        
                )));
    }
    
    @Test
    public void providersByServiceType() throws Exception {
        this.mockMvc.perform(get("/serviceTypes/56568480389a11e6b82100e04c6801d0/providers?history=true"))
            .andExpect(status().isOk());
    }

    @Test
    public void providerGetExample() throws Exception {
        this.mockMvc.perform(get("/providers/1E60A4737EEEDF00A03822000B109B8B"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("alias", is("Comcast")))
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("This <<resources-provider,provider>>"),
                        linkWithRel("serviceTypes").description("This provider's <<resources-serviceTypes,serviceTypes>>"),
                        linkWithRel("bestAcquisitionTemplates").description("This provider's best acquisition <<resources-templates-acquisition,templates>>"),
                        linkWithRel("bestExtractionTemplates").description("This provider's best extraction <<resources-templates-extraction,templates>>")
                ),
                responseFields(
                        fieldWithPath("uuid").description("The uuid of the provider"),
                        fieldWithPath("created").description("The date of creation for this provider"),
                        fieldWithPath("modified").description("The date of last modification for this provider"),
                        fieldWithPath("website").description("The URL associated with the best template for this provider"),
                        fieldWithPath("tracksLoginFailure").description("Indicates whether any templates for this provider track login failures"),
                        fieldWithPath("history").description("Indicates whether any templates for this provider support history"),
                        fieldWithPath("alias").description("The short alias of the provider"),
                        fieldWithPath("name").description("The full name of the provider"),
                        fieldWithPath("classification").description("The classification of the provider (i.e. PRIMARY, SECONDARY, or BOTH)"),
                        fieldWithPath("_links").description("<<resources-provider-links,Links>> to other resources")
                )));
    }
    
    @Test
    public void serviceTypesListExample() throws Exception {
        this.mockMvc.perform(get("/serviceTypes"))
                .andExpect(status().isOk())
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("This <<resources-serviceTypes,ServiceTypes>>")
                ),
                responseFields(
                        fieldWithPath("_embedded.serviceTypes").description("An array of <<resources-serviceType, ServiceType resources>>"),
                        fieldWithPath("page").description("The <<paging, Paging resource>>"),
                        fieldWithPath("_links").description("<<resources-serviceTypes-links,Links>> to other resources")
                ),
                pathParameters(
                        parameterWithName("name").description("Filters results by service type name").optional(),
                        parameterWithName("size").description("Page size for the returned list").optional(),
                        parameterWithName("page").description("Page number for the returned list").optional()
                )));
    }

    @Test
    public void serviceTypeGetExample() throws Exception {
        this.mockMvc.perform(get("/serviceTypes/56568480389a11e6b82100e04c6801d0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("name", is("Mobile Phone")))
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("This <<resources-serviceType,serviceType>>"),
                        linkWithRel("providers").description("This service type's <<resources-providers,providers>>. Can optionally filter by history as a path argument.")
                ),
                responseFields(
                        fieldWithPath("uuid").description("The uuid of the service type"),
                        fieldWithPath("created").description("The date of creation for this service type"),
                        fieldWithPath("modified").description("The date of last modification for this service type"),
                        fieldWithPath("name").description("The name of the service type"),
                        fieldWithPath("_links").description("<<resources-serviceType-links,Links>> to other resources")
                )));
    }

    @Test
    public void templateGetExample() throws Exception {
        this.mockMvc.perform(get("/templates/1E60BFC7D65DDB4194AF22000B109B8B"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("templateName", is("ComcastTemplateProvider")))
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("This <<resources-template,template>>")
                ),
                responseFields(
                        fieldWithPath("uuid").description("The uuid of the template"),
                        fieldWithPath("created").description("The date of creation for this template"),
                        fieldWithPath("modified").description("The date of last modification for this template"),
                        fieldWithPath("templateName").description("The name of this template"),
                        fieldWithPath("website").description("The website associated with this template"),
                        fieldWithPath("hasInterval").description("Indicates whether template supports interval data"),
                        fieldWithPath("hasHistory").description("Indicates whether template supports history navigation"),
                        fieldWithPath("hasPdf").description("Indicates whether template supports PDF extraction"),
                        fieldWithPath("hasHtml").description("Indicates whether template supports HTML extraction"),
                        fieldWithPath("hasEdi").description("Indicates whether template supports EDI extraction"),
                        fieldWithPath("hasXls").description("Indicates whether template supports XLS extraction"),
                        fieldWithPath("hasCsv").description("Indicates whether template supports CSV extraction"),
                        fieldWithPath("hasOcr").description("Indicates whetehr template supports OCR extraction"),
                        fieldWithPath("tracksLoginFailure").description("Indicates whether template tracks login failures"),
                        fieldWithPath("templateType").description("Indicates the type of template (e.g. casper, classic)"),
                        fieldWithPath("attributes").description("List of attributes associated with the template"),
                        fieldWithPath("_links").description("<<resources-template-links,Links>> to other resources")                        
                )));
    }
    
    @Test
    public void acquisitionTemplatesGetExample() throws Exception {
        this.mockMvc.perform(get("/providers/1E60A4737EEEDF00A03822000B109B8B/bestAcquisitionTemplates"))
                .andExpect(status().isOk())
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("These <<resources-templates,Templates>>")
                ),
                responseFields(
                        fieldWithPath("_embedded.templates").description("An array of <<resources-template, Template resources>>"),
                        fieldWithPath("page").description("The <<paging, Paging resource>>"),
                        fieldWithPath("_links").description("<<resources-templates-links,Links>> to other resources")
                ),
                pathParameters(
                        parameterWithName("history").description("Filter by history availability").optional(),
                        parameterWithName("acquisitionType").description("Optionally filter by acquisition type").optional(),
                        parameterWithName("size").description("Page size for the returned list").optional(),
                        parameterWithName("page").description("Page number for the returned list").optional()
                )));
    }
    
    @Test
    public void extractionTemplatesGetExample() throws Exception {
        this.mockMvc.perform(get("/providers/1E60A4737EEEDF00A03822000B109B8B/bestExtractionTemplates"))
                .andExpect(status().isOk())
                .andDo(this.document.document(
                links(
                        linkWithRel("self").description("These <<resources-templates,Templates>>")
                ),
                responseFields(
                        fieldWithPath("_embedded.templates").description("An array of <<resources-template, Template resources>>"),
                        fieldWithPath("page").description("The <<paging, Paging resource>>"),
                        fieldWithPath("_links").description("<<resources-templates-links,Links>> to other resources")
                ),
                pathParameters(
                        parameterWithName("sourceType").description("Optionally filter by source type").optional(),
                        parameterWithName("size").description("Page size for the returned list").optional(),
                        parameterWithName("page").description("Page number for the returned list").optional()
                )));
    }

    /*
    /**
     * Helper class for handling descriptions for external constraints.
     *//*
    private static class ConstrainedFields {

        private final ConstraintDescriptions constraintDescriptions;

        ConstrainedFields(Class<?> input) {
            this.constraintDescriptions = new ConstraintDescriptions(input);
        }

        private FieldDescriptor withPath(String path) {
            System.out.println(path + ": " + key("constraints"));
            return fieldWithPath(path).attributes(key("constraints").value(StringUtils
                    .collectionToDelimitedString(this.constraintDescriptions
                            .descriptionsForProperty(path), ". ")));
        }
    }*/
}