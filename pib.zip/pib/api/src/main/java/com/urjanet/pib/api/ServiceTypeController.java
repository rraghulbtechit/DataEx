package com.urjanet.pib.api;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.ExposesResourceFor;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.pib.Application;
import com.urjanet.pib.api.resource.ProviderResource;
import com.urjanet.pib.api.resource.ServiceTypeResource;

import urjanet.portal.sdk.GetProvidersByServiceTypeCountResponse;
import urjanet.portal.sdk.GetProvidersByServiceTypeRequest;
import urjanet.portal.sdk.GetProvidersByServiceTypeResponse;
import urjanet.portal.sdk.GetServiceTypeRequest;
import urjanet.portal.sdk.GetServiceTypeResponse;
import urjanet.portal.sdk.UrjanetRestClient;
import urjanet.portal.sdk.resource.ServiceType;
import urjanet.portal.sdk.resource.UtilityProvider;

@RestController
@ExposesResourceFor(ServiceTypeResource.class)
@RequestMapping(value = "/serviceTypes", produces = {"application/hal+json"})
//@Transactional
public class ServiceTypeController {
    
    private static Logger logger = LoggerFactory.getLogger(ServiceTypeController.class);
    
    @Autowired
    private Application application;
    
    private ServiceTypeResourceAssembler serviceTypeResourceAssembler;
    private PagedResourcesAssembler<ServiceType> pagedServiceTypeResourceAssembler;
    private ProviderResourceAssembler providerResourceAssembler;
    private PagedResourcesAssembler<UtilityProvider> pagedProviderResourceAssembler;
    
    @Autowired
    public ServiceTypeController(ServiceTypeResourceAssembler serviceTypeResourceAssembler,
                            PagedResourcesAssembler<ServiceType> pagedServiceTypeResourceAssembler,
                            ProviderResourceAssembler providerResourceAssembler,
                            PagedResourcesAssembler<UtilityProvider> pagedProviderResourceAssembler) {
        this.serviceTypeResourceAssembler = serviceTypeResourceAssembler;
        this.pagedServiceTypeResourceAssembler = pagedServiceTypeResourceAssembler;
        this.providerResourceAssembler = providerResourceAssembler;
        this.pagedProviderResourceAssembler = pagedProviderResourceAssembler;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<PagedResources<ServiceTypeResource>> getServiceTypes(Pageable pageable,
            @RequestParam(required=false) String name) {
        
        UrjanetRestClient cli = application.getRestClient();
        List<ServiceType> serviceTypes = cli.getServiceTypes().getData();
        
        if (!StringUtils.isEmpty(name)) {
            for (int i = 0; i < serviceTypes.size(); i++) {
                if (!serviceTypes.get(i).getName().toUpperCase().contains(name.toUpperCase()))
                    serviceTypes.remove(i--);
            }
        }
        
        final Page<ServiceType> pagedServices = new PageImpl<ServiceType>(application.getSubList(serviceTypes, pageable), pageable, serviceTypes.size());
        final PagedResources<ServiceTypeResource> resources = pagedServiceTypeResourceAssembler.toResource(pagedServices, serviceTypeResourceAssembler);
        return ResponseEntity.ok(resources);
    }

    @RequestMapping(value = "/{serviceTypeId}", method = RequestMethod.GET)
    public ResponseEntity<ServiceTypeResource> getServiceType(@PathVariable("serviceTypeId") String serviceTypeId) {
        
        UrjanetRestClient cli = application.getRestClient();
        GetServiceTypeRequest req = new GetServiceTypeRequest();
        req.setId(serviceTypeId);
        GetServiceTypeResponse response = cli.getServiceType(req);
        
        if (response.getData() == null) {
            logger.info("Service type not found: {}", serviceTypeId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        final ServiceTypeResource resource = serviceTypeResourceAssembler.toResource(response.getData());
        return ResponseEntity.ok(resource);
    }

    @RequestMapping(value = "/{serviceTypeId}/providers", method = RequestMethod.GET)
    public ResponseEntity<PagedResources<ProviderResource>> getServiceTypeProviders(@PathVariable("serviceTypeId") String serviceTypeId, 
            @RequestParam(required=false) Boolean history, Pageable pageable) {
        
        UrjanetRestClient cli = application.getRestClient();
        
        GetServiceTypeRequest req = new GetServiceTypeRequest();
        req.setId(serviceTypeId);
        
        GetServiceTypeResponse resp = cli.getServiceType(req);
        
        if (resp.getData() == null) {
            logger.info("Service type not found: {}", serviceTypeId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        GetProvidersByServiceTypeRequest req2 = new GetProvidersByServiceTypeRequest();
        req2.setServiceTypeId(serviceTypeId);
        req2.setIncludeMeta(true);
        req2.setLength(pageable.getPageSize());
        req2.setStart(pageable.getOffset());
        
        if (history != null)
            req2.setHistory(history);
        
        GetProvidersByServiceTypeResponse response = cli.getProvidersByServiceType(req2);
        GetProvidersByServiceTypeCountResponse count = cli.getProvidersByServiceTypeCount(req2);
        List<UtilityProvider> providers = response.getData();
        
        if (providers == null)
            providers = new ArrayList<UtilityProvider>();
        
        final Page<UtilityProvider> pagedProviders = new PageImpl<UtilityProvider>(providers, pageable, count.getCount());
        
        final PagedResources<ProviderResource> resources = pagedProviderResourceAssembler.toResource(pagedProviders, providerResourceAssembler);
        return ResponseEntity.ok(resources);
    }
}