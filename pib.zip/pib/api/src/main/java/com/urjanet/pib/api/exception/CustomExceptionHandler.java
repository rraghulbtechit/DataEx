package com.urjanet.pib.api.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.urjanet.pib.api.resource.BasicErrorResponse;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Custom handler which catches certain exceptions and returns a properly formatted ResponseEntity instead.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
@ControllerAdvice
public class CustomExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public ResponseEntity<BasicErrorResponse> handleIllegalArgumentException(HttpServletRequest request, IllegalArgumentException ex) {
        return new ResponseEntity<>(new BasicErrorResponse("Bad request", ex.getClass().getName(), request.getServletPath(), 400, ex.getLocalizedMessage()), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    @ResponseBody
    public ResponseEntity<BasicErrorResponse> handleEntityNotFoundException(HttpServletRequest request, EntityNotFoundException ex) {
        return new ResponseEntity<>(new BasicErrorResponse("Bad request", ex.getClass().getName(), request.getServletPath(), 400, ex.getLocalizedMessage()), HttpStatus.BAD_REQUEST);
    }

// The built-in error rendering is verbose but matches the format we're using, so let's just go with it
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    @ResponseBody
//    public ResponseEntity<BasicErrorResponse> handleMethodArgumentNotValidException(HttpServletRequest request, MethodArgumentNotValidException ex) {
//        List<String> errors = ex.getBindingResult().getFieldErrors()
//                .stream()
//                .map(err -> err.getField() + ": " + err.getDefaultMessage())
//                .collect(Collectors.toList());
//        return new ResponseEntity<>(new BasicErrorResponse("Bad Request", ex.getClass().getName(), request.getServletPath(), 400, errors), HttpStatus.BAD_REQUEST);
//    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<BasicErrorResponse> handleHttpMessageNotReadableException(HttpServletRequest request, HttpMessageNotReadableException ex) {
        return new ResponseEntity<>(new BasicErrorResponse("Bad request", ex.getClass().getName(), request.getServletPath(), 400, "Required request body is missing or invalid."), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseBody
    public ResponseEntity<BasicErrorResponse> handleDataIntegrityViolationException(HttpServletRequest request, DataIntegrityViolationException ex) {
        return new ResponseEntity<>(new BasicErrorResponse("Conflict", ex.getClass().getName(), request.getServletPath(), 409, ex.getLocalizedMessage()), HttpStatus.CONFLICT);
    }
}
