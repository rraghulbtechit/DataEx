package com.urjanet.pib.api.exception;

/**
 * Exception thrown when a entity cannot be found in the database.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
public class EntityNotFoundException extends RuntimeException {

    public EntityNotFoundException(String resource, Object id) {
        super("No " + resource + " found at " + id);
    }
}
