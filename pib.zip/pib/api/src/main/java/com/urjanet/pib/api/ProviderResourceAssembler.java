package com.urjanet.pib.api;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.RelProvider;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.urjanet.pib.api.resource.ProviderResource;
import com.urjanet.pib.api.resource.ServiceTypeResource;

import urjanet.portal.sdk.resource.UtilityProvider;

@Service
public class ProviderResourceAssembler extends ResourceAssemblerSupport<UtilityProvider, ProviderResource> {
    
    private RelProvider relProvider;

    @Autowired
    public ProviderResourceAssembler(RelProvider relProvider) {
        super(ProviderController.class, ProviderResource.class);
        this.relProvider = relProvider;
    }

    @Override
    public ProviderResource toResource(UtilityProvider entity) {
        ProviderResource resource = createResourceWithId(entity.getId(), entity);

        resource.setUuid(entity.getId());
        resource.setAlias(entity.getProviderAlias());
        resource.setName(entity.getProviderName());
        resource.setCreated(entity.getCreated());
        resource.setModified(entity.getModified());

        resource.setWebsite(entity.getWebsite());
        resource.setHistory(entity.getHistory() != null && entity.getHistory().booleanValue());
        resource.setTracksLoginFailure(entity.getTracksLoginFailure() != null && entity.getTracksLoginFailure().booleanValue());
        
        if (entity.getClassification() != null)
            resource.setClassification(entity.getClassification().toString());

        // add additional links
        resource.add(linkTo(methodOn(ProviderController.class).getProviderServiceTypes(entity.getId(), null))
                .withRel(relProvider.getCollectionResourceRelFor(ServiceTypeResource.class)));
        resource.add(linkTo(methodOn(ProviderController.class).getBestAcquisitionTemplates(entity.getId(), null, null, null))
                .withRel("bestAcquisitionTemplates"));
        resource.add(linkTo(methodOn(ProviderController.class).getBestExtractionTemplates(entity.getId(), null, null, null))
                .withRel("bestExtractionTemplates"));

        return resource;
    }
}
