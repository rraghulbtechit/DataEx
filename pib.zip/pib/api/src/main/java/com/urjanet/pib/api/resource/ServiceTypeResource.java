package com.urjanet.pib.api.resource;

import java.util.Date;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

@Relation(value="serviceType", collectionRelation="serviceTypes")
public class ServiceTypeResource extends ResourceSupport {

    private String uuid;
    private String name;
    private Date created;
    private Date modified;
    
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public Date getCreated() {
        return created;
    }
    

    public void setCreated(Date created) {
        this.created = created;
    }
    

    public Date getModified() {
        return modified;
    }
    

    public void setModified(Date modified) {
        this.modified = modified;
    }
    
}
