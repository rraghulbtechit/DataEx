package com.urjanet.pib.api;

import java.beans.PropertyEditorSupport;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.ExposesResourceFor;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.pib.Application;
import com.urjanet.pib.api.resource.ProviderResource;
import com.urjanet.pib.api.resource.ServiceTypeResource;
import com.urjanet.pib.api.resource.TemplateResource;
import com.urjanet.pib.api.resource.TemplateResource.TemplateType;

import urjanet.portal.sdk.GetBestTemplateRequest;
import urjanet.portal.sdk.GetBestTemplateResponse;
import urjanet.portal.sdk.TemplateInfoGetRequest;
import urjanet.portal.sdk.TemplateInfoGetResponse;
import urjanet.portal.sdk.UrjanetRestClient;
import urjanet.portal.sdk.UtilityProviderGetRequest;
import urjanet.portal.sdk.UtilityProviderGetResponse;
import urjanet.portal.sdk.UtilityProviderSearchRequest;
import urjanet.portal.sdk.UtilityProviderSearchResponse;
import urjanet.portal.sdk.resource.EntityReference;
import urjanet.portal.sdk.resource.QueryCriteria;
import urjanet.portal.sdk.resource.QueryCriteria.Filter;
import urjanet.portal.sdk.resource.QueryCriteria.FilterCondition;
import urjanet.portal.sdk.resource.ServiceType;
import urjanet.portal.sdk.resource.TemplateAttribute;
import urjanet.portal.sdk.resource.TemplateAttributeConstraint;
import urjanet.portal.sdk.resource.TemplateInfo;
import urjanet.portal.sdk.resource.UtilityProvider;

@RestController
@ExposesResourceFor(ProviderResource.class)
@RequestMapping(value = "/providers", produces = {"application/hal+json"})
public class ProviderController {

    private static Logger logger = LoggerFactory.getLogger(ProviderController.class);
    
    @Autowired
    private Application application;
    
    private ServiceTypeResourceAssembler serviceTypeResourceAssembler;
    private PagedResourcesAssembler<ServiceType> pagedServiceTypeResourceAssembler;
    private ProviderResourceAssembler providerResourceAssembler;
    private PagedResourcesAssembler<UtilityProvider> pagedProviderResourceAssembler;
    private PagedResourcesAssembler<TemplateInfo> pagedTemplateResourceAssembler;
    private TemplateResourceAssembler templateResourceAssembler;
    
    @Autowired
    public ProviderController(ServiceTypeResourceAssembler serviceTypeResourceAssembler,
                            PagedResourcesAssembler<ServiceType> pagedServiceTypeResourceAssembler,
                            ProviderResourceAssembler providerResourceAssembler,
                            PagedResourcesAssembler<UtilityProvider> pagedProviderResourceAssembler,
                            TemplateResourceAssembler templateResourceAssembler,
                            PagedResourcesAssembler<TemplateInfo> pagedTemplateResourceAssembler) {
        this.serviceTypeResourceAssembler = serviceTypeResourceAssembler;
        this.pagedServiceTypeResourceAssembler = pagedServiceTypeResourceAssembler;
        this.providerResourceAssembler = providerResourceAssembler;
        this.pagedProviderResourceAssembler = pagedProviderResourceAssembler;
        this.templateResourceAssembler = templateResourceAssembler;
        this.pagedTemplateResourceAssembler = pagedTemplateResourceAssembler;
    }
    
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<PagedResources<ProviderResource>> getProviders(
            @RequestParam(required=false) String alias, @RequestParam(required=false) String name,
            @RequestParam(required=false) Boolean history, @RequestParam(required=false) Boolean all,
            Pageable pageable) {
        
        UrjanetRestClient cli = application.getRestClient();
        List<UtilityProvider> providers = new ArrayList<UtilityProvider>();
        boolean morePages = true;
        
        int offset = pageable.getOffset();
        int end = offset + pageable.getPageSize();
        
        QueryCriteria qC = new QueryCriteria();
        List<FilterCondition> conditions = new ArrayList<FilterCondition>();
        
        if (!StringUtils.isEmpty(alias))
            conditions.add(qC.new FilterCondition("providerAlias", "includes", alias, ""));
        
        if (!StringUtils.isEmpty(name))
            conditions.add(qC.new FilterCondition("providerName", "includes", name, ""));
        
        if (history != null && history.booleanValue())
            conditions.add(qC.new FilterCondition("history", "eq", "true", "boolean"));
        
        if (all == null || !all.booleanValue()) {
            conditions.add(qC.new FilterCondition("classification", "neq", "SECONDARY", ""));
            conditions.add(qC.new FilterCondition("serviceType", "notblank", "", ""));
        }
        
        Filter f = qC.new Filter("", conditions);
        qC.setFilter(f);
        
        UtilityProviderSearchRequest req = new UtilityProviderSearchRequest();
        req.setQueryCriteria(qC);
        
        int total = cli.getProviderCount(req).getCount();
        
        while (morePages && offset < end) {
            
            req = new UtilityProviderSearchRequest();
            req.setIncludeMeta(true);
            
            qC.setStart(offset);
            qC.setLength(end - offset);
            req.setQueryCriteria(qC);
            
            UtilityProviderSearchResponse resp = cli.getProviders(req);
            providers.addAll(resp.getData());
            
            offset = resp.getNextPageOffset();
            morePages = resp.isMorePages();
        }
        
        final Page<UtilityProvider> pagedProviders = new PageImpl<UtilityProvider>(providers, pageable, total);
        final PagedResources<ProviderResource> resources = pagedProviderResourceAssembler.toResource(pagedProviders, providerResourceAssembler);
        return ResponseEntity.ok(resources);
    }

    @RequestMapping(value = "/{providerId}", method = RequestMethod.GET)
    public ResponseEntity<ProviderResource> getProvider(@PathVariable("providerId") String providerId) {
        
        UrjanetRestClient cli = application.getRestClient();
        UtilityProviderGetRequest req = new UtilityProviderGetRequest();
        req.setIdOrAlias(providerId);
        req.setIncludeMeta(true);
        UtilityProviderGetResponse response = cli.getUtilityProvider(req);
        
        if (response.getData() == null) {
            logger.info("Provider not found: {}", providerId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        final ProviderResource resource = providerResourceAssembler.toResource(response.getData());
        return ResponseEntity.ok(resource);
    }

    @RequestMapping(value = "/{providerId}/serviceTypes", method = RequestMethod.GET)
    public ResponseEntity<PagedResources<ServiceTypeResource>> getProviderServiceTypes(@PathVariable("providerId") String providerId, Pageable pageable) {
        
        UrjanetRestClient cli = application.getRestClient();
        UtilityProviderGetRequest req = new UtilityProviderGetRequest();
        req.setIdOrAlias(providerId);
        UtilityProviderGetResponse response = cli.getUtilityProvider(req);
        
        if (response.getData() == null) {
            logger.info("Provider not found: {}", providerId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        List<ServiceType> serviceTypes = new ArrayList<ServiceType>();
        
        for (EntityReference ref : response.getData().getServiceTypes()) {
            ServiceType ind = new ServiceType();
            ind.setId(ref.getId());
            ind.setName(ref.getNaturalKey());
            
            serviceTypes.add(ind);
        }
        
        final Page<ServiceType> pagedIndustries = new PageImpl<ServiceType>(application.getSubList(serviceTypes, pageable), pageable, serviceTypes.size());
        final PagedResources<ServiceTypeResource> resources = pagedServiceTypeResourceAssembler.toResource(pagedIndustries, serviceTypeResourceAssembler);
        
        return ResponseEntity.ok(resources);
    }
    
    /*
     * TEMPLATE STUFF
     */

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(AcquisitionType.class, new PropertyEditorSupport() {
            
            @Override
            public void setAsText(String text) throws IllegalArgumentException {
                String caps = text.toUpperCase();
                AcquisitionType type = AcquisitionType.valueOf(caps); // TODO - just use null if it doesn't match?
                setValue(type);
            }
        });
        
        binder.registerCustomEditor(SourceType.class, new PropertyEditorSupport() {
            
            @Override
            public void setAsText(String text) throws IllegalArgumentException {
                String caps = text.toUpperCase();
                SourceType type = SourceType.valueOf(caps); // TODO - just use null if it doesn't match?
                setValue(type);
            }
        });
    }
    
    private static Map<String, String> templateMap = new HashMap<String, String>() {{
        put("Verizon", "verizon");
        put("TMobile", "tmobile");
        put("CharterCommunications", "charter");
        put("ATT", "att");
        put("Comcast", "comcast");
        put("MetroPCS", "metropcs");
    }};
    
    private static Map<String, String> seleniumMap = new HashMap<String, String>() {{
//        put("GeorgiaPower", "GeorgiaPowerSeleniumNavigator");
//        put("AlabamaPower", "AlabamaPowerSeleniumNavigator");
//        put("MississippiPower", "MississippiPowerSeleniumNavigator");
//        put("GulfPower", "GulfPowerSeleniumNavigator");
    }};
    
    private static Map<String, TemplateInfo> casperTemplateInfo = new HashMap<String, TemplateInfo>();
    private static Map<String, TemplateInfo> seleniumTemplateInfo = new HashMap<String, TemplateInfo>();
    
    static {
    	TemplateInfo ti = new TemplateInfo();
    	ti.setTemplateName("verizon");
    	ti.setAttributes(Arrays.asList(
    			new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
    			));
    	casperTemplateInfo.put("Verizon", ti);
    	
    	ti = new TemplateInfo();
        ti.setTemplateName("metropcs");
        ti.setAttributes(Arrays.asList(
                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
                ));
        casperTemplateInfo.put("MetroPCS", ti);
    	
    	ti = new TemplateInfo();
    	ti.setTemplateName("tmobile");
    	ti.setAttributes(Arrays.asList(
    			new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
    			));
    	casperTemplateInfo.put("TMobile", ti);

        ti = new TemplateInfo();
        ti.setTemplateName("att");
        ti.setAttributes(Arrays.asList(
                        new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
                        new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
                        new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
                        new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
                        new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
                        new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.RECOMMENDED),
                        new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
                        new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
                        ));
        casperTemplateInfo.put("ATT", ti);

    	ti = new TemplateInfo();
    	ti.setTemplateName("charter");
    	ti.setAttributes(Arrays.asList(
    			new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
    			new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
    			new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
    			));
    	casperTemplateInfo.put("CharterCommunications", ti);

        ti = new TemplateInfo();
        ti.setTemplateName("comcast");
        ti.setAttributes(Arrays.asList(
                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
        ));
        casperTemplateInfo.put("Comcast", ti);
        
        // SELENIUM TEMPLATES
//        ti = new TemplateInfo();
//        ti.setTemplateName("GeorgiaPowerSeleniumNavigator");
//        ti.setAttributes(Arrays.asList(
//                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
//        ));
//        seleniumTemplateInfo.put("GeorgiaPower", ti);        
//
//        ti = new TemplateInfo();
//        ti.setTemplateName("AlabamaPowerSeleniumNavigator");
//        ti.setAttributes(Arrays.asList(
//                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
//        ));
//        seleniumTemplateInfo.put("AlabamaPower", ti);
//        
//
//        ti = new TemplateInfo();
//        ti.setTemplateName("GulfPowerSeleniumNavigator");
//        ti.setAttributes(Arrays.asList(
//                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
//        ));
//        seleniumTemplateInfo.put("GulfPower", ti);
//        
//
//        ti = new TemplateInfo();
//        ti.setTemplateName("MississippiPowerSeleniumNavigator");
//        ti.setAttributes(Arrays.asList(
//                new TemplateAttribute("LOGIN_ID", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_ID2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_ID4", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS", "", TemplateAttributeConstraint.REQUIRED),
//                new TemplateAttribute("LOGIN_PASS_2", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_3", "", TemplateAttributeConstraint.NOT_USED),
//                new TemplateAttribute("LOGIN_PASS_4", "", TemplateAttributeConstraint.NOT_USED)
//        ));
//        seleniumTemplateInfo.put("MississippiPower", ti);
    }
    
    public static enum AcquisitionType {
        FTP,
        EMAIL,
        LOCAL_FILE,
        WEB,
        INTERVAL_DATA_WEB,
        WEB_SELENIUM,
        EDI_FTP,
        EDI_LOCAL,
    }
    
    private boolean shouldFilterAcquisitionTemplate(TemplateInfo temp, AcquisitionType acqType, Boolean history) {
        
        if (history != null && history.booleanValue() && !temp.hasHistory())
            return true;
        
        if (acqType == null)
            return false;
        
        switch(acqType) {
            case EDI_FTP:
            case EDI_LOCAL:
                return !temp.hasEdi();
            case INTERVAL_DATA_WEB:
                return !temp.hasInterval();
            case LOCAL_FILE: // DAQ scenarios - no real acquisition needed in template
            case FTP:
            case EMAIL:
                return false;
            case WEB_SELENIUM:
                return false; //TODO ???
            case WEB:
            default:
                return temp.hasEdi() || temp.hasOcr(); // TODO ???
        }
    }
    
    private void filterAcquisitionTemplates(List<TemplateInfo> templates, AcquisitionType acqType, Boolean history) {
        if (acqType == null && history == null)
            return;
        
        for (int i = 0; i < templates.size(); i++) {
            TemplateInfo temp = templates.get(i);
            
            if (shouldFilterAcquisitionTemplate(temp, acqType, history))
                templates.remove(i--);
                
        }
    }
    
    @RequestMapping(value = "/{providerId}/bestAcquisitionTemplates", method = RequestMethod.GET)
    public ResponseEntity<PagedResources<TemplateResource>> getBestAcquisitionTemplates(@PathVariable("providerId") String providerId, 
            @RequestParam(value="acquisitionType", required=false) AcquisitionType acquisitionType, 
            @RequestParam(value="history", required=false) Boolean history, Pageable pageable) {
        
        UrjanetRestClient cli = application.getRestClient();
        
        UtilityProviderGetRequest req = new UtilityProviderGetRequest();
        req.setIdOrAlias(providerId);
        UtilityProviderGetResponse resp = cli.getUtilityProvider(req);
        final TemplateType type;

        List<TemplateInfo> templates = new ArrayList<TemplateInfo>();
        
        if (resp.getData() == null) {
            logger.info("Provider not found: {}", providerId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        // Hardcode the casper templates (for now)
        if (resp.getData() != null && templateMap.containsKey(resp.getData().getProviderAlias())) {
            logger.info("Found Casper template for provider: {}", providerId);

            if (casperTemplateInfo.containsKey(resp.getData().getProviderAlias())) {
            	templates.add(casperTemplateInfo.get(resp.getData().getProviderAlias()));
            } else {
            	TemplateInfo temp = new TemplateInfo();
            	temp.setTemplateName(templateMap.get(resp.getData().getProviderAlias()));
            	templates.add(temp);
            }
            
            type = TemplateType.CASPER;
        } else if (resp.getData() != null && seleniumMap.containsKey(resp.getData().getProviderAlias())) {
            logger.info("Found Selenium template for provider: {}", providerId);

            if (seleniumTemplateInfo.containsKey(resp.getData().getProviderAlias())) {
                templates.add(seleniumTemplateInfo.get(resp.getData().getProviderAlias()));
            } else {
                TemplateInfo temp = new TemplateInfo();
                temp.setTemplateName(seleniumMap.get(resp.getData().getProviderAlias()));
                templates.add(temp);
            }
            
            type = TemplateType.SELENIUM;
        } else {
            GetBestTemplateRequest req2 = new GetBestTemplateRequest(providerId);
            GetBestTemplateResponse response = cli.getBestTemplates(req2);
            templates = response.getData();
            
            filterAcquisitionTemplates(templates, acquisitionType, history);            
            type = TemplateType.CLASSIC;
        }
        
        final Page<TemplateInfo> pagedTemplates = new PageImpl<TemplateInfo>(application.getSubList(templates, pageable), pageable, templates.size());
        final PagedResources<TemplateResource> resources = pagedTemplateResourceAssembler.toResource(pagedTemplates, templateResourceAssembler);
        
        // A bit of a hack (for now)
        resources.forEach(new Consumer<TemplateResource>() {

            @Override
            public void accept(TemplateResource t) {
                t.setTemplateType(type);                
            }
            
        });
        
        return ResponseEntity.ok(resources);
    }
    
    public static enum SourceType {
        UNKNOWN,
        HTML,
        PDF,
        SPREADSHEET_CSV,
        SPREADSHEET_XLS,
        SPREADSHEET_XLSX,
        DAQ_PDF_DEFAULT,
        DAQ_PDF_IMAGE,
        DAQ_PDF_OCRRESULT,
        DAQ_IMAGE,
        DAQ_SPREADSHEET_CSV,
        DAQ_SPREADSHEET_XLS,
        DAQ_SPREADSHEET_XLSX,
        DAQ_WOOT,
        DAQ_EDI
    }
    
    private boolean shouldFilterExtractionTemplate(TemplateInfo temp, SourceType sourceType) {
        
        switch (sourceType) {
            case SPREADSHEET_CSV:
            case DAQ_SPREADSHEET_CSV:
                return !temp.hasCsv();
            case SPREADSHEET_XLS:
            case SPREADSHEET_XLSX:
            case DAQ_SPREADSHEET_XLS:
            case DAQ_SPREADSHEET_XLSX:
                return !temp.hasXls();
            case DAQ_EDI:
                return !temp.hasEdi();
            case HTML:
                return !temp.hasHtml();
            case DAQ_PDF_IMAGE:     // TODO ???
            case DAQ_IMAGE:
            case DAQ_PDF_OCRRESULT: // check for PDF on this/these instead?
                return !temp.hasOcr();
            case PDF:
            case DAQ_PDF_DEFAULT:
                return !temp.hasPdf();
            case UNKNOWN:
            case DAQ_WOOT:
            default:
                return false;
        }
    }
    
    private void filterExtractionTemplates(List<TemplateInfo> templates, SourceType sourceType) {
        if (sourceType == null)
            return;
        
        for (int i = 0; i < templates.size(); i++) {
            TemplateInfo temp = templates.get(i);
            
            if (shouldFilterExtractionTemplate(temp, sourceType))
                templates.remove(i--);
        }
    }
    
    @RequestMapping(value = "/{providerId}/bestExtractionTemplates", method = RequestMethod.GET)
    public ResponseEntity<PagedResources<TemplateResource>> getBestExtractionTemplates(@PathVariable("providerId") String providerId, 
            @RequestParam(value="sourceType", required=false) SourceType sourceType, 
            @RequestParam(value="acquisitionTemplate", required=false) String acquisitionTemplate, Pageable pageable) {
        
        UrjanetRestClient cli = application.getRestClient();
        
        UtilityProviderGetRequest req = new UtilityProviderGetRequest();
        req.setIdOrAlias(providerId);
        UtilityProviderGetResponse resp = cli.getUtilityProvider(req);
        
        if (resp.getData() == null) {
            logger.info("Provider not found: {}", providerId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        List<TemplateInfo> templates = new ArrayList<TemplateInfo>();
        
        if (!StringUtils.isEmpty(acquisitionTemplate)) {
            TemplateInfoGetRequest getReq = new TemplateInfoGetRequest();
            getReq.setIdOrName(acquisitionTemplate);
            TemplateInfoGetResponse getResp = cli.getTemplateInfo(getReq);
            
            if (getResp.getData() != null) {
                templates.add(getResp.getData());
            }

            filterExtractionTemplates(templates, sourceType); // ??
        }
        
        if (templates.isEmpty()) {
            GetBestTemplateRequest req2 = new GetBestTemplateRequest(providerId);
            GetBestTemplateResponse response = cli.getBestTemplates(req2);
            templates = response.getData();
        }
        
        filterExtractionTemplates(templates, sourceType);
        
        final Page<TemplateInfo> pagedTemplates = new PageImpl<TemplateInfo>(application.getSubList(templates, pageable), pageable, templates.size());
        final PagedResources<TemplateResource> resources = pagedTemplateResourceAssembler.toResource(pagedTemplates, templateResourceAssembler);
        return ResponseEntity.ok(resources);
    }

}
