package com.urjanet.pib.api.resource;

import java.util.ArrayList;
import java.util.List;

/**
 * REST representation of a simple message.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
public class BasicResponse {
    private final int status;
    private final List<String> message;

    public BasicResponse(int status, List<String> message) {
        this.status = status;
        this.message = message;
    }

    public BasicResponse(int status, String message) {
        this.status = status;
        this.message = new ArrayList<>();
        this.message.add(message);
    }

    public List<String> getMessage() {
        return message;
    }

    public int getStatus() {
        return status;
    }
}
