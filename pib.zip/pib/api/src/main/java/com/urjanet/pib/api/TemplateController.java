package com.urjanet.pib.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.ExposesResourceFor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.urjanet.pib.Application;
import com.urjanet.pib.api.resource.ServiceTypeResource;
import com.urjanet.pib.api.resource.TemplateResource;

import urjanet.portal.sdk.TemplateInfoGetRequest;
import urjanet.portal.sdk.TemplateInfoGetResponse;
import urjanet.portal.sdk.UrjanetRestClient;
import urjanet.portal.sdk.resource.TemplateInfo;

@RestController
@ExposesResourceFor(TemplateResource.class)
@RequestMapping(value = "/templates", produces = {"application/hal+json"})
public class TemplateController {
    
    private static Logger logger = LoggerFactory.getLogger(TemplateController.class);
    
    @Autowired
    private Application application;
    
    private TemplateResourceAssembler templateResourceAssembler;
    private PagedResourcesAssembler<TemplateInfo> pagedTemplateResourceAssembler;
    
    @Autowired
    public TemplateController(TemplateResourceAssembler templateResourceAssembler,
            PagedResourcesAssembler<TemplateInfo> pagedTemplateResourceAssembler) {
        this.templateResourceAssembler = templateResourceAssembler;
        this.pagedTemplateResourceAssembler = pagedTemplateResourceAssembler;
    }
    
    @RequestMapping(value = "/{templateId}", method = RequestMethod.GET)
    public ResponseEntity<TemplateResource> getTemplate(@PathVariable("templateId") String templateId) {
        
        UrjanetRestClient cli = application.getRestClient();
        TemplateInfoGetRequest req  = new TemplateInfoGetRequest();
        req.setIdOrName(templateId);
        TemplateInfoGetResponse response = cli.getTemplateInfo(req);
        
        if (response.getData() == null) {
            logger.info("Template not found: {}", templateId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        final TemplateResource resource = templateResourceAssembler.toResource(response.getData());
        return ResponseEntity.ok(resource);
    }
    
}
