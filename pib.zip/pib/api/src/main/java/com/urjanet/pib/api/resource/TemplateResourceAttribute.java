package com.urjanet.pib.api.resource;

import urjanet.portal.sdk.resource.TemplateAttributeConstraint;

public class TemplateResourceAttribute {
	private String name, description;
	private TemplateAttributeConstraint constraint;

	public TemplateResourceAttribute() {
		super();
	}

	public TemplateResourceAttribute(String name, String description, TemplateAttributeConstraint constraint) {
		this.name = name;
		this.description = description;
		this.constraint = constraint;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public TemplateAttributeConstraint getConstraint() {
		return constraint;
	}

	public void setContraint(TemplateAttributeConstraint constraint) {
		this.constraint = constraint;
	}
}