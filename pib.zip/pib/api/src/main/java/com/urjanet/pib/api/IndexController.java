package com.urjanet.pib.api;

import com.urjanet.pib.api.resource.IndexResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST access object for working with Index representations.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
@RestController
@RequestMapping(value = "/")
public class IndexController {

    private IndexResourceAssembler indexResourceAssembler;

    @Autowired
    public IndexController(IndexResourceAssembler indexResourceAssembler) {
        this.indexResourceAssembler = indexResourceAssembler;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<IndexResource> getIndex() {
        return ResponseEntity.ok(indexResourceAssembler.buildIndex());
    }
}
