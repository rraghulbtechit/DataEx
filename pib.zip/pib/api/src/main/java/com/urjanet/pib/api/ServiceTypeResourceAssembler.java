package com.urjanet.pib.api;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.RelProvider;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.urjanet.pib.api.resource.ProviderResource;
import com.urjanet.pib.api.resource.ServiceTypeResource;

import urjanet.portal.sdk.resource.ServiceType;

@Service
public class ServiceTypeResourceAssembler extends ResourceAssemblerSupport<ServiceType, ServiceTypeResource> {

    private RelProvider relProvider;

    @Autowired
    public ServiceTypeResourceAssembler(RelProvider relProvider) {
        super(ServiceTypeController.class, ServiceTypeResource.class);
        this.relProvider = relProvider;
    }

    @Override
    public ServiceTypeResource toResource(ServiceType entity) {
        ServiceTypeResource resource = createResourceWithId(entity.getId(), entity);

        resource.setName(entity.getName());
        resource.setUuid(entity.getId());
        resource.setCreated(entity.getCreated());
        resource.setModified(entity.getModified());
        
        resource.add(linkTo(methodOn(ServiceTypeController.class).getServiceTypeProviders(entity.getId(), null, null))
                .withRel(relProvider.getCollectionResourceRelFor(ProviderResource.class)));

        return resource;
    }
}
