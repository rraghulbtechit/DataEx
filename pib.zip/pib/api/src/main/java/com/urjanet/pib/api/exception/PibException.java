package com.urjanet.pib.api.exception;

public class PibException extends Exception {
    public PibException(String message, Throwable e) {
        super(message, e);
    }
    
    public PibException(String message) {
        super(message);
    }

    public PibException() {
        super();
    }
}
