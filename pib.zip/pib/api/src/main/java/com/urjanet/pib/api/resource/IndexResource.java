package com.urjanet.pib.api.resource;

import org.springframework.hateoas.ResourceSupport;

/**
 * REST representation of the Index (root) resource.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
public class IndexResource extends ResourceSupport {

}