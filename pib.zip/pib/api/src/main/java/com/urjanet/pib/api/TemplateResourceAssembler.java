package com.urjanet.pib.api;

import java.util.ArrayList;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import urjanet.portal.sdk.resource.TemplateAttribute;
import urjanet.portal.sdk.resource.TemplateAttributeConstraint;
import urjanet.portal.sdk.resource.TemplateInfo;

import com.urjanet.pib.api.resource.TemplateResource;
import com.urjanet.pib.api.resource.TemplateResource.TemplateResourceAttribute;
import com.urjanet.pib.api.resource.TemplateResource.TemplateType;

@Service
public class TemplateResourceAssembler extends ResourceAssemblerSupport<TemplateInfo, TemplateResource> {

    //private RelProvider relProvider;

    //@Autowired
    public TemplateResourceAssembler() {
        super(TemplateController.class, TemplateResource.class);
        //this.relProvider = relProvider;
    }

    @Override
    public TemplateResource toResource(TemplateInfo entity) {
        TemplateResource resource = null;
        
        if (entity.getId() != null)
            resource = createResourceWithId(entity.getId(), entity);
        else
            resource = new TemplateResource();
        
        resource.setUuid(entity.getId());
        resource.setCreated(entity.getCreated());
        resource.setModified(entity.getModified());
        resource.setHasCsv(entity.hasCsv());
        resource.setHasEdi(entity.hasEdi());
        resource.setHasHistory(entity.hasHistory());
        resource.setHasHtml(entity.hasHtml());
        resource.setHasInterval(entity.hasInterval());
        resource.setHasOcr(entity.hasOcr());
        resource.setHasPdf(entity.hasPdf());
        resource.setHasXls(entity.hasXls());
        resource.setTracksLoginFailure(entity.tracksLoginFailure());
        resource.setTemplateName(entity.getTemplateName());
        resource.setTemplateType(TemplateType.CLASSIC);
        
        resource.setAttributes(new ArrayList<TemplateResourceAttribute>());
        
        if (entity.getAttributes() != null) {
        	for (TemplateAttribute attr : entity.getAttributes()) {
        		TemplateAttributeConstraint c = TemplateAttributeConstraint.valueOf(attr.getConstraint());
        		resource.getAttributes().add(new TemplateResource.TemplateResourceAttribute(attr.getName(), "", c));
        	}
        }

        return resource;
    }
}
