package com.urjanet.pib;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.data.domain.Pageable;

import urjanet.portal.sdk.UrjanetRestClient;

@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, 
        HibernateJpaAutoConfiguration.class})
public class Application {

    private static final Logger log = LoggerFactory.getLogger(Application.class);
    
    @Value("${portal.api.url}")
    private String apiUrl;
    
    @Value("${portal.username}")
    private String portalUser;
    
    @Value("${portal.password}")
    private String portalPass;
    
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);		
	}
	
	public UrjanetRestClient getRestClient() { 
	    return new UrjanetRestClient(portalUser, portalPass, apiUrl);
	}
	
	public <T> List<T> getSubList(List<T> list, Pageable pageable) {
	    int page = pageable.getPageNumber();
        int size = pageable.getPageSize();
        int max = (size * (page + 1)) > list.size() ? 
                list.size() : 
                size * (page + 1);
                
        if (page * size > list.size() || max > list.size())
            return new ArrayList<T>();
                
        return list.subList(page * size, max);
	}
}
