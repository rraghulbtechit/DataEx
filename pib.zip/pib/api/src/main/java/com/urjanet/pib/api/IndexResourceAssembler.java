package com.urjanet.pib.api;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityLinks;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.RelProvider;
import org.springframework.stereotype.Service;

import com.urjanet.pib.api.resource.IndexResource;
import com.urjanet.pib.api.resource.ProviderResource;
import com.urjanet.pib.api.resource.ServiceTypeResource;
import com.urjanet.pib.api.resource.TemplateResource;

/**
 * Assembles an Index REST representation from the self links of all other controllers.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
@Service
public class IndexResourceAssembler {

    private EntityLinks entityLinks;

    private RelProvider relProvider;

    @Autowired
    public IndexResourceAssembler(EntityLinks entityLinks, RelProvider relProvider) {
        this.entityLinks = entityLinks;
        this.relProvider = relProvider;
    }

    public IndexResource buildIndex() {
        final List<Link> links = Arrays.asList(
            entityLinks.linkToCollectionResource(ProviderResource.class).withRel(relProvider.getCollectionResourceRelFor(ProviderResource.class)),
            entityLinks.linkToCollectionResource(ServiceTypeResource.class).withRel(relProvider.getCollectionResourceRelFor(ServiceTypeResource.class))
        );

        final IndexResource resource = new IndexResource();
        resource.add(links);
        return resource;
    }
}