package com.urjanet.pib.api.resource;

import java.util.List;

/**
 * REST representation of a simple error message.
 *
 * @author Michael Pridemore (michael.pridemore@urjanet.com))
 */
public class BasicErrorResponse extends BasicResponse {
    private final String error;
    private final String exception;
    private final String path;
    private final long timestamp;

    public BasicErrorResponse(String error, String exception, int status, List<String> message) {
        this(error, exception, "", status, message);
    }

    public BasicErrorResponse(String error, String exception, int status, String message) {
        this(error, exception, "", status, message);
    }

    public BasicErrorResponse(String error, String exception, String path, int status, List<String> message) {
        super(status, message);
        this.error = error;
        this.exception = exception;
        this.path = path;
        this.timestamp = System.currentTimeMillis();
    }

    public BasicErrorResponse(String error, String exception, String path, int status, String message) {
        super(status, message);
        this.error = error;
        this.exception = exception;
        this.path = path;
        this.timestamp = System.currentTimeMillis();
    }

    public String getError() {
        return error;
    }

    public String getException() {
        return exception;
    }

    public String getPath() { return path; }

    public long getTimestamp() { return timestamp; }
}
