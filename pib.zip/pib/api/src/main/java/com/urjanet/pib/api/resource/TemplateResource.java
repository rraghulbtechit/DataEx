package com.urjanet.pib.api.resource;

import java.util.Date;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

import urjanet.portal.sdk.resource.TemplateAttributeConstraint;

@Relation(value="template", collectionRelation="templates")
public class TemplateResource extends ResourceSupport {
    
    private String uuid;
    private String templateName;
    private String website;
    private boolean hasInterval, hasHistory, hasPdf, hasHtml, hasEdi, hasXls, hasCsv, hasOcr, tracksLoginFailure;
    private TemplateType templateType;
    private Date created;
    private Date modified;
    private List<TemplateResourceAttribute> attributes;

    public static enum TemplateType {
    	CLASSIC,
    	CASPER,
    	SLIMER,
    	SELENIUM
    };

    public String getUuid() {
        return uuid;
    }
    

    public void setUuid(String id) {
        this.uuid = id;
    }
    

    public String getTemplateName() {
        return templateName;
    }
    

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }
    

    public String getWebsite() {
        return website;
    }
    

    public void setWebsite(String website) {
        this.website = website;
    }
    

    public boolean isHasInterval() {
        return hasInterval;
    }
    

    public void setHasInterval(boolean hasInterval) {
        this.hasInterval = hasInterval;
    }
    

    public boolean isHasHistory() {
        return hasHistory;
    }
    

    public void setHasHistory(boolean hasHistory) {
        this.hasHistory = hasHistory;
    }
    

    public boolean isHasPdf() {
        return hasPdf;
    }
    

    public void setHasPdf(boolean hasPdf) {
        this.hasPdf = hasPdf;
    }
    

    public boolean isHasHtml() {
        return hasHtml;
    }
    

    public void setHasHtml(boolean hasHtml) {
        this.hasHtml = hasHtml;
    }
    

    public boolean isHasEdi() {
        return hasEdi;
    }
    

    public void setHasEdi(boolean hasEdi) {
        this.hasEdi = hasEdi;
    }
    

    public boolean isHasXls() {
        return hasXls;
    }
    

    public void setHasXls(boolean hasXls) {
        this.hasXls = hasXls;
    }
    

    public boolean isHasCsv() {
        return hasCsv;
    }
    

    public void setHasCsv(boolean hasCsv) {
        this.hasCsv = hasCsv;
    }
    

    public boolean isHasOcr() {
        return hasOcr;
    }
    

    public void setHasOcr(boolean hasOcr) {
        this.hasOcr = hasOcr;
    }
    

    public boolean isTracksLoginFailure() {
        return tracksLoginFailure;
    }
    

    public void setTracksLoginFailure(boolean tracksLoginFailure) {
        this.tracksLoginFailure = tracksLoginFailure;
    }
    

    public TemplateType getTemplateType() {
        return templateType;
    }
    

    public void setTemplateType(TemplateType templateType) {
        this.templateType = templateType;
    }


    public Date getCreated() {
        return created;
    }
    


    public void setCreated(Date created) {
        this.created = created;
    }
    


    public Date getModified() {
        return modified;
    }
    


    public void setModified(Date modified) {
        this.modified = modified;
    }


	public List<TemplateResourceAttribute> getAttributes() {
		return attributes;
	}


	public void setAttributes(List<TemplateResourceAttribute> attributes) {
		this.attributes = attributes;
	}
	
	
    public static class TemplateResourceAttribute {
    	private String name, description;
    	private TemplateAttributeConstraint constraint;
    	
    	public TemplateResourceAttribute() {
    		super();
    	}
    	
    	public TemplateResourceAttribute(String name, String description, TemplateAttributeConstraint constraint) {
    		this.name = name;
    		this.description = description;
    		this.constraint = constraint;
    	}
    	
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getDescription() {
			return description;
		}
		
		public void setDescription(String description) {
			this.description = description;
		}
		
		public TemplateAttributeConstraint getConstraint() {
			return constraint;
		}
		
		public void setContraint(TemplateAttributeConstraint constraint) {
			this.constraint = constraint;
		}
    }
}
