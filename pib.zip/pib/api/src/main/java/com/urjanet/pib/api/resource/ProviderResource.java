package com.urjanet.pib.api.resource;

import java.util.Date;

import org.springframework.hateoas.ResourceSupport;
import org.springframework.hateoas.core.Relation;

@Relation(value="provider", collectionRelation="providers")
public class ProviderResource extends ResourceSupport {

    private String uuid;
    private String alias;
    private String name;
    private String classification;
    private boolean history;
    private boolean tracksLoginFailure;
    private String website;
    private Date created;
    private Date modified;

    
    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getAlias() {
        return alias;
    }
    

    public void setAlias(String alias) {
        this.alias = alias;
    }
    

    public String getName() {
        return name;
    }
    

    public void setName(String name) {
        this.name = name;
    }
    

    public String getClassification() {
        return classification;
    }
    

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public boolean getHistory() {
        return history;
    }
    

    public void setHistory(boolean history) {
        this.history = history;
    }
    

    public boolean getTracksLoginFailure() {
        return tracksLoginFailure;
    }
    

    public void setTracksLoginFailure(boolean tracksLoginFailure) {
        this.tracksLoginFailure = tracksLoginFailure;
    }
    

    public String getWebsite() {
        return website;
    }
    

    public void setWebsite(String website) {
        this.website = website;
    }
    

    public Date getCreated() {
        return created;
    }
    

    public void setCreated(Date created) {
        this.created = created;
    }
    

    public Date getModified() {
        return modified;
    }
    

    public void setModified(Date modified) {
        this.modified = modified;
    }
    
}
