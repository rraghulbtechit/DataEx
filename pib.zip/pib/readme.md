# PIB - Provider Information Base

## Contents

* [Description](#description)
* [Modules](#modules)
* [Building](#building)
* [Running Locally](#running-locally)

## Description

The PIB is the central hub of top-level provider, service type, and template meta information. It provides an API through which you can request information about any of these entities and their relationships with each other.

An HTML version of the full API documentation can be found in api/src/docs/asciidoc/api-guide.html.

## Modules

### api

This is the primary service in PIB. It provides the functionality via a simple REST HATEOAS API.

The api server is deployed at the following internal URLs. They can only be accessed from within the appropriate VPC.

* **CI** - [https://pib-ci.urjanet.net](https://pib-ci.urjanet.net)
* **QA** - [https://pib-qa.urjanet.net](https://pib-qa.urjanet.net)
* **PROD** - [https://pib.urjanet.net](https://pib.urjanet.net)

## Building

To build the modules in this project:


    $ git checkout https://<username>@bitbucket.org/urjanet/pib.git
    $ cd pib
    $ ./gradlew clean build


## Running Locally

To run locally, there must currently be a reachable UDS API for the PIB to query against. The UDS API can also be running locally (typically port 9669; needed if you are also modifying the UDS API) or the PIB can run against the UDS API in the CI or QA environments. Keep in mind that if you run the UDS API locally, it must be deployed under Java 7, but the PIB API must be deployed under Java 8.

By default, the PIB will run on port 8888 locally and try to query against UDS API on localhost. All of the configuration for this is in api/src/main/resources/application-default.yml. You can start the PIB API server from the command line with the following command:

    $ java -jar api/build/libs/api-1.0.jar --spring.profiles.active=default
