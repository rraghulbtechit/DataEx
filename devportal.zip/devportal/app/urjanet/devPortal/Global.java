package urjanet.devPortal;

import java.util.concurrent.TimeUnit;

import play.Application;
import play.GlobalSettings;
import play.Logger;
import play.libs.Akka;
import scala.concurrent.duration.Duration;
import urjanet.devPortal.service.GitLogStatService;
import urjanet.devPortal.service.HolidayList;

public class Global extends GlobalSettings {

	@Override
	public void onStart(Application app) {
		Logger.info("Devportal has started");
		Akka.system()
				.scheduler()
				.schedule(Duration.create(0, TimeUnit.MILLISECONDS),
						Duration.create(12, TimeUnit.HOURS),
						new GitLogStatService(), Akka.system().dispatcher());
		
		Akka.system()
		.scheduler()
		.schedule(Duration.create(0, TimeUnit.MILLISECONDS),
				Duration.create(12, TimeUnit.HOURS),
				new HolidayList(), Akka.system().dispatcher());
	}

	@Override
	public void onStop(Application app) {
		Logger.info("Application shutdown...");
	}

}