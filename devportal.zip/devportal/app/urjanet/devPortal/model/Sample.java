/**
 * 
 */
package urjanet.devPortal.model;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import urjanet.devPortal.domain.Country;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplateProperties;

/**
 * @author balaji_rajaram
 *
 */
public class Sample {

	static SessionFactory sessionFactory = null;

	static {
		sessionFactory = new Configuration().configure( new File( "./src/hibernate.cfg.xml" ) ).addAnnotatedClass( TemplateProperties.class ).addAnnotatedClass( Template.class ).addAnnotatedClass( Country.class ).buildSessionFactory();
	}

	/**
	 * @param args
	 */
	public static void view() {

		Session session = sessionFactory.openSession();
		Transaction ts = null;

		try {
			ts = session.beginTransaction();
			System.out.println( "c" );
			List<Template> tls =  session.createQuery( "from Template" ).list();
			
			int ii =0;
			for(Template tl:tls){
				
				ii++;
			Set<Country> countries=tl.getCountries();
				System.out.println(ii+"."+  tl.getTemplateName());
				int j =0;
				for(Country c:countries){
					
					j++;
					System.out.println("\t"+j+"."+ c.getCountryName());
				}
			}
			
			List<Country> cls =  session.createQuery( "from Country" ).list();
			
			int i =0;
			for(Country cl:cls){
				
//				i++;
//			Set<Template> templist=cl.getTemplates();
//				System.out.println(i+"."+  cl.getCountryName());
//				int j =0;
//				for(Template t:templist){
//					
//					j++;
//					System.out.println("\t"+j+"."+ t.getTemplateName());
//				}
			}
			
			

		} catch (Exception e) {
			if (ts != null)
				ts.rollback();
			System.out.println( e );
		} finally

		{
			session.close();
			sessionFactory.close();
			System.out.println( "CLOSE" );
		}

	}
	
	public static void store() {

		Session session = sessionFactory.openSession();
		Transaction ts = null;
		File folder = new File( "/opt/urjanet_platform/pull/core/src/main/java/urjanet/pull/template/" );
		File[] listOfFiles = folder.listFiles();
		
		try {

			session = sessionFactory.openSession();
			ts= session.beginTransaction();
			Country usa = new Country();
			usa.setCountryCode( "USA" );
			usa.setCountryName( "UNITED STATES OF AMERICA" );
			Country uk = new Country();
			uk.setCountryCode( "UK" );
			uk.setCountryName( "UNITED KINGDOM" );
			Country de = new Country();
			de.setCountryCode( "DE" );
			de.setCountryName( "GERMANY" );
			Country fr = new Country();
			fr.setCountryCode( "FRA" );
			fr.setCountryName( "FRANCE" );
			session.save( de );
			session.save( usa );
			session.save( uk );
			session.save( fr );
			for (int i = 0; i < listOfFiles.length; i++) {

				if (listOfFiles[i].isFile() && i<6) {
					
					String templateName = listOfFiles[i].getName();
					templateName = templateName.replaceAll( ".java", "" );
					Template template = new Template();
					
					template.setTemplateName( templateName );
					template.setTemplateId( i );
					Set<Country> countries = new HashSet<Country>();
					if(i%2==0){
						countries.add( uk );
						countries.add(usa );}
					else{
						countries.add( de );
						countries.add(fr );
					}
					template.setTemplateName( templateName );
					template.setTemplateId( i );
					template.setCountries( countries );
					
					session.save( template );
					
					System.out.println( i + ". " + listOfFiles[i].getName() + " Persisted" );
					
				}
			}
			ts.commit();

		} catch (Exception e) {
			if (ts != null){System.out.println( "rolling back" );
				ts.rollback();}
			System.out.println("INSIDE");
			e.getStackTrace();
			
			
		} finally

		{
			session.close();
			
			System.out.println( "CLOSE" );
		}

	}
	
	public static void main(String args[]){
		
		store();
		view();
		
		
		
	}

}
