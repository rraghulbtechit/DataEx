package urjanet.devPortal.model;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CommandExecutor {

	public static String execute(String templateName, String filePath) {
		String s;
		Process p;
		String output = " ";
		try {
			String par = " -t " + templateName + " -c a=b -d " + filePath;
			String command[] = { "/opt/urjanet_infra/bin/topgunDevelopmentUpdateRunner.sh", par };
			p = Runtime.getRuntime().exec( command );
			System.out.println( command[0] + par );
			BufferedReader br = new BufferedReader( new InputStreamReader( p.getInputStream() ) );
			while ((s = br.readLine()) != null) {
				output = output + "\n" + s;
				System.out.println( s );
			}
			p.waitFor();

			p.destroy();
		} catch (Exception e) {
		}

		return output;
	}
}