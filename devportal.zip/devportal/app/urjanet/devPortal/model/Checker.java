package urjanet.devPortal.model;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplateProperties;

public class Checker {

	static HashMap<String, Integer> templateMatchList = new HashMap<String, Integer>();
	static String templateName = "";

	static SessionFactory sessionFactory = null;

	static {
		sessionFactory = new Configuration().configure( new File( "./src/hibernate.cfg.xml" ) ).addAnnotatedClass( TemplateProperties.class ).addAnnotatedClass( Template.class ).buildSessionFactory();
	}

	public static HashMap<String, Integer> checking(HashMap<String, ArrayList<TemplateProperties>> templateList, String wholePdf) {

		Session session = sessionFactory.openSession();
		Transaction ts = null;

		try {
			ts = session.beginTransaction();
			ArrayList<Template> list = (ArrayList<Template>) session.createQuery( "from TemplateID" ).list();

			for (Template tid : list) {
				Integer count = 0;
				String temp = "";
				String templateName = tid.getTemplateName();
				List<TemplateProperties> propertyListForTemplate = tid.getTemplateProperties();
				int numberofkeys = propertyListForTemplate.size();
				Iterator<TemplateProperties> iterateTemplatePropertyList = propertyListForTemplate.iterator();
				while (iterateTemplatePropertyList.hasNext()) {
					temp = iterateTemplatePropertyList.next().getFilterString();

					if (wholePdf.contains( temp )) {
						count++;
					}
				}
				if (count != 0 && count > 15) {
					//System.out.println( "count:"+count+"  numberofkeys"+numberofkeys );
					count = ((count * 100) / numberofkeys);
					//System.out.println( templateName +":"+ count );
					templateMatchList.put( templateName, count );
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			session.close();
			sessionFactory.close();
			System.out.println( "CLOSE" );
		}

		return templateMatchList;

	}

}
