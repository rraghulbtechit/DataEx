package urjanet.devPortal.exception;

import play.Logger;

public class DevPortalException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4302158876955632116L;



	public DevPortalException() {
		super();
	}


	public DevPortalException(String msg) {
		
		super(msg);
		Logger.error(msg);
	}



	public DevPortalException(String msg, Throwable cause) {
		super(msg, cause);
	}


}
