package urjanet.devPortal.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
	public static String findSourceType(String fileContent) {
		Set<String> sourceTypeSet = new HashSet<String>();
		if (fileContent.contains("ContentType.PDF")) {
			sourceTypeSet.add("PDF");
		}
		if (fileContent.contains("ContentType.HTML_PDF")) {
			sourceTypeSet.add("HTML_PDF");
		}
		if (fileContent.contains("ContentType.CSV")) {
			sourceTypeSet.add("CSV");
		}
		if (fileContent.contains("ContentType.XLS")) {
			sourceTypeSet.add("XLS");
		}
		if (fileContent.contains("ContentType.XLSX")) {
			sourceTypeSet.add("XLSX");
		}
		if (fileContent.contains("ContentType.EDI")) {
			sourceTypeSet.add("EDI");
		}
		if (fileContent.contains("EdiPageSpecProvider")) {
			sourceTypeSet.add("EDI");
		}
		if (fileContent.contains("ContentType.SPREADSHEET_INTERVAL_DATA")) {
			sourceTypeSet.add("SPREADSHEET_INTERVAL_DATA");
		}
		if (fileContent.contains("HtmlPageSpecProvider")) {
			sourceTypeSet.add("HTML");
		}
		String htmlSourceType = getSourceType(fileContent, "XmlDataTarget");
		if (htmlSourceType != "" && !fileContent.contains("ContentType.CSV")
				&& !fileContent.contains("ContentType.XLS")
				&& !fileContent.contains("ContentType.XLSX")
				&& !fileContent.contains("ContentType.EDI")) {
			sourceTypeSet.add(htmlSourceType);
		}
		return joinString(sourceTypeSet);
	}

	public static String joinString(Set<String> inputSet) {
		StringBuffer sb = new StringBuffer();
		String prefix = "";
		for (String str : inputSet) {
			sb.append(prefix);
			prefix = ",";
			sb.append(str);
		}
		return sb.toString();
	}


	public static void extract(String log, String pattern,
			List<String> webAddresses) {

		Matcher m = Pattern.compile(pattern).matcher(log);

		while (m.find()) {
			String url = m.group();
			webAddresses.add(url);
		}

	}
	public static List<String> findURL(String fileContent) {
		List<String> webAddresses = new ArrayList<String>();

		extract(fileContent,
				"(?<=(SITE_)?URL\\s{0,5}\\=\\s{0,5}\\\")(.*)(?=\\\")",
				webAddresses);
		extract(fileContent,
				"(?<=(SITE_)?URL(_2)\\s{0,5}\\=\\s{0,5}\\\")(.*)(?=\\\")",
				webAddresses);

		return webAddresses;
	}

	private static String getSourceType(String file, String key) {

		String sourceType = "";
		Matcher m = Pattern.compile(
				"new\\s{0,5}" + key + "\\(\\s{0,5}[A-z]+\\.STATEMENT_TYPE_ID")
				.matcher(file);
		while (m.find()) {
			if (m.group().contains("XmlDataTarget")) {
				sourceType = "HTML";
			}
		}
		return sourceType;
	}

	public static String getFileContent(File templateFile) {

		BufferedReader reader = null;
		String wholeJavaFile = "";
		try {

			String line = "";

			reader = new BufferedReader(new FileReader(
					templateFile.getAbsolutePath()));

			while ((line = reader.readLine()) != null) {
				wholeJavaFile = wholeJavaFile + "\n" + line;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return wholeJavaFile;
	}

	public static String getServiceType(String file) {

		String serviceType = "";
		Set<String> services = new HashSet<String>();
		Matcher m = Pattern
				.compile(
						"(?<=(SERVICE_TYPE_ID.getValue\\(\\s{0,5}\\)\\s{0,5}\\)\\.setDefaultValue\\(\\s{0,5}DataValues\\.))[A-z]+(?=\\.getValue)")
				.matcher(file);
		while (m.find()) {
			services.add(m.group());
		}
		serviceType = joinString(services);
		return serviceType;
	}

	public static boolean getHistoricalTemplateStatus(String fileContent) {
		
		return fileContent.contains("HistoricalTemplateProvider");
	}
	
	public static boolean getStatementTrackingStatus(String fileContent) {
		
		return fileContent.contains("TRACKED_INVOICE_NUMBER_KEY")
				|| fileContent.contains("TRACKED_STATEMENT_DATE")
				||fileContent.contains("TRACKED_NEXT_BILL_STATEMENT_DATE")
				||fileContent.contains("TRACKED_TOTAL_BILL_AMOUNT")
				||fileContent.contains("TRACKED_STATEMENT_PERIOD_START_DATE_KEY")
				||fileContent.contains("TRACKED_STATEMENT_PERIOD_END_DATE_KEY")
				||fileContent.contains("TRACKED_STATEMENT_WEBSITE_KEY")
				||fileContent.contains("TRACKED_STATEMENT_WEBSITE_KEY2")
				||fileContent.contains("TRACKED_STATEMENT_WEBSITE_KEY3")
				||fileContent.contains("TRACKED_STATEMENT_WEBSITE_DATE_KEY");
	}
	
	public static boolean getAcctTrackingStatus(String fileContent) {

		return fileContent.contains("TRACKED_ACCOUNT_NUMBER_KEY")
				|| fileContent.contains("TRACKED_SUMMARY_ACCOUNT_NUMBER_KEY")
				||fileContent.contains("TRACKED_CUSTOMER_NUMBER_KEY")
				||fileContent.contains("TRACKED_POD_NUMBER_KEY")
				||fileContent.contains("TRACKED_ACCOUNT_WEBSITE_KEY")
				||fileContent.contains("TRACKED_ACCOUNT_WEBSITE_KEY2")
				||fileContent.contains("TRACKED_ACCOUNT_WEBSITE_KEY3");
	}
	
	public static boolean getTrackedLoginStatus(String fileContent) {
		
		return fileContent.contains("TrackLoginFailurePageSpec");
	}

}
