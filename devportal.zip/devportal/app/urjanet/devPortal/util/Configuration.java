package urjanet.devPortal.util;

import play.Play;

public class Configuration {

	public final static String HOST_BASE_URL = Play.application()
	.configuration().getString("host.base.url");
//	public final static String HOST_BASE = Play.application().configuration()
//	.getString("origin");
	public static final String GOOGLE_CLIENT_ID = Play.application()
	.configuration().getString("google.client.id");
	
	public static final String REPO_PATH_TEMPLATE = Play.application()
			.configuration().getString("repo.path.template");
	
	public static final String SLA_TIME_THRESHOLD = Play.application()
			.configuration().getString("sla.time.threshold");
	
	public static final String GOOGLE_CLIENT_SECRET = Play.application()
	.configuration().getString("google.client.secret");
//	public static final long CACHE_EXPIRY_MINUTES = Play.application()
//	.configuration().getLong("cache.expiry.minutes");
//	public static final String USER_XML = Play.application().configuration()
//	.getString("user.xml");
//	public static final String PROVIDER_XML = Play.application().configuration()
//	.getString("provider.xml");
//	public static final String MAX_LIMIT = Play.application().configuration()
//			.getString("daq.result.size.limit");
//	public static final  String DEV_MODE = Play.application().configuration()
//			.getString("dev.mode");
//	public static final String REPORT_HOME = Play.application().configuration()
//			.getString("report.home");
}
