package urjanet.devPortal.util;

public enum EngineerGroupKeys {
	
	DEVELOPER("dev");

	private final String value;

	private EngineerGroupKeys(String value) {
		this.value = value;
	}

	public String getValue(){
		return this.value;
	}
}
