package urjanet.devPortal.util;


public class Constants {
//
	public static final String GOOGLE_SCOPE = "https://www.googleapis.com/auth/userinfo.profile;https://www.googleapis.com/auth/userinfo.email";
	public static final String GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v1/userinfo";
//
//	public static final String USER_EMAIL = "userEmail";
//	public static final String ROLE = "role";
}
