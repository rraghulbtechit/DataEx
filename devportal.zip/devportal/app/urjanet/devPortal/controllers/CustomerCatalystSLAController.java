package urjanet.devPortal.controllers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.fasterxml.jackson.databind.node.ObjectNode;

import play.Logger;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Slainfo;
import urjanet.devPortal.service.HolidayList;
import urjanet.devPortal.util.Configuration;

@Transactional
public class CustomerCatalystSLAController extends Controller {

	// http://localhost:9000/devPortal/customer/sla/ecova/maintenance

	public Result returnSLAResult(String customerName, String catalystName) {

		ObjectNode resultObj = Json.newObject();
		ObjectNode devSlaObj = Json.newObject();
		ObjectNode qaSlaObj = Json.newObject();
		ObjectNode errorObj = Json.newObject();

		if (!customerName.isEmpty() && !catalystName.isEmpty()) {

			List holidays = HolidayList.getHolidayList();

			List<Object[]> devSlaObject = getSLARecordObject(catalystName, customerName, "Developer");
			List<Object[]> qaSlAObject = getSLARecordObject(catalystName, customerName, "QA");

			if (!devSlaObject.isEmpty() && !qaSlAObject.isEmpty()) {

				Calendar calendar = Calendar.getInstance();
				int devSlaDays = ((Slainfo) devSlaObject.get(0)[0]).getSlaDays();

				if (calendar.get(Calendar.HOUR_OF_DAY) > Integer.parseInt(Configuration.SLA_TIME_THRESHOLD)) {
					devSlaDays = devSlaDays + 1;
				}
				int qaSlaDays = devSlaDays + ((Slainfo) qaSlAObject.get(0)[0]).getSlaDays();

				String devDueDate = getDueDate(devSlaDays, holidays);
				String qaDueDate = getDueDate(qaSlaDays, holidays);

				if (!devDueDate.isEmpty() && !qaDueDate.isEmpty()) {

					devSlaObj.put("slaDays", ((Slainfo) devSlaObject.get(0)[0]).getSlaDays());
					devSlaObj.put("dueDate", devDueDate);
					resultObj.put("development", devSlaObj);

					qaSlaObj.put("slaDays", ((Slainfo) qaSlAObject.get(0)[0]).getSlaDays());
					qaSlaObj.put("dueDate", qaDueDate);
					resultObj.put("qa", qaSlaObj);

					return ok(resultObj);
				} else {

					errorObj.put("message", "Error in due date calculations");
					resultObj.put("error", errorObj);
					return internalServerError(resultObj);
				}
			} else {

				errorObj.put("message", "Record not available in table");
				resultObj.put("error", errorObj);
			}
			return notFound(resultObj);
		} else {

			errorObj.put("message", "Missing CustomerName or CatalystName");
			resultObj.put("error", errorObj);
			return badRequest(resultObj);

		}

	}

	private String getDueDate(int slaNumOfDays, List<String> holidays) {

		SimpleDateFormat fdate = new SimpleDateFormat("MM/dd/yyyy");
		Calendar calendar = Calendar.getInstance();

		while (slaNumOfDays > 0) {
			calendar.add(Calendar.DAY_OF_MONTH, 1);
			if (noWeekEndsorHolidays(calendar, holidays)) {
				slaNumOfDays--;
			}
		}
		return fdate.format(calendar.getTime());
	}

	private boolean noWeekEndsorHolidays(Calendar cal, List<String> holidays) {

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String calString = sdf.format(cal.getTime());

		int day = cal.get(Calendar.DAY_OF_WEEK);
		if (day == 1 || day == 7 || holidays.contains(calString)) {
			return false;
		}
		return true;
	}

	private List<Object[]> getSLARecordObject(String catalystName, String customerName, String engineerGroupName) {

		String devSlaDaysQuery = "from Slainfo result, Catalyst ca,  Customer cu,  Engineer ei "
				+ "where ca.catalystId=result.catalystId and cu.customerId=result.customerId "
				+ "and ei.EId=result.EId and ca.catalystName='" + catalystName + "' and cu.customerName='"
				+ customerName + "' " + "and ei.Name='" + engineerGroupName + "'";
		
		Logger.info("Quering SLA days for :" + engineerGroupName );
		
		List<Object[]> slaObject = JPA.em().createQuery(devSlaDaysQuery).getResultList();

		return slaObject;
	}

}
