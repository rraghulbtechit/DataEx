/**
 * 
 */
package urjanet.devPortal.controllers;

import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.TemplateUpdateProgess;
import play.libs.Json;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * @author balaji_rajaram
 *
 */
public class ProgressHandler extends Controller {
	
	
	TemplateUpdateProgess tup = new TemplateUpdateProgess();
	public Result progress() {
	    ObjectNode result = Json.newObject();
	    result.put("total", tup.getTotal());
	    result.put("progress", tup.getProgress());
	    result.put("templateName", tup.getTemplateName());
	    result.put("percentage", tup.getPercentage());
	    return ok(result);
	}
}
