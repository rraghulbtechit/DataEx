package urjanet.devPortal.controllers;

import play.Logger;
import play.mvc.Controller;
import play.mvc.Result;
//import urjanet.devPortal.domain.User;
import urjanet.devPortal.exception.DevPortalException;
import urjanet.devPortal.util.AuthHelper;

//import com.google.gson.Gson;

public class LoginController extends Controller {

	public Result login() {
		final AuthHelper helper = new AuthHelper();
		Logger.info("In login()");
		if (request().getQueryString("code") == null
				|| request().getQueryString("state") == null) {

			session("state", helper.getStateToken());
			String url = helper.buildLoginUrl();
			Logger.info(url);
			return ok(views.html.login.render(url));
		} else if (request().getQueryString("code") != null
				&& request().getQueryString("state") != null
				&& request().getQueryString("state").equals(
						session().get("state"))) {

			session("state", "");

			String user;
			try {
				user = helper.getUserInfoJson(request().getQueryString("code"));
			} catch (Exception e) {
				user = "";
				Logger.error(e.getMessage());
			}

			return ok(views.html.login.render(user));
		}
		return TODO;
	}

	public Result openIDCallback(String state, String code)
			throws DevPortalException {
		final AuthHelper helper = new AuthHelper();
		String user = "";
		Logger.info("In openIDCallback");
		// Gson gson = new Gson();
		try {
			user = helper.getUserInfoJson(request().getQueryString("code"));
			System.out.println("user: " + user);
			// if (isAuthenticated(gson.fromJson(user, User.class).getEmail()))
			// {
			// Logger.info("Role of the logged in user is "
			// + (session().get("role")));
			return redirect(getHomePage());
			// } else {
			// return ok();//views.html.notAuthorized.render(user));
			// }
		} catch (Exception e) {
			throw new DevPortalException(e.getMessage());
		}
	}

	private String getHomePage() {

		return "/devPortal/home";

	}

	public static boolean isAuthenticated(String userEmail) {

		return true;
	}
}