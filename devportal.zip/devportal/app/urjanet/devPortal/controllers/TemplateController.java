package urjanet.devPortal.controllers;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.lib.Repository;
import org.hibernate.Session;

import com.fasterxml.jackson.databind.node.ObjectNode;

import play.Logger;
import play.data.Form;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Country;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.service.GitLogStatService;
import views.html.templateCountryInfo;
import views.html.updateCountryInfo;

@Transactional
public class TemplateController extends Controller {
	public Result index() {

		String hql = "from Country";
		List<Country> countryList = JPA.em().createQuery(hql).getResultList();
		Logger.info("In TemplateController.index().  Country list size:" + countryList.size());

		hql = "from Template as tl where tl.templateName like '%TemplateProvider%'";
		List<Template> template = JPA.em().createQuery(hql).getResultList();

		Logger.info("In TemplateController.index().  Tempalte list size:" + template.size());

		return ok(templateCountryInfo.render(countryList, template));

	}

	public Result updateTemplateList() throws IOException, NoHeadException, GitAPIException {
		Logger.info("In TemplateController.updateTemplateList(). ");

		GitLogStatService service = new GitLogStatService();
		Session s = (Session) JPA.em().getDelegate();
		StringBuilder sb = new StringBuilder();
		int i = 0;
		File templateDirectory = new File("/opt/templates/templates/src/main/java/urjanet/pull/template");
		File[] flist1 = templateDirectory.listFiles();
		for (File file : flist1) {
			Logger.info(file.getName());
			if (file.getName().endsWith("TemplateProvider.java")) {
				String hql = "from Template as tl where tl.templateName  ='" + file.getName() + "'";
				List<Template> template = JPA.em().createQuery(hql).getResultList();
				if (template != null && template.size() > 0) {
					continue;
				} else {

					i++;
					String author = service.getTemplateAuthor(file.getName());
					sb.append(file.getName() + "," + author + "\n");
					Template temp = new Template();
					temp.setTemplateAuthor(author);
					temp.setTemplateName(file.getName());

					s.saveOrUpdate(temp);
				}
			}
		}
		return ok(i + " is the number to be updated yet " + sb.toString());
	}
	
	/**
	 * 
	 * @deprecated  This post request method is not used now. So deprecated </br>
	 *              use {getTemplateOwnerData(String templateName)} instead of this getTemplate() </br>
	 * 
	 */
	@Deprecated
	public Result getTemplate() {

		String templateName = Form.form().bindFromRequest().get("templateName");
		String hql = "from Template as tl where tl.templateName='" + templateName + ".java'";
		List<Template> templateList = JPA.em().createQuery(hql).getResultList();
		ObjectNode result = Json.newObject();

		if (templateList.size() == 1) {
			Template template = templateList.get(0);

			result.put("Template Name", template.getTemplateName().replace(".java", ""));
			result.put("Template Audit Owner", template.getTemplateAuditOwner());
			result.put("Template Author", template.getTemplateAuthor());
			result.put("Template Author1", template.getTemplateAuthor1());
			result.put("Template Author2", template.getTemplateAuthor2());
			result.put("Template Author3", template.getTemplateAuthor3());

		} else if (templateList.size() > 1) {
			result.put("Template Name", "More one template found");
		} else {
			result.put("Template Name", "Not Found");
		}

		return ok(result);
	}

	// Eg URL:
	// http://localhost:9000/devPortal/assignee/CityOfBloomingtonMNTemplateProvider
	public Result getTemplateOwnerData(String templateName) {

		if (templateName.contains(".java")) {
			templateName = templateName.replace(".java", "");
		}

		String hql = "from Template as tl where tl.templateName='" + templateName + ".java'";
		List<Template> templateList = JPA.em().createQuery(hql).getResultList();
		ObjectNode result = Json.newObject();

		if (!templateName.isEmpty()) {

			if (templateList.size() == 1) {
				Template template = templateList.get(0);

				result.put("templateName", template.getTemplateName().replace(".java", ""));
				result.put("auditAnalyst", template.getTemplateAuditOwner());
				result.put("templateOwner", template.getTemplateAuthor());
				result.put("templateAuthor1", template.getTemplateAuthor1());
				result.put("templateAuthor2", template.getTemplateAuthor2());
				result.put("templateAuthor3", template.getTemplateAuthor3());
				return ok(result);

			} else if (templateList.size() > 1) {

				result.put("message", "More than one template found");
				return internalServerError(result);
			} else {

				result.put("message", "Record not available in table");
				return notFound(result);
			}

		} else {

			result.put("message", "Missing Template Name");
			return badRequest(result);
		}
	}

}
