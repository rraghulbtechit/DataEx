package urjanet.devPortal.controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;

import play.Logger;
import play.data.Form;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Country;
import urjanet.devPortal.domain.Template;

import views.html.countryList;
import views.html.templateList;
import views.html.updateCountryInfo;

/**
 * @author balaji_rajaram
 * 
 */
@Transactional
public class TemplateCountryInfoController extends Controller {

	public Result updateCountryInfo() {

		String templateName = Form.form().bindFromRequest().get("templateName");
		String countryCode = Form.form().bindFromRequest().get("countryId");
		List<String> listNotFound = new ArrayList<String>();
		try {
			String resp = updateCountryInfo(templateName, countryCode,
					listNotFound);
		} catch (Exception e) {
			e.printStackTrace();
			return ok("Something went wrong :(");
		}

		return ok("SUCCESS");
	}
	@Deprecated
	public Result updateCountry() {
		File countryFile = new File("/home/shobaekiri/countryInfo.csv");
		List<String> listNotFound = new ArrayList<String>();
		BufferedReader br = null;
		String line = "";
		// String cvsSplitBy = ",";
		try {

			br = new BufferedReader(new FileReader(countryFile));
			while ((line = br.readLine()) != null) {

				String[] idArray = line.split(",");
				System.out.println(idArray[0]);
				for (int i = 1; i < idArray.length; i++) {
					System.out.println(idArray[i] + " is the country");
					updateCountryInfo(idArray[0], idArray[i], listNotFound);
				}

			}
			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	
		Logger.info("listNotFound size is" + listNotFound.size());
		StringBuilder str = new StringBuilder();
		for (String list : listNotFound) {
			System.out.println(list);
			str.append(list + "\n");

		}

		return ok(str.toString());
	}

	public String updateCountryInfo(String templateName, String countryCode,
			List<String> listNotFound) {
		String retValue = "";
		String hql = "from Template as tl where tl.templateName='"
				+ templateName + ".java'";

		Session s = (Session) JPA.em().getDelegate();
		if (JPA.em().createQuery(hql).getResultList() != null
				&& JPA.em().createQuery(hql).getResultList().size() > 0) {
			Template template = (Template) JPA.em().createQuery(hql)
					.getResultList().get(0);

			System.out.println(template.toString());

			hql = "from Country as cc where cc.countryCode='" + countryCode
					+ "'";
			if (JPA.em().createQuery(hql).getResultList() != null
					&& JPA.em().createQuery(hql).getResultList().size() > 0) {

				Country country = (Country) JPA.em().createQuery(hql)
						.getResultList().get(0);

				Set<Country> countries = template.getCountries();
				for (Country co : countries) {
					if (co.getCountryCode().equals(countryCode)) {
						retValue = "Already Exist";
					}
				}

				countries.add(country);

				template.setCountries(countries);
				System.out.println(template.getCountries().size()
						+ " is the size of the country");
				s.saveOrUpdate(template);
			}
		} else {
			Logger.info("Template not found : " + templateName);
			listNotFound.add(templateName);
		}

		return retValue;
	}

	public Result index() {
		Logger.info("In TemplateCountryInfoController.index()");
		String hql = "from Country";
		List<Country> countryList = JPA.em().createQuery(hql).getResultList();
		Logger.info(countryList.size() + ">>Country size");

		hql = "from Template as tl where tl.templateName like '%TemplateProvider%'";
		List<Template> template = JPA.em().createQuery(hql).getResultList();
		Logger.info(template.size() + ">>template size");

		return ok(updateCountryInfo.render(countryList, template));
	}

	public Result listAllTemplateNeedingCountryInfo() {
		Logger.info("In TemplateCountryInfoController.listAllTemplateNeedingCountryInfo()");
		String hql = "select t from Template as t  left join t.countries tc group by t having count(tc) = 0 order by t.templateName";
		List<Template> templateList = JPA.em().createQuery(hql).getResultList();
		Logger.info(templateList.size() + ">>template size");
		StringBuilder sb = new StringBuilder();
		int i = 1;
		for (Template temp : templateList) {
			sb.append(i + ". " + temp.getTemplateName() + " \n ");

			i++;
		}
		return ok(sb.toString());

	}	
	
	public Result displayTemplateCountries() {
		Logger.info("In TemplateCountryInfoController.displayTemplateCountries()");
		 String templateName =  Form.form().bindFromRequest().get( "temp" );
		
		String hql = "from Template where templateName='"+templateName+".java'" ;
		 
		List<Template> tls =   JPA.em().createQuery(hql ).getResultList();
		Logger.info(tls.get( 0 ).getTemplateId().toString());
       return ok(countryList.render(tls));
   }

	public Result displayTemplates() {
		Logger.info("In TemplateCountryInfoController.displayTemplates()");
		
		 String countryCode =  Form.form().bindFromRequest().get( "country" );
		
		String hql = " select t from Template as t  left join t.countries tc  where tc.countryId=(select  countryId from Country c where c.countryCode='"+countryCode+"') order by t.templateName" ;
		 
		List<Template> cls =  JPA.em().createQuery( hql ).getResultList();
		Logger.info(String.valueOf(cls.size()));
       return ok(templateList.render(cls,countryCode));
   }
	
	
}
