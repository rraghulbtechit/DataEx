/**
 * 
 */
package urjanet.devPortal.controllers;

import org.hibernate.Session;
import org.hibernate.Transaction;

import play.data.Form;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Country;
import views.html.addCountry;

/**
 * @author balaji_rajaram
 *
 */
@Transactional
public class AddCountry extends Controller{
	
	public Result update() {
		Transaction ts=null;
		String countryName =  Form.form().bindFromRequest().get( "countryName" );
		String countryCode =  Form.form().bindFromRequest().get( "countryCode" );
		
		Country country = new Country();
		country.setCountryCode( countryCode );
		country.setCountryName( countryName );
		
		try{
			Session s =(Session)JPA.em().getDelegate();
			s.save( country );
		
		}catch(Exception e){
			
		}
		
		
		return ok(countryName+"-"+countryCode+" Added");
    }
	
	
	
	public Result index() {
       return ok(addCountry.render());
   }
}
