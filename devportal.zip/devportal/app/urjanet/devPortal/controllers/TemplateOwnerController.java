package urjanet.devPortal.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import play.Logger;
import play.data.Form;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Template;
import views.html.templateOwner;

@Transactional
public class TemplateOwnerController extends Controller{
	
	public Result index() {   
		String hql = "from Template as tl where tl.templateName like '%TemplateProvider%'" ;
		List<Template> template =   JPA.em().createQuery(hql ).getResultList();
		
		Logger.info("In TemplateCOwnerontroller.index().  Tempalte list size:"+template.size());
		
		hql = "select distinct templateOwner from Template ";
		List<String> owners = JPA.em().createQuery(hql ).getResultList();

		Logger.info("In TemplateOwnerontroller.index(). Tempalte list size:"+template.size() + " Owners list: "+owners.size());
		return ok(templateOwner.render(template, owners));
    
 }
	public Result updateTemplateOwner() {  
	
	String templateName = Form.form().bindFromRequest().get("templateName");
	String templateOwner = Form.form().bindFromRequest().get("templateOwner");
	
	try {
		String hql = "from Template as tl where tl.templateName='"
				+ templateName + ".java'";

		Session s = (Session) JPA.em().getDelegate();
		if (JPA.em().createQuery(hql).getResultList() != null
				&& JPA.em().createQuery(hql).getResultList().size() > 0) {
			Template template = (Template) JPA.em().createQuery(hql)
					.getResultList().get(0);

				template.setTemplateOwner(templateOwner);
				
				s.saveOrUpdate(template);
			}
		
	} catch (Exception e) {
		e.printStackTrace();
		return ok("Something went wrong :(");
	}

	return ok("SUCCESS");

}
	
}

