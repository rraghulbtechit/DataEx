package urjanet.devPortal.controllers;

import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.service.GitLogStatService;

@Transactional
public class TemplateHealthController extends Controller {

	public Result updateGitInfo(String fromDate, String toDate) {
		GitLogStatService service = new GitLogStatService();
		service.updateMaster();
		service.getGitStats(fromDate, toDate);

		return ok("Template commit stats are captured!");

	}

}
