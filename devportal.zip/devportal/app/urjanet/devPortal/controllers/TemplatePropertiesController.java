/**
 * 
 */
package urjanet.devPortal.controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import play.Logger;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplateProperties;
import urjanet.devPortal.domain.TemplateUpdateProgess;
import views.html.updateTemplateMatcherProps;
import views.html.reDirect;
/**
 * @author balaji_rajaram
 *
 */

@Transactional
public class TemplatePropertiesController extends Controller{
	

	static ArrayList<TemplateProperties> tpList = new ArrayList<TemplateProperties>();
	static int increment = 0;
	
	public Result index(){
		
		return ok(updateTemplateMatcherProps.render());
	}

	public Result extract() {

		Session session = null;

		String path = "/opt/templates/templates/src/main/java/urjanet/pull/template";
		File folder = new File( path );
		File[] listOfFiles = folder.listFiles();
		try {
			session = (Session)JPA.em().getDelegate();
			
			SQLQuery query = session.createSQLQuery("delete from TemplateProperties");
			query.executeUpdate();
			Logger.info("All rows in TemplateProperties are deleted");
			 int noOfFiles = listOfFiles.length;
			
			TemplateUpdateProgess.setTotal(noOfFiles);
			for (int i = 0; i < noOfFiles; i++) {

				if (listOfFiles[(int) i].isFile() ) {
					String templateName = listOfFiles[(int) i].getName();
					String hql = "from Template as tl where tl.templateName='"+ templateName + "'";
					List<Template> templateObjList = session.createQuery(hql).list();
					TemplateUpdateProgess.setTemplateName(templateName);
					TemplateUpdateProgess.setProgress(i);
					Double percent=((double)(i+1)/(double)noOfFiles)*100;
					TemplateUpdateProgess.setPercentage(percent.intValue());
					if(templateObjList.size()==1){
						
						Template tid  = (Template)templateObjList.get(0);
						Logger.info(tid.getTemplateName() + "already exists");
						updateProps(i, session, listOfFiles, tid);
						
						
					}else{
						
						System.out.println( "Template New" + templateName);
						Template tid  = new Template();
						tid.setTemplateName(templateName);
						session.save(tid);
						Logger.info("Template is new , so Persisting :" + templateName);
						updateProps(i, session, listOfFiles, tid);
						
					}
				}
						
			}
					
		}
		catch (Exception e) {

			Logger.error(e.getMessage());
		} 
		
		TemplateUpdateProgess.setTemplateName("");
		TemplateUpdateProgess.setProgress(0);
		TemplateUpdateProgess.setPercentage(0);
		return ok(reDirect.render());
	}

	private static void extract(String log, String pattern, ArrayList<String> wordlist) {

		Matcher m = Pattern.compile( pattern ).matcher( log );

		while (m.find()) {
			String temp = m.group();
			wordlist.add( temp );
		}

	}

	private static String extractFirst(String pattern, String word) {

		Matcher m = Pattern.compile( pattern ).matcher( word );

		if (m.find()) {

			return m.group();
		}
		return "";
	}

	private static ArrayList<String> unique(ArrayList<String> countryList) {

		ArrayList<String> uniquelist = new ArrayList<String>();
		HashSet<String> uniqueValues = new HashSet<String>( countryList );
		for (String value : uniqueValues) {
			uniquelist.add( value );
		}

		return uniquelist;
	}
	
	private static void updateProps(int i,Session session,File[] listOfFiles,Template template) throws Exception{
		
		ArrayList<String> wordList = new ArrayList<String>();
		String wholeJavaFile = "";
		String line = null;
		
		
		BufferedReader reader = new BufferedReader( new FileReader( listOfFiles[(int) i].getAbsolutePath() ) );

		while ((line = reader.readLine()) != null) {
			wholeJavaFile = wholeJavaFile + "\n" + line;
		}
		extract( wholeJavaFile, "(Charges|StringKey|Group)\\s*\\(\\s*\\\"(\\w{1,20}\\W{0,3}\\s?){1,6}\\\".*\\)", wordList );
		
		
		for (String value : wordList) {
			if(value.indexOf( "PROXIMITY" )>0){
				String temp=extractFirst( "\\\"(\\w{1,20}\\W{0,3}\\s?){1,6}\\\"", value ).replaceAll( "\\\"|,", "" );
				String[] splitedword= temp.split( "\\s" );
				for(String eword:splitedword){
					increment++;
					TemplateProperties tp = new TemplateProperties();
					tp.setTempId( template );
					tp.setId( increment );
					tp.setFilterString( eword );
					session.save( tp );
				}
				
			}else{
				increment++;
				TemplateProperties tp = new TemplateProperties();
				tp.setTempId( template );
				tp.setId( increment );
				tp.setFilterString( extractFirst( "\\\"(\\w{1,20}\\W{0,3}\\s?){1,6}\\\"", value ).replaceAll( "\\\"|,", "" ));
				session.save( tp );
			}

		}
		session.save(template);
		Logger.info( "TemplateProperties Presisted");


	}
	


}
