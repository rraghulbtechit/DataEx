package urjanet.devPortal.controllers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;

import org.apache.commons.io.FileUtils;
import org.hibernate.Session;

import play.Logger;
import play.data.Form;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplatePerformanceIndicator;
import urjanet.devPortal.domain.TemplateProperties;
import urjanet.devPortal.domain.TemplateUrlMatchResult;
import urjanet.devPortal.domain.WebAddress;
import urjanet.devPortal.service.TemplatePDFMatcher;
import urjanet.devPortal.service.JiraLookupService;
import urjanet.devPortal.service.PdfFileFeed;
import urjanet.devPortal.service.TemplateUrlMatcher;
import urjanet.devPortal.util.Util;
import views.html.jiraAnalysis;
import views.html.result;
import views.html.templateMatcher;
import views.html.templateUrlList;

/**
 * @author balaji_rajaram
 * 
 */
@Transactional
public class TemplateMatchController extends Controller {
	
	private static final String SHELL_SCRIPT = "/opt/urjanet_infra/bin/classRunner.sh";
	private static final String pattern = "\\[woot\\].*(\n.*)+\\[\\/woot\\]";
	private static final String MAIN_CLASS = "urjanet.think.update.development.DevelopmentUpdateRunner";

	public Result display() {
		Logger.info("In TemplateMatchController.display()");
		return ok(templateMatcher.render());
	}

	public Result analyzeJiraTicket() {
		Logger.info("In TemplateMatchController.analyzeJiraTicket()");
		List<TemplateUrlMatchResult> listReturned = new ArrayList<TemplateUrlMatchResult>();
		String jiraIds = Form.form().bindFromRequest().get("jiraIds");
		String[] ids = jiraIds.split(",");
		JiraLookupService lookupService = new JiraLookupService();
		for (String id : ids) {

			TemplateUrlMatchResult result = new TemplateUrlMatchResult();
			result.setTicketId(id);
			String url = lookupService.getWebAddress(id);
			Logger.info(url + "is the url in the ticket");
			if (url != null) {

				result.setUrlInTicket(url);
				List<Template> tempList = TemplateUrlMatcher.getTemplatesWithGivenUrl(url.trim());

				result.setTemplatesMatched(tempList);
				result.setMatchSize(tempList.size());
			}

			listReturned.add(result);
		}
		return ok(jiraAnalysis.render(listReturned));

	}

	public Result urlMatcher() {

		String url = Form.form().bindFromRequest().get("url");

		return ok(templateUrlList.render(TemplateUrlMatcher.getTemplatesWithGivenUrl(url.trim())));

	}

	
	public Result updateTemplateUrlInfo() {
		Session s = (Session) JPA.em().getDelegate();
		// Iterate through the template directory
		File templateDirectory = new File(
				"/opt/templates/templates/src/main/java/urjanet/pull/template");
		File[] templates = templateDirectory.listFiles();
		List<String> urls = null;
		boolean isStatementTrackingImplemented = false;
		boolean isAcctTrackingImplemented = false;
		boolean isTrackedLoginImplemented = false;
		boolean isHistoricalTemplateImplemented = false;
		String serviceType = "";
		String sourceType = "";
		for (File templateFile : templates) {
			if (templateFile.isFile()) {
				Set<WebAddress> addresses = new HashSet<WebAddress>();
				String fileContent = Util.getFileContent(templateFile);
				urls = Util.findURL(fileContent);
				
				isHistoricalTemplateImplemented = Util.getHistoricalTemplateStatus(fileContent);
				
				isStatementTrackingImplemented = Util.getStatementTrackingStatus(fileContent);

				isAcctTrackingImplemented = Util.getAcctTrackingStatus(fileContent);

				isTrackedLoginImplemented = Util.getTrackedLoginStatus(fileContent);
				
				serviceType = Util.getServiceType(fileContent);

				sourceType = Util.findSourceType(fileContent);

				for (String url : urls) {
					String hql1 = "from WebAddress as wa where wa.webAddress  ='"
							+ url + "'";
					List<WebAddress> addressResults = JPA.em()
							.createQuery(hql1).getResultList();

					WebAddress addrExisting = null;
					if (!addressResults.isEmpty()) {

						addrExisting = addressResults.get(0);
					}

					if (addrExisting != null) {
						addresses.add(addrExisting);

					} else {
						WebAddress addr = new WebAddress();
						addr.setWebAddress(url);
						s.saveOrUpdate(addr);
						addresses.add(addr);
					}
				}
				String hql = "from Template as t where t.templateName  ='"
						+ templateFile.getName() + "'";

				List<Template> tempList = JPA.em().createQuery(hql)
						.getResultList();
				Template temp = null;
			
				if (!tempList.isEmpty()) {

					temp = tempList.get(0);

					temp.setServiceType(serviceType);
					temp.setSourceType(sourceType);
					temp.setStatementTrackingImplemented(isStatementTrackingImplemented);
					temp.setAcctTrackingImplemented(isAcctTrackingImplemented);
					temp.setTrackedBadLoginImplemented(isTrackedLoginImplemented);
					temp.setHistoricalTemplateImplemented(isHistoricalTemplateImplemented);
					for (WebAddress addr1 : addresses) {
						temp.getWebAddresses().add(addr1);
					}
				} else {
					temp = new Template();
					temp.setTemplateName(templateFile.getName());
					temp.setWebAddresses(addresses);
					temp.setAcctTrackingImplemented(isAcctTrackingImplemented);
					temp.setTrackedBadLoginImplemented(isTrackedLoginImplemented);
					temp.setServiceType(serviceType);
					temp.setSourceType(sourceType);
					temp.setHistoricalTemplateImplemented(isHistoricalTemplateImplemented);
					temp.setStatementTrackingImplemented(isStatementTrackingImplemented);
				}
				s.saveOrUpdate(temp);
			}
		}

		return ok();
	}
	
	public Result matcher() throws IOException{
	
		HashMap<String, ArrayList<TemplateProperties>> templateList = new HashMap<String, ArrayList<TemplateProperties>>();
		List<TemplatePerformanceIndicator> templatePerformanceIndicator = null;
		Map<String, Integer> templateWithRank = new HashMap<String, Integer>();

		Logger.info("In TemplateMatchController: matcher()");
		templateList.clear();
		Calendar calendar = Calendar.getInstance();
		String timeStamp = new SimpleDateFormat("dd-MM-yyyy-HH:mm").format(calendar.getTime());

		final Http.MultipartFormData body = request().body()
				.asMultipartFormData();
		final Http.MultipartFormData.FilePart fileFromBody = body
				.getFile("fileToUpload");

		final File inputFile = fileFromBody.getFile();

		String threshold = Form.form().bindFromRequest().get("threshold");
		EntityManager em = JPA.em();

		PdfFileFeed pff = new PdfFileFeed();
		TemplatePDFMatcher matcher = new TemplatePDFMatcher();
		String pdfFeed = pff.getPdfContent(inputFile);
		
		FileInputStream fileInputStream = new FileInputStream(inputFile);
		new File("/tmp/devportal/").mkdir();
		File file = new File("/tmp/devportal/"+timeStamp);
		if (!file.exists()) {
	        if (file.mkdir()) {
	            Logger.info("Directory is created!");
	        } else {
	        	Logger.info("Failed to create directory!");
	        }
		}
		
		File saveFile = new File(file.getAbsolutePath()+"/temp.pdf"); // saving input file to /tmp/devportal/timestamp folder
		OutputStream out=new FileOutputStream(saveFile);
			   byte buf[]=new byte[1024];
			   int len;
			   while((len=fileInputStream.read(buf))>0)
			   out.write(buf,0,len);
			   out.close();
			   fileInputStream.close();
			
		templatePerformanceIndicator = matcher.findMatch(em, templateList, pdfFeed,saveFile,threshold);		
		Collections.sort(templatePerformanceIndicator);
		
		List<TemplatePerformanceIndicator > thresholdTemplateList = templatePerformanceIndicator.subList(1, Integer.parseInt(threshold)+1);
		
		return ok(result.render(evaluateDataPoints(thresholdTemplateList,saveFile)));
	}

	private Map<String, Integer> evaluateDataPoints(List<TemplatePerformanceIndicator > thresholdTemplateList,File inputFile) throws IOException {
			
		Map<String,Integer> templateWithDataPoints = new HashMap<String,Integer>();
	
	    Matcher match;
	    String woot;
	    String directoryPath = inputFile.getParentFile().getAbsolutePath();
	    System.out.println(thresholdTemplateList);
	    
		    for (TemplatePerformanceIndicator name:thresholdTemplateList){
		    	
		    	String template = name.getTemplateName().substring(0, name.getTemplateName().lastIndexOf("."));	    	

		    	int dataPoints=0;
		        String[] command = { SHELL_SCRIPT,MAIN_CLASS,"-t "+template," -c 2=1 ","-d "+directoryPath };         
		       
		    	    ProcessBuilder pb = new ProcessBuilder(command);
		    	    pb.redirectOutput(new File(directoryPath+"/"+template+".txt"));
		    	    Process process = pb.start();
		    	    System.out.println(template+" template started");
			    	    try {
							process.waitFor();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
		    	    
		    	    System.out.println("completed");
		    	    String content = FileUtils.readFileToString(new File(directoryPath+"/"+template+".txt"), "UTF-8");	
		    	    match = Pattern.compile(pattern).matcher(content);
		
					    if (match.find()) {
					    	woot = match.group();
							System.out.println("Data points found "+(woot.split("\r?\n").length));
							dataPoints = woot.split("\r?\n").length;
						}	
					    else {
					    	System.out.println("woot not found");
					    }
					    
					templateWithDataPoints.put(template, dataPoints);
		    	}
		    		    	
			return  (HashMap<String, Integer>) templateWithDataPoints;
	
	}

}
