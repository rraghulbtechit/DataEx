package urjanet.devPortal.controllers;

import java.util.List;


import play.Logger;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.mvc.Controller;
import play.mvc.Result;
import urjanet.devPortal.domain.Country;
import urjanet.devPortal.domain.Template;
import views.html.homePage;
import views.html.main;
import views.html.homeUrl;
import views.html.homeCountry;

@Transactional
public class HomeController extends Controller {

	public Result displayHome() {

		String hql = "from Template as tl where tl.templateName like '%TemplateProvider%'";
		List<Template> template = JPA.em().createQuery(hql).getResultList();

		return ok(homePage.render(template));
	}

	public Result displayHomeUrl() {

		String hql = "from Template";
		List<Template> templates = JPA.em().createQuery(hql).getResultList();
		return ok(homeUrl.render(templates));
	}

public Result displayHomeCountry() {

	String hql = "from Template as tl where tl.templateName like '%TemplateProvider%'";

	List<Template> tls = JPA.em().createQuery(hql).getResultList();
	Logger.info("In displayAllTemplateCountries: Template list size: "
			+ tls == null ? "0" : String.valueOf(tls.size()));
	hql = "from Country";

	List<Country> cls = JPA.em().createQuery(hql).getResultList();
	Logger.info("In displayAllTemplateCountries: countrt list size: " + cls == null ? "0"
			: String.valueOf(cls.size()));
	return ok(homeCountry.render(tls, cls.size()));

}
}
