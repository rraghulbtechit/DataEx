package urjanet.devPortal.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

import play.Logger;

public class PdfFileFeed {

	public String getPdfContent(File input) {
		Logger.info("In PdfFileFeed: getPdfContent() ");
		File output = new File( "/tmp/new.txt" );
		String line;
		String wholePdf = "";
         PDDocument pd;		
         BufferedWriter wr;
         
         try{
         
	         pd = PDDocument.load(input);
	         PDFTextStripper stripper = new PDFTextStripper();
	         wr=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output)));
	         stripper.writeText( pd, wr );
	         stripper.writeText(pd, wr);
	         if (pd != null) {
	             pd.close();
	         }
	        wr.close();
	         BufferedReader pdfReader = new BufferedReader(new FileReader("/tmp/new.txt"));
	     	while((line=pdfReader.readLine())!=null){
	     		
	     		 wholePdf= wholePdf+"\n"+line;
	     		 
	     	}
		
		} catch (Exception e) {
			Logger.error(e.getMessage());
		}

		return wholePdf;
		
	}
}
