package urjanet.devPortal.service;

import java.util.List;

import play.Logger;
import play.db.jpa.JPA;
import urjanet.devPortal.domain.Template;

public class TemplateUrlMatcher {
	public static List<Template> getTemplatesWithGivenUrl(String url) {
		Logger.info("Given url is " + url);
		String hql = "";
		List<Template> result;
		if (url.contains("http") || url.contains("www")
				|| url.contains("https")) {
			hql = "select t from Template as t  left join t.webAddresses tw  where tw.webAddressId=(select  webAddressId from WebAddress w where w.webAddress='"
					+ url + "') order by t.templateName";
			result = JPA.em().createQuery(hql).getResultList();
			if (result != null && result.size() > 0) {
				return result;
			}

			url = getHost(url);
			Logger.info(url + "is the new url being searched");
		}

		hql = "select t from Template as t left join t.webAddresses tw  where tw.webAddressId in (select webAddressId from WebAddress w where w.webAddress like '%"
				+ url + "%') order by t.templateName";

		return JPA.em().createQuery(hql).getResultList();
	}

	public static String getHost(String url) {
		if (url == null || url.length() == 0)
			return "";

		int doubleslash = url.indexOf("//");
		if (doubleslash == -1)
			doubleslash = 0;
		else
			doubleslash += 2;

		int end = url.indexOf('/', doubleslash);
		end = end >= 0 ? end : url.length();

		int port = url.indexOf(':', doubleslash);
		end = (port > 0 && port < end) ? port : end;

		return url.substring(doubleslash, end);
	}

	public static String getBaseDomain(String url) {
		String host = getHost(url);

		int startIndex = 0;
		int nextIndex = host.indexOf('.');
		int lastIndex = host.lastIndexOf('.');
		while (nextIndex < lastIndex) {
			startIndex = nextIndex + 1;
			nextIndex = host.indexOf('.', startIndex);
		}
		if (startIndex > 0) {
			return host.substring(startIndex);
		} else {
			return host;
		}
	}

}
