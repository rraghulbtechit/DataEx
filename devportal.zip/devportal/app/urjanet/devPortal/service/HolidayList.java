package urjanet.devPortal.service;

import java.util.List;

import play.Logger;
import play.db.jpa.JPA;

public class HolidayList extends Thread {

	@Override
	public void run() {
		
		getHolidayList();
	}
	
	public static List getHolidayList() {
		
		Logger.info("Fetching holidays list from DB..!");
		
		String holidayQuery = "from Holidays";
		List indiaHolidays = JPA.em().createQuery(holidayQuery).getResultList();

		return indiaHolidays;
	}
	
}
