package urjanet.devPortal.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import play.Logger;

import com.atlassian.jira.rest.client.JiraRestClient;
import com.atlassian.jira.rest.client.JiraRestClientFactory;
import com.atlassian.jira.rest.client.domain.Issue;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.atlassian.util.concurrent.Promise;

public class JiraLookupService {
	private JiraRestClient client = null;
	private Issue issue = null;
	private String jiraUrl = "http://chn-proxy.urjanet.net/jira";
	private String jiraUser = "autobuild";
	private String jiraPwd = "r3n3w@bl3";

	public JiraLookupService() {
		try {

			URI uri = new URI(jiraUrl);

			JiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();
			client = factory.createWithBasicHttpAuthentication(uri, jiraUser,
					jiraPwd);

		} catch (URISyntaxException e) {
			Logger.error(e.getMessage());
		}

	}

	public String getWebAddress(String ticketId) {
		Promise<com.atlassian.jira.rest.client.domain.Issue> promise = client
				.getIssueClient().getIssue(ticketId);
		issue = promise.claim();

		String desc = issue.getDescription();

		String[] lines = desc.split("\n");

		String urlRegex = "((https?|www)[:((//)|(\\\\))]*[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
		Pattern pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);

		for (String line : lines) {
			Matcher urlMatcher = pattern.matcher(line);

			while (urlMatcher.find()) {
				return line.substring(urlMatcher.start(0), urlMatcher.end(0));
			}

		}

		return null;
	}

}
