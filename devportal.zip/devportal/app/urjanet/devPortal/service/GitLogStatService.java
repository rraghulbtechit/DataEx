package urjanet.devPortal.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;

import play.Logger;
import play.db.jpa.JPA;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplateCommitHistory;
import urjanet.devPortal.domain.TemplateCommitHistoryPK;
import urjanet.devPortal.util.Configuration;

public class GitLogStatService extends Thread {

	String projectPath = Configuration.REPO_PATH_TEMPLATE;

	public String getTemplateAuthor(String fileName) throws NoHeadException,
			GitAPIException, IOException {
		Logger.info("Filename sent: " + fileName);
		Git git = Git.open(new File("/opt/templates"));
		Repository repo = git.getRepository();
		String relativeFileName = "/templates/src/main/java/urjanet/pull/template/"
				+ fileName;
		Logger.info("Relative file name: " + relativeFileName);
		Iterable<RevCommit> logs = git.log()

		.addPath(relativeFileName).call();

		String recentAuthor = "";
		RevCommit oldest = null;
		Iterator<RevCommit> i = logs.iterator();
		if (i.hasNext()) {
			oldest = i.next();
			recentAuthor = oldest.getAuthorIdent().getEmailAddress();
		}
		Logger.info("Author :" + recentAuthor);
		return recentAuthor;

	}

	void runShell(String command, File runPath) {
		runShell(command, runPath, false);
	}

	void runShell(String command, File runPath, boolean storeData) {

		try {
			Process proc = Runtime.getRuntime().exec(command, null, runPath);
			proc.waitFor();

			if (storeData) {
				BufferedReader read = new BufferedReader(new InputStreamReader(
						proc.getInputStream()));

				String line = read.readLine();
				while (read.ready()) {

					// The new commit begins only when the log starts with
					// "commit ".Skipping the empty lines we get.
					while (!line.startsWith("commit ") && line != null) {
						line = read.readLine();
					}
					// CommitId.
					String commitId = line
							.substring(line.lastIndexOf("commit") + 8);
					commitId = commitId.trim();

					// Author
					line = read.readLine();
					String author = getAuthor(line);

					// Commit date.
					line = read.readLine();

					Date date = getCommitDate(line);

					// skipping 2 lines, as we are not concerned about commiter
					// and commiter date, as we have already obtained in author
					// and AuthorDate:
					read.readLine();
					read.readLine();

					// Considering each line as message until we encounter the
					// line starting with "templates" and ending with ".java"
					String message = "";
					while ((line = read.readLine()) != null
							&& !line.startsWith("templates")
							&& !line.endsWith(".java")) {

						message += line;
					}

					// For each commit we may have many number of files
					// committed. Therefore creating a object for each entry and
					// persisting in database.

					while (line != null && line.startsWith("templates")
							&& line.endsWith(".java")) {

						String templateName = line
								.replaceAll(
										"templates/src/main/java/urjanet/pull/template/",
										"");

						persistCommitHistory(commitId, author, date, message,
								templateName);
						line = read.readLine();
					}
				}
			}
		} catch (Exception e) {
			Logger.error(e.getMessage());
		}

	}

	private void persistCommitHistory(final String commitId,
			final String author, final Date date, final String message,
			final String templateName) {
		JPA.withTransaction(new play.libs.F.Callback0() {
			@Override
			public void invoke() throws Throwable {
				// EntityManager em =
				// JPA.em().getEntityManagerFactory().createEntityManager();
				Template template = null;
				Logger.info("Searching for template table by name :"
						+ templateName);
				List<Template> templateList = JPA
						.em()
						.createQuery(
								"from Template as t where t.templateName='"
										+ templateName + "'").getResultList();
				if (templateList != null && templateList.size() > 0) {
					Logger.info("Searching for template table by name :"
						+ templateName+". Found a result");
					
					template = templateList.get(0);
				} else {
					template = new Template();
					Logger.info("Template " + templateName
							+ " not found in table. Persisting...");
					template.setTemplateName(templateName);
					template.setTemplateAuthor(author);
					JPA.em().persist(template);

				}
				List<TemplateCommitHistory> templateCommitHistoryList = JPA
						.em()
						.createQuery(
								"from TemplateCommitHistory as t where t.templateCommitHistoryPK.template.templateId='"
										+ template.getTemplateId()
										+ "' and t.templateCommitHistoryPK.commitId='"
										+ commitId + "'").getResultList();
				if (templateCommitHistoryList != null
						&& templateCommitHistoryList.size() > 0) {
					Logger.info("Commit ID : " + commitId + "Template ID: "
							+ template.getTemplateId() + " already exists.Skipping");
				} else {
					Logger.info("Commit ID : " + commitId + "Template ID: "
							+ template.getTemplateId() + " does not  exist. Persisting");
					final TemplateCommitHistoryPK tpk = new TemplateCommitHistoryPK();
					tpk.setCommitId(commitId);
					tpk.setTemplate(template);

					TemplateCommitHistory tch = new TemplateCommitHistory();
					tch.setTemplateCommitHistoryPK(tpk);
					tch.setCommitAuthor(author);
					tch.setCommitDate(date);
					tch.setCommitSummary(message);
					
					JPA.em().persist(tch);
					Logger.info("Commit ID : " + commitId + "Template ID: "
							+ template.getTemplateId()
							+ "does not exist. Persistedthe entry");

				}
			}
		});
	}

	private Date getCommitDate(String line) throws ParseException {
		String commitDate;
		commitDate = line.substring(line.lastIndexOf("AuthorDate:") + 11);
		commitDate = commitDate.trim();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"EEE MMM dd HH:mm:ss yyyy ZZZ");
		Date date = dateFormat.parse(commitDate);
		return date;
	}

	private String getAuthor(String line) {
		String author;
		author = line.substring(line.lastIndexOf("Author:") + 9);
		String authorMailId = author.substring(author.lastIndexOf("<") + 1);
		authorMailId = authorMailId.replaceAll(">", "");
		authorMailId = authorMailId.trim();
		return authorMailId;
	}

	public void updateMaster() {
		Logger.info("Updating repo to point to master ");
		File projectBasePath = new File(projectPath);

		runShell("git checkout master", projectBasePath);
		runShell("git fetch --all", projectBasePath);
		runShell("git reset --hard origin/master", projectBasePath);

	}

	public void getGitStats(final String fromDate, final String toDate) {
		JPA.withTransaction(new play.libs.F.Callback0() {
			@Override
			public void invoke() throws Throwable {
				Date lastUpdatedDate = new Date();
				Calendar cal = Calendar.getInstance();
				String fromDate1;
				if (fromDate.equals("")) {

					lastUpdatedDate = (Date) JPA
							.em()
							.createNativeQuery(
									"select max(commitDate) from TemplateCommitHistory")
							.getResultList().get(0);

					if (lastUpdatedDate == null) {
						cal.add(Calendar.DATE, -1);
						lastUpdatedDate = cal.getTime();
					}

					SimpleDateFormat dateFormat = new SimpleDateFormat(
							"yyyy-MM-dd");
					fromDate1 = dateFormat.format(lastUpdatedDate);
				} else {
					fromDate1 = fromDate;
				}

				Logger.info("Obtaining git commits from: " + fromDate1
						+ " to: " + toDate);
				/*
				 * Sample Log Structure: 12:42 $ git log --pretty=fuller
				 * --no-merges --name-only --since='2016-07-19' --reverse commit
				 * 6719d4d57b68c35990b9e9a4dda4667c8fdd6e42 Author:
				 * backyalakshmi <backyalakshmi.a@urjanet.com> AuthorDate: Tue
				 * Jul 19 14:48:12 2016 +0530 Commit: backyalakshmi
				 * <backyalakshmi.a@urjanet.com> CommitDate: Tue Jul 19 14:48:12
				 * 2016 +0530
				 * 
				 * EXT-108794 | Ecova | CoservTemlpateProvider
				 * 
				 * templates/src/main/java/urjanet/pull/template/
				 * CoservTemlpateProvider.java
				 * 
				 * commit 758478510de51cc0b617f48d8f35bb0665857bef Author:
				 * backyalakshmi <backyalakshmi.a@urjanet.com> AuthorDate: Tue
				 * Jul 19 15:04:12 2016 +0530 Commit: backyalakshmi
				 * <backyalakshmi.a@urjanet.com> CommitDate: Tue Jul 19 15:04:12
				 * 2016 +0530
				 * 
				 * EXT-108708 Delmarva Power usage delivery
				 * 
				 * templates/src/main/java/urjanet/pull/template/
				 * DelmarvaPowerTemplateProvider.java
				 */

				runShell(
						"git log --pretty=fuller --no-merges --name-only --reverse --since='"
								+ fromDate1 + "' --until='" + toDate + "'",
						new File(projectPath), true);
			}
		});
	}

	@Override
	public void run() {

		updateMaster();
		getGitStats("", "");

	}

}
