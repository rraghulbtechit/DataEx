package urjanet.devPortal.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;

import play.Logger;
import urjanet.devPortal.domain.Template;
import urjanet.devPortal.domain.TemplatePerformanceIndicator;
import urjanet.devPortal.domain.TemplateProperties;

public class TemplatePDFMatcher {
	
	public  List<TemplatePerformanceIndicator> findMatch(EntityManager em,HashMap<String, ArrayList<TemplateProperties>> template, String wholePdf,File inputFile, String threshold) {
		
		List<TemplatePerformanceIndicator> templateStringKeyMatchList = new ArrayList< TemplatePerformanceIndicator>();
		
		String templateName = "";
		Logger.info("In Checker: Checking");
		try {
			ArrayList<Template> list = (ArrayList<Template>) em.createQuery( "from Template" ).getResultList();
			Logger.info("In Checker: Checking() List returned: " +String.valueOf(list.size()));
			for (Template tid : list) {
				Integer matchCount = 0;
				String temp = "";
				templateName = tid.getTemplateName();
				List<TemplateProperties> propertyListForTemplate = tid.getTemplateProperties();
				int numberofkeys = propertyListForTemplate.size();
				
				Iterator<TemplateProperties> iterateTemplatePropertyList = propertyListForTemplate.iterator();
				
				while (iterateTemplatePropertyList.hasNext()) {
					temp = iterateTemplatePropertyList.next().getFilterString();

					if (wholePdf.contains( temp )) {
						matchCount++;
					}
				}
				
				if (matchCount != 0 && matchCount > 15) {
//					Logger.info( "count:"+count+"  numberofkeys: "+numberofkeys );
					int percentage = ((matchCount * 100) / numberofkeys);
					Logger.info( templateName +" has a  count of "+ matchCount );
					
					templateStringKeyMatchList.add(  new TemplatePerformanceIndicator(templateName, percentage, matchCount) );
					
				}
			}
			
		} catch (Exception e) {
			Logger.error(e.getMessage());
		}
		return templateStringKeyMatchList;

	}

}
