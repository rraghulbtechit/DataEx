/**
 * 
 */
package urjanet.devPortal.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 * @author balaji_rajaram
 *
 */

@Entity
@Table(name = "Template")
public class Template {
	
	 @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(unique = true, nullable = false)
	 Integer templateId;
	 
	 @Column( unique = true, nullable = false)
	 String templateName;
	 @Column
	 private String templateAuditOwner;
	 @Column
	 private String templateOwner;
	 @Column
	 private String templateAuthor;
	 @Column
	 private String templateAuthor1;
	 @Column
	 private String templateAuthor2;
	 @Column
	 private String templateAuthor3;
	 @Column
	 private String sourceType;
	 @Column
	 private String serviceType;
	 @Column (columnDefinition="BIT DEFAULT 0")
	 private boolean isStatementTrackingImplemented;

	 @Column (columnDefinition="BIT DEFAULT 0")
	 private boolean isAcctTrackingImplemented;

	 @Column (columnDefinition="BIT DEFAULT 0")
	 private boolean isTrackedBadLoginImplemented;

	 @Column (columnDefinition="BIT DEFAULT 0")
	 private boolean isHistoricalTemplateImplemented;

	 public boolean isHistoricalTemplateImplemented() {
		return isHistoricalTemplateImplemented;
	}

	public void setHistoricalTemplateImplemented(
			boolean isHistoricalTemplateImplemented) {
		this.isHistoricalTemplateImplemented = isHistoricalTemplateImplemented;
	}
	@Column (columnDefinition="BIT DEFAULT 0")
	 private boolean isToughTemplate;


	 public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	 @OneToMany(targetEntity = TemplateProperties.class, mappedBy = "tempId")
	 private List<TemplateProperties> templateProperties;
	 
	 
	 @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
		@JoinTable(name = "TemplateCountry", catalog = "urja_dev_portal", joinColumns = { 
				@JoinColumn(name = "templateId", nullable = false, updatable = false) }, 
				inverseJoinColumns = { @JoinColumn(name = "countryId", 
						nullable = false, updatable = false) })
	 private Set<Country> countries = new HashSet<Country>(0);

	
	public Set<Country> getCountries() {
		return countries;
	}
	
	public void setCountries(Set<Country> countries) {
		this.countries = countries;
	}

	 
	 @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
		@JoinTable(name = "TemplateWebAddress", catalog = "urja_dev_portal", joinColumns = { 
				@JoinColumn(name = "templateId", nullable = false, updatable = false) }, 
				inverseJoinColumns = { @JoinColumn(name = "webAddressId", 
						nullable = false, updatable = false) })
	 private Set<WebAddress> webAddresses = new HashSet<WebAddress>(0);

	
	public Set<WebAddress> getWebAddresses() {
		return webAddresses;
	}

	public void setWebAddresses(Set<WebAddress> webAddresses) {
		this.webAddresses = webAddresses;
	}
	
	public String getTemplateOwner() {
		return templateOwner;
	}

	
	public void setTemplateOwner(String templateOwner) {
		this.templateOwner = templateOwner;
	}

	
	public List<TemplateProperties> getTemplateProperties() {
		return templateProperties;
	}

	
	public void setTemplateProperties(List<TemplateProperties> templateProperties) {
		this.templateProperties = templateProperties;
	}


	    public boolean equals(Object object) {
	        if (object == this)
	            return true;
	        if ((object == null) || !(object instanceof Template))
	            return false;
	 
	        final Template a = (Template)object;
	 
	        if (templateId != null && a.getTemplateId() != null) {
	            return templateId.equals(a.getTemplateId());
	        }
	        return false;
	    }

		public Integer getTemplateId() {
			return templateId;
		}

		public void setTemplateId(Integer templateId) {
			this.templateId = templateId;
		}

		public String getTemplateName() {
			return templateName;
		}

		public void setTemplateName(String templateName) {
			this.templateName = templateName;
		}

		public String getTemplateAuditOwner() {
			return templateAuditOwner;
		}

		public void setTemplateAuditOwner(String templateAuditOwner) {
			this.templateAuditOwner = templateAuditOwner;
		}

		public String getTemplateAuthor() {
			return templateAuthor;
		}

		public void setTemplateAuthor(String templateAuthor) {
			this.templateAuthor = templateAuthor;
		}

		public String getTemplateAuthor1() {
			return templateAuthor1;
		}

		public void setTemplateAuthor1(String templateAuthor1) {
			this.templateAuthor1 = templateAuthor1;
		}

		public String getTemplateAuthor2() {
			return templateAuthor2;
		}

		public void setTemplateAuthor2(String templateAuthor2) {
			this.templateAuthor2 = templateAuthor2;
		}

		public String getTemplateAuthor3() {
			return templateAuthor3;
		}

		public void setTemplateAuthor3(String templateAuthor3) {
			this.templateAuthor3 = templateAuthor3;
		}

		@Override
		public String toString() {
			return "Template [templateId=" + templateId + ", templateName="
					+ templateName + ", templateAuditOwner="
					+ templateAuditOwner + ", templateOwner=" + templateOwner
					+ ", templateAuthor=" + templateAuthor
					+ ", templateAuthor1=" + templateAuthor1
					+ ", templateAuthor2=" + templateAuthor2
					+ ", templateAuthor3=" + templateAuthor3
					+ ", templateProperties=" + templateProperties
					+ ", countries=" + countries + 
					", webAddresses="+ webAddresses+ "]";
		}

		public boolean isStatementTrackingImplemented() {
			return isStatementTrackingImplemented;
		}

		public void setStatementTrackingImplemented(
				boolean isStatementTrackingImplemented) {
			this.isStatementTrackingImplemented = isStatementTrackingImplemented;
		}

		public boolean isAcctTrackingImplemented() {
			return isAcctTrackingImplemented;
		}

		public void setAcctTrackingImplemented(boolean isAcctTrackingImplemented) {
			this.isAcctTrackingImplemented = isAcctTrackingImplemented;
		}

		public boolean isTrackedBadLoginImplemented() {
			return isTrackedBadLoginImplemented;
		}

		public void setTrackedBadLoginImplemented(boolean isTrackedBadLoginImplemented) {
			this.isTrackedBadLoginImplemented = isTrackedBadLoginImplemented;
		}

		public boolean isToughTemplate() {
			return isToughTemplate;
		}

		public void setToughTemplate(boolean isToughTemplate) {
			this.isToughTemplate = isToughTemplate;
		}
	 

}
