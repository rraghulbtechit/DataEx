package urjanet.devPortal.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable

public class TemplateCommitHistoryPK implements Serializable{
	
	protected String commitId;
	 @ManyToOne
		@JoinColumn(name = "templateId")
	protected Template template;
	 
	public TemplateCommitHistoryPK(){ 
		
	}
	
	public TemplateCommitHistoryPK(String commitId, Template template, int templateCommitHistoryId){
		this.commitId=commitId;
		this.template=template;
	}
	
	public String getCommitId() {
		return commitId;
	}

	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	@Override
	public int hashCode() {
		//To generate hashcode, taking a random number.
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((template == null) ? 0 : template.hashCode());
		result = prime * result + commitId.hashCode();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TemplateCommitHistoryPK other = (TemplateCommitHistoryPK) obj;
		if (template == null) {
			if (other.template != null)
				return false;
		} else if (!template.equals(other.template))
			return false;
		if (!commitId.equals(other.commitId))
			return false;
		return true;
	}
	

}
