package urjanet.devPortal.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class EngineerGroup {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(unique = true, nullable = false)
		private Integer EngineerGroupId;

		@Column
		private String EngineerGroupName;

		@OneToMany(mappedBy="EngineerGroupId")
		private List<ServiceLevelAgreement> slaInfo;

		public Integer getEngineerGroupId() {
			return EngineerGroupId;
		}

		public void setEngineerGroupId(Integer engineerGroupId) {
			EngineerGroupId = engineerGroupId;
		}

		public String getEngineerGroupName() {
			return EngineerGroupName;
		}

		public void setEngineerGroupName(String engineerGroupName) {
			EngineerGroupName = engineerGroupName;
		}	
		
}
