/**
 * 
 */
package urjanet.devPortal.domain;

/**
 * @author balaji_rajaram
 *
 */
public class TemplateUpdateProgess {
	
	static int total;
	
	static int progress;
	
	static String templateName = "";
	
	static double percentage;

	public static double getPercentage() {
		
		return percentage;
	}

	public static void setPercentage(double percentage) {
		
		TemplateUpdateProgess.percentage = percentage;
	}

	public static int getTotal() {
		
		return total;
	}

	public static void setTotal(int total) {
		
		TemplateUpdateProgess.total = total;
	}

	public static int getProgress() {
		
		return progress;
	}

	public static void setProgress(int progress) {
		
		TemplateUpdateProgess.progress = progress;
	}

	public static String getTemplateName() {
		
		return templateName;
	}

	public static void setTemplateName(String templateName) {
		
		TemplateUpdateProgess.templateName = templateName;
	}

	
}
