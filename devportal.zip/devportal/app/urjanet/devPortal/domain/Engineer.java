package urjanet.devPortal.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Engineer {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(unique = true, nullable = false)
		private Integer EId;

		@Column
		private String Name;

		@OneToMany(mappedBy="EId")
		private List<Slainfo> slainfo ;

		

		public Integer getEId() {
			return EId;
		}

		public void setEId(Integer eId) {
			EId = eId;
		}

		public String getName() {
			return Name;
		}

		public void setName(String name) {
			Name = name;
		}

	
		
		
}
