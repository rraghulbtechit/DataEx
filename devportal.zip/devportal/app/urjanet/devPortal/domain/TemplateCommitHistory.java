package urjanet.devPortal.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "TemplateCommitHistory")
public class TemplateCommitHistory {
	 @EmbeddedId
	    private TemplateCommitHistoryPK templateCommitHistoryPK;

	 @Column
	private Date  commitDate;
	 @Column
	private String commitAuthor;
	 
	 @Column
	 @Type(type="text")
	private String commitSummary;

	public Date getCommitDate() {
		return commitDate;
	}

	public void setCommitDate(Date commitDate) {
		this.commitDate = commitDate;
	}

	public String getCommitAuthor() {
		return commitAuthor;
	}

	public void setCommitAuthor(String commitAuthor) {
		this.commitAuthor = commitAuthor;
	}

	public String getCommitSummary() {
		return commitSummary;
	}

	public void setCommitSummary(String commitSummary) {
		this.commitSummary = commitSummary;
	}
	
	 public TemplateCommitHistoryPK getTemplateCommitHistoryPK() {
		return templateCommitHistoryPK;
	}

	public void setTemplateCommitHistoryPK(
			TemplateCommitHistoryPK templateCommitHistoryPK) {
		this.templateCommitHistoryPK = templateCommitHistoryPK;
	}
	 
}
