package urjanet.devPortal.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class  ServiceLevelAgreement {
	

	@Id
	int id;
	int slaDays;
	
	public int getSlaDays() {
		return slaDays;
	}

	public void setSlaDays(int slaDays) {
		this.slaDays = slaDays;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@ManyToOne
	@JoinColumn(name = "catalystId")
	Catalyst catalystId;
	
	@ManyToOne
	@JoinColumn(name = "customerId")
	Customer customerId;
	
	@ManyToOne
	@JoinColumn(name ="EngineerGroupId")
	EngineerGroup EngineerGroupId;

	public EngineerGroup getEngineerGroupId() {
		return EngineerGroupId;
	}

	public void setEngineerGroupId(EngineerGroup engineerGroupId) {
		EngineerGroupId = engineerGroupId;
	}

	public Catalyst getCatalystId() {
		return catalystId;
	}

	public void setCatalystId(Catalyst catalystId) {
		this.catalystId = catalystId;
	}

	public Customer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}

}
