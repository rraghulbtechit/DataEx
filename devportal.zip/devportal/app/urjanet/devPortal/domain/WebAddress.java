package urjanet.devPortal.domain;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


import play.mvc.Controller;
@Entity
@Table(name = "WebAddress")
public class WebAddress implements java.io.Serializable   {

		/**
	 * 
	 */
	private static final long serialVersionUID = 8039269517825403014L;

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(unique = true, nullable = false)
		private Integer webAddressId;
		
		@Column(unique = true, nullable = false)
		private String webAddress;
			

	
		
		public boolean equals(Object object) {
	        if (object == this)
	            return true;
	        if ((object == null) || !(object instanceof WebAddress))
	            return false;
	 
	        final WebAddress b = (WebAddress)object;
	 
	        if (webAddressId != null && b.getWebAddressId() != null) {
	            return webAddressId.equals(b.getWebAddressId());
	        }
	        return false;
	    }




		public Integer getWebAddressId() {
			return webAddressId;
		}




		public void setWebAddressId(Integer webAddressId) {
			this.webAddressId = webAddressId;
		}




		public String getWebAddress() {
			return webAddress;
		}




		public void setWebAddress(String webAddress) {
			this.webAddress = webAddress;
		}
		
	}

