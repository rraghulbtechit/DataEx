package urjanet.devPortal.domain;

import java.util.List;

public class TemplateUrlMatchResult {
private String ticketId;
private String urlInTicket;
private int matchSize;
private List<Template> templatesMatched;

public String getTicketId() {
	return ticketId;
}
public void setTicketId(String ticketId) {
	this.ticketId = ticketId;
}
public String getUrlInTicket() {
	return urlInTicket;
}
public void setUrlInTicket(String urlInTicket) {
	this.urlInTicket = urlInTicket;
}
public int getMatchSize() {
	return matchSize;
}
public void setMatchSize(int matchSize) {
	this.matchSize = matchSize;
}
public List<Template> getTemplatesMatched() {
	return templatesMatched;
}
public void setTemplatesMatched(List<Template> templatesMatched) {
	this.templatesMatched = templatesMatched;
}
}
