package urjanet.devPortal.domain;

public class TemplatePerformanceIndicator implements Comparable<TemplatePerformanceIndicator>{
	
	private String templateName;
	
	private Integer percentage;
	
	private Integer matchPoints;
	
	public TemplatePerformanceIndicator(String templateName,Integer percentage, Integer datapoints) {
		super();
		this.templateName = templateName;
		this.percentage = percentage;
		this.matchPoints = datapoints;
	}

	public Integer getPercentage() {
		return percentage;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public Integer getMatchPoints() {
		return matchPoints;
	}

	public void setMatchPoints(Integer matchPoints) {
		this.matchPoints = matchPoints;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	@Override
	public int compareTo(TemplatePerformanceIndicator o) {
		
		int dp= o.getMatchPoints()-this.getMatchPoints();
		int percent = o.getPercentage()-this.getPercentage();
		
		return dp+percent;
		
	}
	
	public String toString() { 
		
	    return this.templateName+"-"+this.matchPoints+"-"+this.percentage+"\n";
	} 

}
