//package urjanet.devPortal.domain;
//
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import play.mvc.Controller;
//
//@Entity
//@Table(name = "country_enum")
//public class CountryEnum   implements java.io.Serializable   {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "country_id", unique = true, nullable = false)
//	private Integer countryId;
//	
//	@Column(name="country_name",unique=true)
//	private String countryName;
//	
//	@Column(name = "country_code", unique = true, length = 100)
//	private String countryCode;
//
//	public Integer getCountryId() {
//		return countryId;
//	}
//	
//	public void setCountryId(Integer countryId) {
//		this.countryId = countryId;
//	}
//	
//	public String getCountryName() {
//		return countryName;
//	}
//	
//	public void setCountryName(String countryName) {
//		this.countryName = countryName;
//	}
//	
//	public String getCountryCode() {
//		return countryCode;
//	}
//	
//	public void setCountryCode(String countryCode) {
//		this.countryCode = countryCode;
//	}
//	
//	
//	
//}
