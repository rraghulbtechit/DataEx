package urjanet.devPortal.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class TemplateProperties {

	@Id
	int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	String domainKey;
	String filterString;
	String filter;

	@ManyToOne
	@JoinColumn(name = "templateId")
	Template tempId;

	public String getDomainKey() {
		return domainKey;
	}

	public void setDomainKey(String domainKey) {
		this.domainKey = domainKey;
	}

	public String getFilterString() {
		return filterString;
	}

	public void setFilterString(String filterString) {
		this.filterString = filterString;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public Template getTempId() {
		return tempId;
	}

	public void setTempId(Template tempId) {
		this.tempId = tempId;
	}

	public String toString() {

		return "Domain Key " + domainKey + "  FilterString Key  " + filterString + "  Filter Key  " + filter;
	}

}
